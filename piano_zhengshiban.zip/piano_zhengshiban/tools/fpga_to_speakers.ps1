[CmdletBinding()]
param(
    [string]$COMPort = '',
    [ValidateRange(1, 4000000)]
    [int]$BaudRate = 115200,
    [ValidateRange(-1, 65535)]
    [int]$MidiDeviceId = -1,
    [ValidateRange(0, 127)]
    [int]$Program = 0,
    [ValidateRange(1.0, 4.0)]
    [double]$VelocityGain = 1.25,
    [ValidateRange(0, 127)]
    [int]$ChannelVolume = 127,
    [ValidateRange(0, 86400)]
    [int]$DurationSeconds = 0,
    [switch]$ListDevices,
    [switch]$TestSound,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$serialPort = $null
$midiOutput = $null

function Get-ConnectedCh340 {
    param([string[]]$Ports)
    $devices = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Enum\USB' -ErrorAction SilentlyContinue |
        Where-Object { $_.PSChildName -match '^VID_1A86' }
    foreach ($device in $devices) {
        foreach ($instance in (Get-ChildItem -LiteralPath $device.PSPath -ErrorAction SilentlyContinue)) {
            $info = Get-ItemProperty -LiteralPath $instance.PSPath -ErrorAction SilentlyContinue
            $parameters = Get-ItemProperty -LiteralPath ($instance.PSPath + '\Device Parameters') -ErrorAction SilentlyContinue
            if ($parameters.PortName -and $Ports -contains $parameters.PortName) {
                [pscustomobject]@{ Port = $parameters.PortName; Description = $info.FriendlyName }
            }
        }
    }
}

try {
    if (-not ('FpgaMidiSpeakers.NativeMidi' -as [type])) {
        Add-Type -Path (Join-Path $PSScriptRoot 'FpgaMidiSpeakers.cs')
    }
    $ports = @([System.IO.Ports.SerialPort]::GetPortNames() | Sort-Object)
    $boardPorts = @(Get-ConnectedCh340 -Ports $ports)
    $devices = @([FpgaMidiSpeakers.NativeMidi]::GetDevices())

    Write-Host 'FPGA serial MIDI -> computer speakers' -ForegroundColor Cyan
    Write-Host ('Serial ports: {0}' -f ($ports -join ', '))
    foreach ($board in $boardPorts) {
        Write-Host ('  Board candidate: {0}  {1}' -f $board.Port, $board.Description)
    }
    Write-Host 'MIDI output devices:'
    foreach ($device in $devices) {
        Write-Host ('  [{0}] {1}' -f $device.Id, $device.Name)
    }
    if ($ListDevices) {
        return
    }

    if ($MidiDeviceId -lt 0) {
        $selectedDevice = $devices | Where-Object { $_.Name -match 'Microsoft.*GS.*Wavetable' } |
            Select-Object -First 1
        if ($null -eq $selectedDevice) {
            throw 'Microsoft GS Wavetable Synth was not found. Choose a synthesizer with -MidiDeviceId. A virtual MIDI port alone does not produce sound.'
        }
        $MidiDeviceId = $selectedDevice.Id
    }
    else {
        $selectedDevice = $devices | Where-Object { $_.Id -eq $MidiDeviceId } | Select-Object -First 1
        if ($null -eq $selectedDevice) {
            throw ('MIDI device {0} does not exist. Run with -ListDevices.' -f $MidiDeviceId)
        }
    }

    if (-not $TestSound) {
        if ([string]::IsNullOrWhiteSpace($COMPort)) {
            $candidatePorts = @($boardPorts | Select-Object -ExpandProperty Port -Unique)
            if ($candidatePorts.Count -eq 1) {
                $COMPort = $candidatePorts[0]
            }
            elseif ($candidatePorts.Count -eq 0 -and $ports.Count -eq 1) {
                $COMPort = $ports[0]
            }
            else {
                throw 'Cannot safely choose one board port. Specify -COMPort COM5 (or your actual port).'
            }
        }
        $COMPort = $COMPort.Trim().ToUpperInvariant()
        if ($ports -notcontains $COMPort) {
            throw ('{0} is not connected. Check the board USB cable and run -ListDevices.' -f $COMPort)
        }
        $serialPort = New-Object System.IO.Ports.SerialPort
        $serialPort.PortName = $COMPort
        $serialPort.BaudRate = $BaudRate
        $serialPort.DataBits = 8
        $serialPort.Parity = [System.IO.Ports.Parity]::None
        $serialPort.StopBits = [System.IO.Ports.StopBits]::Two
        $serialPort.Handshake = [System.IO.Ports.Handshake]::None
        $serialPort.DtrEnable = $false
        $serialPort.RtsEnable = $false
        $serialPort.ReadTimeout = 100
        $serialPort.Open()
        Write-Host ('Serial open: {0}, {1} baud, 8N2' -f $COMPort, $BaudRate) -ForegroundColor Green
    }

    $midiOutput = New-Object FpgaMidiSpeakers.MidiOutput -ArgumentList $MidiDeviceId
    $midiOutput.Initialize($Program, $ChannelVolume)
    Write-Host ('Synth: {0}; program={1} (0 = acoustic piano)' -f $selectedDevice.Name, $Program) -ForegroundColor Green
    Write-Host ('Channel volume: {0}/127; velocity gain: {1}x (zero/release preserved)' -f $ChannelVolume, $VelocityGain)
    if ($TestSound) {
        Write-Host 'Sound test: C4, MIDI note 60. No serial connection is opened.'
        $midiOutput.Send([FpgaMidiSpeakers.MidiDynamics]::ApplyVelocityGain([uint32]0x00503C90, $VelocityGain))
        Start-Sleep -Milliseconds 600
        $midiOutput.Send([uint32]0x00003C80)
        Start-Sleep -Milliseconds 400
        return
    }

    Write-Host 'Switch the FPGA to mode 2 (MIDI), then press/release the music keys.'
    Write-Host 'No transposition: note 60=C4, 69=A4. Press Q or Ctrl+C to stop; Space stops all notes.'
    Write-Host 'If no sound: close other serial tools, check Windows speaker volume/output, then try -TestSound.'
    $parser = New-Object FpgaMidiSpeakers.MidiParser
    $readBuffer = New-Object byte[] 4096
    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $messageCount = 0
    $receivedBytes = 0
    $canReadKeyboard = -not [Console]::IsInputRedirected
    while ($DurationSeconds -eq 0 -or $timer.Elapsed.TotalSeconds -lt $DurationSeconds) {
        if ($canReadKeyboard) {
            try {
                if ([Console]::KeyAvailable) {
                    $key = [Console]::ReadKey($true)
                    if ($key.Key -eq [ConsoleKey]::Q) {
                        break
                    }
                    if ($key.Key -eq [ConsoleKey]::Spacebar) {
                        $midiOutput.Panic()
                        Write-Host 'All notes stopped.'
                    }
                }
            }
            catch {
                $canReadKeyboard = $false
            }
        }
        $available = $serialPort.BytesToRead
        if ($available -gt 0) {
            $requested = [Math]::Min($available, $readBuffer.Length)
            try {
                $readCount = $serialPort.Read($readBuffer, 0, $requested)
            }
            catch [System.TimeoutException] {
                continue
            }
            $receivedBytes += $readCount
            foreach ($message in $parser.Feed($readBuffer, $readCount)) {
                $outputMessage = [FpgaMidiSpeakers.MidiDynamics]::ApplyVelocityGain($message, $VelocityGain)
                $midiOutput.Send($outputMessage)
                $messageCount++
                if (-not $Quiet) {
                    $description = [FpgaMidiSpeakers.MidiParser]::Describe($message)
                    if ($outputMessage -ne $message) {
                        $description += (' -> output velocity={0}' -f (($outputMessage -shr 16) -band 127))
                    }
                    Write-Host $description
                }
            }
        }
        else {
            Start-Sleep -Milliseconds 1
        }
    }
    Write-Host ('Stopped. Received {0} bytes; forwarded {1} MIDI messages.' -f $receivedBytes, $messageCount)
}
catch {
    Write-Host ('ERROR: {0}' -f $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Close serial monitors/old bridges and retry. For device names, use -ListDevices.'
    exit 1
}
finally {
    if ($null -ne $midiOutput) {
        $midiOutput.Dispose()
    }
    if ($null -ne $serialPort) {
        $serialPort.Dispose()
    }
}
