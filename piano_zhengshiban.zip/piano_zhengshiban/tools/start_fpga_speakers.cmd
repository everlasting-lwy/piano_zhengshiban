@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0fpga_to_speakers.ps1" %*
set "bridge_exit=%ERRORLEVEL%"
echo.
pause
exit /b %bridge_exit%
