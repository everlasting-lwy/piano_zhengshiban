#!/usr/bin/env python3
"""PianoLink FAT32 P18 converter. Uses ordinary files; never formats or opens raw disks.

from-csv input.csv P0000000.P18 --title NAME
to-csv P0000000.P18 output.csv [--step-ms 500]
validate P0000000.P18

CSV export assigns synthetic 500 ms steps: P18 stores targets, not performance timing.
"""
import argparse
import binascii
import csv
import io
import os
from pathlib import Path
import re
import struct
import sys
import tempfile

PORT = (0, 7, 1, 8, 2, 3, 9, 4, 10, 5, 11, 6, 12, 13, 14, 15, 16, 17)
LEGACY = (12, 14, 16, 17, 19, 21, 23, 13, 15, 18, 20, 22)
MAX_STEPS = 2048

def crc16(data):
    return binascii.crc_hqx(data, 0xffff)

def title_bytes(title):
    if '\0' in title:
        raise ValueError('title must not contain NUL')
    result = bytearray()
    for character in title:
        encoded = character.encode('utf-8')
        if len(result) + len(encoded) > 32:
            break
        result.extend(encoded)
    return bytes(result)

def valid_mask(mask):
    return 0 < mask <= 0x3ffff and mask.bit_count() <= 4

def encode(title, masks):
    if not 1 <= len(masks) <= MAX_STEPS or any(not valid_mask(mask) for mask in masks):
        raise ValueError('P18 requires 1..2048 steps, each containing 1..4 of the 18 physical keys')
    body = b''.join(mask.to_bytes(3, 'little') for mask in masks)
    title = title_bytes(title)
    header = bytearray(64)
    header[:8] = b'P18GUIDE'
    header[8:10] = bytes((1, len(title)))
    struct.pack_into('<HH', header, 10, len(masks), crc16(body))
    header[16:16+len(title)] = title
    struct.pack_into('<H', header, 62, crc16(header[:62]))
    return bytes(header) + body

def decode(data):
    if len(data) < 64 or len(data) > 6208 or data[:8] != b'P18GUIDE' or data[8] != 1:
        raise ValueError('invalid P18 header, version or file size')
    length = data[9]
    count, body_crc = struct.unpack_from('<HH', data, 10)
    if length > 32 or not 1 <= count <= MAX_STEPS or len(data) != 64 + count*3:
        raise ValueError('invalid title length, step count or exact file size')
    if any(data[14:16] + data[16+length:62]):
        raise ValueError('reserved bytes and title padding must be zero')
    if crc16(data[:62]) != struct.unpack_from('<H', data, 62)[0] or crc16(data[64:]) != body_crc:
        raise ValueError('P18 CRC mismatch')
    title = data[16:16+length].decode('utf-8', errors='strict')
    if '\0' in title:
        raise ValueError('title must not contain NUL')
    masks = [int.from_bytes(data[i:i+3], 'little') for i in range(64, len(data), 3)]
    if any(not valid_mask(mask) for mask in masks):
        raise ValueError('invalid physical mask: requires 1..4 notes within 18 bits')
    return title, masks

def adapt_csv(text):
    if len(text.encode('utf-8')) > 8*1024*1024:
        raise ValueError('CSV exceeds 8MB')
    rows = []
    header = None
    event_count = 0
    for line in text.lstrip('\ufeff').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if header is None:
            if line not in ('time_ms,mask,voices', 'time_ms,mask36,voices'):
                raise ValueError('expected time_ms,mask,voices or time_ms,mask36,voices')
            header = line
            continue
        columns = [part.strip() for part in line.split(',')]
        if len(columns) != 3 or any(not re.fullmatch(r'[0-9]+', part) for part in columns):
            raise ValueError('CSV rows require three non-negative decimal integers')
        time, mask, voices = map(int, columns)
        maximum = 4095 if header == 'time_ms,mask,voices' else (1 << 36)-1
        if time > 86400000 or mask > maximum or voices > 15 or (rows and time < rows[-1][0]):
            raise ValueError('CSV time, mask or voices out of range')
        event_count += 1
        if event_count > 100000:
            raise ValueError('CSV exceeds 100000 events')
        # Multiple snapshots at one timestamp have only one observable final state.
        if rows and time == rows[-1][0]:
            rows[-1] = (time, mask)
        else:
            rows.append((time, mask))
    if header is None or not rows:
        raise ValueError('CSV has no events')
    held = 0
    masks = []
    report = dict(folded=0, merged=0, dropped=0, simplified=0)
    for _, mask in rows:
        if header == 'time_ms,mask,voices':
            mask = sum(1 << key for bit, key in enumerate(LEGACY) if mask & (1 << bit))
        pressed = mask & ~held
        held = mask
        pitches = set()
        for key in range(36):
            if not pressed & (1 << key):
                continue
            adapted = key
            while adapted < 12:
                adapted += 12
            while adapted > 29:
                adapted -= 12
            report['folded'] += adapted != key
            report['merged'] += adapted in pitches
            pitches.add(adapted)
        if len(pitches) > 4:
            report['simplified'] += 1
            report['dropped'] += len(pitches)-4
            pitches = set(sorted(pitches)[-4:])
        if pitches:
            masks.append(sum(1 << PORT[key-12] for key in pitches))
        if len(masks) > MAX_STEPS:
            raise ValueError('score exceeds 2048 steps; crop the CSV first (never silently truncated)')
    if not masks:
        raise ValueError('CSV has no note onsets')
    return masks, report

def csv_from_masks(masks, step_ms=500):
    if step_ms < 2 or step_ms*len(masks) > 86400000:
        raise ValueError('step-ms must be >=2 and total duration <=24 hours')
    output = io.StringIO()
    output.write('# PianoLink v2; synthetic timing from P18 targets; incomplete=false\n')
    writer = csv.writer(output, lineterminator='\n')
    writer.writerow(('time_ms', 'mask36', 'voices'))
    for index, mask in enumerate(masks):
        absolute = sum(1 << (12+key) for key, port in enumerate(PORT) if mask & (1 << port))
        writer.writerow((index*step_ms, absolute, (1 << mask.bit_count())-1))
        writer.writerow((index*step_ms+step_ms//2, 0, 0))
    return output.getvalue()

def atomic_write(path, data):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.p18-', delete=False) as output:
            temporary = Path(output.name)
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest='command', required=True)
    source = commands.add_parser('from-csv', help='adapt CSV note onsets to physical 18-key P18')
    source.add_argument('input', type=Path); source.add_argument('output', type=Path)
    source.add_argument('--title', default=None)
    target = commands.add_parser('to-csv', help='export mask36 CSV with synthetic timing')
    target.add_argument('input', type=Path); target.add_argument('output', type=Path)
    target.add_argument('--step-ms', type=int, default=500)
    validate = commands.add_parser('validate', help='validate header/body CRC and every physical mask')
    validate.add_argument('input', type=Path)
    args = parser.parse_args(argv)
    try:
        if args.command == 'from-csv':
            if not re.fullmatch(r'P00000(?:0[0-9]|[12][0-9]|3[01])\.P18', args.output.name):
                raise ValueError('output filename must be P0000000.P18 .. P0000031.P18 (slot 0..31)')
            masks, report = adapt_csv(args.input.read_text(encoding='utf-8-sig'))
            data = encode(args.title if args.title is not None else args.input.stem, masks)
            atomic_write(args.output, data)
            print(f'OK steps={len(masks)} ' + ' '.join(f'{key}={value}' for key, value in report.items()))
            print('Octave folded to C4..F5; deduplicated; highest four onsets retained. P18 has no rhythm/duration.')
        else:
            if args.input.stat().st_size > 6208:
                raise ValueError('P18 exceeds 6208 bytes')
            title, masks = decode(args.input.read_bytes())
            if args.command == 'to-csv':
                atomic_write(args.output, csv_from_masks(masks, args.step_ms).encode('utf-8'))
            print(f'OK title={title!r} steps={len(masks)} bytes={64+3*len(masks)}')
        return 0
    except (ValueError, OSError, UnicodeError) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
