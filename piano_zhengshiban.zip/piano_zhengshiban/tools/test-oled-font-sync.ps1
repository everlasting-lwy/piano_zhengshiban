param(
    [string]$IcarusBin='',
    [switch]$Synthesize,
    [string]$GowinShell=''
)
$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if(!$IcarusBin){$IcarusBin=Join-Path $projectRoot 'tmp/iverilog/mingw64/bin'}
if(!$GowinShell){$GowinShell=[IO.Path]::GetFullPath((Join-Path $projectRoot '../../IDE/bin/gw_sh.exe'))}
$testOut=Join-Path $projectRoot 'tmp/oled_font_sync_probe'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$previousPath=$env:PATH
$env:PATH=$IcarusBin+';C:/mingw64/bin;'+$env:PATH
Push-Location $projectRoot
try {
    if(!(Test-Path -LiteralPath 'src/oled_font_sync.v')){throw 'RED: synchronous font implementation is missing'}
    & (Join-Path $IcarusBin 'iverilog.exe') -g2012 -s tb_oled_font_sync -o (Join-Path $testOut 'font.vvp') src/oled_font.v src/oled_font_sync.v sim/tb_oled_font_sync.v
    if($LASTEXITCODE -ne 0){throw 'Font equivalence test did not compile'}
    & (Join-Path $IcarusBin 'vvp.exe') (Join-Path $testOut 'font.vvp')
    if($LASTEXITCODE -ne 0){throw 'Font equivalence test failed'}
    if($Synthesize){
        New-Item -ItemType Directory -Force -Path (Join-Path $testOut 'rom') | Out-Null
        Copy-Item -LiteralPath 'rom/oled_font.hex' -Destination (Join-Path $testOut 'rom/oled_font.hex') -Force
        @'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE gowin-fpga-project>
<Project>
  <Template>FPGA</Template><Version>5</Version>
  <Device name="GW5A-25A" pn="GW5A-LV25UG324C2/I1">gw5a25a-008</Device>
  <FileList><File path="../../src/oled_font_sync.v" type="file.verilog" enable="1"/></FileList>
</Project>
'@ | Set-Content -LiteralPath (Join-Path $testOut 'font.gprj') -Encoding utf8
        @'
cd [file dirname [file normalize [info script]]]
open_project font.gprj
set_option -top_module oled_font_sync
set_option -output_base_name oled_font_sync
set_option -verilog_std v2001
set_option -global_freq 50
run syn
'@ | Set-Content -LiteralPath (Join-Path $testOut 'synthesize.tcl') -Encoding utf8
        $synthesisStarted=[DateTime]::UtcNow
        & $GowinShell (Join-Path $testOut 'synthesize.tcl') 2>&1 | Tee-Object -FilePath (Join-Path $testOut 'synthesis.log')
        if($LASTEXITCODE -ne 0){throw 'Independent font synthesis failed'}
        $resourcePath=Join-Path $testOut 'impl/gwsynthesis/oled_font_sync_syn_rsc.xml'
        $reportPath=Join-Path $testOut 'impl/gwsynthesis/oled_font_sync_syn.rpt.html'
        foreach($report in @($resourcePath,$reportPath)){
            if(!(Test-Path -LiteralPath $report) -or (Get-Item -LiteralPath $report).LastWriteTimeUtc -lt $synthesisStarted){throw "Missing or stale synthesis report: $report"}
        }
        [xml]$resources=Get-Content -LiteralPath $resourcePath -Raw
        if([int]$resources.Module.Bsram -ne 1){throw 'Font synthesis must use exactly one BSRAM'}
        $logic=[regex]::Match((Get-Content -LiteralPath $reportPath -Raw),'<td class="label">Logic</td>\s*<td>(\d+)\((\d+) LUT,\s*(\d+) ALU\)')
        if(!$logic.Success -or [int]$logic.Groups[1].Value -ne 0){throw 'Font synthesis must use zero LUT/ALU logic'}
        Write-Output 'PASS isolated Gowin synthesis: 1 BSRAM, 0 LUT/ALU logic'
        Write-Output ('Synthesis resources: '+$resourcePath)
    }
} finally {Pop-Location;$env:PATH=$previousPath}
