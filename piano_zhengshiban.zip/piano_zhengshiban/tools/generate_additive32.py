"""Generate periodic, preweighted SINGLE-harmonic tables, never recorded audio."""
import hashlib
import json
import math
from pathlib import Path

root = Path(__file__).resolve().parents[1]
directory = root / "rom/additive32"
directory.mkdir(parents=True, exist_ok=True)
entries = []
for group_name, group in (("body", range(1, 9)), ("strike", range(9, 33))):
    weights = [h ** -1.5 for h in group]
    amplitudes = [math.floor(32700 * weight / sum(weights)) for weight in weights]
    assert sum(amplitudes) <= 32700 and min(amplitudes) > 0
    for h, amplitude in zip(group, amplitudes):
        samples = [round(amplitude * math.sin(2 * math.pi * n / 1024))
                   for n in range(1024)]
        assert max(map(abs, samples)) <= amplitude
        target = directory / f"h{h:02d}.hex"
        target.write_bytes("".join(f"{value & 0xffff:04X}\n" for value in samples).encode("ascii"))
        entries.append(dict(harmonic=h, group=group_name, amplitude=amplitude,
                            file=target.name, sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
(directory / "manifest.json").write_text(json.dumps(
    dict(description="32 independent preweighted single-sine period tables",
         samplesPerTable=1024, bits=16, groupAbsoluteSumLimit=32700, entries=entries),
    indent=2) + "\n", encoding="utf-8")
print("Generated32 sine-component ROMs; each group integer amplitude sum <=32700")
