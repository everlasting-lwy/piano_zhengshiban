param([string]$IcarusBin='',[switch]$Synthesize,[string]$GowinShell='')
$ErrorActionPreference='Stop'
$projectRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if(!$IcarusBin){$IcarusBin=Join-Path $projectRoot 'tmp/iverilog/mingw64/bin'}
if(!$GowinShell){$GowinShell=[IO.Path]::GetFullPath((Join-Path $projectRoot '../../IDE/bin/gw_sh.exe'))}
$testOut=Join-Path $projectRoot 'tmp/oled_decimal_serial_probe'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$previousPath=$env:PATH
$env:PATH=$IcarusBin+';C:/mingw64/bin;'+$env:PATH
Push-Location $projectRoot
try {
    if(!(Test-Path -LiteralPath 'src/oled_decimal_serial.v')){throw 'RED: serial decimal implementation is missing'}
    & (Join-Path $IcarusBin 'iverilog.exe') -g2012 -s tb_oled_decimal_serial -o (Join-Path $testOut 'decimal.vvp') src/oled_decimal_serial.v sim/tb_oled_decimal_serial.v
    if($LASTEXITCODE -ne 0){throw 'Serial decimal test did not compile'}
    & (Join-Path $IcarusBin 'vvp.exe') (Join-Path $testOut 'decimal.vvp')
    if($LASTEXITCODE -ne 0){throw 'Serial decimal test failed'}
    if($Synthesize){
        # This function is copied exactly from oled_visual_panel's parallel decimal4.
        @'
module oled_decimal_parallel_probe(input wire [11:0] value0,value1,value2,
 output wire [15:0] bcd0,bcd1,bcd2);
 function [15:0] decimal4;
  input [11:0] value;
  integer bit_index,digit;
  reg [15:0] bcd;
  begin
   bcd=0;
   for(bit_index=11;bit_index>=0;bit_index=bit_index-1)begin
    for(digit=0;digit<4;digit=digit+1)
     if(bcd[digit*4+:4]>=5)bcd[digit*4+:4]=bcd[digit*4+:4]+4'd3;
    bcd={bcd[14:0],value[bit_index]};
   end
   decimal4=bcd;
  end
 endfunction
 assign bcd0=decimal4(value0);
 assign bcd1=decimal4(value1);
 assign bcd2=decimal4(value2);
endmodule
'@ | Set-Content -LiteralPath (Join-Path $testOut 'parallel.v') -Encoding ascii
        # Also measure the panel's actual slot range (1..32) and two displayed digits.
        @'
module oled_decimal_panel_parallel_probe(input wire [11:0] value0,value1,input wire [4:0] slot,
 output wire [15:0] bcd0,bcd1,output wire [7:0] slot_bcd);
 wire [15:0] full_slot;
 oled_decimal_parallel_probe u(.value0(value0),.value1(value1),.value2({7'd0,slot}+12'd1),
  .bcd0(bcd0),.bcd1(bcd1),.bcd2(full_slot));
 assign slot_bcd=full_slot[7:0];
endmodule
module oled_decimal_panel_serial_probe(input wire clk,rst_n,start,input wire [11:0] value0,value1,input wire [4:0] slot,
 output wire done,output wire [15:0] bcd0,bcd1,output wire [7:0] slot_bcd);
 wire [15:0] full_slot;
 oled_decimal_serial u(.clk(clk),.rst_n(rst_n),.start(start),.value0(value0),.value1(value1),.value2({7'd0,slot}+12'd1),
  .done(done),.bcd0(bcd0),.bcd1(bcd1),.bcd2(full_slot));
 assign slot_bcd=full_slot[7:0];
endmodule
'@ | Set-Content -LiteralPath (Join-Path $testOut 'panel_shape.v') -Encoding ascii
        $measurements=@{}
        foreach($kind in @('parallel','serial','panel_parallel','panel_serial')){
            $moduleName=if($kind -eq 'parallel'){'oled_decimal_parallel_probe'}elseif($kind -eq 'serial'){'oled_decimal_serial'}else{"oled_decimal_${kind}_probe"}
            @"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE gowin-fpga-project>
<Project><Template>FPGA</Template><Version>5</Version>
<Device name="GW5A-25A" pn="GW5A-LV25UG324C2/I1">gw5a25a-008</Device>
<FileList><File path="parallel.v" type="file.verilog" enable="1"/>
<File path="../../src/oled_decimal_serial.v" type="file.verilog" enable="1"/>
<File path="panel_shape.v" type="file.verilog" enable="1"/></FileList></Project>
"@ | Set-Content -LiteralPath (Join-Path $testOut "$kind.gprj") -Encoding utf8
            @"
cd [file dirname [file normalize [info script]]]
open_project $kind.gprj
set_option -top_module $moduleName
set_option -output_base_name $kind
set_option -verilog_std v2001
set_option -global_freq 50
run syn
"@ | Set-Content -LiteralPath (Join-Path $testOut "$kind.tcl") -Encoding utf8
            $synthesisStarted=[DateTime]::UtcNow
            & $GowinShell (Join-Path $testOut "$kind.tcl") 2>&1 | Tee-Object -FilePath (Join-Path $testOut "$kind.log")
            if($LASTEXITCODE -ne 0){throw "$kind decimal synthesis failed"}
            $reportPath=Join-Path $testOut "impl/gwsynthesis/${kind}_syn.rpt.html"
            if(!(Test-Path -LiteralPath $reportPath) -or (Get-Item -LiteralPath $reportPath).LastWriteTimeUtc -lt $synthesisStarted){throw "Missing/stale report: $reportPath"}
            $report=Get-Content -LiteralPath $reportPath -Raw
            $logic=[regex]::Match($report,'<td class="label">Logic</td>\s*<td>(\d+)\((\d+) LUT,\s*(\d+) ALU\)')
            $registers=[regex]::Match($report,'<td class="label">Register</td>\s*<td>(\d+) /')
            if(!$logic.Success -or !$registers.Success){throw "Unknown synthesis report format: $reportPath"}
            $measurements[$kind]=[pscustomobject]@{Logic=[int]$logic.Groups[1].Value;LUT=[int]$logic.Groups[2].Value;ALU=[int]$logic.Groups[3].Value;Registers=[int]$registers.Groups[1].Value}
        }
        $saved=$measurements.parallel.Logic-$measurements.serial.Logic
        $measurements | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $testOut 'resources.json') -Encoding utf8
        Write-Output ('Parallel: '+($measurements.parallel|ConvertTo-Json -Compress))
        Write-Output ('Serial: '+($measurements.serial|ConvertTo-Json -Compress))
        Write-Output ('Panel parallel: '+($measurements.panel_parallel|ConvertTo-Json -Compress))
        Write-Output ('Panel serial: '+($measurements.panel_serial|ConvertTo-Json -Compress))
        if($saved -le 0){throw 'Serial decimal did not reduce logic resources'}
        Write-Output "PASS independent Gowin comparison: saved $saved logic cells"
        Write-Output ('Panel-shaped comparison saved '+($measurements.panel_parallel.Logic-$measurements.panel_serial.Logic)+' logic cells (slot range/digit pruning included)')
    }
} finally {Pop-Location;$env:PATH=$previousPath}
