using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace FpgaMidiSpeakers
{
    public static class MidiDynamics
    {
        public static uint ApplyVelocityGain(uint message, double gain)
        {
            if (Double.IsNaN(gain) || gain < 1.0 || gain > 4.0)
                throw new ArgumentOutOfRangeException("gain");
            // Note On velocity zero means Note Off; never turn it into a sound.
            if ((message & 0xF0U) != 0x90U)
                return message;
            int velocity = (int)((message >> 16) & 0x7FU);
            if (velocity == 0)
                return message;
            int boosted = Math.Min(127, (int)Math.Round(velocity * gain,
                MidpointRounding.AwayFromZero));
            return (message & ~0x007F0000U) | ((uint)boosted << 16);
        }
    }

    public sealed class MidiDevice
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public static class NativeMidi
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct OutputCaps
        {
            public ushort Manufacturer;
            public ushort Product;
            public uint DriverVersion;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string Name;
            public ushort Technology;
            public ushort Voices;
            public ushort Notes;
            public ushort ChannelMask;
            public uint Support;
        }

        [DllImport("winmm.dll", ExactSpelling = true)]
        private static extern uint midiOutGetNumDevs();
        [DllImport("winmm.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
        private static extern uint midiOutGetDevCapsW(UIntPtr device, out OutputCaps caps, uint size);
        [DllImport("winmm.dll", ExactSpelling = true)]
        private static extern uint midiOutOpen(out IntPtr handle, uint device, UIntPtr callback, UIntPtr instance, uint flags);
        [DllImport("winmm.dll", ExactSpelling = true)]
        internal static extern uint midiOutClose(IntPtr handle);
        [DllImport("winmm.dll", ExactSpelling = true)]
        internal static extern uint midiOutReset(IntPtr handle);
        [DllImport("winmm.dll", ExactSpelling = true)]
        private static extern uint midiOutShortMsg(IntPtr handle, uint message);
        [DllImport("winmm.dll", ExactSpelling = true)]
        private static extern uint midiOutSetVolume(IntPtr handle, uint volume);
        [DllImport("winmm.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
        private static extern uint midiOutGetErrorTextW(uint result, StringBuilder text, uint size);

        public static MidiDevice[] GetDevices()
        {
            var devices = new List<MidiDevice>();
            uint count = midiOutGetNumDevs();
            for (uint deviceIndex = 0; deviceIndex < count; deviceIndex++)
            {
                OutputCaps caps;
                Check(midiOutGetDevCapsW(new UIntPtr(deviceIndex), out caps,
                    (uint)Marshal.SizeOf(typeof(OutputCaps))), "List MIDI devices");
                devices.Add(new MidiDevice { Id = (int)deviceIndex, Name = caps.Name });
            }
            return devices.ToArray();
        }

        internal static IntPtr Open(int deviceId)
        {
            IntPtr handle;
            Check(midiOutOpen(out handle, (uint)deviceId, UIntPtr.Zero, UIntPtr.Zero, 0), "Open MIDI output");
            return handle;
        }

        internal static void Send(IntPtr handle, uint message)
        {
            Check(midiOutShortMsg(handle, message), "Send MIDI message");
        }

        internal static void SetVolume(IntPtr handle)
        {
            uint result = midiOutSetVolume(handle, UInt32.MaxValue);
            if (result != 8)
                Check(result, "Set MIDI output volume");
        }

        private static void Check(uint result, string operation)
        {
            if (result == 0)
                return;
            var text = new StringBuilder(256);
            midiOutGetErrorTextW(result, text, (uint)text.Capacity);
            throw new InvalidOperationException(operation + " failed (" + result + "): " + text);
        }
    }

    public sealed class MidiOutput : IDisposable
    {
        private IntPtr handle;

        public MidiOutput(int deviceId)
        {
            handle = NativeMidi.Open(deviceId);
        }

        public void Initialize(int program, int channelVolume = 127)
        {
            if (program < 0 || program > 127)
                throw new ArgumentOutOfRangeException("program");
            if (channelVolume < 0 || channelVolume > 127)
                throw new ArgumentOutOfRangeException("channelVolume");
            NativeMidi.SetVolume(handle);
            Panic();
            Send(0x000079B0);
            Send(0x000000B0);
            Send(0x000020B0);
            Send(0x000007B0U | ((uint)channelVolume << 16));
            Send(0x007F0BB0);
            Send(0x004000E0);
            Send(0xC0U | ((uint)program << 8));
        }

        public void Send(uint message)
        {
            if (handle == IntPtr.Zero)
                throw new ObjectDisposedException("MidiOutput");
            NativeMidi.Send(handle, message);
        }

        public void Panic()
        {
            if (handle != IntPtr.Zero)
                NativeMidi.midiOutReset(handle);
        }

        public void Dispose()
        {
            if (handle == IntPtr.Zero)
                return;
            NativeMidi.midiOutReset(handle);
            NativeMidi.midiOutClose(handle);
            handle = IntPtr.Zero;
        }
    }

    public sealed class MidiParser
    {
        private int status;
        private int expected;
        private int collected;
        private int firstData;

        public uint[] Feed(byte[] bytes, int count)
        {
            if (bytes == null)
                throw new ArgumentNullException("bytes");
            if (count < 0 || count > bytes.Length)
                throw new ArgumentOutOfRangeException("count");
            var messages = new List<uint>();
            for (int byteIndex = 0; byteIndex < count; byteIndex++)
            {
                int value = bytes[byteIndex];
                if (value >= 0xF8)
                    continue;
                if (value >= 0x80)
                {
                    collected = 0;
                    if (value >= 0xF0)
                    {
                        status = 0;
                        expected = 0;
                    }
                    else
                    {
                        status = value;
                        int command = value & 0xF0;
                        expected = (command == 0xC0 || command == 0xD0) ? 1 : 2;
                    }
                    continue;
                }
                if (status == 0)
                    continue;
                if (collected == 0)
                {
                    firstData = value;
                    collected = 1;
                    if (expected == 2)
                        continue;
                    messages.Add((uint)(status | (firstData << 8)));
                }
                else
                {
                    messages.Add((uint)(status | (firstData << 8) | (value << 16)));
                }
                collected = 0;
            }
            return messages.ToArray();
        }

        public static string Describe(uint message)
        {
            int status = (int)(message & 0xFF);
            int command = status & 0xF0;
            int firstData = (int)((message >> 8) & 0x7F);
            int secondData = (int)((message >> 16) & 0x7F);
            if (command == 0x80 || command == 0x90)
            {
                string[] names = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
                string action = (command == 0x90 && secondData != 0) ? "ON " : "OFF";
                return String.Format("{0} ch={1} note={2} ({3}{4}) velocity={5}", action,
                    (status & 0x0F) + 1, firstData, names[firstData % 12], firstData / 12 - 1, secondData);
            }
            return String.Format("MIDI {0:X2} {1:X2} {2:X2}", status, firstData, secondData);
        }
    }
}
