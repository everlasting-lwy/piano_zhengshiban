@echo off
start "" "%~dp0PianoMonitor\PianoMonitor.exe"
