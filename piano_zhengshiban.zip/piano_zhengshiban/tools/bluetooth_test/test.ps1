$ErrorActionPreference = 'Stop'
$compiler = 'C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$out = Join-Path $PSScriptRoot 'bin'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$sources = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' | Select-Object -ExpandProperty FullName
& $compiler /nologo /warnaserror+ /target:exe /platform:x64 /main:PianoBluetoothTest.TestEntry "/out:$out/PianoBluetoothTests.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll $sources (Join-Path $PSScriptRoot '../FpgaMidiSpeakers.cs')
if ($LASTEXITCODE -ne 0) { throw 'PC test compilation failed' }
& "$out/PianoBluetoothTests.exe"
if ($LASTEXITCODE -ne 0) { throw 'PC self-test failed' }
