using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
namespace PianoBluetoothTest {
internal static class NativeBluetooth {
    public static readonly IntPtr Invalid=new IntPtr(-1);
    public static readonly Guid Spp=new Guid("00001101-0000-1000-8000-00805f9b34fb");
    [StructLayout(LayoutKind.Sequential,Pack=1)] internal struct BthAddress {public ushort Family;public ulong Address;public Guid Service;public uint Port;}
    [StructLayout(LayoutKind.Sequential)] internal struct SocketAddress {public IntPtr Address;public int Length;}
    [StructLayout(LayoutKind.Sequential)] internal struct CsAddress {public SocketAddress Local,Remote;public int SocketType,Protocol;}
    [StructLayout(LayoutKind.Sequential)] internal struct QuerySet {
        public uint Size;public IntPtr Name,ServiceClass,Version,Comment;public uint NameSpace;
        public IntPtr Provider,Context;public uint ProtocolCount;public IntPtr Protocols,Query;
        public uint AddressCount;public IntPtr Addresses;public uint Flags;public IntPtr Blob;
    }
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] internal struct RadioInfo {
        public uint Size;public ulong Address;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=248)] public string Name;
        public uint DeviceClass;public ushort Subversion,Manufacturer;
    }
    [DllImport("BluetoothAPIs.dll",SetLastError=true)] static extern IntPtr BluetoothFindFirstRadio(ref uint parameters,out IntPtr radio);
    [DllImport("BluetoothAPIs.dll",SetLastError=true)] static extern bool BluetoothFindRadioClose(IntPtr find);
    [DllImport("BluetoothAPIs.dll")] static extern uint BluetoothGetRadioInfo(IntPtr radio,ref RadioInfo info);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("ws2_32.dll")] internal static extern int WSAStartup(ushort version,IntPtr data);
    [DllImport("ws2_32.dll")] internal static extern int WSACleanup();
    [DllImport("ws2_32.dll")] internal static extern int WSAGetLastError();
    [DllImport("ws2_32.dll")] internal static extern IntPtr socket(int family,int type,int protocol);
    [DllImport("ws2_32.dll")] internal static extern int bind(IntPtr socket,ref BthAddress address,int size);
    [DllImport("ws2_32.dll")] internal static extern int getsockname(IntPtr socket,ref BthAddress address,ref int size);
    [DllImport("ws2_32.dll")] internal static extern int listen(IntPtr socket,int backlog);
    [DllImport("ws2_32.dll")] internal static extern IntPtr accept(IntPtr socket,ref BthAddress address,ref int size);
    [DllImport("ws2_32.dll")] internal static extern int closesocket(IntPtr socket);
    [DllImport("ws2_32.dll")] internal static extern int ioctlsocket(IntPtr socket,uint command,ref uint value);
    [DllImport("ws2_32.dll")] internal static extern int recv(IntPtr socket,byte[] buffer,int length,int flags);
    [DllImport("ws2_32.dll")] internal static extern int send(IntPtr socket,byte[] buffer,int length,int flags);
    [DllImport("ws2_32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)] internal static extern int WSASetServiceW(ref QuerySet query,int operation,uint flags);
    public static void AssertLayouts() {
        if(Marshal.SizeOf(typeof(BthAddress))!=30 || Marshal.OffsetOf(typeof(BthAddress),"Address").ToInt32()!=2 || Marshal.OffsetOf(typeof(BthAddress),"Port").ToInt32()!=26)throw new Exception("SOCKADDR_BTH ABI mismatch");
        if(Marshal.SizeOf(typeof(QuerySet))!=(IntPtr.Size==8?120:60)||Marshal.SizeOf(typeof(CsAddress))!=(IntPtr.Size==8?40:24)||Marshal.SizeOf(typeof(RadioInfo))!=520)throw new Exception("Windows Bluetooth ABI mismatch");
    }
    public static RadioInfo Probe() {
        AssertLayouts();uint size=4;IntPtr radio;IntPtr find=BluetoothFindFirstRadio(ref size,out radio);
        if(find==IntPtr.Zero)throw new InvalidOperationException("No usable Windows Bluetooth radio (error "+Marshal.GetLastWin32Error()+"). Turn on your existing adapter and retry; no settings were changed.");
        try {var info=new RadioInfo();info.Size=(uint)Marshal.SizeOf(typeof(RadioInfo));uint error=BluetoothGetRadioInfo(radio,ref info);if(error!=0)throw new Win32Exception((int)error,"BluetoothGetRadioInfo");return info;}
        finally {CloseHandle(radio);BluetoothFindRadioClose(find);}
    }
    public static string FormatAddress(ulong address) {string hex=address.ToString("X12");return String.Join(":",new[]{hex.Substring(0,2),hex.Substring(2,2),hex.Substring(4,2),hex.Substring(6,2),hex.Substring(8,2),hex.Substring(10,2)});}
    public static void Check(int result,string operation){if(result==-1)throw Error(operation);}
    public static Exception Error(string operation){int e=WSAGetLastError();return new Win32Exception(e,operation+" (Winsock "+e+")");}
    public static void Nonblocking(IntPtr socket){uint yes=1;Check(ioctlsocket(socket,0x8004667e,ref yes),"ioctlsocket FIONBIO");}
}
internal sealed class SppListener : IDisposable {
    public IntPtr Socket=NativeBluetooth.Invalid;public NativeBluetooth.BthAddress Address;
    NativeBluetooth.QuerySet query;IntPtr name,service,address,cs;bool registered,started;
    public SppListener(ulong local) {
        try {
            IntPtr data=Marshal.AllocHGlobal(512);try {int e=NativeBluetooth.WSAStartup(0x202,data);if(e!=0)throw new Win32Exception(e,"WSAStartup");started=true;}finally{Marshal.FreeHGlobal(data);}
            Socket=NativeBluetooth.socket(32,1,3);if(Socket==NativeBluetooth.Invalid)throw NativeBluetooth.Error("Bluetooth socket");
            Address=new NativeBluetooth.BthAddress{Family=32,Address=local,Port=UInt32.MaxValue};
            NativeBluetooth.Check(NativeBluetooth.bind(Socket,ref Address,30),"Bluetooth bind");int size=30;
            NativeBluetooth.Check(NativeBluetooth.getsockname(Socket,ref Address,ref size),"Bluetooth getsockname");
            NativeBluetooth.Nonblocking(Socket);NativeBluetooth.Check(NativeBluetooth.listen(Socket,1),"Bluetooth listen");
            name=Marshal.StringToHGlobalUni("PianoLink PC Test");service=Marshal.AllocHGlobal(16);Marshal.StructureToPtr(NativeBluetooth.Spp,service,false);
            address=Marshal.AllocHGlobal(30);Marshal.StructureToPtr(Address,address,false);
            var info=new NativeBluetooth.CsAddress{Local=new NativeBluetooth.SocketAddress{Address=address,Length=30},SocketType=1,Protocol=3};
            cs=Marshal.AllocHGlobal(Marshal.SizeOf(typeof(NativeBluetooth.CsAddress)));Marshal.StructureToPtr(info,cs,false);
            query=new NativeBluetooth.QuerySet{Size=(uint)Marshal.SizeOf(typeof(NativeBluetooth.QuerySet)),Name=name,ServiceClass=service,NameSpace=16,AddressCount=1,Addresses=cs};
            NativeBluetooth.Check(NativeBluetooth.WSASetServiceW(ref query,0,0),"Register SPP SDP service");registered=true;
        }catch{Dispose();throw;}
    }
    public void Dispose() {
        int deleteError=0;
        if(registered){if(NativeBluetooth.WSASetServiceW(ref query,2,0)==-1)deleteError=NativeBluetooth.WSAGetLastError();registered=false;}
        if(Socket!=NativeBluetooth.Invalid){NativeBluetooth.closesocket(Socket);Socket=NativeBluetooth.Invalid;}
        foreach(IntPtr p in new[]{cs,address,service,name})if(p!=IntPtr.Zero)Marshal.FreeHGlobal(p);
        cs=address=service=name=IntPtr.Zero;
        if(started){NativeBluetooth.WSACleanup();started=false;}
        if(deleteError!=0)throw new Win32Exception(deleteError,"Remove SPP SDP service failed; sockets closed");
    }
}
}
