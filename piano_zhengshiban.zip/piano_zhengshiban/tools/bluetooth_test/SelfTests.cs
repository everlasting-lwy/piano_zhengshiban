using System;
using System.Collections.Generic;
using System.Text;
namespace PianoBluetoothTest {
internal sealed class CaptureSink : INoteSink {
    public readonly List<string> Calls = new List<string>();
    public void NoteOn(int note) { Calls.Add("on:" + note); }
    public void NoteOff(int note) { Calls.Add("off:" + note); }
    public void Controls(int timbre, int volume) { Calls.Add("controls:" + timbre + ":" + volume); }
    public void Panic() { Calls.Add("panic"); }
}
internal static class SelfTests {
    static int count;
    static void Check(bool ok, string name) { if (!ok) throw new Exception("FAIL " + name); count++; }
    static bool Equal(byte[] a, byte[] b) { return BitConverter.ToString(a) == BitConverter.ToString(b); }
    static byte[] Request(int cmd, params int[] data) { int[] d = new int[6]; Array.Copy(data, d, data.Length); return Wire.Encode(17, cmd, d); }
    static byte[] Send(DeviceModel model, int cmd, long now, params int[] data) { return model.Accept(Wire.Decode(Request(cmd, data)), now); }
    static void Drain(DeviceModel model) { while (model.PollEvent() != null) {} }
    public static int Run() {
        try {
            Check(Wire.Crc(Encoding.ASCII.GetBytes("123456789"), 0, 9) == 0xf4, "CRC SMBUS check vector");
            Check(Equal(Request(6), new byte[] {165,90,17,6,0,0,0,0,0,0,232,13}), "frozen status request");
            var sink = new CaptureSink(); var model = new DeviceModel(sink);
            Check(Equal(Send(model, 6, 0), Wire.Encode(17,129,0,8,0,0,0,0)), "exact legacy status");
            Check(Equal(Send(model, 11, 0), Wire.Encode(17,131,0,0,0,0,0,32)), "exact capability status");
            Check(Equal(Send(model, 2, 0, 15), Wire.Encode(17,128,2,0,1,0,0,0)), "exact ACK");
            Send(model, 2, 0, 16); Check(model.Volume == 15, "out of range setter preserves state");
            Check(Wire.Decode(Send(model, 1, 0, 0,1)).Data[1] == 1, "reserved byte rejected");
            Check(Wire.Decode(Send(model, 99, 0)).Data[1] == 2, "unsupported ACK");
            var legacyVoices = new DeviceModel(new CaptureSink()); Send(legacyVoices,4,0,159);
            Check(Array.IndexOf(legacyVoices.SoundingNotes,61)>=0 && Array.IndexOf(legacyVoices.SoundingNotes,62)<0,"legacy allocator uses wire key order when stealing");
            int[] semitones = {0,2,4,5,7,9,11,1,3,6,8,10};
            for(int octave=0;octave<3;octave++) for(int key=0;key<12;key++) {
                Send(model,5,0); Send(model,3,0,octave); int bits=1<<key;
                Send(model,4,0,bits&255,bits>>8);
                int note=(octave==1?72:octave==2?48:60)+semitones[key];
                Check(model.Keys == (1UL << (note-48)), "legacy octave/key " + octave + "/" + key);
            }
            Send(model,5,0);
            for(int key=0;key<36;key++) {
                ulong mask=1UL<<key; Send(model,9,0,(int)mask&255,(int)(mask>>8)&255,(int)(mask>>16)&255,(int)(mask>>24)&255,(int)(mask>>32)&15);
                Check(model.Keys==mask && model.SoundingNotes[0]==48+key, "absolute pitch " + key);
                Check(sink.Calls[sink.Calls.Count-1]=="on:"+(48+key),"MIDI sink receives absolute pitch "+key);
            }
            Check(model.Extended, "extended mode selected");
            Check(Wire.Decode(Send(model,9,0,0,0,0,0,16)).Data[1]==1 && model.Keys==(1UL<<35), "extended reserved nibble rejected");
            Send(model,4,0,1); Check(!model.Extended && model.Keys==(1UL<<0), "legacy replaces absolute using selected lower octave");
            Send(model,9,100,31); Check(model.SoundingNotes.Length==4, "four shared voices");
            Check(model.Keys==31, "key state includes stolen note");
            Send(model,9,101,15); Check(model.SoundingNotes.Length==3, "stolen held key does not retrigger on release");
            Send(model,5,102); Check(model.Keys==0 && model.SoundingNotes.Length==0, "explicit release");
            Send(model,10,1000,1); model.Tick(2999); Check(model.Keys==1, "watchdog before boundary");
            Send(model,10,2999,1); model.Tick(4998); Check(model.Keys==1, "heartbeat refresh");
            model.Tick(4999); Check(model.Keys==0 && model.SoundingNotes.Length==0, "watchdog exact boundary releases sound");
            Check(sink.Calls[sink.Calls.Count-1]=="off:48","watchdog sends MIDI note off");
            Send(model,10,5000,1);int callsBefore=sink.Calls.Count; Send(model,10,5100,1);
            Check(sink.Calls.Count==callsBefore,"heartbeat same snapshot does not retrigger sound");
            Send(model,10,6000,1,0,0,0,16);model.Tick(7100);Check(model.Keys==0,"invalid heartbeat cannot postpone watchdog");
            Drain(model); Send(model,8,4999); Send(model,9,5000,1); byte[] ev=model.PollEvent();
            Check(Equal(ev,Wire.Encode(ev[2],132,1,0,0,0,16,32)), "exact extended event");
            Drain(model); Send(model,4,0x12345678,1); ev=model.PollEvent();
            Check(Equal(ev,Wire.Encode(ev[2],130,120,86,52,18,1,16)), "exact timestamp legacy event");
            Drain(model); for(int i=0;i<18;i++) Send(model,4,i,i%2); Check(model.Overflow,"event FIFO overflow");
            Send(model,8,1); Check(!model.Overflow,"clear overflow");
            var session = new EmulatorSession(new CaptureSink()); byte[] req=Request(9,1);
            Check(session.Feed(new byte[]{9,8,165},3,0).Count==0,"noise and partial frame");
            Check(session.Feed(req,5,1).Count==0,"fragment first half");
            byte[] rest=new byte[7]; Array.Copy(req,5,rest,0,7);
            List<byte[]> output=session.Feed(rest,7,2);
            Check(output.Count==2 && output[0][3]==128 && output[1][3]==132,"fragment completion reply before event");
            byte[] bad=Request(5); bad[10]^=1; Check(session.Feed(bad,12,3).Count==0 && session.CrcErrors==1 && session.Model.Keys==1,"invalid CRC has no execution");
            Check(session.Feed(Request(5),12,4).Count==2,"stream resynchronizes after CRC error");
            session.Feed(req,5,10); Check(session.Feed(rest,7,311).Count==0,"partial frame timeout");
            session.Feed(req,12,400); session.Disconnect(); Check(session.Model.Keys==0 && session.Model.SoundingNotes.Length==0,"disconnect panic");
            byte[] doubled=new byte[24];Array.Copy(Request(6),doubled,12);Array.Copy(Request(11),0,doubled,12,12);
            output=session.Feed(doubled,24,500);Check(output.Count==2&&output[0][3]==129&&output[1][3]==131,"coalesced requests decoded independently");
            NativeBluetooth.AssertLayouts(); Check(true,"native ABI packing");
            Console.WriteLine("PASS " + count + " PC Bluetooth emulator checks (no radio/audio opened)"); return 0;
        } catch(Exception e) { Console.Error.WriteLine(e.Message); return 1; }
    }
}
}


