using System;
using System.Collections.Generic;
namespace PianoBluetoothTest {
internal interface INoteSink { void NoteOn(int note); void NoteOff(int note); void Controls(int timbre,int volume); void Panic(); }
internal sealed class SilentSink : INoteSink {
    public void NoteOn(int note) {} public void NoteOff(int note) {} public void Controls(int timbre,int volume) {} public void Panic() {}
}
internal static class Wire {
    public static int Crc(byte[] b,int offset,int length) {
        int crc=0; for(int i=offset;i<offset+length;i++) { crc^=b[i]; for(int bit=0;bit<8;bit++) crc=((crc<<1)^((crc&128)!=0?7:0))&255; } return crc;
    }
    public static byte[] Encode(int seq,int cmd,params int[] data) {
        if(data.Length!=6) throw new ArgumentException("Six data bytes required");
        byte[] b=new byte[12]; b[0]=165;b[1]=90;b[2]=(byte)seq;b[3]=(byte)cmd;
        for(int i=0;i<6;i++) b[i+4]=(byte)data[i]; b[10]=(byte)Crc(b,2,8);b[11]=13;return b;
    }
    public static Frame Decode(byte[] b) {
        if(b==null||b.Length!=12||b[0]!=165||b[1]!=90||b[11]!=13||b[10]!=Crc(b,2,8))return null;
        int[] d=new int[6];for(int i=0;i<6;i++)d[i]=b[i+4]; return new Frame(b[2],b[3],d);
    }
}
internal sealed class Frame {
    public readonly int Sequence,Command; public readonly int[] Data;
    public Frame(int sequence,int command,int[] data) {Sequence=sequence;Command=command;Data=data;}
}
internal sealed class DeviceModel {
    static readonly int[] Semitones={0,2,4,5,7,9,11,1,3,6,8,10};
    readonly INoteSink sink; readonly Queue<byte[]> events=new Queue<byte[]>(); readonly int[] slots={-1,-1,-1,-1};
    int timbre,volume=8,octave,legacy,eventSequence,nextSlot; ulong keys; bool extended,overflow; long refreshed;
    public DeviceModel(INoteSink sink) {this.sink=sink; sink.Controls(timbre,volume);}
    public int Volume {get{return volume;}} public int Timbre {get{return timbre;}} public int Octave {get{return octave;}}
    public ulong Keys {get{return keys;}} public bool Extended {get{return extended;}} public bool Overflow {get{return overflow;}}
    public int Voices {get{int mask=0;for(int i=0;i<4;i++)if(slots[i]>=0)mask|=1<<i;return mask;}}
    public int[] SoundingNotes {get{var notes=new List<int>();foreach(int n in slots)if(n>=0)notes.Add(n);return notes.ToArray();}}
    ulong LegacyKeys() {ulong mask=0;int shift=octave==1?24:octave==2?0:12;for(int n=0;n<12;n++)if((legacy&(1<<n))!=0)mask|=1UL<<(shift+Semitones[n]);return mask;}
    byte[] State36(int seq,int cmd) {return Wire.Encode(seq,cmd,(int)keys&255,(int)(keys>>8)&255,(int)(keys>>16)&255,(int)(keys>>24)&255,((int)(keys>>32)&15)|(Voices<<4),32|(overflow?128:0));}
    void Publish(ulong old,bool oldExtended,int oldLegacy,long now) {
        // Held voices stay allocated; release edges first, then steal round-robin.
        for(int i=0;i<4;i++)if(slots[i]>=0 && (keys&(1UL<<(slots[i]-48)))==0){sink.NoteOff(slots[i]);slots[i]=-1;}
        ulong added=keys&~old;
        for(int index=0;index<(extended?36:12);index++) {
            int bit=extended?index:(octave==1?24:octave==2?0:12)+Semitones[index];
            if((added&(1UL<<bit))==0)continue;
            int slot=Array.IndexOf(slots,-1);if(slot<0)slot=nextSlot;
            if(slots[slot]>=0)sink.NoteOff(slots[slot]);slots[slot]=48+bit;sink.NoteOn(slots[slot]);nextSlot=(slot+1)%4;
        }
        bool changed=extended?(old!=keys||!oldExtended):(legacy!=oldLegacy||oldExtended);
        if(changed) {
            byte[] ev=extended?State36(eventSequence++,132):Wire.Encode(eventSequence++,130,(int)now,(int)(now>>8),(int)(now>>16),(int)(now>>24),legacy&255,(legacy>>8)|(Voices<<4));
            if(events.Count==16)overflow=true;else events.Enqueue(ev);
        }
    }
    public byte[] Accept(Frame f,long now) {
        int cmd=f.Command,status=0;int[] d=f.Data;
        int reserved=(cmd==4||cmd==7)?2:(cmd==9||cmd==10)?5:(cmd>=1&&cmd<=3)?1:0;
        for(int i=reserved;i<6;i++)if(d[i]!=0)status=1;
        if((cmd==1&&d[0]>3)||(cmd==2&&d[0]>15)||(cmd==3&&d[0]>2)||((cmd==4||cmd==7)&&d[1]>15)||((cmd==9||cmd==10)&&d[4]>15))status=1;
        if(cmd<1||cmd>11)status=2;
        ulong old=keys;bool oldExtended=extended;int oldLegacy=legacy;
        if(status==0)switch(cmd) {
            case 1:timbre=d[0];sink.Controls(timbre,volume);break;
            case 2:volume=d[0];sink.Controls(timbre,volume);break;
            case 3:octave=d[0];if(!extended)keys=LegacyKeys();break;
            case 4:case 7:legacy=d[0]|(d[1]<<8);extended=false;keys=LegacyKeys();refreshed=now;break;
            case 9:case 10:keys=(ulong)(byte)d[0]|((ulong)(byte)d[1]<<8)|((ulong)(byte)d[2]<<16)|((ulong)(byte)d[3]<<24)|((ulong)(byte)d[4]<<32);legacy=0;extended=true;refreshed=now;break;
            case 5:keys=0;legacy=0;refreshed=now;break;
            case 8:overflow=false;break;
        }
        Publish(old,oldExtended,oldLegacy,now);
        if(cmd==6&&status==0)return Wire.Encode(f.Sequence,129,timbre,volume,octave,overflow?128:0,legacy&255,(legacy>>8)|(Voices<<4));
        if(cmd==11&&status==0)return State36(f.Sequence,131);
        return Wire.Encode(f.Sequence,128,cmd,status,1,overflow?1:0,0,0);
    }
    public byte[] PollEvent(){return events.Count==0?null:events.Dequeue();}
    public void Tick(long now){if(keys!=0&&now-refreshed>=2000){ulong old=keys;int oldLegacy=legacy;keys=0;legacy=0;Publish(old,extended,oldLegacy,now);}}
    public void Disconnect(){keys=0;legacy=0;for(int i=0;i<4;i++)slots[i]=-1;sink.Panic();events.Clear();}
}
internal sealed class EmulatorSession {
    readonly byte[] window=new byte[12];int count;long last;
    public readonly DeviceModel Model;public long Frames {get;private set;} public long CrcErrors {get;private set;} public long ReceivedBytes {get;private set;}
    public EmulatorSession(INoteSink sink){Model=new DeviceModel(sink);}
    public List<byte[]> Feed(byte[] b,int length,long now) {
        var output=new List<byte[]>();ReceivedBytes+=length;
        for(int i=0;i<length;i++) {
            if(count>0&&now-last>300)count=0;last=now;
            if(count==12){Array.Copy(window,1,window,0,11);count=11;}
            window[count++]=b[i];if(count<12)continue;
            Frame frame=Wire.Decode(window);
            if(frame==null){if(window[0]==165&&window[1]==90&&window[11]==13&&window[10]!=Wire.Crc(window,2,8))CrcErrors++;continue;}
            count=0;Frames++;output.Add(Model.Accept(frame,now));Drain(output);
        }
        return output;
    }
    void Drain(List<byte[]> output){byte[] ev;while((ev=Model.PollEvent())!=null)output.Add(ev);}
    public List<byte[]> Tick(long now){Model.Tick(now);var output=new List<byte[]>();Drain(output);return output;}
    public void Disconnect(){count=0;Model.Disconnect();}
}
internal static class TestEntry {public static int Main(){return SelfTests.Run();}}
}

