using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using FpgaMidiSpeakers;
namespace PianoBluetoothTest {
internal sealed class GsSink : INoteSink,IDisposable {
    readonly MidiOutput output;
    public GsSink() {
        int device=-1;foreach(MidiDevice d in NativeMidi.GetDevices())if(d.Name.IndexOf("Microsoft GS",StringComparison.OrdinalIgnoreCase)>=0){device=d.Id;break;}
        if(device<0)throw new InvalidOperationException("Microsoft GS MIDI output unavailable. Uncheck PC sound to test Bluetooth only.");
        output=new MidiOutput(device);output.Panic();output.Send(0x000079B0);output.Send(0x007F0BB0);
    }
    public void NoteOn(int note){output.Send(0x90U|((uint)note<<8)|(100U<<16));}
    public void NoteOff(int note){output.Send(0x80U|((uint)note<<8));}
    public void Controls(int timbre,int volume){int[] programs={0,4,24,48};output.Send(0xC0U|((uint)programs[timbre]<<8));output.Send(0x000007B0U|((uint)(volume*127/15)<<16));}
    public void Panic(){output.Panic();}public void Dispose(){output.Dispose();}
}
internal sealed class ReceiverHost : IDisposable {
    readonly object gate=new object();Thread worker;volatile bool stopping;string status="Stopped",details="No packets";
    public event Action<string> Log;
    public bool Running {get{lock(gate)return worker!=null&&worker.IsAlive;}}
    public string Status {get{lock(gate)return status;}}public string Details {get{lock(gate)return details;}}
    void Report(string value){lock(gate)status=value;Action<string> log=Log;if(log!=null)log(DateTime.Now.ToString("HH:mm:ss.fff ")+value);}
    public void Start(bool sound){lock(gate){if(worker!=null&&worker.IsAlive)return;stopping=false;worker=new Thread(delegate(){Run(sound);});worker.IsBackground=true;worker.Name="PianoLink RFCOMM";worker.Start();}}
    public void Stop(){Thread t;lock(gate){stopping=true;t=worker;}if(t!=null&&t!=Thread.CurrentThread)t.Join(2000);}
    void Update(EmulatorSession s){lock(gate)details=String.Format("Frames {0} | CRC errors {1} | bytes {2}\r\nKeys {3:X9} ({4}) | voices {5:X1}/4\r\nVolume {6}/15 | timbre {7} | octave {8} | {9} | overflow {10}",s.Frames,s.CrcErrors,s.ReceivedBytes,s.Model.Keys,NoteNames(s.Model.Keys),s.Model.Voices,s.Model.Volume,s.Model.Timbre,s.Model.Octave,s.Model.Extended?"36-key":"12-key",s.Model.Overflow);}
    static string NoteNames(ulong mask){var names=new List<string>();string[] scale={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};for(int bit=0;bit<36;bit++)if((mask&(1UL<<bit))!=0)names.Add(scale[bit%12]+(3+bit/12));return names.Count==0?"released":String.Join(" ",names.ToArray());}
    void SendFrames(IntPtr client,List<byte[]> frames){foreach(byte[] frame in frames){int offset=0;var wait=Stopwatch.StartNew();while(offset<frame.Length&&!stopping){byte[] part=new byte[frame.Length-offset];Array.Copy(frame,offset,part,0,part.Length);int written=NativeBluetooth.send(client,part,part.Length,0);if(written>0){offset+=written;continue;}if(written==0)throw new InvalidOperationException("Bluetooth send closed");if(NativeBluetooth.WSAGetLastError()!=10035)throw NativeBluetooth.Error("Bluetooth send");if(wait.ElapsedMilliseconds>=500)throw new TimeoutException("Bluetooth send stalled; released client");Thread.Sleep(10);}}}
    void Run(bool sound){GsSink audio=null;EmulatorSession session=null;
        try {
            NativeBluetooth.RadioInfo radio=NativeBluetooth.Probe();Report("Radio "+radio.Name+" / "+NativeBluetooth.FormatAddress(radio.Address));
            INoteSink sink=new SilentSink();if(sound){audio=new GsSink();sink=audio;}
            session=new EmulatorSession(sink);Update(session);var clock=Stopwatch.StartNew();
            using(var listener=new SppListener(radio.Address)) {
                string listening="Listening "+NativeBluetooth.FormatAddress(listener.Address.Address)+" channel "+listener.Address.Port+" / SPP 1101";Report(listening);
                while(!stopping) {
                    var remote=new NativeBluetooth.BthAddress();int size=30;IntPtr client=NativeBluetooth.accept(listener.Socket,ref remote,ref size);
                    if(client==NativeBluetooth.Invalid){if(NativeBluetooth.WSAGetLastError()!=10035)throw NativeBluetooth.Error("Bluetooth accept");Thread.Sleep(20);continue;}
                    try {
                        NativeBluetooth.Nonblocking(client);Report("Connected "+NativeBluetooth.FormatAddress(remote.Address));byte[] buffer=new byte[1024];ulong previous=0;
                        while(!stopping) {
                            int n=NativeBluetooth.recv(client,buffer,buffer.Length,0);if(n==0)break;
                            if(n<0&&NativeBluetooth.WSAGetLastError()!=10035)throw NativeBluetooth.Error("Bluetooth receive");
                            long now=clock.ElapsedMilliseconds;if(n>0)SendFrames(client,session.Feed(buffer,n,now));SendFrames(client,session.Tick(now));Update(session);
                            if(previous!=session.Model.Keys){previous=session.Model.Keys;Action<string> log=Log;if(log!=null)log(DateTime.Now.ToString("HH:mm:ss.fff ")+"Keys "+NoteNames(previous));}
                            if(n<0)Thread.Sleep(20);
                        }
                    }catch(Exception e){Report("Client ended: "+e.Message);}
                    finally{NativeBluetooth.closesocket(client);session.Disconnect();Update(session);}
                    if(!stopping)Report(listening+" (previous client released)");
                }
            }
            Report("Stopped; SDP removed, sockets closed, notes released");
        }catch(Exception e){Report("ERROR: "+e.Message);}
        finally{if(session!=null){session.Disconnect();Update(session);}if(audio!=null)audio.Dispose();}
    }
    public void Dispose(){Stop();}
}
}
