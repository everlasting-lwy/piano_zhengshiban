# Phone -> PC Bluetooth test receiver

`bin/PianoBluetoothTest.exe` is a standalone Windows x64 .NET Framework receiver for PianoLink. It substitutes for the FPGA/HC-05 during application testing. It needs no NuGet packages, COM port, or FPGA connection. It listens only on native Bluetooth RFCOMM (`AF_BTH`), using the standard SPP UUID `00001101-0000-1000-8000-00805F9B34FB` and an automatically allocated RFCOMM channel advertised through SDP.

## Run

1. Open `bin/PianoBluetoothTest.exe`. Its initial screen reads the local radio name/address. Click **Start receiver** to advertise SPP. Check **PC GS sound** before starting if you want audible notes; default is silent protocol testing.
2. Pair the Android phone and this PC using their normal system Bluetooth settings, accepting any pairing confirmation yourself. The receiver does not change pairing, discoverability, authentication, drivers, or radio settings.
3. In PianoLink choose the already paired **PC name**. Select its real Bluetooth connection; the phone's simulation mode does not connect to this receiver. On this test machine the radio reports `LAPTOP-FJJS26RL`, `28:D0:43:52:4E:0B`.
4. Try the normal 12-key dashboard, controls, and 36-key screen. The PC displays connection state, valid frames, CRC errors, bytes, held notes, allocated voice bitmap, volume, timbre, octave, and mode. The log records connections and key changes.
5. **Stop / release** closes the client/listener, removes its SDP record, and resets MIDI. Closing the window performs the same cleanup. After a client disconnect the receiver releases its notes and accepts another connection automatically.

If there is no usable Windows Bluetooth radio, the receiver gives an explicit error. It does not create an Internet listener. Sound requires the existing Microsoft GS MIDI output. If that output is unavailable, uncheck sound and restart the receiver.

## Build and self-test

From the repository root in PowerShell:

```powershell
& ./tools/bluetooth_test/test.ps1
& ./tools/bluetooth_test/build.ps1
& ./tools/bluetooth_test/bin/PianoBluetoothTest.exe --self-test
& ./tools/bluetooth_test/bin/PianoBluetoothTest.exe --probe
```

Both scripts use `C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe`, treat warnings as errors, and include the existing `../FpgaMidiSpeakers.cs` MIDI implementation at compile time. The resulting EXE does not need that source file beside it.

`--self-test`/`test.ps1` exercise the production parser/model with a capture MIDI sink. They do not open a radio, register a service, or open audio. The 143 checks cover CRC-8/SMBUS, a fixed byte fixture, commands 01..0B, responses 80/81/83, events 82/84, reserved/unsupported requests, all 36 absolute pitches, all legacy pitches/octaves, four-voice stealing, release, unchanged heartbeat, the exact 2000 ms watchdog boundary, invalid heartbeat safety, FIFO overflow, corrupt/fragmented/coalesced frames, resynchronization, timeout, disconnect panic, and native structure sizes/offsets.

Additional explicit receiver modes:

```powershell
# Opens a real Bluetooth listener, then cleans up after two seconds:
& ./tools/bluetooth_test/bin/PianoBluetoothTest.exe --listen-seconds 2
# Keep a receiver in this terminal until Ctrl+C; add --sound for GS:
& ./tools/bluetooth_test/bin/PianoBluetoothTest.exe --console
```

Do not run two receivers concurrently for the same SPP service. `--listen-seconds` accepts 1..300 seconds and also accepts `--sound`; sound is never opened unless explicitly selected.

## Fidelity and limits

The 12-byte frame, CRC, request validation, legacy ordering (`C D E F G A B C# D# F# G# A#`), absolute C3..B5/MIDI48..83 masks, protocol markers and reply/event layouts follow `../../docs/BLUETOOTH_APP_PROTOCOL.md` and the current RTL. ACKs precede their resulting events. All remote notes share four slots with edge-triggered allocation and round-robin stealing. Held stolen notes do not automatically retrigger. Release, disconnect, Stop and the key heartbeat watchdog prevent hanging notes. Controls and mode remain in the emulator when the next phone connects; the remote key state is cleared.

This PC has no physical FPGA keys: returned key masks represent phone input. The emulated mode is normal mode (`0`); FPGA ultrasonic/audio synthesis and hardware release envelopes are not simulated. GS uses channel 1, velocity100, CC7 for 0..15 volume, and programs 0/4/24/48 as convenient sound previews of the four timbre settings. It reuses the existing `FpgaMidiSpeakers.MidiOutput`; it does not alter the system mixer/device volume. GS audio is a functional check, not a low-latency claim: an earlier GS path measured approximately 262-268 ms. No PCM, recording, or permanent song download is involved.

Legacy82 timestamps are PC monotonic milliseconds for this receiver's current run, not FPGA timestamps. Extended84 is an untimestamped state event. Neither PC receive times nor this synth output establish real FPGA performance. Opening/importing a CSV should preserve the Android connection while its UI releases/stops playback; verify that on an authorized real phone separately.

## Native ABI references

- [Microsoft ws2bth.h](https://raw.githubusercontent.com/microsoft/win32metadata/main/generation/WinSDK/RecompiledIdlHeaders/um/ws2bth.h): `SOCKADDR_BTH` lies inside `pshpack1.h`/`poppack.h`; size30, address offset2, port offset26. Other Winsock structures retain normal platform packing.
- [Microsoft WSAQUERYSET for Set Service](https://learn.microsoft.com/en-us/windows/win32/bluetooth/bluetooth-and-wsaqueryset-for-set-service): simple SDP registration uses `NS_BTH`, one `CSADDR_INFO` local address and the service-class GUID.
- [Microsoft WSASetService](https://learn.microsoft.com/en-us/windows/win32/bluetooth/bluetooth-and-wsasetservice): register/delete operations and process lifetime.
- [Microsoft SOCKADDR_BTH](https://learn.microsoft.com/en-us/windows/win32/api/ws2bth/ns-ws2bth-sockaddr_bth): `BT_PORT_ANY` allocation followed by `getsockname`.

## Verification on 2026-10-23

Self-tests: **143 checks passed**; x64 build passed with warnings as errors. Read-only probe returned `LAPTOP-FJJS26RL / 28:D0:43:52:4E:0B`. Three bounded real-radio listener runs successfully registered SPP on channel4 and then removed SDP/closed sockets with zero frames received. No receiver process remained after the smoke checks. These checks do not establish an actual Android connection, audible GS playback, or CSV/file-picker behavior; those require the phone and optional listening test.

Subsequent live test: ALN-AL00 phone connected to the visible receiver with optional GS enabled. Final observation2304 valid frames/27648 bytes,0 CRC errors,volume15,keys/voices released; single notes and chords were received. User confirmed audible PC sound and connection retained after CSV import and backgrounding. This passes those direct-PC functional scenarios; no acoustic latency or HC-05/FPGA path was measured. The GUI was left listening for continued user testing.

本PC模拟接收器仅用于基础演奏/36键链路，不替代FPGA的硬件音效、图形OLED或RAM曲谱引导验收。
