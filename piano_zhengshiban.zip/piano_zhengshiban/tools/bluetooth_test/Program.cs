using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
namespace PianoBluetoothTest {
internal sealed class ReceiverForm : Form {
    readonly ReceiverHost host=new ReceiverHost();readonly Button start=new Button(),stop=new Button();readonly CheckBox sound=new CheckBox();
    readonly Label status=new Label(),details=new Label();readonly TextBox log=new TextBox();readonly System.Windows.Forms.Timer refresh=new System.Windows.Forms.Timer();
    public ReceiverForm(){
        Text="PianoLink PC Bluetooth SPP Test";ClientSize=new Size(820,540);MinimumSize=new Size(760,520);Font=new Font("Segoe UI",10);
        start.Text="Start receiver";start.SetBounds(15,15,140,34);stop.Text="Stop / release";stop.SetBounds(165,15,140,34);
        sound.Text="PC GS sound (optional)";sound.SetBounds(325,20,260,25);sound.Checked=false;
        status.SetBounds(15,65,790,50);status.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;
        details.SetBounds(15,120,790,100);details.Font=new Font("Consolas",10);details.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;
        var warning=new Label{Text="Pair phone with this PC in Windows settings, then select this PC in PianoLink.\r\n4 voices; no COM port. GS sound is a functional preview (~262 ms measured previously), not a latency test.",AutoSize=false};warning.SetBounds(15,225,790,55);
        log.SetBounds(15,285,790,240);log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Vertical;log.Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right;
        Controls.AddRange(new Control[]{start,stop,sound,status,details,warning,log});
        host.Log+=delegate(string message){if(IsHandleCreated&&!IsDisposed)try{BeginInvoke((Action)delegate{if(log.TextLength>60000)log.Clear();log.AppendText(message+Environment.NewLine);});}catch(InvalidOperationException){}};
        start.Click+=delegate{host.Start(sound.Checked);};stop.Click+=delegate{host.Stop();};
        refresh.Interval=150;refresh.Tick+=delegate{status.Text=host.Status;details.Text=host.Details;start.Enabled=!host.Running;stop.Enabled=host.Running;sound.Enabled=!host.Running;};refresh.Start();
        FormClosed+=delegate{refresh.Stop();host.Dispose();};
        try{var radio=NativeBluetooth.Probe();status.Text="Ready: "+radio.Name+" / "+NativeBluetooth.FormatAddress(radio.Address);}catch(Exception e){status.Text=e.Message;}
    }
}
internal static class Program {
    [STAThread] public static int Main(string[] args) {
        if(Array.IndexOf(args,"--self-test")>=0)return SelfTests.Run();
        if(Array.IndexOf(args,"--probe")>=0){try{var r=NativeBluetooth.Probe();Console.WriteLine("Radio: "+r.Name+" / "+NativeBluetooth.FormatAddress(r.Address));return 0;}catch(Exception e){Console.Error.WriteLine(e.Message);return 2;}}
        int timed=Array.IndexOf(args,"--listen-seconds");
        if(timed>=0){int seconds;if(timed+1>=args.Length||!Int32.TryParse(args[timed+1],out seconds)||seconds<1||seconds>300){Console.Error.WriteLine("--listen-seconds requires 1..300");return 2;}using(var host=new ReceiverHost()){host.Log+=Console.WriteLine;host.Start(Array.IndexOf(args,"--sound")>=0);var elapsed=System.Diagnostics.Stopwatch.StartNew();Thread.Sleep(200);while(host.Running&&elapsed.Elapsed.TotalSeconds<seconds)Thread.Sleep(50);host.Stop();Console.WriteLine(host.Details);return host.Status.StartsWith("ERROR:")?2:0;}}
        if(Array.IndexOf(args,"--console")>=0){using(var host=new ReceiverHost()){host.Log+=Console.WriteLine;host.Start(Array.IndexOf(args,"--sound")>=0);bool quit=false;Console.CancelKeyPress+=delegate(object sender,ConsoleCancelEventArgs e){e.Cancel=true;quit=true;};Thread.Sleep(200);while(host.Running&&!quit)Thread.Sleep(100);host.Stop();Console.WriteLine(host.Details);return host.Status.StartsWith("ERROR:")?2:0;}}
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new ReceiverForm());return 0;
    }
}
}
