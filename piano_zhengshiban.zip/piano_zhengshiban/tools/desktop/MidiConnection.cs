using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Threading;
using Microsoft.Win32;
using FpgaMidiSpeakers;

namespace PianoDesktop
{
    public delegate int ReadBytes(byte[] buffer,int offset,int count);

    public sealed class MidiByteReader
    {
        private readonly Func<int> available;
        private readonly ReadBytes read;
        public MidiByteReader(Func<int> available,ReadBytes read)
        {this.available=available;this.read=read;}
        public int Read(byte[] buffer)
        {
            if(buffer==null||buffer.Length==0)throw new ArgumentException("Read buffer is empty");
            // Even with zero buffered bytes, enter the driver's blocking read.
            // ReadTimeout limits idle control/stop response, not data arrival.
            int requested=Math.Max(1,Math.Min(buffer.Length,available()));
            try{return read(buffer,0,requested);}catch(TimeoutException){return 0;}
        }
    }

    public sealed class PortChoice
    {
        public string Port, Description;
        public override string ToString() { return Description; }
        public static PortChoice[] List()
        {
            string[] ports=SerialPort.GetPortNames();
            Array.Sort(ports,StringComparer.OrdinalIgnoreCase);
            var descriptions=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                using(var usb=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Enum\USB"))
                if(usb!=null) foreach(string name in usb.GetSubKeyNames())
                using(var device=usb.OpenSubKey(name))
                if(device!=null) foreach(string instanceName in device.GetSubKeyNames())
                using(var instance=device.OpenSubKey(instanceName))
                using(var parameters=instance==null ? null : instance.OpenSubKey("Device Parameters"))
                {
                    string port=parameters==null ? null : parameters.GetValue("PortName") as string;
                    string friendly=instance==null ? null : instance.GetValue("FriendlyName") as string;
                    if(port!=null && friendly!=null) descriptions[port]=friendly;
                }
            }
            catch(System.Security.SecurityException) { }
            catch(UnauthorizedAccessException) { }
            var result=new List<PortChoice>();
            foreach(string port in ports)
                result.Add(new PortChoice {Port=port,Description=descriptions.ContainsKey(port) ? descriptions[port] : port});
            return result.ToArray();
        }
    }

    // Reused by real serial input and the explicit, silent offline demonstration.
    public sealed class MidiPipeline
    {
        private readonly MidiParser parser=new MidiParser();
        private readonly MidiMonitor monitor;
        private readonly Action<uint> send;
        public MidiPipeline(MidiMonitor monitor,Action<uint> send)
        { this.monitor=monitor;this.send=send; }
        public void Feed(byte[] bytes,int count,double gain,double elapsedMs)
        {
            monitor.AddBytes(count);
            foreach(uint raw in parser.Feed(bytes,count))
            {
                uint output=MidiDynamics.ApplyVelocityGain(raw,gain);
                long began=Stopwatch.GetTimestamp();
                send(output);
                double forwardMs=(Stopwatch.GetTimestamp()-began)*1000.0/Stopwatch.Frequency;
                monitor.Accept(raw,output,elapsedMs,forwardMs);
            }
        }
    }

    public sealed class MidiConnection : IDisposable
    {
        public readonly MidiMonitor Monitor=new MidiMonitor();
        private readonly object sync=new object();
        private readonly Stopwatch clock=Stopwatch.StartNew();
        private Thread worker;
        private volatile bool stop=true;
        private bool running,demo,panic;
        private string status="未连接 · 选择串口后连接，开发板需切到模式 2";
        private double gain=1.25;
        private int volume=127,program;
        public bool Running { get {lock(sync)return running;} }
        public bool IsDemo { get {lock(sync)return demo;} }
        public string Status { get {lock(sync)return status;} }
        public double ElapsedMs {get{return clock.Elapsed.TotalMilliseconds;}}
        public void Configure(double velocityGain,int channelVolume,int instrument)
        {
            if(double.IsNaN(velocityGain)||velocityGain<1||velocityGain>4 || channelVolume<0 || channelVolume>127 || instrument<0 || instrument>127)
                throw new ArgumentOutOfRangeException("MIDI settings");
            lock(sync){gain=velocityGain;volume=channelVolume;program=instrument;}
        }
        public void Panic() {lock(sync)panic=true;}
        private void SetStatus(string text) {lock(sync)status=text;}
        public void Connect(string port,int deviceId)
        {
            Disconnect();
            var serial=new SerialPort(port,115200,Parity.None,8,StopBits.Two) {
                Handshake=Handshake.None,DtrEnable=false,RtsEnable=false,ReadTimeout=10,ReadBufferSize=16384 };
            serial.ErrorReceived+=delegate(object sender,SerialErrorReceivedEventArgs args){Monitor.AddSerialError();};
            MidiOutput output=null;
            try
            {
                serial.Open();
                output=new MidiOutput(deviceId);
                lock(sync)output.Initialize(program,volume);
            }
            catch {serial.Dispose();if(output!=null)output.Dispose();throw;}
            Monitor.Reset();
            stop=false;
            lock(sync){running=true;demo=false;panic=false;status="已连接 "+port+" · 115200 / 8N2 · 等待 MIDI";}
            MidiOutput ownedOutput=output;
            worker=new Thread(delegate(){Receive(serial,ownedOutput);}) {IsBackground=true,Name="FPGA MIDI receiver"};
            worker.Start();
        }
        private void Receive(SerialPort serial,MidiOutput output)
        {
            try
            {
                var pipe=new MidiPipeline(Monitor,output.Send);
                var buffer=new byte[4096];
                var reader=new MidiByteReader(delegate{return serial.BytesToRead;},serial.Read);
                int appliedVolume,appliedProgram;
                lock(sync){appliedVolume=volume;appliedProgram=program;}
                // Apply again on the worker: settings may change during Open().
                output.Send(0x000007B0U|((uint)appliedVolume<<16));
                output.Send(0xC0U|((uint)appliedProgram<<8));
                while(!stop)
                {
                    double currentGain;int currentVolume,currentProgram;bool doPanic;
                    lock(sync){currentGain=gain;currentVolume=volume;currentProgram=program;doPanic=panic;panic=false;}
                    if(doPanic){output.Panic();Monitor.ReleaseNotes();}
                    if(currentVolume!=appliedVolume){output.Send(0x000007B0U|((uint)currentVolume<<16));appliedVolume=currentVolume;}
                    if(currentProgram!=appliedProgram){output.Send(0xC0U|((uint)currentProgram<<8));appliedProgram=currentProgram;}
                    int count=reader.Read(buffer);
                    if(count>0)
                        pipe.Feed(buffer,count,currentGain,ElapsedMs);
                }
            }
            catch(Exception error){if(!stop)SetStatus("连接中断："+error.Message+"；请检查 USB 后重新连接。");}
            finally
            {
                try {output.Dispose();} catch(Exception) { }
                try {serial.Dispose();} catch(Exception) { }
                Monitor.ReleaseNotes();
                lock(sync)running=false;
            }
        }
        public void StartDemo()
        {
            Disconnect();Monitor.Reset();stop=false;
            lock(sync){running=true;demo=true;panic=false;status="离线演示 · 模拟 MIDI 数据，不占用串口、不发声";}
            worker=new Thread(Demonstrate) {IsBackground=true,Name="MIDI offline demo"};
            worker.Start();
        }
        private void Demonstrate()
        {
            var pipe=new MidiPipeline(Monitor,delegate(uint message){});
            int step=0;
            try
            {
                while(!stop)
                {
                    int note=60+step%18,velocity=40+(step*13)%81;
                    double currentGain;bool doPanic;
                    lock(sync){currentGain=gain;doPanic=panic;panic=false;}
                    if(doPanic)Monitor.ReleaseNotes();
                    byte[] on={(byte)0x90,(byte)note,(byte)velocity};
                    pipe.Feed(on,on.Length,currentGain,ElapsedMs);
                    for(int n=0;n<18&&!stop;n++)Thread.Sleep(20);
                    byte[] off={(byte)0x80,(byte)note,0};
                    pipe.Feed(off,off.Length,currentGain,ElapsedMs);
                    for(int n=0;n<5&&!stop;n++)Thread.Sleep(20);
                    step++;
                }
            }
            finally {Monitor.ReleaseNotes();lock(sync){running=false;demo=false;}}
        }
        public void Disconnect()
        {
            stop=true;
            if(worker!=null)
            {
                if(!worker.Join(1500))throw new InvalidOperationException("接收线程尚未退出，请稍后重试。");
                worker=null;
            }
            Monitor.ReleaseNotes();
            lock(sync){running=false;demo=false;status="已断开 · 串口已释放";}
        }
        public void Dispose(){Disconnect();}
    }
}
