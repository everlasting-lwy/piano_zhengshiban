using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace PianoDesktop
{
    internal static class Program
    {
        [DllImport("user32.dll")]private static extern bool SetProcessDPIAware();
        [STAThread]
        private static void Main()
        {
            SetProcessDPIAware();
            Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException+=delegate(object sender,System.Threading.ThreadExceptionEventArgs args)
            {MessageBox.Show(args.Exception.Message,"Piano Monitor",MessageBoxButtons.OK,MessageBoxIcon.Error);};
            Application.Run(new PianoForm());
        }
    }
}
