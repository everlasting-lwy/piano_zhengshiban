using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using FpgaMidiSpeakers;

namespace PianoDesktop
{
    public sealed class PianoForm : Form
    {
        private readonly MidiConnection connection=new MidiConnection();
        private readonly Timer refresh=new Timer {Interval=30};
        private readonly Timer testRelease=new Timer {Interval=600};
        private readonly ComboBox ports=Combo("串口选择"),devices=Combo("MIDI 音源"),instruments=Combo("电脑音色"),octaves=Combo("显示音域");
        private readonly Button connect=Button("连接",true),disconnect=Button("断开",false),demo=Button("离线演示",false),test=Button("测试音",false);
        private readonly NumericUpDown gain=new NumericUpDown {Minimum=1,Maximum=4,DecimalPlaces=2,Increment=.05M,Value=1.25M,Width=72};
        private readonly TrackBar volume=new TrackBar {Minimum=0,Maximum=127,Value=127,TickStyle=TickStyle.None,Width=170,Height=32};
        private readonly Label volumeText=TextLabel("127",Color.FromArgb(30,50,70));
        private readonly Label status=TextLabel("未连接",Color.FromArgb(90,107,128)),statistics=TextLabel("等待 MIDI 数据",Color.FromArgb(90,107,128));
        private readonly Label noteText=TextLabel("—",Color.FromArgb(24,43,68)),noteDetail=TextLabel("等待实体琴键 / MIDI 输入",Color.FromArgb(102,118,139));
        private readonly Label rawText=TextLabel("0 / 127",Color.FromArgb(59,130,246)),outputText=TextLabel("0 / 127",Color.FromArgb(19,157,117));
        private readonly ProgressBar rawBar=new ProgressBar {Maximum=127,Dock=DockStyle.Bottom,Height=9},outputBar=new ProgressBar {Maximum=127,Dock=DockStyle.Bottom,Height=9};
        private readonly PianoKeyboard keyboard=new PianoKeyboard {Dock=DockStyle.Fill};
        private readonly VelocityGraph graph=new VelocityGraph {Dock=DockStyle.Fill};
        private readonly CheckBox follow=new CheckBox {Text="跟随音域",Checked=true,AutoSize=true};
        private readonly DataGridView log=new DataGridView();
        private readonly Label diagnostic=TextLabel("按一次琴键，检查是否收到 ON 和 OFF。",Color.FromArgb(90,107,128));
        private long lastEvent;
        private bool wasRunning;
        private MidiOutput testOutput;
        private readonly int[] programNumbers={0,4,10,11,24,40,80};

        public PianoForm()
        {
            Text="Piano Monitor 1.1.1 · FPGA MIDI 可视化";
            AutoScaleMode=AutoScaleMode.Dpi;
            Font=new Font("Microsoft YaHei UI",9F);
            ClientSize=new Size(1180,830);MinimumSize=new Size(1020,620);
            StartPosition=FormStartPosition.CenterScreen;
            BackColor=Color.FromArgb(241,245,249);
            BuildLayout();
            // Set the design DPI after Font and all child controls are assigned.
            // Font changes can otherwise consume autoscaling before the layout exists.
            AutoScaleDimensions=new SizeF(96,96);
            instruments.Items.AddRange(new object[]{"钢琴","电钢琴","八音盒","颤音琴","尼龙吉他","小提琴","合成主音"});
            instruments.SelectedIndex=0;
            octaves.Items.AddRange(new object[]{"C3 – F4","C4 – F5","C5 – F6"});octaves.SelectedIndex=1;
            gain.AccessibleName="力度增强倍数";volume.AccessibleName="电脑通道音量";
            connect.Click+=delegate{ConnectBoard();};
            disconnect.Click+=delegate{TryAction(delegate{connection.Disconnect();});};
            demo.Click+=delegate{TryAction(delegate{StopTest();connection.StartDemo();ClearRows();});};
            test.Click+=delegate{TryAction(TestSound);};
            gain.ValueChanged+=delegate{ApplySettings();};volume.ValueChanged+=delegate{ApplySettings();};
            instruments.SelectedIndexChanged+=delegate{ApplySettings();};
            octaves.SelectedIndexChanged+=delegate{keyboard.BaseNote=48+12*octaves.SelectedIndex;keyboard.Invalidate();};
            testRelease.Tick+=delegate{StopTest();};
            refresh.Tick+=delegate{RefreshMonitor();};
            FormClosing+=delegate(object sender,FormClosingEventArgs args)
            {
                refresh.Stop();StopTest();
                try{connection.Dispose();}catch(Exception error){MessageBox.Show(error.Message,"关闭提示");}
            };
            Shown+=delegate{TryAction(RefreshDevices);refresh.Start();};
        }

        private static ComboBox Combo(string name)
        {return new ComboBox {DropDownStyle=ComboBoxStyle.DropDownList,Dock=DockStyle.Fill,AccessibleName=name};}
        private static Label TextLabel(string text,Color color)
        {return new Label {Text=text,ForeColor=color,AutoSize=false,TextAlign=ContentAlignment.MiddleLeft};}
        private static Button Button(string text,bool primary)
        {
            return new Button {Text=text,Height=32,Width=83,FlatStyle=FlatStyle.Flat,
                BackColor=primary?Color.FromArgb(24,155,117):Color.White,
                ForeColor=primary?Color.White:Color.FromArgb(40,57,79),Cursor=Cursors.Hand};
        }
        private Panel Card(){return new Panel {BackColor=Color.White,Dock=DockStyle.Fill,Padding=new Padding(14,10,14,10),Margin=new Padding(0,0,0,10)};}
        private Label Caption(string value){var label=TextLabel(value,Color.FromArgb(92,109,130));label.Dock=DockStyle.Top;label.Height=23;return label;}
        private void BuildLayout()
        {
            var root=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=7,Padding=new Padding(20,12,20,8)};
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            foreach(int height in new[]{86,96,70,132,207})root.RowStyles.Add(new RowStyle(SizeType.Absolute,height));
            root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.Absolute,31));
            var viewport=new Panel {Dock=DockStyle.Fill,AutoScroll=true};
            Controls.Add(viewport);viewport.Controls.Add(root);
            root.Dock=DockStyle.Top;root.MinimumSize=new Size(0,900);root.Height=900;
            viewport.SizeChanged+=delegate{root.Height=Math.Max(root.MinimumSize.Height,viewport.ClientSize.Height);};

            var header=new Panel {Dock=DockStyle.Fill};
            var title=TextLabel("Piano Monitor",Color.FromArgb(23,42,66));title.Font=new Font(Font.FontFamily,23F,FontStyle.Bold);title.Dock=DockStyle.Top;title.Height=46;
            var subtitle=TextLabel("FPGA 串口 MIDI  /  实时琴键 · 力度诊断 · 电脑发声",Color.FromArgb(94,112,135));subtitle.Dock=DockStyle.Fill;
            header.Controls.Add(subtitle);header.Controls.Add(title);root.Controls.Add(header,0,0);

            var connectionCard=Card();
            var connections=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=7,RowCount=2};
            connections.RowStyles.Add(new RowStyle(SizeType.Absolute,23));connections.RowStyles.Add(new RowStyle(SizeType.Percent,100));
            connections.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,48));
            connections.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,75));
            connections.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,52));
            foreach(int width in new[]{82,82,82,98})connections.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,width));
            connections.Controls.Add(Caption("串口 / USB 转串口"),0,0);connections.Controls.Add(ports,0,1);
            var rescan=Button("刷新",false);rescan.Dock=DockStyle.Fill;rescan.Click+=delegate{TryAction(RefreshDevices);};connections.Controls.Add(rescan,1,1);
            connections.Controls.Add(Caption("MIDI 输出音源"),2,0);connections.Controls.Add(devices,2,1);
            connections.Controls.Add(connect,3,1);connections.Controls.Add(disconnect,4,1);connections.Controls.Add(test,5,1);connections.Controls.Add(demo,6,1);
            foreach(Control item in new Control[]{connect,disconnect,test,demo})item.Dock=DockStyle.Fill;
            connectionCard.Controls.Add(connections);root.Controls.Add(connectionCard,0,1);

            var settings=Card();settings.Padding=new Padding(10,6,10,6);
            var settingsFlow=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};
            settingsFlow.Controls.Add(FlowText("电脑音色"));instruments.Dock=DockStyle.None;instruments.Width=113;settingsFlow.Controls.Add(instruments);
            settingsFlow.Controls.Add(FlowText("力度增强"));settingsFlow.Controls.Add(gain);
            settingsFlow.Controls.Add(FlowText("倍    音量"));settingsFlow.Controls.Add(volume);
            volumeText.Width=36;volumeText.Height=30;settingsFlow.Controls.Add(volumeText);
            var panic=Button("全部停音",false);panic.Width=84;panic.Click+=delegate{connection.Panic();StopTest();};settingsFlow.Controls.Add(panic);
            var export=Button("导出 CSV",false);export.Width=87;export.Click+=delegate{TryAction(ExportCsv);};settingsFlow.Controls.Add(export);
            var clear=Button("清空记录",false);clear.Width=84;clear.Click+=delegate{TryAction(delegate{
                if(connection.Running)throw new InvalidOperationException("请先断开连接或停止演示，再清空诊断记录。");
                connection.Monitor.Reset();ClearRows();});};settingsFlow.Controls.Add(clear);
            settings.Controls.Add(settingsFlow);root.Controls.Add(settings,0,2);

            var metrics=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=3,RowCount=1,Margin=new Padding(0)};
            for(int i=0;i<3;i++)metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.333F));
            var noteCard=Card();noteCard.Margin=new Padding(0,0,10,10);
            noteText.Font=new Font(Font.FontFamily,23F,FontStyle.Bold);noteText.Dock=DockStyle.Fill;
            noteDetail.Dock=DockStyle.Bottom;noteDetail.Height=22;
            noteCard.Controls.Add(noteText);noteCard.Controls.Add(noteDetail);noteCard.Controls.Add(Caption("最近击键"));metrics.Controls.Add(noteCard,0,0);
            metrics.Controls.Add(VelocityCard("接收力度 · 原始 velocity",rawText,rawBar),1,0);
            metrics.Controls.Add(VelocityCard("发声力度 · 增强后 velocity",outputText,outputBar),2,0);root.Controls.Add(metrics,0,3);

            var keyboardCard=Card();
            var keyboardHeader=new TableLayoutPanel {Dock=DockStyle.Top,Height=34,ColumnCount=4};
            keyboardHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
            keyboardHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,132));keyboardHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,110));
            keyboardHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,260));
            var keysTitle=Caption("18 键音符显示");keysTitle.Font=new Font(Font,FontStyle.Bold);keyboardHeader.Controls.Add(keysTitle,0,0);
            keyboardHeader.Controls.Add(octaves,1,0);keyboardHeader.Controls.Add(follow,2,0);
            keyboardHeader.Controls.Add(Caption("绿色：按住    浅绿：短按提示"),3,0);
            var keyboardFoot=Caption("依据收到的 MIDI 显示，非全部实体接点；当前 FPGA 最多同时输出四声部。屏幕刷新约 30 ms。");keyboardFoot.Dock=DockStyle.Bottom;keyboardFoot.Height=25;
            keyboardCard.Controls.Add(keyboard);keyboardCard.Controls.Add(keyboardFoot);keyboardCard.Controls.Add(keyboardHeader);root.Controls.Add(keyboardCard,0,4);

            var bottom=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0)};
            bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,68));bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,32));
            var logCard=Card();logCard.Margin=new Padding(0,0,10,0);logCard.Controls.Add(log);logCard.Controls.Add(Caption("MIDI 消息记录 · 最近 1000 条可导出，表格显示最近 300 条"));SetupLog();bottom.Controls.Add(logCard,0,0);
            var graphCard=Card();graphCard.Margin=new Padding(0);
            diagnostic.Dock=DockStyle.Bottom;diagnostic.Height=58;
            graphCard.Controls.Add(graph);graphCard.Controls.Add(diagnostic);graphCard.Controls.Add(Caption("最近 40 次击键力度"));bottom.Controls.Add(graphCard,1,0);root.Controls.Add(bottom,0,5);

            var footer=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,Margin=new Padding(0)};
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,62));footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,38));
            status.Dock=statistics.Dock=DockStyle.Fill;statistics.TextAlign=ContentAlignment.MiddleRight;
            footer.Controls.Add(status,0,0);footer.Controls.Add(statistics,1,0);root.Controls.Add(footer,0,6);
        }
        private Label FlowText(string value){var label=TextLabel(value,Color.FromArgb(65,82,104));label.AutoSize=true;label.Padding=new Padding(0,5,0,0);label.Height=30;return label;}
        private Panel VelocityCard(string title,Label value,ProgressBar bar)
        {
            var card=Card();card.Margin=new Padding(0,0,10,10);value.Font=new Font(Font.FontFamily,20F,FontStyle.Bold);value.Dock=DockStyle.Fill;
            card.Controls.Add(value);card.Controls.Add(bar);card.Controls.Add(Caption(title));return card;
        }
        private void SetupLog()
        {
            log.Dock=DockStyle.Fill;log.ReadOnly=true;log.AllowUserToAddRows=false;log.AllowUserToDeleteRows=false;log.AllowUserToResizeRows=false;
            log.RowHeadersVisible=false;log.SelectionMode=DataGridViewSelectionMode.FullRowSelect;log.MultiSelect=false;
            log.BorderStyle=BorderStyle.None;log.BackgroundColor=Color.White;log.GridColor=Color.FromArgb(234,239,245);
            log.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;log.EnableHeadersVisualStyles=false;
            log.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(242,246,250);log.ColumnHeadersDefaultCellStyle.ForeColor=Color.FromArgb(75,92,114);
            log.ColumnHeadersHeight=28;log.RowTemplate.Height=25;
            string[] labels={"时间","事件","通道","音符","原始","输出","持续 ms"};
            for(int i=0;i<labels.Length;i++){int index=log.Columns.Add("c"+i,labels[i]);log.Columns[index].SortMode=DataGridViewColumnSortMode.NotSortable;}
            log.Columns[0].FillWeight=155;log.Columns[3].FillWeight=110;
        }
        private void RefreshDevices()
        {
            if(connection.Running)throw new InvalidOperationException("请先断开连接，再刷新设备。");
            string previous=ports.SelectedItem is PortChoice?((PortChoice)ports.SelectedItem).Port:null;
            ports.Items.Clear();int preferred=-1;
            foreach(var port in PortChoice.List())
            {
                int index=ports.Items.Add(port);
                if(port.Port==previous)preferred=index;
                else if(preferred<0&&(port.Description.IndexOf("CH9102",StringComparison.OrdinalIgnoreCase)>=0||port.Description.IndexOf("CH340",StringComparison.OrdinalIgnoreCase)>=0))preferred=index;
            }
            if(ports.Items.Count>0)ports.SelectedIndex=preferred>=0?preferred:0;
            devices.Items.Clear();devices.DisplayMember="Name";
            foreach(var device in NativeMidi.GetDevices())
            {
                int index=devices.Items.Add(device);
                if(device.Name.IndexOf("Microsoft GS",StringComparison.OrdinalIgnoreCase)>=0)devices.SelectedIndex=index;
            }
            if(devices.SelectedIndex<0&&devices.Items.Count>0)devices.SelectedIndex=0;
        }
        private int SelectedDevice()
        {
            var device=devices.SelectedItem as MidiDevice;
            if(device==null)throw new InvalidOperationException("没有可用的 MIDI 输出音源，请检查 Windows 音频设置。");
            return device.Id;
        }
        private void ApplySettings()
        {
            volumeText.Text=volume.Value.ToString();
            if(instruments.SelectedIndex>=0)connection.Configure((double)gain.Value,volume.Value,programNumbers[instruments.SelectedIndex]);
        }
        private void ConnectBoard()
        {
            TryAction(delegate{
                var port=ports.SelectedItem as PortChoice;
                if(port==null)throw new InvalidOperationException("没有选择串口，请插入 USB 数据线并点击刷新。");
                StopTest();ApplySettings();connection.Connect(port.Port,SelectedDevice());ClearRows();
            });
        }
        private void ClearRows(){lastEvent=0;log.Rows.Clear();}
        private void RefreshMonitor()
        {
            bool running=connection.Running;
            ports.Enabled=devices.Enabled=connect.Enabled=!running;
            disconnect.Enabled=running;demo.Enabled=!running;test.Enabled=!running;
            if(wasRunning&&!running)connection.Monitor.ReleaseNotes();wasRunning=running;
            status.Text=connection.Status;status.ForeColor=running?Color.FromArgb(16,135,97):Color.FromArgb(90,107,128);
            var snapshot=connection.Monitor.Snapshot();
            noteText.Text=MidiMonitor.NoteName(snapshot.LastNote);
            noteDetail.Text=snapshot.LastNote<0?"等待实体琴键 / MIDI 输入":"MIDI "+snapshot.LastNote+"   ·   活动声部 "+snapshot.ActiveCount;
            rawText.Text=snapshot.LastRawVelocity+" / 127";outputText.Text=snapshot.LastOutputVelocity+" / 127";
            rawBar.Value=snapshot.LastRawVelocity;outputBar.Value=snapshot.LastOutputVelocity;
            if(follow.Checked&&snapshot.LastNote>=0)
            {
                int note=snapshot.LastNote;
                if(note<keyboard.BaseNote||note>keyboard.BaseNote+17)
                {
                    int octave=Math.Max(0,Math.Min(2,note/12-4));
                    octaves.SelectedIndex=octave;
                }
            }
            keyboard.UpdateNotes(snapshot,connection.ElapsedMs);graph.UpdateHistory(snapshot);
            foreach(var item in connection.Monitor.EventsAfter(lastEvent))
            {
                lastEvent=item.Id;
                int row=log.Rows.Add(item.Time.ToString("HH:mm:ss.fff"),item.Action,item.Channel,
                    item.Action=="ON"||item.Action=="OFF"?MidiMonitor.NoteName(item.Note)+" / "+item.Note:item.Note.ToString(),
                    item.RawVelocity,item.OutputVelocity,item.DurationMs<0?"—":item.DurationMs.ToString("F1"));
                if(item.Action=="ON")log.Rows[row].DefaultCellStyle.ForeColor=Color.FromArgb(15,139,101);
                while(log.Rows.Count>300)log.Rows.RemoveAt(0);
            }
            if(log.Rows.Count>0&&log.FirstDisplayedScrollingRowIndex>=log.Rows.Count-14)
                log.FirstDisplayedScrollingRowIndex=log.Rows.Count-1;
            statistics.Text=String.Format("RX {0} B · ON {1}/OFF {2} · 活动 {3} · 错误 {4}",snapshot.ByteCount,snapshot.OnCount,snapshot.OffCount,snapshot.ActiveCount,snapshot.SerialErrorCount);
            string timing="转发 API 最近 / 最大："+snapshot.LastForwardMs.ToString("F2")+" / "+snapshot.MaxForwardMs.ToString("F2")+" ms。";
            if(snapshot.SerialErrorCount>0)diagnostic.Text=timing+"收到串口错误，先检查波特率、接线与 USB；导出 CSV 保留证据。";
            else if(snapshot.ZeroVelocityOnCount>0)diagnostic.Text=timing+"收到力度 0 的 Note On："+snapshot.ZeroVelocityOnCount+" 次，按 MIDI 约定作为松键。";
            else diagnostic.Text=timing+(snapshot.LastDurationMs>=0&&snapshot.LastDurationMs<30?"最近音符很短："+snapshot.LastDurationMs.ToString("F1")+" ms，检查提前松键。":"高亮及时但声音晚时，需检查电脑音源及音频缓冲。力度来自板端音量，并非测得按压力。");
        }
        private void TestSound()
        {
            StopTest();testOutput=new MidiOutput(SelectedDevice());
            try{
                testOutput.Initialize(programNumbers[instruments.SelectedIndex],volume.Value);
                testOutput.Send(MidiDynamics.ApplyVelocityGain(0x00503C90,(double)gain.Value));testRelease.Start();
            }catch{StopTest();throw;}
        }
        private void StopTest()
        {testRelease.Stop();if(testOutput!=null){testOutput.Dispose();testOutput=null;}}
        private void ExportCsv()
        {
            using(var dialog=new SaveFileDialog {Filter="CSV 记录 (*.csv)|*.csv",FileName="piano_midi_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".csv"})
                if(dialog.ShowDialog(this)==DialogResult.OK)File.WriteAllText(dialog.FileName,connection.Monitor.ExportCsv(),new UTF8Encoding(true));
        }
        private void TryAction(Action action)
        {
            try{action();}catch(Exception error){MessageBox.Show(this,error.Message+"\r\n\r\n若串口被占用，请先关闭旧的命令行桥接或串口调试软件。","操作提示",MessageBoxButtons.OK,MessageBoxIcon.Information);}
        }
    }
}
