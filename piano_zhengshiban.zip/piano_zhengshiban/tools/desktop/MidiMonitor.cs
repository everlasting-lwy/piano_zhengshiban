using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace PianoDesktop
{
    public sealed class MidiEvent
    {
        public long Id;
        public DateTime Time;
        public string Action;
        public int Channel, Note, RawVelocity, OutputVelocity;
        public double DurationMs = -1;
        public double ForwardMs;
        public uint RawMessage;
    }

    public sealed class MonitorSnapshot
    {
        public bool[] Active = new bool[128];
        public double[] LastPressedMs = new double[128];
        public int ActiveCount, LastNote = -1, LastRawVelocity, LastOutputVelocity;
        public long OnCount, OffCount, MessageCount, ByteCount;
        public double LastDurationMs = -1;
        public double LastForwardMs, MaxForwardMs;
        public long ZeroVelocityOnCount, SerialErrorCount;
        public int[] RawHistory, OutputHistory;
    }

    public sealed class MidiMonitor
    {
        private readonly object sync = new object();
        private readonly bool[,] active = new bool[16,128];
        private readonly double[,] pressedAt = new double[16,128];
        private readonly double[] lastPressed = new double[128];
        private readonly Queue<MidiEvent> events = new Queue<MidiEvent>();
        private readonly Queue<int> rawHistory = new Queue<int>();
        private readonly Queue<int> outputHistory = new Queue<int>();
        private long nextId, onCount, offCount, messageCount, byteCount;
        private int lastNote = -1, lastRaw, lastOutput;
        private double lastDuration = -1;
        private double lastForward,maxForward;
        private long zeroVelocityOnCount,serialErrorCount;

        public static string NoteName(int note)
        {
            if (note < 0 || note > 127) return "—";
            string[] names = {"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
            return names[note % 12] + (note / 12 - 1).ToString(CultureInfo.InvariantCulture);
        }

        public void AddBytes(int count) { lock(sync) byteCount += count; }
        public void AddSerialError() {lock(sync)serialErrorCount++;}

        public void Accept(uint raw, uint output, double elapsedMs,double forwardMs=0)
        {
            lock(sync)
            {
                int status = (int)(raw & 255), command = status & 240, channel = status & 15;
                int note = (int)((raw >> 8) & 127), velocity = (int)((raw >> 16) & 127);
                messageCount++;
                lastForward=forwardMs;maxForward=Math.Max(maxForward,forwardMs);
                if(command==0x90&&velocity==0)zeroVelocityOnCount++;
                var item = new MidiEvent { Id = ++nextId, Time = DateTime.Now,
                    Channel = channel + 1, Note = note, RawVelocity = velocity,
                    OutputVelocity = (int)((output >> 16) & 127), Action = "MIDI",ForwardMs=forwardMs,RawMessage=raw };
                if (command == 0x90 && velocity > 0)
                {
                    item.Action = "ON";
                    active[channel,note] = true;
                    pressedAt[channel,note] = elapsedMs;
                    lastPressed[note] = elapsedMs;
                    lastNote = note; lastRaw = velocity; lastOutput = item.OutputVelocity;
                    onCount++;
                    rawHistory.Enqueue(lastRaw); outputHistory.Enqueue(lastOutput);
                    if (rawHistory.Count > 40) { rawHistory.Dequeue(); outputHistory.Dequeue(); }
                }
                else if (command == 0x80 || command == 0x90)
                {
                    item.Action = "OFF";
                    if (active[channel,note])
                    {
                        item.DurationMs = Math.Max(0, elapsedMs - pressedAt[channel,note]);
                        lastDuration = item.DurationMs;
                    }
                    active[channel,note] = false;
                    offCount++;
                }
                else if (command == 0xB0)
                {
                    item.Action = "CC";
                    if (note == 120 || note == 123)
                        for (int n=0;n<128;n++) active[channel,n] = false;
                }
                events.Enqueue(item);
                if (events.Count > 1000) events.Dequeue();
            }
        }

        public void ReleaseNotes()
        {
            lock(sync) Array.Clear(active, 0, active.Length);
        }

        public void Reset()
        {
            lock(sync)
            {
                Array.Clear(active,0,active.Length);
                Array.Clear(lastPressed,0,lastPressed.Length);
                events.Clear(); rawHistory.Clear(); outputHistory.Clear();
                onCount=offCount=messageCount=byteCount=0;
                lastNote=-1; lastRaw=lastOutput=0; lastDuration=-1;
                lastForward=maxForward=0;zeroVelocityOnCount=serialErrorCount=0;
            }
        }

        public MonitorSnapshot Snapshot()
        {
            lock(sync)
            {
                var result = new MonitorSnapshot { LastNote=lastNote, LastRawVelocity=lastRaw,
                    LastOutputVelocity=lastOutput, OnCount=onCount, OffCount=offCount,
                    MessageCount=messageCount, ByteCount=byteCount, LastDurationMs=lastDuration,
                    RawHistory=rawHistory.ToArray(), OutputHistory=outputHistory.ToArray(),
                    LastForwardMs=lastForward,MaxForwardMs=maxForward,ZeroVelocityOnCount=zeroVelocityOnCount,SerialErrorCount=serialErrorCount };
                for(int c=0;c<16;c++) for(int n=0;n<128;n++)
                    if(active[c,n]) { result.Active[n]=true; result.ActiveCount++; }
                Array.Copy(lastPressed,result.LastPressedMs,128);
                return result;
            }
        }

        public MidiEvent[] EventsAfter(long id)
        {
            lock(sync)
            {
                var result = new List<MidiEvent>();
                foreach(var item in events) if(item.Id > id) result.Add(item);
                return result.ToArray();
            }
        }

        public string ExportCsv()
        {
            // Formatting runs outside the receiver lock: exporting while playing
            // must not hold up subsequent MIDI messages.
            MidiEvent[] copy;
            lock(sync) copy=events.ToArray();
                var result = new StringBuilder("time,event,channel,note,name,raw_velocity,output_velocity,duration_ms,forward_ms,raw_hex\r\n");
                foreach(var item in copy)
                    result.AppendFormat(CultureInfo.InvariantCulture,"{0:yyyy-MM-dd HH:mm:ss.fff},{1},{2},{3},{4},{5},{6},{7},{8:F4},{9:X2} {10:X2} {11:X2}\r\n",
                        item.Time,item.Action,item.Channel,item.Note,NoteName(item.Note),item.RawVelocity,
                        item.OutputVelocity,item.DurationMs<0 ? "" : item.DurationMs.ToString("F2",CultureInfo.InvariantCulture),
                        item.ForwardMs,item.RawMessage&255,(item.RawMessage>>8)&255,(item.RawMessage>>16)&255);
                return result.ToString();
        }
    }
}
