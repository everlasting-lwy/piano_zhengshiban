using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PianoDesktop
{
    public sealed class PianoKeyboard : Control
    {
        public int BaseNote=60;
        private MonitorSnapshot snapshot=new MonitorSnapshot();
        private double elapsed;
        public PianoKeyboard(){DoubleBuffered=true;BackColor=Color.White;AccessibleName="接收到的 MIDI 琴键状态";}
        public void UpdateNotes(MonitorSnapshot value,double milliseconds)
        {snapshot=value;elapsed=milliseconds;Invalidate();}
        private static bool Black(int note)
        {int p=note%12;return p==1||p==3||p==6||p==8||p==10;}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if(Width<100||Height<50)return;
            var whites=new List<int>();
            for(int i=0;i<18;i++)if(!Black(BaseNote+i))whites.Add(BaseNote+i);
            float width=(Width-4f)/whites.Count,height=Height-4f;
            e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
            for(int i=0;i<whites.Count;i++)DrawKey(e.Graphics,whites[i],new RectangleF(2+i*width,2,width-2,height),false);
            int whiteIndex=0;
            for(int i=0;i<18;i++)
            {
                int note=BaseNote+i;
                if(!Black(note))whiteIndex++;
                else DrawKey(e.Graphics,note,new RectangleF(2+whiteIndex*width-width*.31f,2,width*.60f,height*.61f),true);
            }
        }
        private void DrawKey(Graphics g,int note,RectangleF rect,bool black)
        {
            bool active=snapshot.Active[note];
            bool flash=snapshot.LastPressedMs[note]>0 && elapsed-snapshot.LastPressedMs[note]<120;
            Color fill=active?Color.FromArgb(25,176,131):flash?Color.FromArgb(155,227,199):black?Color.FromArgb(34,46,65):Color.FromArgb(247,249,252);
            using(var brush=new SolidBrush(fill))g.FillRectangle(brush,rect);
            using(var pen=new Pen(active?Color.FromArgb(10,135,99):Color.FromArgb(205,214,225)))g.DrawRectangle(pen,rect.X,rect.Y,rect.Width,rect.Height);
            using(var brush=new SolidBrush(active||black?Color.White:Color.FromArgb(55,70,91)))
            using(var format=new StringFormat {Alignment=StringAlignment.Center,LineAlignment=StringAlignment.Far})
                g.DrawString(MidiMonitor.NoteName(note),Font,brush,new RectangleF(rect.X,rect.Y,rect.Width,rect.Height-9),format);
        }
    }

    public sealed class VelocityGraph : Control
    {
        private MonitorSnapshot snapshot=new MonitorSnapshot();
        public VelocityGraph(){DoubleBuffered=true;BackColor=Color.White;AccessibleName="最近四十次击键的原始与输出力度曲线";}
        public void UpdateHistory(MonitorSnapshot value){snapshot=value;Invalidate();}
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Rectangle area=new Rectangle(30,20,Math.Max(1,Width-45),Math.Max(1,Height-53));
            using(var pen=new Pen(Color.FromArgb(228,234,241)))
            using(var brush=new SolidBrush(Color.Gray))
            {
                for(int i=0;i<3;i++)
                {
                    int velocity=i==2?127:i*64;
                    float y=area.Bottom-velocity*area.Height/127f;
                    e.Graphics.DrawLine(pen,area.Left,y,area.Right,y);
                    e.Graphics.DrawString(velocity.ToString(),Font,brush,0,y-7);
                }
            }
            DrawLine(e.Graphics,area,snapshot.RawHistory,Color.FromArgb(59,130,246));
            DrawLine(e.Graphics,area,snapshot.OutputHistory,Color.FromArgb(19,157,117));
            using(var brush=new SolidBrush(Color.FromArgb(59,130,246)))e.Graphics.DrawString("原始力度",Font,brush,30,Height-24);
            using(var brush=new SolidBrush(Color.FromArgb(19,157,117)))e.Graphics.DrawString("输出力度",Font,brush,125,Height-24);
        }
        private void DrawLine(Graphics graphics,Rectangle area,int[] values,Color color)
        {
            if(values==null||values.Length==0)return;
            var points=new PointF[values.Length];
            for(int i=0;i<values.Length;i++)points[i]=new PointF(area.Left+i*area.Width/39f,area.Bottom-values[i]*area.Height/127f);
            using(var pen=new Pen(color,2))if(points.Length>1)graphics.DrawLines(pen,points);
            using(var brush=new SolidBrush(color))foreach(var point in points)graphics.FillEllipse(brush,point.X-2,point.Y-2,4,4);
        }
    }
}
