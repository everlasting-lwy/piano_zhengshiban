﻿param([string]$OutputDirectory='')
$ErrorActionPreference = 'Stop'
$tools = Split-Path $PSScriptRoot -Parent
$output = if($OutputDirectory){[System.IO.Path]::GetFullPath($OutputDirectory)}else{Join-Path $tools 'PianoMonitor'}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework/v4.0.30319/csc.exe'
}
New-Item -ItemType Directory -Force -Path $output | Out-Null
$sources = @((Join-Path $tools 'FpgaMidiSpeakers.cs')) + @(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' | Select-Object -ExpandProperty FullName)
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ /codepage:65001 /warn:4 /warnaserror+ `
    /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll `
    "/win32manifest:$(Join-Path $PSScriptRoot 'app.manifest')" "/out:$(Join-Path $output 'PianoMonitor.exe')" @sources
if ($LASTEXITCODE -ne 0) { throw "C# build failed: $LASTEXITCODE" }
if($output -ne (Join-Path $tools 'PianoMonitor')) {
    Get-ChildItem -LiteralPath (Join-Path $tools 'PianoMonitor') -File | Where-Object {$_.Extension -eq '.md' -or $_.Name -eq 'PianoMonitor.exe.config'} | Copy-Item -Destination $output -Force
}
Write-Output (Join-Path $output 'PianoMonitor.exe')
