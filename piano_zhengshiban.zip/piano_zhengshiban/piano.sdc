# ACG525-V2 active oscillator U3: 50 MHz, FPGA ball T9.
create_clock -name sys_clk -period 20.000 [get_ports {sys_clk}]
set_clock_uncertainty 0.100 -setup -to [get_clocks {sys_clk}]
# Human controls/UART/HC-SR04 are asynchronous to sys_clk.
# Two-stage synchronization is present in the board wrapper or original drivers.
set_false_path -from [get_ports {sys_rst_n key_in[*] key_timbre key_mode key_vol_up key_vol_down key_octave bt_rxd hmi_rxd hc_echo}]
# External serial outputs have protocol timing, not a sys_clk-synchronous receiver.
# Internal timing closure alone does not prove external-board signal integrity.
