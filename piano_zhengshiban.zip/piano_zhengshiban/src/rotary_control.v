// Full quadrature accumulation cancels contact bounce and partial reversals.
// All arithmetic starts from actual shared parameter readback, never a shadow.
module rotary_control #(
 parameter integer SAMPLE_CYCLES=500,
 parameter integer AB_FILTER_SAMPLES=10,
 parameter integer SW_FILTER_SAMPLES=500,
 parameter integer LONG_PRESS_SAMPLES=100000,
 parameter integer TRANSITIONS_PER_STEP=4,
 parameter integer INITIAL_SELECTION=0,
 parameter integer REVERSE=0
)(
 input wire clk,rst_n,a,b,sw_n,
 input wire [31:0] values,
 output reg [2:0] selected,
 output reg [7:0] command,
 output reg command_valid
);
 reg [2:0] meta,sync;
 reg [15:0] sample_count,sw_count;
 reg [19:0] hold_count;
 reg [1:0] previous;
 localparam AB_COUNT_WIDTH=AB_FILTER_SAMPLES<2 ? 1 : $clog2(AB_FILTER_SAMPLES+1);
 reg [AB_COUNT_WIDTH-1:0] ab_count;
 reg [1:0] ab_candidate;
 reg ab_initialized;
 reg sw_stable,long_sent;
 reg signed [3:0] accumulated;
 reg signed [1:0] direction;
 reg [4:0] current,maximum,neutral;
 reg [7:0] prefix;
 wire tick=sample_count==SAMPLE_CYCLES-1;
 wire signed [4:0] next_sum=$signed(accumulated)+$signed(direction);
 always @(*)begin
  case({previous,sync[2:1]})
   4'b1110,4'b1000,4'b0001,4'b0111:direction=REVERSE ? -2'sd1 : 2'sd1;
   4'b1101,4'b0100,4'b0010,4'b1011:direction=REVERSE ? 2'sd1 : -2'sd1;
   default:direction=0;
  endcase
  maximum=15;neutral=0;
  case(selected)
   0:begin current={1'b0,values[7:4]};prefix=8'ha0;neutral=15;end
   1:begin current=values[12:8];prefix=8'hb0;maximum=16;neutral=8;end
   2:begin current={1'b0,values[16:13]};prefix=8'hd0;end
   3:begin current={1'b0,values[20:17]};prefix=8'h10;end
   4:begin current={1'b0,values[24:21]};prefix=8'h20;end
   5:begin current={1'b0,values[28:25]};prefix=8'h30;end
   6:begin current={3'd0,values[30:29]};prefix=8'h50;maximum=2;end
   7:begin current={1'b0,values[3:0]};prefix=8'h80;neutral=15;end
   default:begin current=0;prefix=8'ha0;end
  endcase
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   meta<=7;sync<=7;sample_count<=0;sw_count<=0;hold_count<=0;
   previous<=3;sw_stable<=1;long_sent<=0;accumulated<=0;
   ab_count<=0;ab_candidate<=3;ab_initialized<=0;
   selected<=INITIAL_SELECTION;command<=0;command_valid<=0;
  end else begin
   meta<={a,b,sw_n};sync<=meta;
   command_valid<=0;
   sample_count<=tick ? 16'd0 : sample_count+1'b1;
   if(tick)begin
    // Sampling alone does not debounce A/B. Learn the initial resting phase,
    // then accept only a phase held stable for the configured sample count.
    if(sync[2:1]!=ab_candidate)begin ab_candidate<=sync[2:1];ab_count<=1;end
    else if(ab_count<AB_FILTER_SAMPLES)ab_count<=ab_count+1'b1;
    if(AB_FILTER_SAMPLES<=1 ||
       (sync[2:1]==ab_candidate && ab_count>=AB_FILTER_SAMPLES-1))begin
     previous<=sync[2:1];
     if(!ab_initialized)begin ab_initialized<=1;accumulated<=0;end
     else if(previous!=sync[2:1])begin
     if(direction==0)accumulated<=0;
     else if(next_sum>=TRANSITIONS_PER_STEP)begin
      accumulated<=0;command_valid<=1;
      command<=prefix+((current<maximum) ? current+5'd1 : maximum);
     end else if(next_sum<=-TRANSITIONS_PER_STEP)begin
      accumulated<=0;command_valid<=1;
      command<=prefix+((current!=0) ? current-5'd1 : 5'd0);
     end else accumulated<=next_sum[3:0];
     end
    end
    if(sync[0]!=sw_stable)begin
     if(sw_count==SW_FILTER_SAMPLES-1)begin
      sw_stable<=sync[0];sw_count<=0;
      if(sync[0])begin
       if(!long_sent)selected<=selected+1'b1;
       hold_count<=0;long_sent<=0;
      end
     end else sw_count<=sw_count+1'b1;
    end else sw_count<=0;
    if(!sw_stable && !long_sent && !sync[0])begin
     if(hold_count==LONG_PRESS_SAMPLES-1)begin
      command<=prefix+neutral;command_valid<=1;long_sent<=1;
     end else hold_count<=hold_count+1'b1;
    end
   end
  end
 end
endmodule
