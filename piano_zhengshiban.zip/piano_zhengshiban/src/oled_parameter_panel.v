// SSD1306 128x64 page-mode display; streams characters without framebuffer.
// 0x3c/0x3d are 7-bit addresses. Missing/stuck display never gates audio.
module oled_parameter_panel #(
 parameter integer I2C_DIV=40,
 parameter integer BOOT_CYCLES=5000000,
 parameter integer REFRESH_CYCLES=5000000,
 parameter integer RETRY_CYCLES=50000000,
 parameter integer TIMEOUT_CYCLES=50000,
 parameter integer COLUMN_OFFSET=0
)(
 input wire clk,rst_n,
 input wire [2:0] selected,
 input wire [31:0] values,
 input wire [2:0] volume_source,
 inout wire scl,sda,
 output reg online,frame_done
);
 localparam BOOT=0,INIT=1,INIT_WAIT=2,FRAME=3,CMD=4,CMD_WAIT=5,
 DATA=6,DATA_WAIT=7,REFRESH=8,RETRY=9,DISPLAY_ON=10,DISPLAY_ON_WAIT=11;
 reg [3:0] state;
 reg [31:0] wait_count,snapshot;
 reg [2:0] selection,page;
 reg [2:0] source_snapshot;
 reg address_high;
 reg start;
 reg [10:0] length;
 reg [1:0] kind;
 wire [10:0] index;
 wire busy,done,error;
 reg [7:0] outgoing;
 wire [7:0] address=address_high ? 8'h7a : 8'h78;
 wire [6:0] x=index[6:0]-7'd2;
 wire [4:0] char_column=x/6;
 wire [2:0] font_column=x%6;
 reg [167:0] line;
 reg [7:0] character;
 wire [7:0] font_pixels;
 reg [4:0] current,maximum;
 reg [7:0] shown_value,shown_max,delay_ms;
 reg [7:0] bar_width;
 function [7:0] tens;input [4:0] n;begin tens=(n>=10) ? 8'd49 : 8'd48;end endfunction
 function [7:0] ones;input [4:0] n;begin ones=8'd48+(n>=10 ? n-5'd10 : n);end endfunction
 always @(*)begin
  current=0;maximum=15;
  case(selection)
   0:current={1'b0,snapshot[7:4]};
   1:begin current=snapshot[12:8];maximum=16;end
   2:current={1'b0,snapshot[16:13]};
   3:current={1'b0,snapshot[20:17]};
   4:current={1'b0,snapshot[24:21]};
   5:current={1'b0,snapshot[28:25]};
   6:begin current={3'd0,snapshot[30:29]};maximum=2;end
   7:current={1'b0,snapshot[3:0]};
  endcase
  case(snapshot[30:29])
   1:delay_ms=126;2:delay_ms=168;default:delay_ms=84;
  endcase
  shown_value=current;shown_max=maximum;
  bar_width=(current==maximum) ? 8'd128 :
            selection==6 ? {current[1:0],6'd0} : {current,3'd0};
  line="                     ";
  case(page)
   0:line="PIANOLINK LOCAL      ";
   1:case(selection)
   3'd0:line="01 EXPRESSION        ";
   3'd1:line="02 BEND CENTER 08    ";
   3'd2:line="03 VIBRATO           ";
   3'd3:line="04 REVERB            ";
   3'd4:line="05 ECHO              ";
   3'd5:line="06 CHORUS            ";
   3'd6:line="07 TIME              ";
   3'd7:line="08 VOLUME            ";
     endcase
   2:begin
    line="VALUE 00 / 15        ";
    line[167-6*8-:8]=tens(current);line[167-7*8-:8]=ones(current);
    line[167-11*8-:8]=tens(maximum);line[167-12*8-:8]=ones(maximum);
    if(selection==6)begin
     line="TIME 000 MS          ";
     case(snapshot[30:29])
      1:begin line[167-5*8-:8]="1";line[167-6*8-:8]="2";line[167-7*8-:8]="6";end
      2:begin line[167-5*8-:8]="1";line[167-6*8-:8]="6";line[167-7*8-:8]="8";end
      default:begin line[167-5*8-:8]="0";line[167-6*8-:8]="8";line[167-7*8-:8]="4";end
     endcase
    end
   end
   4:begin
    line="REV 00  ECHO 00      ";
    line[167-4*8-:8]=tens({1'b0,snapshot[20:17]});line[167-5*8-:8]=ones({1'b0,snapshot[20:17]});
    line[167-13*8-:8]=tens({1'b0,snapshot[24:21]});line[167-14*8-:8]=ones({1'b0,snapshot[24:21]});
   end
   5:begin
    line="CHR 00  TIME 000     ";
    line[167-4*8-:8]=tens({1'b0,snapshot[28:25]});line[167-5*8-:8]=ones({1'b0,snapshot[28:25]});
    case(snapshot[30:29])
     1:begin line[167-13*8-:8]="1";line[167-14*8-:8]="2";line[167-15*8-:8]="6";end
     2:begin line[167-13*8-:8]="1";line[167-14*8-:8]="6";line[167-15*8-:8]="8";end
     default:begin line[167-13*8-:8]="0";line[167-14*8-:8]="8";line[167-15*8-:8]="4";end
    endcase
   end
   6:begin
    line="EXP 00  BEND 00      ";
    line[167-4*8-:8]=tens({1'b0,snapshot[7:4]});line[167-5*8-:8]=ones({1'b0,snapshot[7:4]});
    line[167-13*8-:8]=tens(snapshot[12:8]);line[167-14*8-:8]=ones(snapshot[12:8]);
   end
   7:begin
    line="VIB 00  VOL 00       ";
    line[167-4*8-:8]=tens({1'b0,snapshot[16:13]});line[167-5*8-:8]=ones({1'b0,snapshot[16:13]});
    line[167-12*8-:8]=tens({1'b0,snapshot[3:0]});line[167-13*8-:8]=ones({1'b0,snapshot[3:0]});
   end
  endcase
  if(page==2)begin
   line[167-14*8-:8]="S";line[167-15*8-:8]="R";line[167-16*8-:8]="C";
   case(source_snapshot)
    1:line[167-18*8-:8]="E";
    2:line[167-18*8-:8]="H";
    3:line[167-18*8-:8]="B";
    4:line[167-18*8-:8]="K";
    default:line[167-18*8-:8]="I";
   endcase
  end
  character=char_column<21 ? line[167-char_column*8-:8] : 8'd32;
  outgoing=0;
  if(index==0)outgoing=address;
  else if(index==1)outgoing=(kind==2) ? 8'h40 : 8'h00;
  else if(kind==0)begin
   case(index-2)
    0:outgoing=8'hae;
    1:outgoing=8'h00;
    2:outgoing=8'h10;
    3:outgoing=8'h40;
    4:outgoing=8'h81;
    5:outgoing=8'hcf;
    6:outgoing=8'ha1;
    7:outgoing=8'hc8;
    8:outgoing=8'ha6;
    9:outgoing=8'ha8;
    10:outgoing=8'h3f;
    11:outgoing=8'hd3;
    12:outgoing=8'h00;
    13:outgoing=8'hd5;
    14:outgoing=8'h80;
    15:outgoing=8'hd9;
    16:outgoing=8'hf1;
    17:outgoing=8'hda;
    18:outgoing=8'h12;
    19:outgoing=8'hdb;
    20:outgoing=8'h30;
    21:outgoing=8'h20;
    22:outgoing=8'h02;
    23:outgoing=8'h8d;
    24:outgoing=8'h14;
    default:outgoing=0;
   endcase
  end else if(kind==1)begin
   case(index)
    2:outgoing=8'hb0+{5'd0,page};
    3:outgoing=COLUMN_OFFSET%16;
    4:outgoing=8'h10+COLUMN_OFFSET/16;
    default:outgoing=0;
   endcase
  end else if(kind==3)outgoing=8'haf;
  else if(page==3)begin
   if(x==0 || x==127)outgoing=8'h7e;
   else outgoing=({1'b0,x}<bar_width) ? 8'h7e : 8'h42;
  end else outgoing=(page==1) ? ~font_pixels : font_pixels;
 end
 // One extra fetch phase supplies the synchronous font at DIV=1 as well.
 oled_font_sync font(.clk(clk),.character(character),.column(font_column),.pixels(font_pixels));
 i2c_write_stream #(.DIV(I2C_DIV),.FETCH_DELAY(1),.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) bus(
  .clk(clk),.rst_n(rst_n),.start(start),.length(length),.data(outgoing),.index(index),
  .busy(busy),.done(done),.error(error),.scl(scl),.sda(sda));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=BOOT;wait_count<=0;snapshot<=0;selection<=0;page<=0;address_high<=0;source_snapshot<=0;
   start<=0;length<=0;kind<=0;online<=0;frame_done<=0;
  end else begin
   start<=0;frame_done<=0;
   case(state)
    BOOT:if(wait_count==BOOT_CYCLES-1)begin wait_count<=0;state<=INIT;end
         else wait_count<=wait_count+1'b1;
    INIT:begin kind<=0;length<=27;start<=1;state<=INIT_WAIT;end
    INIT_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else state<=FRAME;
    end
    FRAME:begin snapshot<=values;source_snapshot<=volume_source;selection<=selected;page<=0;state<=CMD;end
    CMD:begin kind<=1;length<=5;start<=1;state<=CMD_WAIT;end
    CMD_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else state<=DATA;
    end
    DATA:begin kind<=2;length<=130;start<=1;state<=DATA_WAIT;end
    DATA_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else if(page==7)begin
      if(!online)state<=DISPLAY_ON;
      else begin frame_done<=1;wait_count<=0;state<=REFRESH;end
     end
     else begin page<=page+1'b1;state<=CMD;end
    end
    DISPLAY_ON:begin kind<=3;length<=3;start<=1;state<=DISPLAY_ON_WAIT;end
    DISPLAY_ON_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else begin online<=1;frame_done<=1;wait_count<=0;state<=REFRESH;end
    end
    REFRESH:if(wait_count==REFRESH_CYCLES-1)begin wait_count<=0;state<=FRAME;end
            else wait_count<=wait_count+1'b1;
    RETRY:if(wait_count==RETRY_CYCLES-1)begin wait_count<=0;state<=INIT;end
          else wait_count<=wait_count+1'b1;
    default:state<=BOOT;
   endcase
  end
 end
endmodule

