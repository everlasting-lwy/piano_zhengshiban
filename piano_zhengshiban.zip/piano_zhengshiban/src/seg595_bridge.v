// ACG525: U13 holds digit selects (active high), U14 holds segments
// {dp,g,f,e,d,c,b,a} (active low). Send U14 first, MSB first.
module seg595_bridge #(
    parameter HALF_PERIOD = 25  // 1 MHz SH_CP at 50 MHz system clock
)(
    input wire clk,
    input wire rst_n,
    input wire [5:0] seg_sel,   // original six-digit active-low select
    input wire [7:0] seg_led,
    output reg ds,
    output reg sh_cp,
    output reg st_cp
);
    localparam LOAD = 3'd0, RISE = 3'd1, FALL = 3'd2,
               LATCH = 3'd3, UNLATCH = 3'd4;
    reg [2:0] state;
    reg [15:0] divider;
    reg [15:0] shift;
    reg [3:0] bit_index;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= LOAD;
            divider <= 0;
            shift <= 16'hFF00;
            bit_index <= 0;
            ds <= 0;
            sh_cp <= 0;
            st_cp <= 0;
        end
        else if (divider == HALF_PERIOD - 1) begin
            divider <= 0;
            case (state)
                LOAD: begin
                    // Capture digit and segment together; don't change them mid-word.
                    // The two leftmost board digits (7:6) are always off.
                    shift <= {seg_led, 2'b00, ~seg_sel};
                    ds <= seg_led[7];
                    sh_cp <= 0;
                    st_cp <= 0;
                    bit_index <= 15;
                    state <= RISE;
                end
                RISE: begin
                    sh_cp <= 1;
                    state <= FALL;
                end
                FALL: begin
                    sh_cp <= 0;
                    if (bit_index == 0)
                        state <= LATCH;
                    else begin
                        shift <= {shift[14:0], 1'b0};
                        ds <= shift[14];
                        bit_index <= bit_index - 1'b1;
                        state <= RISE;
                    end
                end
                LATCH: begin
                    st_cp <= 1;
                    state <= UNLATCH;
                end
                UNLATCH: begin
                    st_cp <= 0;
                    state <= LOAD;
                end
                default: state <= LOAD;
            endcase
        end
        else divider <= divider + 1'b1;
    end
endmodule
