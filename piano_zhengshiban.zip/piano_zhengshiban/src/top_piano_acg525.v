// Board adaptation for ACG525-V2 / GW5A-LV25UG324C2/I1, revision A.
// KEY0=reset, KEY1=timbre, KEY2=mode. See docs/PINOUT.md for P6 wiring.
module top_piano_acg525 #(
    parameter integer ENABLE_VOLUME_KEYS=0,
    parameter integer ENC_INITIAL_SELECTION=7,
    parameter integer ENC_SAMPLE_CYCLES=500,
    parameter integer ENC_AB_FILTER_SAMPLES=10,
    parameter integer ENC_SW_FILTER_SAMPLES=500,
    parameter integer ENC_LONG_PRESS_SAMPLES=100000,
    parameter integer ENC_TRANSITIONS_PER_STEP=4,
    parameter integer ENC_REVERSE=0,
    parameter integer OLED_I2C_DIV=40,
    parameter integer OLED_BOOT_CYCLES=5000000,
    parameter integer OLED_REFRESH_CYCLES=5000000,
    parameter integer OLED_RETRY_CYCLES=50000000,
    parameter integer OLED_TIMEOUT_CYCLES=50000,
    parameter integer OLED_COLUMN_OFFSET=0,
    parameter integer VISUAL_I2C_DIV=40,
    parameter integer VISUAL_BOOT_CYCLES=5000000,
    parameter integer VISUAL_REFRESH_CYCLES=500000,
    parameter integer VISUAL_RETRY_CYCLES=50000000,
    parameter integer VISUAL_TIMEOUT_CYCLES=50000,
`ifdef VISUAL_SSD1306
    parameter integer VISUAL_COLUMN_OFFSET=0,
    parameter integer VISUAL_SH1106=0,
`else
    parameter integer VISUAL_COLUMN_OFFSET=2,
    parameter integer VISUAL_SH1106=1,
`endif
    parameter integer BT_UART_CYCLES=5208,
    parameter integer BT_MS_CYCLES=50000,
    parameter integer BT_WATCHDOG_MS=2000,
    parameter integer SD_INIT_DIV=125,SD_DATA_DIV=8,
    parameter integer SD_POWERUP_CYCLES=500000,SD_INIT_TIMEOUT_CYCLES=100000000
)(
    input wire encoder_a,encoder_b,encoder_sw_n,
    inout wire oled_scl,oled_sda,
    input wire visual_encoder_a,visual_encoder_b,visual_encoder_sw_n,
    inout wire visual_oled_scl,visual_oled_sda,
    output wire sd_cs_n,sd_clk,sd_mosi,input wire sd_miso,
    input wire sys_clk,
    input wire sys_rst_n,
    input wire [17:0] key_in,
    input wire key_timbre,
    input wire key_mode,
    input wire key_vol_up,
    input wire key_vol_down,
    input wire key_octave,
    input wire bt_rxd,
    output wire bt_txd,
    input wire hc_echo,
    output wire hc_trig,
    output wire i2s_bclk,
    output wire i2s_lrck,
    output wire i2s_din,
    output wire [3:0] led,
    output wire uart_txd,
    output wire seg_ds,
    output wire seg_sh_cp,
    output wire seg_st_cp
);
    // FPGA initialization gives a power-on reset; KEY0 asserts it asynchronously.
    // Releasing KEY0 releases the design only after 16 system clocks.
    reg [15:0] reset_pipe = 16'd0;
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) reset_pipe <= 16'd0;
        else reset_pipe <= {reset_pipe[14:0], 1'b1};
    end
    wire core_rst_n = reset_pipe[15];

    // Synchronize all mechanical controls before the original debouncers.
    // UART RX and ultrasonic ECHO have their own synchronizers in the core.
    reg [22:0] keys_meta, keys_sync;
    always @(posedge sys_clk or negedge core_rst_n) begin
        if (!core_rst_n) begin
            keys_meta <= 23'h7FFFFF;
            keys_sync <= 23'h7FFFFF;
        end
        else begin
            keys_meta <= {key_mode,key_timbre,key_octave,key_vol_down,key_vol_up,key_in};
            keys_sync <= keys_meta;
        end
    end
    wire [31:0] panel_state;
    wire [2:0] volume_source;
    wire signed [15:0] pcm_frame;
    wire pcm_frame_valid;
    wire [2:0] local_selected;
    wire [7:0] local_command;
    wire local_command_valid;
    wire [1:0] visual_view;
    wire [2:0] visual_gain_shift;
    wire song_active,song_loaded,song_loading,song_complete,song_wrong;
    wire song_toggle,song_restart,song_next,song_prev;
    wire sd_busy,sd_selected_valid;
    wire [4:0] sd_selected_slot;
    wire [7:0] sd_error;
    wire [17:0] song_target,song_physical;
    wire [11:0] song_step,song_total;
    wire [255:0] spectrum_bars;
    wire spectrum_valid;
    rotary_control #(.SAMPLE_CYCLES(ENC_SAMPLE_CYCLES),
        .AB_FILTER_SAMPLES(ENC_AB_FILTER_SAMPLES),
        .SW_FILTER_SAMPLES(ENC_SW_FILTER_SAMPLES),.LONG_PRESS_SAMPLES(ENC_LONG_PRESS_SAMPLES),
        .TRANSITIONS_PER_STEP(ENC_TRANSITIONS_PER_STEP),.INITIAL_SELECTION(ENC_INITIAL_SELECTION),.REVERSE(ENC_REVERSE)) u_rotary(
        .clk(sys_clk),.rst_n(core_rst_n),.a(encoder_a),.b(encoder_b),.sw_n(encoder_sw_n),
        .values(panel_state),.selected(local_selected),.command(local_command),
        .command_valid(local_command_valid));
    oled_parameter_panel #(.I2C_DIV(OLED_I2C_DIV),.BOOT_CYCLES(OLED_BOOT_CYCLES),
        .REFRESH_CYCLES(OLED_REFRESH_CYCLES),.RETRY_CYCLES(OLED_RETRY_CYCLES),
        .TIMEOUT_CYCLES(OLED_TIMEOUT_CYCLES),.COLUMN_OFFSET(OLED_COLUMN_OFFSET)) u_oled(
        .clk(sys_clk),.rst_n(core_rst_n),.selected(local_selected),
        .values(panel_state),.volume_source(volume_source),
        .scl(oled_scl),.sda(oled_sda),.online(),.frame_done());
    visual_rotary_control #(.SAMPLE_CYCLES(ENC_SAMPLE_CYCLES),
        .AB_FILTER_SAMPLES(ENC_AB_FILTER_SAMPLES),.SW_FILTER_SAMPLES(ENC_SW_FILTER_SAMPLES),
        .LONG_PRESS_SAMPLES(ENC_LONG_PRESS_SAMPLES),
        .TRANSITIONS_PER_STEP(ENC_TRANSITIONS_PER_STEP),.REVERSE(ENC_REVERSE)) u_visual_rotary(
        .clk(sys_clk),.rst_n(core_rst_n),.a(visual_encoder_a),.b(visual_encoder_b),
        .sw_n(visual_encoder_sw_n),.view(visual_view),.gain_shift(visual_gain_shift),
        .guide_active(song_active),.guide_toggle(song_toggle),.guide_restart(song_restart),
        .guide_next(song_next),.guide_prev(song_prev));
    oled_visual_panel #(.I2C_DIV(VISUAL_I2C_DIV),.BOOT_CYCLES(VISUAL_BOOT_CYCLES),
        .REFRESH_CYCLES(VISUAL_REFRESH_CYCLES),.RETRY_CYCLES(VISUAL_RETRY_CYCLES),
        .TIMEOUT_CYCLES(VISUAL_TIMEOUT_CYCLES),.COLUMN_OFFSET(VISUAL_COLUMN_OFFSET),.SH1106(VISUAL_SH1106)) u_visual_oled(
        .clk(sys_clk),.rst_n(core_rst_n),.pcm_frame(pcm_frame),.pcm_frame_valid(pcm_frame_valid),
        .view(visual_view),.gain_shift(visual_gain_shift),
        .spectrum_bars(spectrum_bars),.spectrum_valid(spectrum_valid),
        .guide_active(song_active),.guide_loaded(song_loaded),.guide_complete(song_complete),.guide_wrong(song_wrong),
        .guide_target(song_target),.guide_physical(song_physical),.guide_step(song_step),.guide_total(song_total),
        .sd_busy(sd_busy),.sd_selected_valid(sd_selected_valid),.sd_selected_slot(sd_selected_slot),.sd_error(sd_error),
        .scl(visual_oled_scl),.sda(visual_oled_sda),.online(),.frame_done());
    wire [5:0] seg_sel;
    wire [7:0] seg_led;
    top_piano_test #(.BT_UART_CYCLES(BT_UART_CYCLES),.BT_MS_CYCLES(BT_MS_CYCLES),
                     .BT_WATCHDOG_MS(BT_WATCHDOG_MS),.SD_INIT_DIV(SD_INIT_DIV),.SD_DATA_DIV(SD_DATA_DIV),
                     .SD_POWERUP_CYCLES(SD_POWERUP_CYCLES),.SD_INIT_TIMEOUT_CYCLES(SD_INIT_TIMEOUT_CYCLES)) u_core(
        .sys_clk(sys_clk), .sys_rst_n(core_rst_n),
        .local_command(local_command),.local_command_valid(local_command_valid),.panel_state(panel_state),.volume_source(volume_source),
        .key_in(keys_sync[17:0]),
        .key0(keys_sync[21]), .key1(ENABLE_VOLUME_KEYS ? keys_sync[18] : 1'b1),
        .key2(ENABLE_VOLUME_KEYS ? keys_sync[19] : 1'b1), .key3(keys_sync[20]), .key4(keys_sync[22]),
        .uart_rxd(bt_rxd), .bt_txd(bt_txd),
        .pcm_frame(pcm_frame),.pcm_frame_valid(pcm_frame_valid),
        .oled_spectrum_enable(visual_view==2'd1 && !song_active),
        .oled_spectrum_bars(spectrum_bars),.oled_spectrum_valid(spectrum_valid),
        .song_toggle(song_toggle),.song_restart(song_restart),.song_next(song_next),.song_prev(song_prev),
        .sd_cs_n(sd_cs_n),.sd_clk(sd_clk),.sd_mosi(sd_mosi),.sd_miso(sd_miso),
        .sd_busy(sd_busy),.sd_selected_valid(sd_selected_valid),.sd_selected_slot(sd_selected_slot),.sd_error(sd_error),
        .song_active(song_active),.song_loaded(song_loaded),.song_loading(song_loading),
        .song_complete(song_complete),.song_wrong(song_wrong),.song_target(song_target),
        .song_physical(song_physical),.song_step(song_step),.song_total(song_total),
        .hc_echo(hc_echo), .hc_trig(hc_trig),
        .seg_sel(seg_sel), .seg_led(seg_led),
        .i2s_bclk(i2s_bclk), .i2s_lrck(i2s_lrck), .i2s_din(i2s_din),
        .led(led), .uart_txd(uart_txd)
    );
    // Board LED transistors are active high, matching the original gate signals.
    seg595_bridge u_display(
        .clk(sys_clk), .rst_n(core_rst_n),
        .seg_sel(seg_sel), .seg_led(seg_led),
        .ds(seg_ds), .sh_cp(seg_sh_cp), .st_cp(seg_st_cp)
    );
endmodule
