// Alternate top for the original SSD1306 visual screen. Exposes exactly the
// same54 board signals/CST names; no extra logic or pins beyond parameterization.
module top_piano_acg525_ssd1306(
 input wire encoder_a,encoder_b,encoder_sw_n,
 inout wire oled_scl,oled_sda,
 input wire visual_encoder_a,visual_encoder_b,visual_encoder_sw_n,
 inout wire visual_oled_scl,visual_oled_sda,
 output wire sd_cs_n,sd_clk,sd_mosi,input wire sd_miso,
 input wire sys_clk,sys_rst_n,
 input wire [17:0] key_in,
 input wire key_timbre,key_mode,key_vol_up,key_vol_down,key_octave,
 input wire bt_rxd,hc_echo,
 output wire bt_txd,hc_trig,i2s_bclk,i2s_lrck,i2s_din,
 output wire [3:0] led,
 output wire uart_txd,seg_ds,seg_sh_cp,seg_st_cp
);
 top_piano_acg525 #(.VISUAL_SH1106(0),.VISUAL_COLUMN_OFFSET(0)) u_board(
  .encoder_a(encoder_a),.encoder_b(encoder_b),.encoder_sw_n(encoder_sw_n),
  .oled_scl(oled_scl),.oled_sda(oled_sda),
  .visual_encoder_a(visual_encoder_a),.visual_encoder_b(visual_encoder_b),.visual_encoder_sw_n(visual_encoder_sw_n),
  .visual_oled_scl(visual_oled_scl),.visual_oled_sda(visual_oled_sda),
  .sys_clk(sys_clk),.sys_rst_n(sys_rst_n),.key_in(key_in),
  .sd_cs_n(sd_cs_n),.sd_clk(sd_clk),.sd_mosi(sd_mosi),.sd_miso(sd_miso),
  .key_timbre(key_timbre),.key_mode(key_mode),.key_vol_up(key_vol_up),.key_vol_down(key_vol_down),.key_octave(key_octave),
  .bt_rxd(bt_rxd),.bt_txd(bt_txd),.hc_echo(hc_echo),.hc_trig(hc_trig),
  .i2s_bclk(i2s_bclk),.i2s_lrck(i2s_lrck),.i2s_din(i2s_din),.led(led),
  .uart_txd(uart_txd),.seg_ds(seg_ds),.seg_sh_cp(seg_sh_cp),.seg_st_cp(seg_st_cp));
endmodule
