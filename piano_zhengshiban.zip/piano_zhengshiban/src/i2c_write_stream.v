// Bounded streaming write, open-drain on BOTH pins. Provider supplies byte[index].
module i2c_write_stream #(
 parameter integer DIV=40,
 parameter integer FETCH_DELAY=0,
 parameter integer TIMEOUT_CYCLES=50000
)(
 input wire clk,rst_n,start,
 input wire [10:0] length,
 input wire [7:0] data,
 output reg [10:0] index,
 output reg busy,done,error,
 inout wire scl,sda
);
 localparam IDLE=0,START_WAIT=1,START_HOLD=2,FETCH=3,
 L0=4,L1=5,H0=6,H1=7,AL0=8,AL1=9,AH0=10,AH1=11,
 STOPL0=12,STOPL1=13,STOPH0=14,STOPH1=15,RELEASE=16,GAP=17,PREFETCH=18;
 reg [4:0] state;
 reg scl_low,sda_low;
 reg [15:0] count;
 reg [31:0] timeout_count;
 reg [10:0] last_index;
 reg [7:0] shift;
 reg [2:0] bit_index;
 wire high_wait=state==START_WAIT || state==H0 || state==AH0 || state==STOPH0;
 wire blocked=(high_wait && scl!==1'b1) || (state==START_WAIT && sda!==1'b1);
 assign scl=scl_low ? 1'b0 : 1'bz;
 assign sda=sda_low ? 1'b0 : 1'bz;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;scl_low<=0;sda_low<=0;count<=0;timeout_count<=0;
   index<=0;last_index<=0;shift<=0;bit_index<=7;busy<=0;done<=0;error<=0;
  end else begin
   done<=0;
   if(state==IDLE)begin
    count<=0;timeout_count<=0;scl_low<=0;sda_low<=0;
    if(start && length!=0)begin
     busy<=1;error<=0;index<=0;last_index<=length-1'b1;state<=START_WAIT;
    end
   end else if(blocked)begin
    count<=0;
    if(timeout_count==TIMEOUT_CYCLES-1)begin
     state<=IDLE;scl_low<=0;sda_low<=0;busy<=0;done<=1;error<=1;timeout_count<=0;
    end else timeout_count<=timeout_count+1'b1;
   end else begin
    timeout_count<=0;
    if(count==DIV-1)begin
     count<=0;
     case(state)
      START_WAIT:begin sda_low<=1;state<=START_HOLD;end
      START_HOLD:begin
       scl_low<=1;shift<=data;bit_index<=7;sda_low<=!data[7];state<=L0;
      end
      FETCH:begin shift<=data;bit_index<=7;sda_low<=!data[7];state<=L0;end
      PREFETCH:state<=FETCH;
      L0:state<=L1;
      L1:begin scl_low<=0;state<=H0;end
      H0:state<=H1;
      H1:begin
       scl_low<=1;
       if(bit_index==0)begin sda_low<=0;state<=AL0;end
       else begin bit_index<=bit_index-1'b1;shift<={shift[6:0],1'b0};sda_low<=!shift[6];state<=L0;end
      end
      AL0:state<=AL1;
      AL1:begin scl_low<=0;state<=AH0;end
      AH0:begin if(sda!==1'b0)error<=1;state<=AH1;end
      AH1:begin
       scl_low<=1;
       if(error || index==last_index)begin sda_low<=1;state<=STOPL0;end
       else begin index<=index+1'b1;state<=FETCH_DELAY ? PREFETCH : FETCH;end
      end
      STOPL0:state<=STOPL1;
      STOPL1:begin scl_low<=0;state<=STOPH0;end
      STOPH0:state<=STOPH1;
      STOPH1:begin sda_low<=0;state<=RELEASE;end
      RELEASE:state<=GAP;
      GAP:begin state<=IDLE;busy<=0;done<=1;end
      default:begin state<=IDLE;busy<=0;scl_low<=0;sda_low<=0;error<=1;done<=1;end
     endcase
    end else count<=count+1'b1;
   end
  end
 end
endmodule
