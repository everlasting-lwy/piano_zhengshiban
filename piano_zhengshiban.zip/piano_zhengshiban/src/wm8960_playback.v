// ACG525 WM8960: 12.5 MHz MCLK, 48,828.125 Hz Fs, 16-bit I2S slave.
// Left speaker only. The existing audio sample rate and DSP are unchanged.
module wm8960_playback #(
 parameter integer I2C_DIV=125,
 parameter integer BOOT_CYCLES=5000000,
 parameter integer RESET_CYCLES=5000,
 parameter integer BIAS_CYCLES=10000000,
 parameter integer RETRY_CYCLES=2500000,
 parameter integer TIMEOUT_CYCLES=50000
)(input wire clk,rst_n, inout wire scl,sda,
 output reg ready,fault, output reg [6:0] failed_reg);
 localparam WAIT_BOOT=0,ISSUE=1,WAIT_WRITE=2,SETTLE=3,RETRY=4,RUN=5;
 reg [2:0] state;
 reg [31:0] delay_count,delay_limit;
 reg [4:0] reg_index;
 reg start;
 wire busy,done,error;
 wire [10:0] byte_index;
 reg [15:0] word;
 wire [7:0] byte_data=byte_index==0 ? 8'h34 :
                            byte_index==1 ? word[15:8] : word[7:0];
 // Packed {7-bit register, 9-bit value}; preserve all reserved defaults.
 always @(*)begin
  case(reg_index)
   0:word={7'd15,9'h000}; // Software reset, default DAC soft-mute asserted.
   1:word={7'd5, 9'h008}; // Keep DAC muted throughout clock/power setup.
   2:word={7'd49,9'h037}; // Class D off; reserved [5:0] must remain 0x37.
   3:word={7'd25,9'h1c0}; // VMID 5k + VREF; allow board VMID capacitor to settle.
   4:word={7'd7, 9'h002}; // Slave, standard I2S, 16-bit, normal polarity.
   5:word={7'd4, 9'h000}; // SYSCLK=MCLK; DACDIV=1, Fs=SYSCLK/256.
   6:word={7'd8, 9'h1c0}; // DCLKDIV=16 -> 781.25 kHz, valid class D clock.
   7:word={7'd34,9'h100}; // Left DAC to left output mixer; no analog bypass.
   8:word={7'd37,9'h000}; // Right mixer disconnected.
   9:word={7'd10,9'h1ff}; // Left DAC 0 dB with volume-update latch.
  10:word={7'd11,9'h100}; // Right DAC digital mute.
  11:word={7'd40,9'h173}; // Left speaker PGA -6 dB, conservative fixed gain.
  12:word={7'd41,9'h100}; // Right speaker PGA mute; latch both speaker gains.
  13:word={7'd51,9'h080}; // No AC/DC boost; reserved [8:6]=010.
  14:word={7'd25,9'h0c0}; // Steady-state VMID 50k + VREF; ADC/MIC off.
  15:word={7'd47,9'h008}; // Left output mixer only.
  16:word={7'd26,9'h110}; // Left DAC + left speaker PGA; headphones/PLL off.
  17:word={7'd49,9'h077}; // Enable left class D only after clock and bias settle.
  18:word={7'd5, 9'h000}; // Last transaction: soft unmute.
  default:word={7'd5,9'h008};
  endcase
 end
 i2c_write_stream #(.DIV(I2C_DIV),.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) writer(
  .clk(clk),.rst_n(rst_n),.start(start),.length(11'd3),.data(byte_data),
  .index(byte_index),.busy(busy),.done(done),.error(error),.scl(scl),.sda(sda));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=WAIT_BOOT;delay_count<=0;delay_limit<=0;reg_index<=0;
   start<=0;ready<=0;fault<=0;failed_reg<=0;
  end else begin
   start<=0;
   case(state)
    WAIT_BOOT:if(delay_count>=BOOT_CYCLES-1)begin delay_count<=0;state<=ISSUE;end
              else delay_count<=delay_count+1'b1;
    ISSUE:if(!busy)begin start<=1;state<=WAIT_WRITE;end
    WAIT_WRITE:if(done)begin
     if(error)begin
      fault<=1;failed_reg<=word[15:9];ready<=0;delay_count<=0;state<=RETRY;
     end else if(reg_index==18)begin ready<=1;fault<=0;state<=RUN;end
     else begin
      reg_index<=reg_index+1'b1;delay_count<=0;
      if(reg_index==0 || reg_index==3 || reg_index==16)begin
       delay_limit<=reg_index==3 ? BIAS_CYCLES : RESET_CYCLES;state<=SETTLE;
      end else state<=ISSUE;
     end
    end
    SETTLE:if(delay_count>=delay_limit-1)begin delay_count<=0;state<=ISSUE;end
           else delay_count<=delay_count+1'b1;
    RETRY:if(delay_count>=RETRY_CYCLES-1)begin
     delay_count<=0;reg_index<=0;state<=ISSUE;
    end else delay_count<=delay_count+1'b1;
    RUN:begin end
    default:begin state<=WAIT_BOOT;ready<=0;delay_count<=0;end
   endcase
  end
 end
endmodule
