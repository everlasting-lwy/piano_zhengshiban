`timescale 1ns/1ps
// A display-only snapshot of the PCM stream. Audio never waits for a reader.
module oled_wave_capture #(
    parameter DECIMATE = 4,
    parameter TRIGGER_TIMEOUT = 512
) (
    input wire clk,
    input wire rst_n,
    input wire sample_valid,
    input wire signed [15:0] sample,
    input wire snapshot_request,
    input wire [6:0] read_index,
    output reg snapshot_ready,
    output reg [5:0] y_top,
    output reg [5:0] y_bottom
);
    localparam IDLE = 2'd0, ARMED = 2'd1, CAPTURE = 2'd2;
    localparam DECIMATE_BITS = (DECIMATE > 1) ? $clog2(DECIMATE) : 1;
    localparam WAIT_BITS = (TRIGGER_TIMEOUT > 1) ? $clog2(TRIGGER_TIMEOUT + 1) : 1;

    reg [1:0] state;
    reg previous_negative;
    reg [WAIT_BITS-1:0] wait_count;
    reg [DECIMATE_BITS-1:0] bucket_count;
    reg [6:0] column_index;
    reg [5:0] bucket_top, bucket_bottom;
    reg [5:0] previous_top, previous_bottom;
    reg write_bank, read_bank, frame_valid;

    // Separate unreset synchronous-read RAM banks: 2 x (128 x 12 bits).
    // Only control/valid bits reset. In particular neither RAM nor either RAM
    // read register is in the reset process, allowing block-RAM inference.
    (* syn_ramstyle = "block_ram" *) reg [11:0] bank0 [0:127];
    (* syn_ramstyle = "block_ram" *) reg [11:0] bank1 [0:127];
    reg [11:0] bank0_read, bank1_read;
    reg read_bank_delayed, frame_valid_delayed;

    // The widened signed subtraction preserves y64 for -32768 until clamping.
    wire signed [16:0] scaled_sample = $signed(sample) >>> 10;
    wire signed [16:0] unclamped_y = 17'sd32 - scaled_sample;
    wire [5:0] sample_y = (unclamped_y < 0) ? 6'd0 :
                         (unclamped_y > 63) ? 6'd63 : unclamped_y[5:0];
    wire rising_zero = previous_negative && !sample[15];
    wire capture_start = rst_n && sample_valid &&
        (((state == IDLE) && snapshot_request &&
          (rising_zero || (TRIGGER_TIMEOUT <= 1))) ||
         ((state == ARMED) &&
          (rising_zero || (wait_count >= TRIGGER_TIMEOUT - 1))));
    wire capture_sample = rst_n && sample_valid &&
                          ((state == CAPTURE) || capture_start);
    wire first_in_bucket = capture_start || (bucket_count == 0);
    wire [5:0] current_top = first_in_bucket ? sample_y :
                            ((sample_y < bucket_top) ? sample_y : bucket_top);
    wire [5:0] current_bottom = first_in_bucket ? sample_y :
                               ((sample_y > bucket_bottom) ? sample_y : bucket_bottom);
    wire [6:0] write_index = capture_start ? 7'd0 : column_index;
    wire bucket_complete = capture_sample &&
        ((DECIMATE <= 1) || (!capture_start && (bucket_count == DECIMATE - 1)));
    // Join raw adjacent bucket extents; never feed the connected extent back
    // into the next column, which would incorrectly fill the rest of a frame.
    wire [5:0] connected_top = ((write_index != 0) && (previous_top < current_top)) ?
                               previous_top : current_top;
    wire [5:0] connected_bottom = ((write_index != 0) && (previous_bottom > current_bottom)) ?
                                  previous_bottom : current_bottom;
    wire [11:0] write_data = {connected_top, connected_bottom};

    always @(posedge clk) begin
        if (bucket_complete && !write_bank)
            bank0[write_index] <= write_data;
        bank0_read <= bank0[read_index];
    end

    always @(posedge clk) begin
        if (bucket_complete && write_bank)
            bank1[write_index] <= write_data;
        bank1_read <= bank1[read_index];
    end

    // Match the bank/valid selection to the RAM's one-clock address latency.
    // At a swap edge the read still refers to the old bank; the next edge
    // returns the newly complete bank, including its last column write.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            read_bank_delayed <= 1'b0;
            frame_valid_delayed <= 1'b0;
        end else begin
            read_bank_delayed <= read_bank;
            frame_valid_delayed <= frame_valid;
        end
    end

    always @* begin
        if (!frame_valid_delayed) begin
            y_top = 6'd32;
            y_bottom = 6'd32;
        end else if (read_bank_delayed) begin
            y_top = bank1_read[11:6];
            y_bottom = bank1_read[5:0];
        end else begin
            y_top = bank0_read[11:6];
            y_bottom = bank0_read[5:0];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            previous_negative <= 1'b0;
            wait_count <= 0;
            bucket_count <= 0;
            column_index <= 0;
            bucket_top <= 6'd32;
            bucket_bottom <= 6'd32;
            previous_top <= 6'd32;
            previous_bottom <= 6'd32;
            write_bank <= 1'b1;
            read_bank <= 1'b0;
            frame_valid <= 1'b0;
            snapshot_ready <= 1'b0;
        end else begin
            snapshot_ready <= 1'b0;
            if (sample_valid)
                previous_negative <= sample[15];

            // A sample on the request edge is eligible for trigger/timeout.
            // Duplicate requests while ARMED or CAPTURE are deliberately ignored.
            if ((state == IDLE) && snapshot_request) begin
                state <= ARMED;
                wait_count <= sample_valid ? 1 : 0;
                bucket_count <= 0;
                column_index <= 0;
            end else if ((state == ARMED) && sample_valid) begin
                wait_count <= wait_count + 1'b1;
            end

            if (capture_sample) begin
                state <= CAPTURE;
                bucket_top <= current_top;
                bucket_bottom <= current_bottom;
                if (bucket_complete) begin
                    bucket_count <= 0;
                    previous_top <= current_top;
                    previous_bottom <= current_bottom;
                    if (write_index == 127) begin
                        state <= IDLE;
                        read_bank <= write_bank;
                        write_bank <= !write_bank;
                        frame_valid <= 1'b1;
                        snapshot_ready <= 1'b1;
                    end else begin
                        column_index <= write_index + 1'b1;
                    end
                end else begin
                    bucket_count <= capture_start ? 1 : bucket_count + 1'b1;
                    if (capture_start)
                        column_index <= 0;
                end
            end
        end
    end
endmodule
