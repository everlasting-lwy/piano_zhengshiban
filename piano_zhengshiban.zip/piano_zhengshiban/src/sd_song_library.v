// SD peripheral island: sector traffic and file work never clock-enable audio.
module sd_song_library #(
 parameter integer INIT_DIV=125,DATA_DIV=8,
 parameter integer POWERUP_CYCLES=500000,INIT_TIMEOUT_CYCLES=100000000
)(
 input wire clk,rst_n,
 input wire bt_req_valid,input wire[7:0]bt_req_command,input wire[47:0]bt_req_payload,
 output wire bt_rsp_valid,output wire[7:0]bt_rsp_command,output wire[47:0]bt_rsp_payload,
 output wire g_req_valid,output wire[7:0]g_req_command,output wire[47:0]g_req_payload,
 input wire g_rsp_valid,input wire[7:0]g_rsp_command,input wire[47:0]g_rsp_payload,
 input wire guide_loaded,guide_loading,guide_active,input wire[11:0]guide_total_steps,
 input wire[17:0]physical_keys,input wire local_next,local_prev,
 output wire sd_busy,output wire[4:0]selected_slot,output wire selected_valid,
 output wire[7:0]sd_error,
 output wire sd_cs_n,sd_clk,sd_mosi,input wire sd_miso
);
wire media_ready,media_busy,media_reinit,block_start,block_write,block_done;
wire[31:0]media_sectors,block_lba;
wire[7:0]media_error,rd_data,wr_data;
wire rd_valid,wr_request,wr_valid;wire[8:0]rd_index,wr_index;
wire f_block_start,f_block_write,f_wr_valid,r_block_start,r_block_write,r_wr_valid;
wire[31:0]f_block_lba,r_block_lba;wire[7:0]f_wr_data,r_wr_data;
wire rpc_active,rpc_uncertain,storage_idle;
wire bridge_rsp_valid,rpc_rsp_valid;wire[7:0]bridge_rsp_command,rpc_rsp_command;
wire[47:0]bridge_rsp_payload,rpc_rsp_payload;
wire is_rpc=(bt_req_command>=8'h20&&bt_req_command<=8'h26)||bt_req_command==8'h28;
wire rpc_begin=bt_req_valid&&bt_req_command==8'h20&&bt_req_payload[7:0]==0;
assign bt_rsp_valid=rpc_rsp_valid||bridge_rsp_valid;
assign bt_rsp_command=rpc_rsp_valid?rpc_rsp_command:bridge_rsp_command;
assign bt_rsp_payload=rpc_rsp_valid?rpc_rsp_payload:bridge_rsp_payload;
assign block_start=rpc_active?r_block_start:f_block_start;
assign block_write=rpc_active?r_block_write:f_block_write;
assign block_lba=rpc_active?r_block_lba:f_block_lba;
assign wr_valid=rpc_active?r_wr_valid:f_wr_valid;
assign wr_data=rpc_active?r_wr_data:f_wr_data;
wire file_request,file_mounted,file_busy,file_done,read_valid,read_ready,source_request,source_valid,write_locked;
wire[1:0]file_operation;wire[4:0]file_slot;
wire[15:0]file_write_size,file_size,read_index,source_index;
wire[31:0]present_slots;
wire[7:0]file_error,file_attributes,read_data,source_data;
sd_spi_block #(.INIT_DIV(INIT_DIV),.DATA_DIV(DATA_DIV),.POWERUP_CYCLES(POWERUP_CYCLES),
 .INIT_TIMEOUT_CYCLES(INIT_TIMEOUT_CYCLES)) u_spi(
 .clk(clk),.rst_n(rst_n),.reinit(media_reinit&&!rpc_active),.start(block_start),.write(block_write),.lba(block_lba),
 .initialized(media_ready),.card_sectors(media_sectors),.busy(media_busy),.done(block_done),.error(media_error),
 .rd_valid(rd_valid),.rd_index(rd_index),.rd_data(rd_data),.wr_request(wr_request),.wr_index(wr_index),.wr_valid(wr_valid),.wr_data(wr_data),
 .cs_n(sd_cs_n),.sclk(sd_clk),.mosi(sd_mosi),.miso(sd_miso));
fat32_file_store u_files(
 .clk(clk),.rst_n(rst_n),.media_ready(media_ready),.media_sectors(media_sectors),.media_error(media_error),
 .request(file_request),.operation(file_operation),.slot(file_slot),.write_size(file_write_size),
 .mounted(file_mounted),.busy(file_busy),.done(file_done),.error(file_error),.file_size(file_size),.present_slots(present_slots),
 .write_locked(write_locked),.file_attributes(file_attributes),
 .read_valid(read_valid),.read_index(read_index),.read_data(read_data),.read_ready(read_ready),
 .source_request(source_request),.source_index(source_index),.source_valid(source_valid),.source_data(source_data),
 .block_start(f_block_start),.block_write(f_block_write),.block_lba(f_block_lba),.block_busy(media_busy||rpc_active),.block_done(block_done&&!rpc_active),.block_error(media_error),
 .rd_valid(rd_valid&&!rpc_active),.rd_index(rd_index),.rd_data(rd_data),.wr_request(wr_request&&!rpc_active),.wr_index(wr_index),.wr_valid(f_wr_valid),.wr_data(f_wr_data));
sd_song_bridge u_bridge(
 .clk(clk),.rst_n(rst_n),.bt_req_valid(bt_req_valid&&!is_rpc),.bt_req_command(bt_req_command),.bt_req_payload(bt_req_payload),
 .bt_rsp_valid(bridge_rsp_valid),.bt_rsp_command(bridge_rsp_command),.bt_rsp_payload(bridge_rsp_payload),
 .remote_active(rpc_active||rpc_begin),.remote_uncertain(rpc_uncertain),.storage_idle(storage_idle),
 .g_req_valid(g_req_valid),.g_req_command(g_req_command),.g_req_payload(g_req_payload),
 .g_rsp_valid(g_rsp_valid),.g_rsp_command(g_rsp_command),.g_rsp_payload(g_rsp_payload),
 .guide_loaded(guide_loaded),.guide_loading(guide_loading),.guide_active(guide_active),.guide_total_steps(guide_total_steps),
 .physical_keys(physical_keys),.local_next(local_next),.local_prev(local_prev),
 .sd_busy(sd_busy),.selected_slot(selected_slot),.selected_valid(selected_valid),.sd_error(sd_error),
 .media_ready(media_ready),.media_busy(media_busy),.media_error(media_error),.media_reinit(media_reinit),
 .file_request(file_request),.file_operation(file_operation),.file_slot(file_slot),.file_write_size(file_write_size),
 .file_mounted(file_mounted),.file_busy(file_busy),.file_done(file_done),.file_error(file_error),.file_size(file_size),
 .present_slots(present_slots),.write_locked(write_locked),.file_attributes(file_attributes),
 .read_valid(read_valid),.read_index(read_index),.read_data(read_data),.read_ready(read_ready),
 .source_request(source_request),.source_index(source_index),.source_valid(source_valid),.source_data(source_data));
sd_sector_rpc u_rpc(
 .clk(clk),.rst_n(rst_n),.bt_req_valid(bt_req_valid&&is_rpc),.bt_req_command(bt_req_command),.bt_req_payload(bt_req_payload),
 .bt_rsp_valid(rpc_rsp_valid),.bt_rsp_command(rpc_rsp_command),.bt_rsp_payload(rpc_rsp_payload),
 .session_active(rpc_active),.write_uncertain(rpc_uncertain),.file_idle(storage_idle&&!file_busy&&!file_request),
 .media_ready(media_ready),.media_sectors(media_sectors),.media_busy(media_busy),.media_error(media_error),
 .block_start(r_block_start),.block_write(r_block_write),.block_lba(r_block_lba),.block_done(block_done&&rpc_active),.block_error(media_error),
 .rd_valid(rd_valid&&rpc_active),.rd_index(rd_index),.rd_data(rd_data),.wr_request(wr_request&&rpc_active),.wr_index(wr_index),.wr_valid(r_wr_valid),.wr_data(r_wr_data));
endmodule
