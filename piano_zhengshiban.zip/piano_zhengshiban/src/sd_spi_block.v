`timescale 1ns/1ps
// Single-block SD memory driver, SPI mode 0. No sector RAM is used here.
// DIV is the number of clk cycles in each SCLK half-period. At 50 MHz the
// defaults are 200 kHz for initialization and 3.125 MHz for block traffic.
// A read's streamed bytes are provisional until done && error == 0.
module sd_spi_block #(
 parameter integer CLOCK_HZ=50000000,
 parameter integer INIT_DIV=125,
 parameter integer DATA_DIV=8,
 parameter integer POWERUP_CYCLES=CLOCK_HZ/100,
 parameter integer INIT_TIMEOUT_CYCLES=CLOCK_HZ*2,
 parameter integer R1_TIMEOUT_BYTES=16,
 parameter integer TOKEN_TIMEOUT_BYTES=100000,
 parameter integer BUSY_TIMEOUT_BYTES=200000,
 parameter integer SOURCE_TIMEOUT_CYCLES=CLOCK_HZ/2
)(
 input wire clk,rst_n,reinit,start,write,
 input wire [31:0] lba,
 output reg initialized,
 output reg [31:0] card_sectors,
 output reg busy,done,
 output reg [7:0] error,
 output reg rd_valid,
 output reg [8:0] rd_index,
 output reg [7:0] rd_data,
 output reg wr_request,
 output reg [8:0] wr_index,
 input wire wr_valid,
 input wire [7:0] wr_data,
 output reg cs_n,sclk,mosi,
 input wire miso
);
function integer width;
 input integer n;integer v;
 begin v=n-1;width=1;while(v>1)begin width=width+1;v=v>>1;end end
endfunction
localparam integer MAX_DIV=(INIT_DIV>DATA_DIV?INIT_DIV:DATA_DIV);
localparam integer MAX_WAIT=(SOURCE_TIMEOUT_CYCLES>POWERUP_CYCLES?SOURCE_TIMEOUT_CYCLES:POWERUP_CYCLES);
localparam integer MAX_BYTES=(TOKEN_TIMEOUT_BYTES>BUSY_TIMEOUT_BYTES?TOKEN_TIMEOUT_BYTES:BUSY_TIMEOUT_BYTES)>R1_TIMEOUT_BYTES?
 (TOKEN_TIMEOUT_BYTES>BUSY_TIMEOUT_BYTES?TOKEN_TIMEOUT_BYTES:BUSY_TIMEOUT_BYTES):R1_TIMEOUT_BYTES;
localparam [7:0] POWER=0,POWER_CLOCK=1,POWER_NEXT=2,WAIT_BYTE=3,
 CMD_GAP=4,CMD_SELECT=5,CMD_SEND=6,CMD_NEXT=7,R1_SEND=8,R1_CHECK=9,
 RESP0=10,RESP8=11,EXT_SEND=12,EXT_NEXT=13,CHECK_R7=14,
 RESP55=15,RESP41=16,RESP58=17,CHECK_OCR=18,RESP9=19,
 TOKEN_SEND=20,TOKEN_CHECK=21,READ_SEND=22,READ_NEXT=23,CRC_HI=24,CRC_HI_NEXT=25,
 CRC_LO=26,CRC_CHECK=27,CHECK_CSD=28,RESP16=29,IDLE=30,RESP_BLOCK=31,
 WRITE_TOKEN=32,WRITE_WAIT=33,WRITE_NEXT=34,WRITE_CRC_HI=35,WRITE_CRC_LO=36,
 WRITE_RESP=37,WRITE_RESP_CHECK=38,WRITE_BUSY=39,WRITE_BUSY_CHECK=40,
 FINISH_GAP=41,FINISH_DONE=42,RESP59=43,WRITE_STATUS=44,WRITE_STATUS_CHECK=45,WRITE_PRE=46;
// Error codes: 01 init deadline, 02 no R1, 03 R1 refused, 04 R7,
// 05 OCR, 06 CSD/capacity, 07 data CRC, 08 token deadline, 09 data token,
// 0a write response, 0b write busy, 0c source deadline, 0d LBA range,
// 0e write programming/status error (CMD13 R2).
reg [7:0] state,byte_return,command_return;
reg spi_active,spi_done;
reg [width(MAX_DIV)-1:0] div_count;
reg [2:0] bit_count;
reg [7:0] tx_shift,rx_shift,byte_result;
reg [47:0] command_frame;
reg [2:0] command_pos;
reg [6:0] command_crc7;
reg [7:0] r1;
reg [31:0] extended;
reg [1:0] ext_pos;
reg [7:0] ext_return;
reg [width(MAX_BYTES+1)-1:0] byte_count;
reg [width(MAX_WAIT+1)-1:0] wait_count;
reg [width(INIT_TIMEOUT_CYCLES+1)-1:0] init_count;
reg [3:0] power_bytes;
reg init_active,v2,high_capacity,block_write,reading_csd,reinit_pending;
reg [8:0] data_index;
reg [15:0] crc;
reg [7:0] crc_hi;
// Retain only CSD fields that affect addressing; never buffer a whole sector.
reg [1:0] csd_structure;
reg [3:0] csd_read_bl_len;
reg [11:0] csd_sc_size;
reg [21:0] csd_hc_size;
reg [2:0] csd_size_mult;
wire [width(MAX_DIV)-1:0] selected_div=initialized?DATA_DIV:INIT_DIV;
wire [32:0] hc_sectors=({11'd0,csd_hc_size}+33'd1)<<10;
wire [21:0] sc_blocks=({10'd0,csd_sc_size}+22'd1) << ({1'b0,csd_size_mult}+4'd2);
wire [23:0] sc_sectors=csd_read_bl_len==9?{2'b0,sc_blocks}:
 csd_read_bl_len==10?{1'b0,sc_blocks,1'b0}:{sc_blocks,2'b0};

// Calls only occur at a completed byte boundary: SCLK is low, and stays low
// while waiting for a write source. CS never creates an extra clock edge.
task transfer;
 input [7:0] value;input [7:0] next_state;
 begin
  tx_shift<=value;rx_shift<=0;bit_count<=7;div_count<=0;
  mosi<=value[7];sclk<=0;spi_active<=1;byte_return<=next_state;state<=WAIT_BYTE;
 end
endtask
task command_start;
 input [5:0] cmd;input [31:0] arg;input [7:0] next_state;
 begin
  // Build CRC7 while the first five command bytes leave on MOSI. The sixth
  // byte is filled after the final argument bit, with no extra SPI clocks.
  command_frame<={{2'b01,cmd},arg,8'hff};command_crc7<=0;
  command_return<=next_state;command_pos<=0;cs_n<=1;state<=CMD_GAP;
 end
endtask
task finish;
 input [7:0] result;
 begin error<=result;init_active<=0;wr_request<=0;cs_n<=1;state<=FINISH_GAP;end
endtask

always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  initialized<=0;card_sectors<=0;busy<=1;done<=0;error<=0;
  rd_valid<=0;rd_index<=0;rd_data<=0;wr_request<=0;wr_index<=0;
  cs_n<=1;sclk<=0;mosi<=1;state<=POWER;
  spi_active<=0;spi_done<=0;div_count<=0;bit_count<=0;tx_shift<=8'hff;rx_shift<=0;byte_result<=0;
  byte_return<=0;command_return<=0;command_frame<=0;command_pos<=0;command_crc7<=0;r1<=0;
  extended<=0;ext_pos<=0;ext_return<=0;byte_count<=0;wait_count<=0;init_count<=0;
  power_bytes<=0;init_active<=1;v2<=0;high_capacity<=0;block_write<=0;reading_csd<=0;reinit_pending<=0;
  data_index<=0;crc<=0;crc_hi<=0;
  csd_structure<=0;csd_read_bl_len<=0;csd_sc_size<=0;csd_hc_size<=0;csd_size_mult<=0;
 end else begin
  done<=0;rd_valid<=0;spi_done<=0;
  if(reinit)reinit_pending<=1;
  if((reinit || reinit_pending) && !spi_active)begin
   initialized<=0;card_sectors<=0;busy<=1;error<=0;wr_request<=0;
   cs_n<=1;sclk<=0;mosi<=1;spi_active<=0;state<=POWER;
   wait_count<=0;init_count<=0;power_bytes<=0;init_active<=1;
   v2<=0;high_capacity<=0;reinit_pending<=0;
  end else if(init_active && init_count>=INIT_TIMEOUT_CYCLES-1 && !spi_active)begin
   // Abort only after a falling edge, never by truncating a high pulse.
   finish(8'h01);
  end else begin
   if(init_active && init_count<INIT_TIMEOUT_CYCLES-1)init_count<=init_count+1'b1;
   if(spi_active)begin
    if(div_count>=selected_div-1'b1)begin
     div_count<=0;
     if(!sclk)begin
      sclk<=1;rx_shift<={rx_shift[6:0],miso};
      if(byte_return==CMD_NEXT&&command_pos<5)
       command_crc7<={command_crc7[5:0],1'b0}^((command_crc7[6]^tx_shift[7])?7'h09:7'h00);
      // Only payload transfers advance CRC16. For reads (including CSD),
      // consume the same MISO bit sampled above; writes consume MOSI's bit.
      // Token, response and checksum bytes leave this accumulator unchanged.
      if(byte_return==READ_NEXT||byte_return==WRITE_NEXT)
       crc<={crc[14:0],1'b0}^((crc[15]^(byte_return==READ_NEXT?miso:tx_shift[7]))?16'h1021:16'h0000);
     end
     else begin
      sclk<=0;
      if(bit_count==0)begin spi_active<=0;spi_done<=1;byte_result<=rx_shift;mosi<=1;end
      else begin bit_count<=bit_count-1'b1;tx_shift<={tx_shift[6:0],1'b1};mosi<=tx_shift[6];end
     end
    end else div_count<=div_count+1'b1;
   end
   case(state)
    POWER:if(wait_count>=POWERUP_CYCLES-1)begin wait_count<=0;state<=POWER_CLOCK;end else wait_count<=wait_count+1'b1;
    POWER_CLOCK:transfer(8'hff,POWER_NEXT);
    POWER_NEXT:if(power_bytes==9)command_start(0,0,RESP0);else begin power_bytes<=power_bytes+1'b1;state<=POWER_CLOCK;end
    WAIT_BYTE:if(spi_done)state<=byte_return;
    CMD_GAP:transfer(8'hff,CMD_SELECT);
    CMD_SELECT:begin cs_n<=0;state<=CMD_SEND;end
    CMD_SEND:transfer(command_frame[47:40],CMD_NEXT);
    CMD_NEXT:begin
     if(command_pos==4)command_frame<={{command_crc7,1'b1},40'hffffffffff};
     else command_frame<={command_frame[39:0],8'hff};
     if(command_pos==5)begin byte_count<=0;state<=R1_SEND;end
     else begin command_pos<=command_pos+1'b1;state<=CMD_SEND;end
    end
    R1_SEND:transfer(8'hff,R1_CHECK);
    R1_CHECK:if(byte_result[7]==1'b0)begin r1<=byte_result;state<=command_return;end
     else if(byte_count>=R1_TIMEOUT_BYTES-1)finish(8'h02);
     else begin byte_count<=byte_count+1'b1;state<=R1_SEND;end
    RESP0:if(r1==8'h01)command_start(8,32'h000001aa,RESP8);else finish(8'h03);
    RESP8:if(r1==8'h05)begin v2<=0;command_start(55,0,RESP55);end
     else if(r1==8'h01)begin v2<=1;extended<=0;ext_pos<=0;ext_return<=CHECK_R7;state<=EXT_SEND;end
     else finish(8'h03);
    EXT_SEND:transfer(8'hff,EXT_NEXT);
    EXT_NEXT:begin extended<={extended[23:0],byte_result};if(ext_pos==3)state<=ext_return;else begin ext_pos<=ext_pos+1'b1;state<=EXT_SEND;end end
    CHECK_R7:if(extended==32'h000001aa)command_start(55,0,RESP55);else finish(8'h04);
    RESP55:if(r1==8'h01 || r1==8'h00)command_start(41,v2?32'h40000000:32'h00000000,RESP41);else finish(8'h03);
    RESP41:if(r1==8'h01)command_start(55,0,RESP55);
     else if(r1==8'h00)command_start(58,0,RESP58);else finish(8'h03);
    RESP58:if(r1==8'h00)begin extended<=0;ext_pos<=0;ext_return<=CHECK_OCR;state<=EXT_SEND;end else finish(8'h03);
    CHECK_OCR:if(extended[31]==1'b1 && extended[21:20]!=0 && (v2 || extended[30]==1'b0))begin
     high_capacity<=v2 && extended[30];command_start(59,1,RESP59);
    end else finish(8'h05);
    RESP59:if(r1==8'h00)command_start(9,0,RESP9);else finish(8'h03);
    RESP9:if(r1==8'h00)begin reading_csd<=1;byte_count<=0;state<=TOKEN_SEND;end else finish(8'h03);
    TOKEN_SEND:transfer(8'hff,TOKEN_CHECK);
    TOKEN_CHECK:if(byte_result==8'hfe)begin data_index<=0;crc<=0;state<=READ_SEND;end
     else if(byte_result[7:4]==4'h0)finish(8'h09);
     else if(byte_count>=TOKEN_TIMEOUT_BYTES-1)finish(8'h08);
     else begin byte_count<=byte_count+1'b1;state<=TOKEN_SEND;end
    READ_SEND:transfer(8'hff,READ_NEXT);
    READ_NEXT:begin
     if(reading_csd)begin
      case(data_index)
       0:csd_structure<=byte_result[7:6];
       5:csd_read_bl_len<=byte_result[3:0];
       6:csd_sc_size[11:10]<=byte_result[1:0];
       7:begin csd_sc_size[9:2]<=byte_result;csd_hc_size[21:16]<=byte_result[5:0];end
       8:begin csd_sc_size[1:0]<=byte_result[7:6];csd_hc_size[15:8]<=byte_result;end
       9:begin csd_hc_size[7:0]<=byte_result;csd_size_mult[2:1]<=byte_result[1:0];end
       10:csd_size_mult[0]<=byte_result[7];
      endcase
     end
     else begin rd_valid<=1;rd_index<=data_index;rd_data<=byte_result;end
     if(data_index==(reading_csd?9'd15:9'd511))state<=CRC_HI;
     else begin data_index<=data_index+1'b1;state<=READ_SEND;end
    end
    CRC_HI:transfer(8'hff,CRC_HI_NEXT);
    CRC_HI_NEXT:begin crc_hi<=byte_result;state<=CRC_LO;end
    CRC_LO:transfer(8'hff,CRC_CHECK);
    CRC_CHECK:if({crc_hi,byte_result}==crc)begin if(reading_csd)state<=CHECK_CSD;else finish(0);end else finish(8'h07);
    CHECK_CSD:begin
     if(high_capacity && csd_structure==2'b01 && hc_sectors!=0 && !hc_sectors[32])begin
      card_sectors<=hc_sectors[31:0];initialized<=1;finish(0);
     end else if(!high_capacity && csd_structure==2'b00 && csd_read_bl_len>=9 && csd_read_bl_len<=11 && sc_sectors!=0 && sc_sectors<=24'd8388608)begin
      card_sectors<={8'd0,sc_sectors};command_start(16,512,RESP16);
     end else finish(8'h06);
    end
    RESP16:if(r1==8'h00)begin initialized<=1;finish(0);end else finish(8'h03);
    IDLE:if(start && initialized)begin
     busy<=1;error<=0;block_write<=write;reading_csd<=0;
     if(lba<card_sectors)command_start(write?24:17,high_capacity?lba:(lba<<9),RESP_BLOCK);else finish(8'h0d);
    end
    RESP_BLOCK:if(r1==8'h00)begin
     byte_count<=0;crc<=0;data_index<=0;wait_count<=0;
     if(block_write)state<=WRITE_PRE;else state<=TOKEN_SEND;
    end else finish(8'h03);
    WRITE_PRE:transfer(8'hff,WRITE_TOKEN); // NWR: at least eight clocks after R1.
    WRITE_TOKEN:transfer(8'hfe,WRITE_WAIT);
    WRITE_WAIT:begin
     wr_request<=1;wr_index<=data_index;
     if(wr_request && wr_valid)begin
      wr_request<=0;wait_count<=0;transfer(wr_data,WRITE_NEXT);
     end else if(wait_count>=SOURCE_TIMEOUT_CYCLES-1)finish(8'h0c);
     else wait_count<=wait_count+1'b1;
    end
    WRITE_NEXT:if(data_index==511)state<=WRITE_CRC_HI;
     else begin data_index<=data_index+1'b1;state<=WRITE_WAIT;end
    WRITE_CRC_HI:transfer(crc[15:8],WRITE_CRC_LO);
    WRITE_CRC_LO:transfer(crc[7:0],WRITE_RESP);
    WRITE_RESP:transfer(8'hff,WRITE_RESP_CHECK);
    WRITE_RESP_CHECK:if(byte_result[4:0]==5'h05)begin byte_count<=0;state<=WRITE_BUSY;end
     else if(byte_result==8'hff && byte_count<R1_TIMEOUT_BYTES-1)begin byte_count<=byte_count+1'b1;state<=WRITE_RESP;end
     else finish(8'h0a);
    WRITE_BUSY:transfer(8'hff,WRITE_BUSY_CHECK);
    WRITE_BUSY_CHECK:if(byte_result==8'hff)command_start(13,0,WRITE_STATUS);
     else if(byte_count>=BUSY_TIMEOUT_BYTES-1)finish(8'h0b);
     else begin byte_count<=byte_count+1'b1;state<=WRITE_BUSY;end
    WRITE_STATUS:if(r1==8'h00)transfer(8'hff,WRITE_STATUS_CHECK);else finish(8'h0e);
    WRITE_STATUS_CHECK:if(byte_result==8'h00)finish(0);else finish(8'h0e);
    FINISH_GAP:transfer(8'hff,FINISH_DONE);
    FINISH_DONE:begin busy<=0;done<=1;state<=IDLE;end
    default:begin state<=IDLE;end
   endcase
  end
 end
end
endmodule
