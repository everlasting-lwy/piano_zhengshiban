// Exact oled_font glyphs, addressed as {character,column}; one rising-edge read.
// Columns 5..7 and unsupported characters are blank, as in the original font.
module oled_font_sync(
    input wire clk,
    input wire [7:0] character,
    input wire [2:0] column,
    output reg [7:0] pixels
);
    (* syn_romstyle="block_rom" *) reg [7:0] font [0:2047];
    initial $readmemh("rom/oled_font.hex",font);
    always @(posedge clk) pixels<=font[{character,column}];
endmodule
