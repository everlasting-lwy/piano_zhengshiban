// Independent SSD1306 visual display. One frame freezes controls and its data.
// Header y0..7; graph y8..63, zero y36. XY is mono x(t),x(t-64Ts).
// 0x3c/0x3d are 7-bit addresses. Missing/stuck display never gates audio.
module oled_visual_panel #(
 parameter integer I2C_DIV=40,
 parameter integer BOOT_CYCLES=5000000,
 parameter integer REFRESH_CYCLES=500000,
 parameter integer RETRY_CYCLES=50000000,
 parameter integer TIMEOUT_CYCLES=50000,
 parameter integer COLUMN_OFFSET=0,
 parameter integer SH1106=0
)(
 input wire clk,rst_n,
 input wire signed [15:0] pcm_frame,
 input wire pcm_frame_valid,
 input wire [1:0] view,
 input wire [2:0] gain_shift,
 input wire [255:0] spectrum_bars,
 input wire spectrum_valid,
 input wire guide_active,guide_loaded,guide_complete,guide_wrong,
 input wire [17:0] guide_target,guide_physical,
 input wire [11:0] guide_step,guide_total,
 input wire sd_busy,sd_selected_valid,
 input wire [4:0] sd_selected_slot,
 input wire [7:0] sd_error,
 inout wire scl,sda,
 output reg online,frame_done
);
 localparam BOOT=0,INIT=1,INIT_WAIT=2,FRAME=3,CMD=4,CMD_WAIT=5,
 DATA=6,DATA_WAIT=7,REFRESH=8,RETRY=9,DISPLAY_ON=10,DISPLAY_ON_WAIT=11,
 SNAPSHOT_WAIT=12,SNAPSHOT_REQUEST=13,XY_CLEAR=14,XY_POINT_ADDR=15,
 XY_POINT_WAIT=16,XY_PIXEL_WAIT=17,XY_PIXEL_WRITE=18,XY_FINISH=19,DECIMAL_WAIT=20;
 reg [4:0] state;
 reg [31:0] wait_count;
 reg [2:0] page;
 reg address_high;
 reg start;
 reg [10:0] length;
 reg [1:0] kind;
 wire [10:0] index;
 wire busy,done,error;
 reg [7:0] outgoing;
 wire [7:0] address=address_high ? 8'h7a : 8'h78;
 reg capture_request;
 wire capture_ready;
 wire [5:0] y_top,y_bottom;
 // During a data byte, read its successor. The control byte prefetches x=0.
 // index changes immediately before FETCH; DIV=1 allows only one clock.
 wire [6:0] capture_read_index=(kind==2 && index>=2) ? index[6:0]-7'd1 : 7'd0;
 reg [10:0] pixel_index;
 reg [7:0] held_pixels;
 wire [7:0] prefetched_pixels;
 wire [7:0] stream_pixels=(index==pixel_index) ? held_pixels : prefetched_pixels;


 reg [1:0] frame_view;
 reg [2:0] frame_gain;
 reg [255:0] latest_bars,frame_bars;
 reg frame_loaded,frame_complete,frame_wrong;
 reg [17:0] frame_target,frame_physical;
 reg [11:0] frame_step,frame_total;
 reg frame_sd_busy,frame_sd_valid;
 reg [4:0] frame_sd_slot;
 // A21-bit signed path contains every16-bit sample at16X before saturation.
 wire signed [20:0] wide_pcm=$signed({{5{pcm_frame[15]}},pcm_frame}) <<< frame_gain;
 wire signed [15:0] gained_pcm=(wide_pcm>21'sd32767) ? 16'sh7fff :
  (wide_pcm < -21'sd32768) ? 16'sh8000 : wide_pcm[15:0];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)latest_bars<=0;
  else if(spectrum_valid)latest_bars<=spectrum_bars;
 end
 // Seven eighths maps the original64 rows into56 graph rows:32 becomes36.
 function [5:0] graph_y;
  input [5:0] y;
  reg [8:0] seven_y;
  begin seven_y=({3'd0,y}<<3)-y;graph_y=6'd8+seven_y[8:3];end
 endfunction
 function [7:0] wave_pixels;
  input [2:0] pg;
  input [5:0] top,bottom;
  integer bit_number,row;
  begin
   wave_pixels=0;
   for(bit_number=0;bit_number<8;bit_number=bit_number+1)begin
    row=pg*8+bit_number;
    if(row>=8 && (row==36 || (row>=graph_y(top) && row<=graph_y(bottom))))
     wave_pixels[bit_number]=1;
   end
  end
 endfunction
 wire [6:0] display_x=capture_read_index;
 reg [7:0] header_character;
 reg [2:0] header_column;
 reg [8*21-1:0] guide_line;
 wire [15:0] step_bcd,total_bcd,slot_bcd;
 wire decimal_done;
 oled_decimal_serial u_decimal(.clk(clk),.rst_n(rst_n),.start(state==FRAME),
  .value0(guide_loaded ? (guide_complete ? guide_total : guide_step+12'd1) : 12'd0),
  .value1(guide_total),.value2({7'd0,sd_selected_slot}+12'd1),
  .done(decimal_done),.bcd0(step_bcd),.bcd1(total_bcd),.bcd2(slot_bcd));
 integer character_index;
 always @(*)begin
  header_character=" ";header_column=display_x%6;character_index=display_x/6;
  case(frame_view)
   0:case(character_index)0:header_character="W";1:header_character="A";
     2:header_character="V";3:header_character="E";default:header_character=" ";endcase
   1:case(character_index)0:header_character="S";1:header_character="P";
     2:header_character="E";3:header_character="C";4:header_character="T";
     5:header_character="R";6:header_character="U";7:header_character="M";default:header_character=" ";endcase
   2:case(character_index)0:header_character="X";1:header_character="Y";
     3:header_character="D";4:header_character="E";5:header_character="L";
     6:header_character="A";7:header_character="Y";default:header_character=" ";endcase
  endcase
  if(display_x>=102)begin
   case(character_index)
    17:header_character="X";
    18:case(frame_gain)0,4:header_character="1";1:header_character="2";
       2:header_character="4";3:header_character="8";default:header_character="1";endcase
    19:header_character=(frame_gain==4) ? "6" : " ";
    default:header_character=" ";
   endcase
  end
  guide_line="                     ";
  if(frame_view==3)begin
   if(page==0)begin
    guide_line="GUIDE                ";
    if(!frame_loaded)guide_line="GUIDE        NO SONG ";
    else if(frame_complete)guide_line="GUIDE           DONE ";
    header_character=(character_index<21) ? guide_line[(20-character_index)*8+:8] : " ";
    if(frame_loaded)case(character_index)
     6:header_character=8'd48+{4'd0,step_bcd[15:12]};
     7:header_character=8'd48+{4'd0,step_bcd[11:8]};
     8:header_character=8'd48+{4'd0,step_bcd[7:4]};
     9:header_character=8'd48+{4'd0,step_bcd[3:0]};
     10:header_character="/";
     11:header_character=8'd48+{4'd0,total_bcd[15:12]};
     12:header_character=8'd48+{4'd0,total_bcd[11:8]};
     13:header_character=8'd48+{4'd0,total_bcd[7:4]};
     14:header_character=8'd48+{4'd0,total_bcd[3:0]};
     default:;
    endcase
    if(frame_loaded && !frame_complete && frame_sd_valid)case(character_index)
     17:header_character="S";
     18:header_character=8'd48+{4'd0,slot_bcd[7:4]};
     19:header_character=8'd48+{4'd0,slot_bcd[3:0]};
     default:;
    endcase
   end else begin
    guide_line=!frame_loaded ? "BT LOAD SONG         " : frame_complete ? "SHORT PRESS RESTART  " :
       frame_wrong ? "WRONG - RELEASE ALL  " : "PRESS LIT KEYS       ";
    if(frame_sd_busy)guide_line="SD BUSY - PLEASE WAIT";
    header_character=(character_index<21) ? guide_line[(20-character_index)*8+:8] : " ";
   end
  end
 end
 wire [7:0] header_pixels_read;
 oled_font_sync u_font(.clk(clk),.character(header_character),.column(header_column),.pixels(header_pixels_read));
 wire [7:0] guide_pixels;
 reg [7:0] guide_pixels_read;
 oled_guide_keyboard u_keyboard(.x(display_x),.page(page),.target(frame_target),
  .physical(frame_physical),.pixels(guide_pixels));
 reg [11:0] wide_bar;
 reg [7:0] clipped_bar;
 reg [10:0] bar_product;
 reg [5:0] bar_height;
 reg [7:0] spectrum_pixels;
 integer k,graph_row;
 always @(*)begin
  wide_bar={4'd0,frame_bars[display_x[6:2]*8+:8]} << frame_gain;
  clipped_bar=wide_bar>255 ? 8'd255 : wide_bar[7:0];
  // ceil(level*56/256), without a multiplier or additional DFT.
  bar_product=({3'd0,clipped_bar}<<3)-clipped_bar+11'd31;
  bar_height=bar_product[10:5];
  spectrum_pixels=0;
  for(k=0;k<8;k=k+1)begin
   graph_row=page*8+k;
   if(graph_row>=8 && graph_row>=64-bar_height)spectrum_pixels[k]=1;
  end
 end
 oled_wave_capture u_capture(
  .clk(clk),.rst_n(rst_n),.sample_valid(pcm_frame_valid),.sample(gained_pcm),
  .snapshot_request(capture_request),.read_index(capture_read_index),
  .snapshot_ready(capture_ready),.y_top(y_top),.y_bottom(y_bottom));

 // Dedicated raw mono capture, independent of the Bluetooth capture owner.
 // Gain is applied only after its complete snapshot, so a gain change cannot
 // leave old-gain samples in the64-sample history or tear the frame.
 reg xy_request;
 wire xy_ready;
 wire [15:0] xy_point;
 reg [5:0] xy_point_index;
 visual_capture u_xy_capture(.clk(clk),.rst_n(rst_n),.clear(1'b0),
  .sample_valid(pcm_frame_valid),.sample(pcm_frame),.snapshot_request(xy_request),
  .snapshot_ready(xy_ready),.read_index(xy_point_index),.point_data(xy_point));
 function signed [8:0] axis_gain;
  input [7:0] coordinate;
  input [2:0] gain;
  reg signed [12:0] centered;
  begin
   centered=$signed({1'b0,coordinate})-13'sd128;
   centered=centered <<< gain;
   axis_gain=(centered>127) ? 9'sd127 : (centered < -128) ? -9'sd128 : centered[8:0];
  end
 endfunction
 wire signed [8:0] xy_x_gain=axis_gain(xy_point[7:0],frame_gain);
 wire signed [8:0] xy_y_gain=axis_gain(xy_point[15:8],frame_gain);
 wire signed [9:0] xy_x_mapped=10'sd64+(xy_x_gain >>> 1);
 wire signed [9:0] xy_y_unclamped=10'sd32-(xy_y_gain >>> 2);
 wire [5:0] xy_y_clamped=(xy_y_unclamped<0) ? 6'd0 : (xy_y_unclamped>63) ? 6'd63 : xy_y_unclamped[5:0];
 wire [5:0] xy_y_mapped=graph_y(xy_y_clamped);
 // One1024x8 RAM: initialized by a sequential clear, then64 point writes.
 // It is never rebuilt while I2C is transmitting. Only controls reset.
 (* syn_ramstyle="block_ram" *) reg [7:0] xy_pixels[0:1023];
 reg [7:0] xy_ram_read;
 reg [9:0] xy_clear_address,xy_pixel_address;
 reg [2:0] xy_pixel_bit;
 wire [9:0] xy_ram_address=(state==XY_PIXEL_WAIT || state==XY_PIXEL_WRITE) ?
  xy_pixel_address : {page,capture_read_index};
 wire xy_write_enable=(state==XY_CLEAR || state==XY_PIXEL_WRITE);
 wire [9:0] xy_write_address=(state==XY_CLEAR) ? xy_clear_address : xy_pixel_address;
 wire [7:0] xy_write_data=(state==XY_CLEAR) ? 8'd0 : xy_ram_read | (8'b1<<xy_pixel_bit);
 always @(posedge clk)begin
  xy_ram_read<=xy_pixels[xy_ram_address];
  if(rst_n && xy_write_enable)xy_pixels[xy_write_address]<=xy_write_data;
 end
 reg [7:0] xy_axis_pixels;
 integer axis_bit;
 always @(*)begin
  xy_axis_pixels=0;
  for(axis_bit=0;axis_bit<8;axis_bit=axis_bit+1)
   if(page!=0 && (display_x==64 || page*8+axis_bit==36))xy_axis_pixels[axis_bit]=1;
 end
 // Match font/bar/axis latency to the synchronous capture and pixel RAMs.
 reg [7:0] spectrum_pixels_read,xy_axis_pixels_read;
 always @(posedge clk)begin
  spectrum_pixels_read<=spectrum_pixels;xy_axis_pixels_read<=xy_axis_pixels;
  guide_pixels_read<=guide_pixels;
 end
 assign prefetched_pixels=frame_view==3 ? ((page<=1) ? header_pixels_read : guide_pixels_read) : page==0 ? header_pixels_read :
  frame_view==0 ? wave_pixels(page,y_top,y_bottom) :
  frame_view==1 ? spectrum_pixels_read : (xy_ram_read | xy_axis_pixels_read);

 // On the first clock of a new index the synchronous RAM still presents its
 // prefetched column. Hold it for a slow FETCH, while RAM reads the successor.
 // The bypass also supplies that same column to FETCH when I2C_DIV is one.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin pixel_index<=0;held_pixels<=0;end
  else if(index!=pixel_index)begin
   pixel_index<=index;
   held_pixels<=prefetched_pixels;
  end
 end

 always @(*)begin
  outgoing=0;
  if(index==0)outgoing=address;
  else if(index==1)outgoing=(kind==2) ? 8'h40 : 8'h00;
  else if(kind==0)begin
   case(index-2)
    0:outgoing=8'hae;
    1:outgoing=8'h00;
    2:outgoing=8'h10;
    3:outgoing=8'h40;
    4:outgoing=8'h81;
    5:outgoing=8'hcf;
    6:outgoing=8'ha1;
    7:outgoing=8'hc8;
    8:outgoing=8'ha6;
    9:outgoing=8'ha8;
    10:outgoing=8'h3f;
    11:outgoing=8'hd3;
    12:outgoing=8'h00;
    13:outgoing=8'hd5;
    14:outgoing=8'h80;
    15:outgoing=8'hd9;
    16:outgoing=8'hf1;
    17:outgoing=8'hda;
    18:outgoing=8'h12;
    19:outgoing=8'hdb;
    20:outgoing=8'h30;
    21:outgoing=SH1106 ? 8'had : 8'h20;
    22:outgoing=SH1106 ? 8'h8b : 8'h02;
    23:outgoing=SH1106 ? 8'he3 : 8'h8d;
    24:outgoing=SH1106 ? 8'he3 : 8'h14;
    default:outgoing=0;
   endcase
  end else if(kind==1)begin
   case(index)
    2:outgoing=8'hb0+{5'd0,page};
    3:outgoing=COLUMN_OFFSET%16;
    4:outgoing=8'h10+COLUMN_OFFSET/16;
    default:outgoing=0;
   endcase
  end else if(kind==3)outgoing=8'haf;
  else outgoing=stream_pixels;
 end

 i2c_write_stream #(.DIV(I2C_DIV),.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) bus(
  .clk(clk),.rst_n(rst_n),.start(start),.length(length),.data(outgoing),.index(index),
  .busy(busy),.done(done),.error(error),.scl(scl),.sda(sda));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=BOOT;wait_count<=0;page<=0;address_high<=0;
   start<=0;length<=0;kind<=0;online<=0;frame_done<=0;capture_request<=0;
   frame_view<=0;frame_gain<=0;frame_bars<=0;xy_request<=0;
   frame_loaded<=0;frame_complete<=0;frame_wrong<=0;frame_target<=0;
   frame_physical<=0;frame_step<=0;frame_total<=0;
   frame_sd_busy<=0;frame_sd_valid<=0;frame_sd_slot<=0;
   xy_point_index<=0;xy_clear_address<=128;xy_pixel_address<=0;xy_pixel_bit<=0;
  end else begin
   start<=0;frame_done<=0;capture_request<=0;xy_request<=0;
   case(state)
    BOOT:if(wait_count==BOOT_CYCLES-1)begin wait_count<=0;state<=INIT;end
         else wait_count<=wait_count+1'b1;
    INIT:begin kind<=0;length<=27;start<=1;state<=INIT_WAIT;end
    INIT_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else state<=FRAME;
    end
    FRAME:begin
     if(guide_active)frame_view<=3;
     else frame_view<=(view<=2) ? view : 0;
     frame_gain<=(gain_shift<=4) ? gain_shift : 0;
     frame_bars<=spectrum_valid ? spectrum_bars : latest_bars;
     frame_loaded<=guide_loaded;frame_complete<=guide_complete;frame_wrong<=guide_wrong;
     frame_target<=guide_target;frame_physical<=guide_physical;
     frame_step<=guide_step;frame_total<=guide_total;
     frame_sd_busy<=sd_busy;frame_sd_valid<=sd_selected_valid;frame_sd_slot<=sd_selected_slot;
     state<=DECIMAL_WAIT;
    end
    DECIMAL_WAIT:if(decimal_done)state<=SNAPSHOT_REQUEST;
    SNAPSHOT_REQUEST:begin
     if(frame_view==0)begin capture_request<=1;state<=SNAPSHOT_WAIT;end
     else if(frame_view==2)begin xy_request<=1;state<=SNAPSHOT_WAIT;end
     else begin page<=0;state<=CMD;end
    end
    SNAPSHOT_WAIT:begin
     if(frame_view==0 && capture_ready)begin page<=0;state<=CMD;end
     if(frame_view==2 && xy_ready)begin xy_clear_address<=128;xy_point_index<=0;state<=XY_CLEAR;end
    end
    XY_CLEAR:if(xy_clear_address==1023)state<=XY_POINT_ADDR;
             else xy_clear_address<=xy_clear_address+1'b1;
    XY_POINT_ADDR:state<=XY_POINT_WAIT;
    XY_POINT_WAIT:begin
     xy_pixel_address<={xy_y_mapped[5:3],xy_x_mapped[6:0]};
     xy_pixel_bit<=xy_y_mapped[2:0];state<=XY_PIXEL_WAIT;
    end
    XY_PIXEL_WAIT:state<=XY_PIXEL_WRITE;
    XY_PIXEL_WRITE:begin
     if(xy_point_index==63)state<=XY_FINISH;
     else begin xy_point_index<=xy_point_index+1'b1;state<=XY_POINT_ADDR;end
    end
    XY_FINISH:begin page<=0;state<=CMD;end
    CMD:begin kind<=1;length<=5;start<=1;state<=CMD_WAIT;end
    CMD_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else state<=DATA;
    end
    DATA:begin kind<=2;length<=130;start<=1;state<=DATA_WAIT;end
    DATA_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else if(page==7)begin
      if(!online)state<=DISPLAY_ON;
      else begin frame_done<=1;wait_count<=0;state<=REFRESH;end
     end
     else begin page<=page+1'b1;state<=CMD;end
    end
    DISPLAY_ON:begin kind<=3;length<=3;start<=1;state<=DISPLAY_ON_WAIT;end
    DISPLAY_ON_WAIT:if(done)begin
     if(error)begin address_high<=!address_high;online<=0;wait_count<=0;state<=RETRY;end
     else begin online<=1;frame_done<=1;wait_count<=0;state<=REFRESH;end
    end
    REFRESH:if(wait_count==REFRESH_CYCLES-1)begin wait_count<=0;state<=FRAME;end
            else wait_count<=wait_count+1'b1;
    RETRY:if(wait_count==RETRY_CYCLES-1)begin wait_count<=0;state<=INIT;end
          else wait_count<=wait_count+1'b1;
    default:state<=BOOT;
   endcase
  end
 end
endmodule
