// Three snapshotted 12-bit unsigned values share one double-dabble datapath.
// start is accepted only while idle. Results are valid together on the one-cycle
// done pulse, 36 clocks after acceptance; outputs may update before that pulse.
module oled_decimal_serial(
    input wire clk,
    input wire rst_n,
    input wire start,
    input wire [11:0] value0,value1,value2,
    output reg done,
    output wire [15:0] bcd0,bcd1,bcd2
);
    reg active;
    reg [5:0] bit_index;
    reg [35:0] binary_values;
    reg [47:0] results;
    reg [14:0] work,adjusted;
    assign {bcd0,bcd1,bcd2}=results;
    integer digit;
    always @(*)begin
        adjusted=work;
        // A 12-bit value is at most 4095: the thousands digit never needs add-3.
        for(digit=0;digit<3;digit=digit+1)
            if(work[digit*4+:4]>=5)
                adjusted[digit*4+:4]=work[digit*4+:4]+4'd3;
    end
    wire [15:0] shifted={1'b0,adjusted[13:0],binary_values[bit_index]};
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            active<=0;bit_index<=0;binary_values<=0;
            work<=0;done<=0;results<=0;
        end else begin
            done<=0;
            if(!active)begin
                if(start)begin
                    active<=1;bit_index<=35;work<=0;
                    binary_values<={value0,value1,value2};
                end
            end else begin
                work<=shifted[14:0];
                bit_index<=bit_index-1'b1;
                if(bit_index==24 || bit_index==12 || bit_index==0)begin
                    work<=0;
                    results<={results[31:0],shifted};
                    if(bit_index==0)begin active<=0;done<=1;end
                end
            end
        end
    end
endmodule
