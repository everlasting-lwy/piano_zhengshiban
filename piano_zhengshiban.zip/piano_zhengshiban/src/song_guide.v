// Volatile physical-key song guidance. A download only writes the inactive RAM
// bank; publication is a constant-time bank swap after count and CRC validation.
module song_guide #(
    parameter integer MAX_STEPS=2048
)(
    input wire clk,rst_n,
    input wire request_valid,
    input wire [7:0] request_command,
    input wire [47:0] request_payload,
    input wire local_toggle,local_restart,
    input wire [17:0] physical_keys,
    output reg response_valid,
    output reg [7:0] response_command,
    output reg [47:0] response_payload,
    output reg [17:0] target,
    output reg active,loaded,loading,complete,wrong,
    output reg [11:0] step,total_steps
);
    localparam integer ADDRESS_BITS=(MAX_STEPS<=2)?1:$clog2(MAX_STEPS);
    localparam [15:0] CAPACITY=MAX_STEPS;
    reg [17:0] bank0[0:MAX_STEPS-1];
    reg [17:0] bank1[0:MAX_STEPS-1];
    reg active_bank;
    reg [ADDRESS_BITS-1:0] read_address;
    reg [17:0] read_data;
    reg [1:0] read_wait;
    reg wait_release;
    reg [11:0] stage_total,stage_count;
    reg [15:0] expected_crc,running_crc,crc_work;
    reg [17:0] last_mask,crc_mask;
    // First-step caches let entry, restart and publication update step/target
    // atomically without adding a second RAM read port.
    reg [17:0] first_mask,stage_first_mask;
    reg have_last,commit_retry;
    reg [1:0] crc_phase;

    function [4:0] note_count;
        input [17:0] mask;integer i;
        begin note_count=0;for(i=0;i<18;i=i+1)note_count=note_count+mask[i];end
    endfunction
    function [15:0] crc16_byte;
        input [15:0] crc;input [7:0] value;integer i;reg [15:0] next_crc;
        begin
            next_crc=crc^{value,8'd0};
            for(i=0;i<8;i=i+1)
                next_crc=next_crc[15]?(next_crc<<1)^16'h1021:next_crc<<1;
            crc16_byte=next_crc;
        end
    endfunction
    wire [17:0] requested_mask=request_payload[33:16];
    wire [15:0] crc_input_state=(crc_phase==0)?running_crc:crc_work;
    wire [7:0] crc_input_byte=(crc_phase==3)?crc_mask[15:8]:
        (crc_phase==2)?{6'd0,crc_mask[17:16]}:requested_mask[7:0];
    wire [15:0] next_crc=crc16_byte(crc_input_state,crc_input_byte);
    wire step_parameter_valid=request_payload[47:34]==0 && requested_mask!=0 && note_count(requested_mask)<=4;
    wire write_step=request_valid && crc_phase==0 && request_command==8'h11 &&
        loading && step_parameter_valid && request_payload[15:0]=={4'd0,stage_count} && stage_count<stage_total;
    wire [ADDRESS_BITS-1:0] bank_read_address=read_address;
    // Dedicated synchronous RAM ports, with no array reset or asynchronous read.
    // The read address always belongs to the published song, never staging.
    always @(posedge clk)begin
        if(write_step)begin
            if(active_bank)bank0[stage_count[ADDRESS_BITS-1:0]]<=requested_mask;
            else bank1[stage_count[ADDRESS_BITS-1:0]]<=requested_mask;
        end
        if(active_bank)read_data<=bank1[bank_read_address];
        else read_data<=bank0[bank_read_address];
    end

    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            response_valid<=0;response_command<=0;response_payload<=0;
            target<=0;active<=0;loaded<=0;loading<=0;complete<=0;wrong<=0;
            step<=0;total_steps<=0;active_bank<=0;read_address<=0;read_wait<=0;wait_release<=1;
            stage_total<=0;stage_count<=0;expected_crc<=0;running_crc<=16'hffff;
            crc_work<=0;last_mask<=0;crc_mask<=0;first_mask<=0;stage_first_mask<=0;
            have_last<=0;commit_retry<=0;crc_phase<=0;
        end else begin
            response_valid<=0;
            if(read_wait!=0)begin
                read_wait<=read_wait-1'b1;
                if(read_wait==1)begin target<=read_data;step<=read_address;end
            end
            if(active && loaded && !complete)begin
                if(wait_release)begin
                    if(physical_keys==0)begin wait_release<=0;wrong<=0;end
                end else if(read_wait==0)begin
                    if((physical_keys & ~target)!=0)begin wrong<=1;wait_release<=1;end
                    else if(target!=0 && physical_keys==target)begin
                        wait_release<=1;wrong<=0;
                        if(step+12'd1>=total_steps)begin step<=step+1'b1;complete<=1;target<=0;end
                        else begin read_address<=step+1'b1;read_wait<=2;end
                    end
                end
            end
            // Local controls and command controls have identical restart arming:
            // even a correct key held before entry must first be fully released.
            if(local_toggle)begin
                active<=!active;wrong<=0;wait_release<=1;
                if(!active)begin
                    step<=0;complete<=0;target<=loaded?first_mask:18'd0;
                    read_address<=0;read_wait<=0;
                end
            end
            if(local_restart && active)begin
                step<=0;complete<=0;wrong<=0;wait_release<=1;target<=loaded?first_mask:18'd0;
                read_address<=0;read_wait<=0;
            end

            // One CRC byte per cycle keeps the combinational path small. STEP
            // ACK follows the third byte and is still within four clock cycles.
            if(crc_phase!=0)begin
                crc_phase<=crc_phase-1'b1;
                case(crc_phase)
                    3,2:crc_work<=next_crc;
                    1:begin
                        running_crc<=crc_work;response_valid<=1;response_command<=8'h80;
                        response_payload<=48'h000000010011;
                    end
                    default:;
                endcase
            end else if(request_valid)begin
                response_valid<=1;response_command<=8'h80;
                response_payload<={24'd0,8'd1,8'd0,request_command};
                case(request_command)
                    8'h0f:begin
                        if(request_payload!=0)response_payload[15:8]<=1;
                        else begin response_command<=8'h88;response_payload<={8'd4,8'd18,CAPACITY,8'd1,8'h47};end
                    end
                    8'h10:begin
                        if(request_payload[47:32]!=16'h0001 || request_payload[15:0]==0 || request_payload[15:0]>CAPACITY)
                            response_payload[15:8]<=1;
                        else if(!(loading && stage_total==request_payload[15:0] && expected_crc==request_payload[31:16]))begin
                            loading<=1;stage_total<=request_payload[11:0];stage_count<=0;
                            expected_crc<=request_payload[31:16];running_crc<=16'hffff;have_last<=0;commit_retry<=0;
                        end
                    end
                    8'h11:begin
                        if(!step_parameter_valid)response_payload[15:8]<=1;
                        else if(!loading)response_payload[15:8]<=3;
                        else if(have_last && request_payload[15:0]==({4'd0,stage_count}-16'd1) && requested_mask==last_mask)begin
                            // Only the immediately preceding identical STEP is a retry.
                        end else if(!write_step)response_payload[15:8]<=3;
                        else begin
                            stage_count<=stage_count+1'b1;have_last<=1;last_mask<=requested_mask;
                            if(stage_count==0)stage_first_mask<=requested_mask;
                            crc_mask<=requested_mask;crc_work<=next_crc;
                            crc_phase<=3;response_valid<=0;
                        end
                    end
                    8'h12:begin
                        if(request_payload!=0)response_payload[15:8]<=1;
                        else if(!loading)begin if(!commit_retry)response_payload[15:8]<=3;end
                        else if(stage_count!=stage_total)response_payload[15:8]<=3;
                        else if(running_crc!=expected_crc)begin
                            response_payload[15:8]<=1;loading<=0;have_last<=0;commit_retry<=0;
                        end else begin
                            active_bank<=!active_bank;loaded<=1;loading<=0;commit_retry<=1;have_last<=0;
                            total_steps<=stage_total;step<=0;complete<=0;wrong<=0;wait_release<=1;
                            first_mask<=stage_first_mask;target<=stage_first_mask;read_address<=0;read_wait<=0;
                        end
                    end
                    8'h13:begin
                        if(request_payload[47:8]!=0 || request_payload[7:0]>4)response_payload[15:8]<=1;
                        else case(request_payload[7:0])
                            0:begin active<=0;wrong<=0;wait_release<=1;end
                            1,2:begin
                                if(request_payload[7:0]==1)active<=1;
                                step<=0;complete<=0;wrong<=0;wait_release<=1;target<=loaded?first_mask:18'd0;
                                read_address<=0;read_wait<=0;
                            end
                            3:begin
                                loaded<=0;loading<=0;complete<=0;wrong<=0;step<=0;total_steps<=0;target<=0;
                                read_wait<=0;wait_release<=1;have_last<=0;commit_retry<=0;stage_count<=0;
                            end
                            4:begin loading<=0;have_last<=0;commit_retry<=0;end
                            default:;
                        endcase
                    end
                    8'h14:begin
                        if(request_payload!=0)response_payload[15:8]<=1;
                        else begin
                            response_command<=8'h89;
                            response_payload<={8'd1,3'd0,wrong,loading,complete,active,loaded,4'd0,total_steps,4'd0,step};
                        end
                    end
                    8'h15:begin
                        if(request_payload!=0)response_payload[15:8]<=1;
                        else begin response_command<=8'h8a;response_payload<={6'd0,physical_keys,6'd0,target};end
                    end
                    default:response_payload[15:8]<=2;
                endcase
            end
        end
    end
endmodule
