//****************************************************************************************//
// 模块名：uart_tx —— 异步 UART 发送（直接移植参考工程，11bit shift 架构）
// 协议  ：起始位(低) + 8 数据位(LSB first) + 停止位(高)
// 输入  ：tbus[7:0] + start 脉冲
// 输出  ：tx (物理) + ready (可接新数据)
// 频率  ：sys_clk=50MHz, 115200bps → CD_MAX = 50_000_000 / 115200 = 434
// 架构  ：{2'b11, tbus, 1'b0} 移入 shift，running 时每 CD_MAX 拍右移 1 位
//****************************************************************************************//

module uart_tx(
    input             clk    ,
    input             rst_n  ,
    input      [7:0]  tbus   ,
    input             start  ,
    output reg        tx     ,
    output            ready
);

// 50MHz / 115200 = 434.028 ≈ 434
parameter CD_MAX   = 10'd434;
parameter CD_WIDTH = 4'd10;
// Keep legacy MIDI at 8N2; the independent HMI instance selects 8N1.
parameter STOP_BITS = 2;
localparam LAST_BIT = 8 + STOP_BITS;

reg [CD_WIDTH-1:0] cd_count;
reg [3:0]          count;
reg                running;
reg [10:0]         shift;  // {stop, stop, D7..D0, start} = 11bit

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cd_count <= {CD_WIDTH{1'b0}};
        count    <= 4'd0;
        running  <= 1'b0;
        shift    <= 11'h7ff;  // 默认 IDLE (高)
        tx       <= 1'b1;
    end
    else begin
        if (!running) begin
            // 空闲：等 start
            shift   <= {2'b11, tbus, 1'b0};  // 2停止+8数据+1起始 = 11bit
            running <= start;
            cd_count <= {CD_WIDTH{1'b0}};
            count   <= 4'd0;
        end
        else if (cd_count == CD_MAX - 1'd1) begin
            // 一个 bit 时间到 → 右移
            shift   <= {1'b1, shift[10:1]};
            cd_count <= {CD_WIDTH{1'b0}};
            if (count == LAST_BIT) begin
                running <= 1'b0;
                count   <= 4'd0;
            end
            else
                count <= count + 4'd1;
        end
        else begin
            cd_count <= cd_count + {{(CD_WIDTH-1){1'b0}}, 1'b1};
        end
        tx <= (running == 1'b1) ? shift[0] : 1'b1;
    end
end

assign ready = ((running == 1'b0 && start == 1'b0) ||
                (cd_count == CD_MAX - 1'd1 && count == LAST_BIT));

endmodule
