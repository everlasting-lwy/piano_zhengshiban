// 32 physical parallel harmonic lanes. Four notes share them on successive clocks.
// Each ROM contains ONLY one weighted sine period; summation is real-time HDL.
// One frame captures all voice inputs. Last output arrives11 clocks after tick.
module additive32_bank(
    input wire clk,rst_n,clear,sample_tick,
    input wire [127:0] phase_all,increment_all,
    output reg [63:0] body_all,strike_all,
    output reg [3:0] result_valid
);
    reg [127:0] phase_snapshot,increment_snapshot;
    reg issuing;
    reg [1:0] issue_voice;
    wire [31:0] phase=phase_snapshot[issue_voice*32+:32];
    wire [31:0] increment=increment_snapshot[issue_voice*32+:32];
    reg [6:0] valid_pipe;
    reg [1:0] tag[0:6];
    reg signed [20:0] body_sum,strike_sum;
    integer t;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            phase_snapshot<=0;increment_snapshot<=0;issuing<=0;issue_voice<=0;
            valid_pipe<=0;body_all<=0;strike_all<=0;result_valid<=0;
            for(t=0;t<7;t=t+1)tag[t]<=0;
        end else if(clear) begin
            phase_snapshot<=0;increment_snapshot<=0;issuing<=0;issue_voice<=0;
            valid_pipe<=0;body_all<=0;strike_all<=0;result_valid<=0;
            for(t=0;t<7;t=t+1)tag[t]<=0;
        end else begin
            result_valid<=0;
            valid_pipe<={valid_pipe[5:0],issuing};
            tag[0]<=issue_voice;
            for(t=1;t<7;t=t+1)tag[t]<=tag[t-1];
            if(issuing)begin
                if(issue_voice==3)issuing<=0;
                else issue_voice<=issue_voice+1'b1;
            end
            if(sample_tick)begin
                phase_snapshot<=phase_all;increment_snapshot<=increment_all;
                issuing<=1;issue_voice<=0;
            end
            if(valid_pipe[6])begin
                body_all[tag[6]*16+:16]<=body_sum[15:0];
                strike_all[tag[6]*16+:16]<=strike_sum[15:0];
                result_valid[tag[6]]<=1;
            end
        end
    end

    wire signed [20:0] component[0:31];
    wire [8:0] half_address[0:31];
    wire [15:0] half_magnitude[0:31];
    genvar pair;
    generate for(pair=0;pair<16;pair=pair+1)begin:G_ROM_PAIR
        // Both ports read on the SAME edge:32 concurrent components remain.
        additive32_rom_pair #(.PAIR_INDEX(pair)) rom_pair(
            .clk(clk),.enable0(valid_pipe[1]),.enable1(valid_pipe[1]),
            .address0(half_address[pair*2]),.address1(half_address[pair*2+1]),
            .magnitude0(half_magnitude[pair*2]),.magnitude1(half_magnitude[pair*2+1]));
    end endgenerate
    genvar h;
    generate for(h=0;h<32;h=h+1)begin:G_HARMONIC
        wire signed [15:0] partial_wave;
        additive32_lane #(.HARMONIC(h+1)) lane(
            .clk(clk),.issue(issuing),.stage0(valid_pipe[0]),.stage1(valid_pipe[1]),
            .phase(phase),.increment(increment),
            .half_address(half_address[h]),.half_magnitude(half_magnitude[h]),
            .wave(partial_wave));
        assign component[h]={{5{partial_wave[15]}},partial_wave};
    end endgenerate

    reg signed [20:0] pair_sum[0:15],quad_sum[0:7],oct_sum[0:3];
    integer j;
    // No reset in ROM/sum datapath: resettable tags alone control publication.
    always @(posedge clk)begin
        if(valid_pipe[2])
            for(j=0;j<16;j=j+1)pair_sum[j]<=component[j*2]+component[j*2+1];
        if(valid_pipe[3])
            for(j=0;j<8;j=j+1)quad_sum[j]<=pair_sum[j*2]+pair_sum[j*2+1];
        if(valid_pipe[4])
            for(j=0;j<4;j=j+1)oct_sum[j]<=quad_sum[j*2]+quad_sum[j*2+1];
        if(valid_pipe[5])begin
            body_sum<=oct_sum[0];
            strike_sum<=oct_sum[1]+oct_sum[2]+oct_sum[3];
        end
    end
endmodule

module additive32_lane #(
    parameter integer HARMONIC=1
)(
    input wire clk,issue,stage0,stage1,
    input wire [31:0] phase,increment,
    output reg [8:0] half_address,
    input wire [15:0] half_magnitude,
    output wire signed [15:0] wave
);
    localparam [31:0] MAX_INCREMENT=32'h7fffffff/HARMONIC;
    reg [31:0] phase_low,phase_high;
    reg negative1,negative2;
    reg allowed0,allowed1,allowed2;
    wire [31:0] phase_sum=phase_low+phase_high;
    wire [9:0] phase_address=phase_sum[31:22];
    // Constant shift/add, split across two pipeline stages; no general multiplier.
    function [31:0] low_multiple;
        input [31:0] value;
        integer bit_index;
        reg [31:0] total;
        begin
            total=0;
            for(bit_index=0;bit_index<3;bit_index=bit_index+1)
                if((HARMONIC & (1<<bit_index))!=0)total=total+(value<<bit_index);
            low_multiple=total;
        end
    endfunction
    function [31:0] high_multiple;
        input [31:0] value;
        integer bit_index;
        reg [31:0] total;
        begin
            total=0;
            for(bit_index=3;bit_index<6;bit_index=bit_index+1)
                if((HARMONIC & (1<<bit_index))!=0)total=total+(value<<bit_index);
            high_multiple=total;
        end
    endfunction
    always @(posedge clk)begin
        if(issue)begin
            phase_low<=low_multiple(phase);phase_high<=high_multiple(phase);
            allowed0<=(increment!=0 && increment<=MAX_INCREMENT);
        end
        if(stage0)begin
            // Each existing 512-word port stores the entire positive half.
            half_address<=phase_address[8:0];
            negative1<=phase_address[9];allowed1<=allowed0;
        end
        if(stage1)begin allowed2<=allowed1;negative2<=negative1;end
    end
    assign wave=allowed2 ? (negative2 ? -$signed(half_magnitude) : $signed(half_magnitude)) : 16'sd0;
endmodule
