//****************************************************************************************//
// 模块名：voice_engine —— 单声部 FM 双算子合成引擎（载波 + 调制器 + A/D/R 包络 + 八度）
// 移植  ：jiyinjiang.ino 第212行核心式 sine[(phase + sine[FMphase]*FMamp)>>8] 的硬件化
// 结构  ：调制器 DDS → 正弦表 → ×调制指数 → 扰动载波相位 → 载波正弦表 → ×包络 → 样本
// 音色  ：4 套预设（纯正弦/FM电钢琴/FM钟琴/FM拨弦），参数随 timbre 在起音时锁存
//         调制指数按 fm_idx -= fm_idx>>K 指数衰减（起音亮、延音暗，乐器感来源）
// 流水  ：6 级寄存器流水线（地址→调制ROM→乘法→载波地址→载波ROM→包络乘法），
//         每级延迟 ≤ 一个 18x18 乘法器，保证 50MHz 收敛；相位每采样周期(sample_tick)更新
// 发声  ：gate 上升沿 retrigger（相位清零、包络归零、调制指数复位 a1、锁存音高与参数）
//         busy = gate 或包络未归零，供分配器在 release 尾音结束后回收声部
//****************************************************************************************//

module voice_engine(
    input  wire               sys_clk    ,   // 50MHz
    input  wire               sys_rst_n  ,
    input  wire               mode_clear ,
    input  wire               sample_tick,   // 48.828kHz 采样脉冲（单周期）
    input  wire               gate       ,   // 按键电平：1=按住(attack/sustain)，0=松开(release)
    input  wire        [3:0]  note       ,   // 音符号 1~7（gate=1 期间有效）
    input  wire        [1:0]  timbre     ,   // 音色 0~3
    input  wire        [1:0]  octave     ,   // 八度：0=原位, 1=升(×2), 2=降(÷2)
    input  wire signed [31:0] detune_offset, // Detuning 频率字偏移：+/-66000≈±5cent
    // ⭐ 外部频率 override（特雷门琴/超声测距模式）
    input  wire               use_override,   // 1=用 f_car_ext 覆盖内部 note→频率计算
    input  wire        [31:0] f_car_ext    ,   // 外部直接频率字（32bit 相位累加步进）
    output reg  signed [15:0] wave       ,   // 当前样本（流水持续刷新）
    output wire               busy           // 声部占用中（含 release 尾音）
);

//*****************************************************
//**  1. 音符 → 载波频率字（32bit 相位累加，fs=48828.125Hz）
//*****************************************************
reg [31:0] f_car_base;
always @(*) begin
    case (note)
        4'd1   : f_car_base = 32'd23012828;   // do   261.626
        4'd2   : f_car_base = 32'd25831026;   // re   293.665
        4'd3   : f_car_base = 32'd28994347;   // mi   329.628
        4'd4   : f_car_base = 32'd30718440;   // fa   349.228
        4'd5   : f_car_base = 32'd34480283;   // sol  391.995
        4'd6   : f_car_base = 32'd38702809;   // la   440.000
        4'd7   : f_car_base = 32'd43442435;   // si   493.883
        default: f_car_base = 32'd23012828;
    endcase
end

// 八度移位：0=原位, 1=升八度(×2), 2=降八度(÷2)
wire [31:0] f_car = (octave == 2'd1) ? {f_car_base[30:0], 1'b0} :
                    (octave == 2'd2) ? {1'b0, f_car_base[31:1]} :
                                       f_car_base;

//*****************************************************
//**  2. 音色参数表
//  ratio编码：0=×1, 1=×2, 2=×3, 3=×4（调制器/载波频率比，用移位实现，不占乘法器）
//  a1/a2    ：调制指数起音值/衰减保持值（Q15，0=纯正弦关闭FM）
//  kdec     ：指数衰减常数（fm_idx 每样本减去 fm_idx>>kdec）
//  atk/rel  ：包络起音/释音每样本增量（@48.8k：256≈5.2ms，44≈30ms，7≈234ms）
//*****************************************************
reg [1:0]  ratio;
reg [15:0] fm_a1, fm_a2, atk_step, rel_step, dec_step, sus_lvl;
reg [3:0]  kdec;

always @(*) begin
    case (timbre)
        // 0: 纯正弦（无 FM，A/D/R 包络）
        2'd0: begin ratio=2'd0; fm_a1=16'd0;     fm_a2=16'd0;    kdec=4'd10;
                    atk_step=16'd256;  rel_step=16'd256; dec_step=16'd2; sus_lvl=16'd0; end
        // 1: FM 电钢琴（2 次谐波，中调制度，慢衰减）
        2'd1: begin ratio=2'd1; fm_a1=16'd9000;  fm_a2=16'd1200; kdec=4'd10;
                    atk_step=16'd400;  rel_step=16'd44;  dec_step=16'd3; sus_lvl=16'd0; end
        // 2: FM 钟琴（3 次谐波，强调制，快衰减，长余音）
        2'd2: begin ratio=2'd2; fm_a1=16'd21000; fm_a2=16'd0;    kdec=4'd7;
                    atk_step=16'd2000; rel_step=16'd7;    dec_step=16'd1; sus_lvl=16'd0; end
        // 3: FM 拨弦（基频比，强调制，极快衰减）
        2'd3: begin ratio=2'd0; fm_a1=16'd15000; fm_a2=16'd0;    kdec=4'd6;
                    atk_step=16'd1500; rel_step=16'd16;   dec_step=16'd5; sus_lvl=16'd0; end
    endcase
end

// 调制器频率字（整数倍比，移位+加法）
wire [31:0] f_mod = (ratio == 2'd0) ? f_car                              :
                    (ratio == 2'd1) ? {f_car[30:0], 1'b0}                 :
                    (ratio == 2'd2) ? (f_car + {f_car[30:0], 1'b0})       :
                                      {f_car[29:0], 2'b0};

//*****************************************************
//**  3. gate 上升沿检测 → retrigger；参数/音高锁存
//*****************************************************
reg        gate_d;
wire       start = gate & ~gate_d;

reg [31:0] f_mod_ext;
reg [31:0] car_inc, mod_inc;     // 锁存的载波/调制器频率字
reg [15:0] a1_lat, a2_lat, atk_lat, rel_lat, dec_lat, sus_lat;
reg [3:0]  kdec_lat;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        gate_d   <= 1'b0;
        car_inc  <= 32'd0;
        mod_inc  <= 32'd0;
        a1_lat   <= 16'd0; a2_lat <= 16'd0;
        atk_lat  <= 16'd0; rel_lat <= 16'd0; dec_lat <= 16'd0; sus_lat <= 16'd0; kdec_lat <= 4'd10;
    end
    else if (mode_clear) begin
        gate_d   <= 1'b0;
        car_inc  <= 32'd0;
        mod_inc  <= 32'd0;
        a1_lat   <= 16'd0; a2_lat <= 16'd0;
        atk_lat  <= 16'd0; rel_lat <= 16'd0; dec_lat <= 16'd0; sus_lat <= 16'd0; kdec_lat <= 4'd10;
    end
    else begin
        gate_d <= gate;

        if (use_override) begin
            // ⭐ Theremin 模式：外部频率实时更新（每次 sample_tick 刷新）
            if (sample_tick) begin
                car_inc <= f_car_ext + detune_offset;
                mod_inc <= f_mod_ext;   // 组合逻辑预计算好
            end
            // ⭐ Theremin 模式强制：sus_lat=0xFFFF 永不衰减，env 永远满幅，fm_idx 不衰减
            if (start) begin
                a1_lat   <= fm_a1;  a2_lat  <= fm_a2;
                atk_lat  <= 16'hFFFF; rel_lat <= 16'd128; dec_lat <= 16'h0001;
                sus_lat  <= 16'hFFFF;  // ⭐ 关键！特雷门琴永不衰减
                kdec_lat <= 4'd15;     // ⭐ 最大 kdec → fm_dec = fm_idx>>15 ≈ 0 → fm_idx 几乎不衰减
            end
        end
        else if (start) begin
            // 正常模式：start 时锁存一次
            car_inc  <= f_car + detune_offset;   // ⭐ Detuning：叠加频率偏移
            mod_inc  <= f_mod + detune_offset;   // ⭐ 调制器也偏移，保持 ratio 不变
            a1_lat   <= fm_a1;  a2_lat  <= fm_a2;
            atk_lat  <= atk_step; rel_lat <= rel_step; dec_lat <= dec_step; sus_lat <= sus_lvl; kdec_lat <= kdec;
        end
    end
end

// ⭐ Theremin 模式下调制器频率字（组合逻辑预计算，避免 Quartus 嵌套三元解析 bug）
wire [31:0] f_car_offset = f_car_ext + detune_offset;

always @(*) begin
    case (ratio)
        2'd0:    f_mod_ext = f_car_offset;
        2'd1:    f_mod_ext = {f_car_offset[30:0], 1'b0};
        2'd2:    f_mod_ext = f_car_offset + {f_car_offset[30:0], 1'b0};
        default: f_mod_ext = {f_car_offset[29:0], 2'b0};
    endcase
end

//*****************************************************
//**  4. 相位累加 + 调制指数指数衰减 + A/D/R 包络（采样速率）
//**     gate=1  ：Attack（起音到满幅）→ Decay（按住自然衰减到 sus_lvl）
//**     gate=0  ：Release（线性释音到 0）
//*****************************************************
reg [31:0] ph_car, ph_mod;
reg [15:0] fm_idx;
reg [15:0] env;
reg        env_state;            // 0=Attack  1=Decay
reg [31:0] fm_dec;               // 指数衰减量

// ⭐ 饱和加法：防止 sus_lat=0xFFFF（特雷门琴永不衰减）+ dec_lat 溢出回绕
// 回绕会导致 Decay 比较永远不满足 → env 一直递减到 ~0 又跳回 0xFFFF → 周期性强音
wire [15:0] sus_plus_dec =
    (sus_lat > 16'hFFFF - dec_lat) ? 16'hFFFF : sus_lat + dec_lat;

assign busy = gate || (env != 16'd0);

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        ph_car <= 32'd0; ph_mod <= 32'd0;
        fm_idx <= 16'd0; env    <= 16'd0; env_state <= 1'b0;
    end
    else if (mode_clear) begin
        ph_car <= 32'd0; ph_mod <= 32'd0;
        fm_idx <= 16'd0; env    <= 16'd0; env_state <= 1'b0;
    end
    else if (start) begin
        // 新音符：相位/包络/调制全部从头开始
        ph_car <= 32'd0;
        ph_mod <= 32'd0;
        env    <= 16'd0;
        env_state <= 1'b0;    // 从 Attack 开始
        fm_idx <= a1_lat;
    end
    else if (sample_tick) begin
        ph_car <= ph_car + car_inc;
        ph_mod <= ph_mod + mod_inc;

        // ⭐ 包络：特雷门琴模式 → 永远满幅不走 A/D/R；正常模式 → A/D/R 三段
        if (use_override) begin
            // Theremin：gate=1 → env 永远满幅；gate=0 → Release 到 0
            if (gate)
                env <= 16'hFFFF;
            else if (env <= rel_lat)
                env <= 16'h0000;
            else
                env <= env - rel_lat;
        end
        else if (gate) begin
            if (env_state == 1'b0) begin
                // Attack：起音到满幅后切到 Decay
                if (env >= 16'hFF00) begin
                    env <= 16'hFFFF;
                    env_state <= 1'b1;
                end
                else
                    env <= env + atk_lat;
            end
            else begin
                // Decay：按住期间自然衰减到 sus_lvl（=0 则彻底消失）
                if (env <= sus_plus_dec)   // ⭐ 饱和加法替换 sus_lat + dec_lat
                    env <= sus_lat;
                else
                    env <= env - dec_lat;
            end
        end
        else begin
            // Release：松键线性释音到 0，复位 env_state
            env_state <= 1'b0;
            if (env <= rel_lat)
                env <= 16'h0000;
            else
                env <= env - rel_lat;
        end

        // FM 调制指数：特雷门琴模式不衰减（保持 a1 不变）；正常模式指数衰减到 a2
        if (use_override) begin
            fm_idx <= a1_lat;   // ⭐ 特雷门琴：FM 调制指数永远保持起始值
        end
        else if (fm_idx == 16'd0)
            fm_dec <= 32'd0;
        else begin
            fm_dec <= {16'd0, fm_idx} >> kdec_lat;

            if (fm_idx > a2_lat + fm_dec[15:0])
                fm_idx <= fm_idx - fm_dec[15:0];
            else
                fm_idx <= a2_lat;
        end
    end
end

//*****************************************************
//**  5. 调制器与载波正弦 ROM
//*****************************************************
(* syn_romstyle = "block_rom" *) reg signed [15:0] rom_mod  [0:1023];
(* syn_romstyle = "block_rom" *) reg signed [15:0] rom_car  [0:1023];
initial begin
    $readmemh("sine_1024x16.hex", rom_mod);
    $readmemh("sine_1024x16.hex", rom_car);
end

//*****************************************************
//**  6. FM 声部采样流水
//*****************************************************
reg        [9:0]  am;
reg signed [15:0] mw;
reg signed [31:0] pfm;
reg        [31:0] caddr;
reg signed [15:0] cw;
reg signed [31:0] penv;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        am <= 10'd0; mw <= 16'd0; pfm <= 32'd0;
        caddr <= 32'd0; cw <= 16'd0; penv <= 32'd0;
        wave <= 16'd0;
    end
    else begin
        // —— 基频 FM 路径 ——
        am    <= ph_mod[31:22];
        mw    <= rom_mod[am];
        pfm   <= (mw * $signed({1'b0, fm_idx})) >>> 8;
        caddr <= ph_car + pfm;
        cw    <= rom_car[caddr[31:22]];
        penv  <= cw * $signed({1'b0, env});

        wave <= penv[31:16];
    end
end

endmodule
