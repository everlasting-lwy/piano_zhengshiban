module keyboard_voice_engine #(parameter integer EXPRESSION_ENABLE=0)(
    input wire sys_clk,
    input wire sys_rst_n,
    input wire mode_clear,
    input wire sample_tick,
    input wire gate,
    input wire [4:0] note,
    input wire [1:0] timbre,
    input wire [1:0] octave,
    input wire [15:0] note_level,
    input wire [31:0] pitch_increment,
    input wire signed [15:0] piano_body,piano_strike,
    output wire [31:0] synth_phase,synth_increment,
    output reg signed [15:0] wave,
    output wire busy
);

reg [31:0] frequency_base;
always @(*) begin
    case (note)
        5'd1: frequency_base = 32'd23012828;
        5'd2: frequency_base = 32'd25831026;
        5'd3: frequency_base = 32'd28994347;
        5'd4: frequency_base = 32'd30718440;
        5'd5: frequency_base = 32'd34480283;
        5'd6: frequency_base = 32'd38702809;
        5'd7: frequency_base = 32'd43442435;
        5'd8: frequency_base = 32'd24381242;
        5'd9: frequency_base = 32'd27367019;
        5'd10: frequency_base = 32'd32545054;
        5'd11: frequency_base = 32'd36530588;
        5'd12: frequency_base = 32'd41004198;
        5'd13: frequency_base = 32'd46025656;
        5'd14: frequency_base = 32'd48762484;
        5'd15: frequency_base = 32'd51662052;
        5'd16: frequency_base = 32'd54734038;
        5'd17: frequency_base = 32'd57988694;
        5'd18: frequency_base = 32'd61436880;
        default: frequency_base = 32'd23012828;
    endcase
end

wire [31:0] carrier_frequency = (octave == 2'd1) ? (frequency_base << 1) :
                                (octave == 2'd2) ? (frequency_base >> 1) : frequency_base;
reg [1:0] ratio_select;
reg [15:0] fm_initial, fm_floor, attack_step;
reg [4:0] decay_shift, release_shift;
reg [3:0] fm_decay_shift;

always @(*) begin
    case (timbre)
        2'd0: begin
            ratio_select = 2'd0; fm_initial = 16'd0; fm_floor = 16'd0;
            attack_step = 16'd384; decay_shift = 5'd16;
            release_shift = 5'd10; fm_decay_shift = 4'd13;
        end
        2'd1: begin
            ratio_select = 2'd1; fm_initial = 16'd9000; fm_floor = 16'd2400;
            attack_step = 16'd400; decay_shift = 5'd16;
            release_shift = 5'd10; fm_decay_shift = 4'd13;
        end
        2'd2: begin
            ratio_select = 2'd2; fm_initial = 16'd21000; fm_floor = 16'd1200;
            attack_step = 16'd2000; decay_shift = 5'd17;
            release_shift = 5'd12; fm_decay_shift = 4'd12;
        end
        default: begin
            ratio_select = 2'd0; fm_initial = 16'd15000; fm_floor = 16'd800;
            attack_step = 16'd1500; decay_shift = 5'd15;
            release_shift = 5'd10; fm_decay_shift = 4'd11;
        end
    endcase
end

wire [31:0] modulator_frequency = (ratio_select == 2'd0) ? carrier_frequency :
                                  (ratio_select == 2'd1) ? (carrier_frequency << 1) :
                                  (ratio_select == 2'd2) ? (carrier_frequency + (carrier_frequency << 1)) :
                                                          (carrier_frequency << 2);

reg gate_previous;
reg [4:0] note_latched;
reg [1:0] octave_latched;
reg [1:0] ratio_latched;
reg piano_latched;
reg [31:0] carrier_increment, modulator_increment;
reg [15:0] attack_latched, fm_floor_latched;
reg [4:0] decay_latched, release_latched;
reg [3:0] fm_decay_latched;
reg [31:0] carrier_phase, modulator_phase;
assign synth_phase=carrier_phase;
assign synth_increment=carrier_increment;
wire [31:0] effective_carrier=EXPRESSION_ENABLE ? pitch_increment : carrier_increment;
wire [31:0] effective_modulator=EXPRESSION_ENABLE ?
    (ratio_latched==0 ? pitch_increment : ratio_latched==1 ? (pitch_increment<<1) :
     ratio_latched==2 ? pitch_increment+(pitch_increment<<1) : (pitch_increment<<2)) : modulator_increment;
reg [15:0] fm_index;
reg [23:0] envelope_level, brightness_level;
reg envelope_decay;
reg [23:0] envelope_peak_latched;

wire start_note = gate && (!gate_previous || note != note_latched || octave != octave_latched);
wire [23:0] attack_delta = {attack_latched, 8'd0};
wire [24:0] attack_sum = {1'b0, envelope_level} + {1'b0, attack_delta};
wire [23:0] envelope_delta_raw = envelope_level >> (gate ? decay_latched : release_latched);
wire [23:0] envelope_delta = (envelope_delta_raw == 24'd0) ? 24'd1 : envelope_delta_raw;
wire [23:0] brightness_delta_raw = brightness_level >> (gate ? 5'd13 : release_latched);
wire [23:0] brightness_delta = (brightness_delta_raw == 24'd0) ? 24'd1 : brightness_delta_raw;
wire [15:0] fm_difference = (fm_index > fm_floor_latched) ? fm_index - fm_floor_latched : 16'd0;
wire [15:0] fm_delta_raw = fm_difference >> fm_decay_latched;
wire [15:0] fm_delta = (fm_delta_raw == 16'd0) ? 16'd1 : fm_delta_raw;

assign busy = gate || (envelope_level != 24'd0);

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        gate_previous <= 1'b0;
        note_latched <= 5'd0; octave_latched <= 2'd0; piano_latched <= 1'b1;ratio_latched<=0;
        carrier_increment <= 32'd0; modulator_increment <= 32'd0;
        attack_latched <= 16'd0; fm_floor_latched <= 16'd0;
        decay_latched <= 5'd16; release_latched <= 5'd10; fm_decay_latched <= 4'd13;
        carrier_phase <= 32'd0; modulator_phase <= 32'd0; fm_index <= 16'd0;
        envelope_level <= 24'd0; brightness_level <= 24'd0; envelope_decay <= 1'b0;
        envelope_peak_latched <= 24'hFFFF00;
    end
    else if (mode_clear) begin
        gate_previous <= 1'b0;
        note_latched <= 5'd0; octave_latched <= 2'd0; piano_latched <= 1'b1;ratio_latched<=0;
        carrier_increment <= 32'd0; modulator_increment <= 32'd0;
        attack_latched <= 16'd0; fm_floor_latched <= 16'd0;
        decay_latched <= 5'd16; release_latched <= 5'd10; fm_decay_latched <= 4'd13;
        carrier_phase <= 32'd0; modulator_phase <= 32'd0; fm_index <= 16'd0;
        envelope_level <= 24'd0; brightness_level <= 24'd0; envelope_decay <= 1'b0;
        envelope_peak_latched <= 24'hFFFF00;
    end
    else begin
        gate_previous <= gate;
        if (start_note) begin
            note_latched <= note; octave_latched <= octave; piano_latched <= (timbre == 2'd0);
            carrier_increment <= carrier_frequency; modulator_increment <= modulator_frequency;
            ratio_latched<=ratio_select;
            attack_latched <= attack_step; fm_floor_latched <= fm_floor;
            decay_latched <= decay_shift; release_latched <= release_shift; fm_decay_latched <= fm_decay_shift;
            carrier_phase <= 32'd0; modulator_phase <= 32'd0; fm_index <= fm_initial;
            envelope_level <= 24'd0; brightness_level <= 24'd0; envelope_decay <= 1'b0;
            envelope_peak_latched <= {note_level, 8'd0};
        end
        else if (sample_tick) begin
            carrier_phase <= carrier_phase + effective_carrier;
            modulator_phase <= modulator_phase + effective_modulator;
            if (gate && !envelope_decay) begin
                if (attack_sum >= {1'b0, envelope_peak_latched}) begin
                    envelope_level <= envelope_peak_latched;
                    brightness_level <= envelope_peak_latched;
                    envelope_decay <= 1'b1;
                end
                else begin
                    envelope_level <= envelope_level + attack_delta;
                    brightness_level <= envelope_level + attack_delta;
                end
            end
            else begin
                if (envelope_level <= 24'd256 || envelope_level <= envelope_delta)
                    envelope_level <= 24'd0;
                else
                    envelope_level <= envelope_level - envelope_delta;
                if (brightness_level <= 24'd256 || brightness_level <= brightness_delta)
                    brightness_level <= 24'd0;
                else
                    brightness_level <= brightness_level - brightness_delta;
            end
            if (fm_difference == 16'd0)
                fm_index <= fm_floor_latched;
            else if (fm_difference <= fm_delta)
                fm_index <= fm_floor_latched;
            else
                fm_index <= fm_index - fm_delta;
        end
    end
end

(* syn_romstyle = "block_rom" *) reg signed [15:0] rom_modulator [0:1023];
(* syn_romstyle = "block_rom" *) reg signed [15:0] rom_carrier [0:1023];
initial begin
    $readmemh("sine_1024x16.hex", rom_modulator);
    $readmemh("sine_1024x16.hex", rom_carrier);
end

reg [9:0] modulator_address;
reg signed [15:0] modulator_sample, carrier_rom_sample;
reg signed [32:0] modulation_product;
reg [31:0] modulated_phase;
reg signed [15:0] carrier_sample, transient_sample;
reg signed [32:0] body_product, strike_product;
wire signed [15:0] body_level = body_product[31:16];
wire signed [15:0] strike_level = strike_product[31:16];
wire signed [17:0] body_extended = {{2{body_level[15]}}, body_level};
wire signed [17:0] strike_extended = {{2{strike_level[15]}}, strike_level};
wire signed [17:0] piano_sum = (body_extended >>> 1) + (body_extended >>> 2) + (strike_extended >>> 2);

always @(posedge sys_clk) begin
    modulator_sample <= rom_modulator[modulator_address];
    carrier_rom_sample <= rom_carrier[modulated_phase[31:22]];
end

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        modulator_address <= 10'd0;
        modulation_product <= 33'sd0; modulated_phase <= 32'd0;
        carrier_sample <= 16'sd0; transient_sample <= 16'sd0;
        body_product <= 33'sd0; strike_product <= 33'sd0; wave <= 16'sd0;
    end
    else if (mode_clear) begin
        modulator_address <= 10'd0;
        modulation_product <= 33'sd0; modulated_phase <= 32'd0;
        carrier_sample <= 16'sd0; transient_sample <= 16'sd0;
        body_product <= 33'sd0; strike_product <= 33'sd0; wave <= 16'sd0;
    end
    else begin
        modulator_address <= modulator_phase[31:22];
        modulation_product <= modulator_sample * $signed({1'b0, fm_index});
        modulated_phase <= carrier_phase + (modulation_product[31:0] << 1);
        carrier_sample <= piano_latched ? piano_body : carrier_rom_sample;
        transient_sample <= piano_latched ? piano_strike : 16'sd0;
        body_product <= carrier_sample * $signed({1'b0, envelope_level[23:8]});
        strike_product <= transient_sample * $signed({1'b0, brightness_level[23:8]});
        wave <= piano_latched ? piano_sum[15:0] : body_level;
    end
end

endmodule
