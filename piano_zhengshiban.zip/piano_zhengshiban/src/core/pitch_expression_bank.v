// One multiplier time-shared by four voice contexts; no phase or gate reset.
// bend0..16 maps to -64..64 /1024 (~-112..+105cents). Vibrato ~6Hz.
module pitch_expression_bank(
    input wire clk,rst_n,clear,sample_tick,
    input wire [4:0] bend,
    input wire [3:0] vibrato,
    input wire [127:0] base_all,
    output reg [127:0] adjusted_all
);
    reg [23:0] lfo;
    wire [6:0] triangle=lfo[23] ? ~lfo[22:16] : lfo[22:16];
    wire signed [8:0] tri_center=$signed({2'b0,triangle})-9'sd64;
    wire signed [13:0] vibrato_product=tri_center*$signed({1'b0,vibrato});
    wire signed [9:0] bend_offset=($signed({1'b0,bend})-10'sd8)<<<3;
    wire signed [9:0] correction=bend_offset+(vibrato_product>>>6);
    reg [1:0] voice,stage;
    reg [31:0] base;
    reg signed [9:0] correction_latched;
    reg signed [42:0] product;
    reg signed [43:0] result;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin lfo<=0;voice<=0;stage<=0;base<=0;correction_latched<=0;product<=0;result<=0;adjusted_all<=0;end
        else if(clear)begin lfo<=0;voice<=0;stage<=0;adjusted_all<=0;end
        else begin
            if(sample_tick)lfo<=lfo+24'd2062;
            stage<=stage+1'b1;
            case(stage)
                0:begin base<=base_all[voice*32+:32];correction_latched<=correction;end
                1:product<=$signed({1'b0,base})*correction_latched;
                2:result<=$signed({1'b0,base})+(product>>>10);
                3:begin
                    adjusted_all[voice*32+:32]<=result<0 ? 32'd0 : result>44'sh7fffffff ? 32'h7fffffff : result[31:0];
                    voice<=voice+1'b1;
                end
            endcase
        end
    end
endmodule
