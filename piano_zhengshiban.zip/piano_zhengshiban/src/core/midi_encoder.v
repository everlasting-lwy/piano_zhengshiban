//****************************************************************************************//
// 模块名：midi_encoder —— data 字节 → 24bit MIDI 消息 → 3 字节 → UART
// 修复  ：4 状态握手，解决 tstart 和 tready 的 1 拍重叠竞争
//         S_IDLE → S_SEND(发字节) → S_WAIT_BUSY(UART 真正收到) → S_WAIT_DONE(UART 发完)
//****************************************************************************************//

module midi_encoder(
    input             clk        ,
    input             rst_n      ,

    input      [7:0]  data       ,
    input      [7:0]  volume_in  ,
    input             mstart     ,
    output            mready     ,

    output reg [7:0]  tbus       ,
    output reg        tstart     ,
    input             tready
);

// === 24bit MIDI 组装 ===
reg [23:0] midi;
reg [7:0]  data_reg;
reg [7:0]  volume;

always @(*) begin
    case (data_reg[0])
        1'b0: midi[23:16] = 8'h80;  // NoteOff
        1'b1: midi[23:16] = 8'h90;  // NoteOn
        default: midi[23:16] = 8'h90;
    endcase
    midi[15:8] = data_reg[7:1];       // note number 7bit
    midi[7:0]  = data_reg[0] ? {1'b0, volume[7:1]} : 8'h00;
end

// === 4 状态握手 ===
reg        working;      // 忙标志（驱动 mready）
reg [1:0]  state;
reg [1:0]  datasel;

localparam S_IDLE     = 2'd0,
           S_SEND     = 2'd1,   // tready=1 时发字节
           S_WAIT_BUSY = 2'd2,   // 等 tready 变 0（UART 真正启动）
           S_WAIT_DONE = 2'd3;   // 等 tready 变 1（UART 发完）

assign mready = ~working;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        working <= 1'b0;
        state   <= S_IDLE;
        datasel <= 2'd0;
        tstart  <= 1'b0;
        tbus    <= 8'h00;
        data_reg<= 8'h00;
        volume  <= 8'd100;
    end
    else begin
        tstart <= 1'b0;

        case (state)
            S_IDLE: begin
                if (mstart) begin
                    working  <= 1'b1;
                    data_reg <= data;
                    // Capture parameters together. Later volume changes must
                    // not alter the third byte of this accepted MIDI message.
                    volume   <= volume_in;
                    datasel  <= 2'd0;
                    state    <= S_SEND;
                end
            end

            S_SEND: begin
                // UART 空闲 → 发这个字节
                if (tready) begin
                    tstart <= 1'b1;
                    case (datasel)
                        2'd0: tbus <= midi[23:16];  // Status byte
                        2'd1: tbus <= midi[15:8];   // Note number
                        2'd2: tbus <= midi[7:0];    // Velocity
                        default: tbus <= 8'h00;
                    endcase
                    state <= S_WAIT_BUSY;
                end
            end

            S_WAIT_BUSY: begin
                // 等 UART 捕获 start → tready 变 0
                if (!tready) state <= S_WAIT_DONE;
            end

            S_WAIT_DONE: begin
                // 等 UART 发完 → tready 变 1
                if (tready) begin
                    if (datasel == 2'd2) begin
                        // 3 字节发完！
                        working <= 1'b0;
                        state   <= S_IDLE;
                    end
                    else begin
                        datasel <= datasel + 2'd1;
                        state   <= S_SEND;
                    end
                end
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
