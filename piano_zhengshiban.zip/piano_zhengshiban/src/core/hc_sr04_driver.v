//****************************************************************************************//
// 模块名：hc_sr04_driver —— HC-SR04 超声波测距驱动
// 硬件  ：HC-SR04 模块（VCC=5V, GND=GND, TRIG→FPGA, ECHO→FPGA）
// 原理  ：FPGA 发 ≥10μs 脉冲到 TRIG → HC-SR04 发 8 个 40kHz 超声波 → ECHO 变高
//         ECHO 高电平宽度 = 声波往返时间 → distance(cm) = ECHO_width(μs) / 58
// 周期  ：标准 30ms 一次测距（HC-SR04 建议最大 40Hz）
// 输出  ：distance_cm = 厘米整数（999=无有效回波/超出范围）
//         dist_valid  = 高 1 周期 = 新距离数据有效
// 换算  ：ECHO 高电平每累计 2900 个时钟记 1cm
// 超时  ：60ms 无回波或 ECHO 长时间保持高电平，distance_cm=999
// 分辨率：1cm
//****************************************************************************************//

module hc_sr04_driver(
    input  wire        sys_clk,        // 50MHz
    input  wire        sys_rst_n,
    output reg         hc_trig,        // → HC-SR04 TRIG
    input  wire        hc_echo,        // ← HC-SR04 ECHO
    output reg  [15:0] distance_cm,    // 厘米（整数），999=超出范围
    output reg         dist_valid      // 高 1 周期 = 新距离数据有效
);

// ======== 时序参数（50MHz 时钟）========
localparam TRIG_WIDTH      = 20'd600;       // 12μs 脉冲（≥10μs 要求）
localparam MEASURE_PERIOD  = 24'd1_500_000; // 30ms 周期（标准）
localparam ECHO_TIMEOUT    = 23'd3_000_000; // 60ms 超时（覆盖 ~10m）
localparam US_PER_CM       = 12'd2900;      // 58μs/cm × 50 = 2900 周期/cm

// ======== 状态机 ========
reg [1:0] state;
reg [23:0] period_cnt;      // 30ms 周期倒计时
reg [19:0] trig_cnt;        // TRIG 脉冲宽度计数
reg [22:0] echo_cnt;        // ECHO 高电平宽度计数（最多 3M）
reg [11:0] cm_tick;
reg [10:0] cm_count;
wire       echo_high;       // ECHO 当前状态（组合输出）
wire       echo_rising;     // ECHO 上升沿（组合输出）
wire       echo_falling;    // ECHO 下降沿（组合输出）

localparam S_IDLE       = 2'd0,
           S_TRIG       = 2'd1,
           S_WAIT_ECHO  = 2'd2,
           S_MEASURE    = 2'd3;

// ECHO 边沿检测（两级打一拍）
reg d_echo_d1, d_echo_d2;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        d_echo_d1 <= 1'b0;
        d_echo_d2 <= 1'b0;
    end else begin
        d_echo_d1 <= hc_echo;
        d_echo_d2 <= d_echo_d1;
    end
end
assign echo_rising  = d_echo_d1 & ~d_echo_d2;
assign echo_falling = ~d_echo_d1 & d_echo_d2;
assign echo_high    = d_echo_d1;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        state        <= S_IDLE;
        period_cnt   <= MEASURE_PERIOD;
        trig_cnt     <= 20'd0;
        echo_cnt     <= 23'd0;
        cm_tick      <= 12'd0;
        cm_count     <= 11'd0;
        hc_trig      <= 1'b0;
        distance_cm  <= 16'd999;
        dist_valid   <= 1'b0;
    end
    else begin
        dist_valid <= 1'b0;

        case (state)
            // ============================================================
            S_IDLE: begin
                hc_trig    <= 1'b0;
                echo_cnt   <= 23'd0;
                cm_tick    <= 12'd0;
                cm_count   <= 11'd0;
                period_cnt <= period_cnt - 24'd1;

                if (period_cnt == 24'd0) begin
                    state      <= S_TRIG;
                    trig_cnt   <= TRIG_WIDTH;
                    period_cnt <= MEASURE_PERIOD;   // 重装下一周期
                end
            end

            // ============================================================
            S_TRIG: begin
                hc_trig  <= 1'b1;
                trig_cnt <= trig_cnt - 20'd1;
                if (trig_cnt == 20'd0) begin
                    hc_trig <= 1'b0;
                    state   <= S_WAIT_ECHO;
                end
            end

            // ============================================================
            S_WAIT_ECHO: begin
                echo_cnt <= echo_cnt + 23'd1;  // 超时计数器

                if (echo_rising) begin
                    echo_cnt <= 23'd1;
                    cm_tick  <= 12'd1;
                    cm_count <= 11'd0;
                    state    <= S_MEASURE;
                end
                else if (echo_cnt >= ECHO_TIMEOUT) begin
                    // 超时无回波 → 距离无效
                    echo_cnt    <= 23'd0;
                    state       <= S_IDLE;
                    distance_cm <= 16'd999;
                    dist_valid  <= 1'b1;
                end
            end

            // ============================================================
            S_MEASURE: begin
                if (echo_cnt >= ECHO_TIMEOUT) begin
                    distance_cm <= 16'd999;
                    dist_valid  <= 1'b1;
                    state       <= S_IDLE;
                end
                else if (echo_high) begin
                    echo_cnt <= echo_cnt + 23'd1;
                    if (cm_tick == US_PER_CM - 12'd1) begin
                        cm_tick  <= 12'd0;
                        cm_count <= cm_count + 11'd1;
                    end
                    else cm_tick <= cm_tick + 12'd1;
                end
                else begin
                    distance_cm <= (cm_count == 11'd0) ? 16'd999 : {5'd0, cm_count};
                    dist_valid <= 1'b1;
                    state      <= S_IDLE;
                end
            end

            default: state <= S_IDLE;
        endcase
    end
end

endmodule
