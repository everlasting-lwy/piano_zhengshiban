//****************************************************************************************//
// 模块名：uart_cmd_decoder —— APP 指令解码（1 字节协议）
// 协议  ：高 2 位 = 类别，低 6 位 = 数值
//   00xxxxxx → 音色切换   timbre = xxxxxx[1:0]  (0~3)
//   01xxxxxx → 八度切换   octave = xxxxxx[1:0]  (0~2)
//   10xxxxxx → 音量设置   vol    = xxxxxx[3:0]  (0~15)
//   11xxxxxx → 音符 ON/OFF note=xxxxxx[2:0] (1~7), on=xxxxxx[6]
// 输出  ：每类一个单独的 valid 脉冲 + 对应数值，top 层 OR 叠加到现有逻辑
//****************************************************************************************//

module uart_cmd_decoder(
    input  wire        sys_clk     ,
    input  wire        sys_rst_n   ,
    input  wire [7:0]  rx_data     ,
    input  wire        rx_valid    ,

    // 音色指令
    output reg  [1:0]  bt_timbre   ,
    output reg         bt_timbre_en,

    // 八度指令
    output reg  [1:0]  bt_octave   ,
    output reg         bt_octave_en,

    // 音量指令
    output reg  [3:0]  bt_vol      ,
    output reg         bt_vol_en   ,

    // 音符指令（APP 虚拟键盘）
    output reg         bt_note_on  ,     // 1=按下, 0=松开
    output reg  [2:0]  bt_note_idx ,     // 1~7 (do~si)
    output reg         bt_note_en
);

wire [1:0] cat = rx_data[7:6];

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        bt_timbre    <= 2'd0;
        bt_timbre_en <= 1'b0;
        bt_octave    <= 2'd0;
        bt_octave_en <= 1'b0;
        bt_vol       <= 4'd0;
        bt_vol_en    <= 1'b0;
        bt_note_on   <= 1'b0;
        bt_note_idx  <= 3'd0;
        bt_note_en   <= 1'b0;
    end
    else begin
        // 默认清零（脉冲型 valid）
        bt_timbre_en <= 1'b0;
        bt_octave_en <= 1'b0;
        bt_vol_en    <= 1'b0;
        bt_note_en   <= 1'b0;

        if (rx_valid) begin
            case (cat)
                2'b00: begin   // 音色
                    bt_timbre    <= rx_data[1:0];
                    bt_timbre_en <= 1'b1;
                end
                2'b01: begin   // 八度
                    if (rx_data[1:0] <= 2'd2) begin
                        bt_octave    <= rx_data[1:0];
                        bt_octave_en <= 1'b1;
                    end
                end
                2'b10: begin   // 音量
                    bt_vol    <= rx_data[3:0];
                    bt_vol_en <= 1'b1;
                end
                2'b11: begin   // 音符 ON/OFF
                    bt_note_on  <= rx_data[6];
                    bt_note_idx <= rx_data[2:0];
                    bt_note_en  <= 1'b1;
                end
            endcase
        end
    end
end

endmodule
