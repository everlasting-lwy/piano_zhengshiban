//****************************************************************************************//
// 模块名：mixer —— 4 声部衰减混音器
// 每路 /2 衰减（-6dB）后求和：2 音不削波，3~4 音轻微饱和保护
// 单音 -6dB 仍清晰响亮；多音和弦无削波失真
//****************************************************************************************//

module mixer(
    input  wire               sys_clk  ,
    input  wire               sys_rst_n,
    input  wire signed [15:0] v0, v1, v2, v3,
    output reg  signed [15:0] mix
);

// 每路算术右移1位 = /2（-6dB），符号位扩展
wire signed [15:0] v0h = {v0[15], v0[15:1]};
wire signed [15:0] v1h = {v1[15], v1[15:1]};
wire signed [15:0] v2h = {v2[15], v2[15:1]};
wire signed [15:0] v3h = {v3[15], v3[15:1]};

wire signed [17:0] sum = {{2{v0h[15]}}, v0h} + {{2{v1h[15]}}, v1h}
                       + {{2{v2h[15]}}, v2h} + {{2{v3h[15]}}, v3h};

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n)
        mix <= 16'sd0;
    else if (sum > 16'sd32767)
        mix <= 16'sd32767;
    else if (sum < 16'sh8000)      // -32768（16bit signed 最小值，不用负号避免 overflow 警告）
        mix <= 16'sh8000;
    else
        mix <= sum[15:0];
end

endmodule
