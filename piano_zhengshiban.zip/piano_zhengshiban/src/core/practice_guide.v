// Practice only: observes physical debounced keys; never injects sound events.
module practice_guide(
    input wire clk,rst_n,
    input wire [1:0] mode,
    input wire [17:0] keys,
    output reg [17:0] target,
    output reg [4:0] step,
    output wire wrong,
    output reg complete
);
    reg [1:0] previous_mode;
    reg awaiting_release;
    reg wrong_lockout;
    reg [4:0] key_index;
    always @(*)begin
        if(mode==1)key_index=(step==7) ? 5'd12 : step;
        else case(step)
            0:key_index=0;1:key_index=7;2:key_index=1;3:key_index=8;
            4:key_index=2;5:key_index=3;6:key_index=9;7:key_index=4;
            8:key_index=10;9:key_index=5;10:key_index=11;11:key_index=6;
            default:key_index=step;
        endcase
        target=(mode==0) ? 18'd0 : (18'd1<<key_index);
    end
    assign wrong=mode!=0 && keys!=0 && (keys!=target || wrong_lockout);
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin step<=0;previous_mode<=0;awaiting_release<=0;complete<=0;wrong_lockout<=0;end
        else begin
            previous_mode<=mode;complete<=0;
            if(mode==0 || mode!=previous_mode)begin step<=0;awaiting_release<=0;wrong_lockout<=0;end
            else if(keys!=0 && keys!=target)begin awaiting_release<=0;wrong_lockout<=1;end
            else if(keys==0)begin
                wrong_lockout<=0;
                if(awaiting_release)begin
                awaiting_release<=0;
                if(step==((mode==1)?7:17))begin step<=0;complete<=1;end
                else step<=step+1'b1;
                end
            end
            else if(!wrong_lockout && !awaiting_release && keys==target)awaiting_release<=1;
        end
    end
endmodule
