//****************************************************************************************//
// 模块名：voice_allocator —— 4 声部复音分配器（电平边沿检测版）
// 改动  ：输入从 k_on/k_off 脉冲改为 keys[KEY_COUNT-1:0] 稳定电平，内部做边沿检测
//         彻底消除脉冲握手时序问题：无论多快多键同按，都不会丢事件
// 规则  ：on  ① 同音 retrigger（gate 已释放的声部优先）
//              ② 空闲声部分配
//              ③ 全忙轮转覆盖最旧声部
//         off 拉低对应声部 gate（进入 release 尾音）
//         busy 归零（尾音结束）后回收 note=0
//****************************************************************************************//

module voice_allocator #(parameter integer KEY_COUNT=18, parameter integer NOTE_WIDTH=5)(
    input  wire        sys_clk  ,
    input  wire        sys_rst_n,
    input  wire [KEY_COUNT-1:0] keys     ,    // 稳定电平（位 0~6 = do~si，1=按住）
    input  wire [3:0]  busy     ,    // 各声部占用（含 release）
    output reg  [NOTE_WIDTH-1:0]  n0,n1,n2,n3,
    output reg  [3:0]  gate
);

// 键值（位编号）→ 音符号（独立按键连续映射：位 0~6 = do~si = 音符 1~7）
// Preserve original note IDs 1..12; IDs 13..18 are C5,C#5,D5,D#5,E5,F5.
function [NOTE_WIDTH-1:0] key2note;
    input [NOTE_WIDTH-1:0] k;
    begin
        key2note = (k < KEY_COUNT) ? k + 1'b1 : 0;
    end
endfunction

function [KEY_COUNT-1:0] note_bit;
    input [NOTE_WIDTH-1:0] nn;
    begin
        note_bit = (nn >= 1 && nn <= KEY_COUNT) ? ({{(KEY_COUNT-1){1'b0}},1'b1} << (nn - 1'b1)) : 0;
    end
endfunction

function [NOTE_WIDTH-1:0] first_bit;
    input [KEY_COUNT-1:0] v;
    integer bit_index;
    begin
        first_bit = 0;
        for (bit_index=KEY_COUNT-1; bit_index>=0; bit_index=bit_index-1)
            if (v[bit_index]) first_bit = bit_index[NOTE_WIDTH-1:0];
    end
endfunction

reg [KEY_COUNT-1:0] keys_d;                 // 上一拍 keys（仅在 S_IDLE 更新）
reg [KEY_COUNT-1:0] pend_on, pend_off;
reg [1:0]  st;
reg [1:0]  rr;
localparam S_IDLE = 2'd0, S_OFF = 2'd1, S_ON = 2'd2;

// 组合：当前 on 键的音符
wire [NOTE_WIDTH-1:0] on_key  = first_bit(pend_on);
wire [NOTE_WIDTH-1:0] on_note = key2note(on_key);

// 组合：分配目标声部
reg [1:0] slot;
integer   ii;
always @(*) begin
    slot = rr;
    if (n0==0) slot = 2'd0;
    else if (n1==0) slot = 2'd1;
    else if (n2==0) slot = 2'd2;
    else if (n3==0) slot = 2'd3;
    // A matching release tail must win over an empty slot. Reusing it
    // retriggers that voice instead of layering another copy of the note.
    for (ii=0; ii<4; ii=ii+1) begin
        if ((ii==0)? (n0==on_note && !gate[0]) :
            (ii==1)? (n1==on_note && !gate[1]) :
            (ii==2)? (n2==on_note && !gate[2]) :
                     (n3==on_note && !gate[3]))
            slot = ii[1:0];
    end
end

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        st <= S_IDLE; keys_d <= 0; pend_on <= 0; pend_off <= 0; rr <= 2'd0;
        n0 <= 0; n1 <= 0; n2 <= 0; n3 <= 0; gate <= 4'd0;
    end
    else begin
        // 尾音结束的声部回收
        if (!busy[0] && !gate[0]) n0 <= 0;
        if (!busy[1] && !gate[1]) n1 <= 0;
        if (!busy[2] && !gate[2]) n2 <= 0;
        if (!busy[3] && !gate[3]) n3 <= 0;

        case (st)
            S_IDLE: begin
                keys_d <= keys;       // 更新上一拍值
                // 边沿检测：on = 新按下，off = 新松开
                if ((keys & ~keys_d) != 0 || (~keys & keys_d) != 0) begin
                    pend_on  <= keys & ~keys_d;
                    pend_off <= ~keys & keys_d;
                    st       <= ((~keys & keys_d) != 0) ? S_OFF : S_ON;
                end
            end

            S_OFF: begin
                if (pend_off & note_bit(n0)) gate[0] <= 1'b0;
                if (pend_off & note_bit(n1)) gate[1] <= 1'b0;
                if (pend_off & note_bit(n2)) gate[2] <= 1'b0;
                if (pend_off & note_bit(n3)) gate[3] <= 1'b0;
                st <= (pend_on != 0) ? S_ON : S_IDLE;
            end

            S_ON: begin
                if (pend_on == 0)
                    st <= S_IDLE;
                else begin
                    case (slot)
                        2'd0: begin n0 <= on_note; gate[0] <= 1'b1; end
                        2'd1: begin n1 <= on_note; gate[1] <= 1'b1; end
                        2'd2: begin n2 <= on_note; gate[2] <= 1'b1; end
                        2'd3: begin n3 <= on_note; gate[3] <= 1'b1; end
                    endcase
                    pend_on[on_key] <= 1'b0;
                    rr <= slot + 2'd1;
                end
            end

            default: st <= S_IDLE;
        endcase
    end
end

endmodule
