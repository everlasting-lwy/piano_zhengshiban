//****************************************************************************************//
// 模块名：i2s_tx —— 纯 I2S 发送器（合成在外部，本模块只管时序与并串转换）
// 输出  ：BCLK = 50MHz/16 = 3.125MHz；LRCK = BCLK/64 = 48.828kHz（采样率）
// 格式  ：标准 I2S（飞利浦），MSB 延迟 LRCK 边沿 1 BCLK，左右各 16bit，0 填充 32bit 槽
// 节拍  ：sample_tick 在帧尾(lrck_cnt==60)产生，留64个sys_clk供并行谐波/包络流水；
//         cnt==0 原子锁存一帧单声道样本，左右槽使用同一值，避免帧中控制变化造成左右不一致
//****************************************************************************************//

module i2s_tx(
    input  wire               sys_clk    ,
    input  wire               sys_rst_n  ,
    input  wire signed [15:0] sample     ,   // 混音样本（帧内保持稳定）
    output wire               sample_tick,   // 48.828kHz 采样脉冲（单周期）
    output wire               i2s_bclk   ,
    output wire               i2s_lrck   ,
    output reg                i2s_din,
    output wire signed [15:0] pcm_frame,      // Exact atomically latched stereo sample.
    output reg                pcm_frame_valid
);

reg [3:0] bclk_cnt;
reg [5:0] lrck_cnt;
reg [15:0] shift;
reg [15:0] frame_sample;
assign pcm_frame = frame_sample;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n)
        bclk_cnt <= 4'd0;
    else
        bclk_cnt <= bclk_cnt + 4'd1;
end

assign i2s_bclk    = bclk_cnt[3];
wire bit_tick      = (bclk_cnt == 4'd0);                  // BCLK 下降沿节拍点
assign sample_tick = bit_tick && (lrck_cnt == 6'd60);    // 采样周期仍1024系统时钟

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        lrck_cnt <= 6'd0;
        shift    <= 16'd0;
        frame_sample <= 16'd0;
        pcm_frame_valid <= 1'b0;
    end
    else begin
      pcm_frame_valid <= 1'b0;
      if (bit_tick) begin
        lrck_cnt <= (lrck_cnt == 6'd63) ? 6'd0 : lrck_cnt + 6'd1;

        if (lrck_cnt == 6'd0)begin
            shift <= sample;
            frame_sample <= sample;
            pcm_frame_valid <= 1'b1;
        end
        else if (lrck_cnt == 6'd32)
            shift <= frame_sample;
        else if ((lrck_cnt >= 6'd1  && lrck_cnt <= 6'd15) ||
                 (lrck_cnt >= 6'd33 && lrck_cnt <= 6'd47))
            shift <= {shift[14:0], 1'b0};                 // MSB 先出
      end
    end
end

assign i2s_lrck = ~lrck_cnt[5];

always @(*) begin
    if ((lrck_cnt >= 6'd1  && lrck_cnt <= 6'd16) ||
        (lrck_cnt >= 6'd33 && lrck_cnt <= 6'd48))
        i2s_din = shift[15];
    else
        i2s_din = 1'b0;
end

endmodule
