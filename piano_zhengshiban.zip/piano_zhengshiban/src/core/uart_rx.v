// 8N1 UART receive. Default 50 MHz / 9600 baud, rounded to 5208 clocks.
// Validate START at half a bit; DATA may begin with either 0 or 1.
module uart_rx #(
    parameter integer BIT_CYCLES = 5208
)(
    input wire sys_clk,
    input wire sys_rst_n,
    input wire uart_rxd,
    output reg [7:0] rx_data,
    output reg rx_valid
);
    localparam IDLE=3'd0, START=3'd1, DATA=3'd2, STOP=3'd3, BREAK=3'd4;
    reg d1,d2;
    reg [2:0] state,bit_idx;
    reg [15:0] count;
    reg [7:0] shift_reg;
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            d1<=1'b1; d2<=1'b1;
            state<=IDLE; bit_idx<=0; count<=0;
            shift_reg<=0; rx_data<=0; rx_valid<=0;
        end else begin
            d1<=uart_rxd; d2<=d1;
            rx_valid<=0;
            case(state)
                IDLE: begin
                    count<=0;
                    if(!d2) state<=START;
                end
                START: begin
                    if(count==BIT_CYCLES/2-1) begin
                        count<=0;
                        bit_idx<=0;
                        state<=d2 ? IDLE : DATA;
                    end else count<=count+1'b1;
                end
                DATA: begin
                    if(count==BIT_CYCLES-1) begin
                        count<=0;
                        shift_reg[bit_idx]<=d2;
                        if(bit_idx==7) state<=STOP;
                        else bit_idx<=bit_idx+1'b1;
                    end else count<=count+1'b1;
                end
                STOP: begin
                    if(count==BIT_CYCLES-1) begin
                        count<=0;
                        if(d2) begin
                            rx_data<=shift_reg;
                            rx_valid<=1;
                            state<=IDLE;
                        end else state<=BREAK;
                    end else count<=count+1'b1;
                end
                BREAK: if(d2) state<=IDLE;
                default: state<=IDLE;
            endcase
        end
    end
endmodule
