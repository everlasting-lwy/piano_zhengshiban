// Passive 64-point scope. Two RAM banks isolate rendering from continuous capture.
// A request swaps banks only after a complete frame; the read bank then stays frozen.
module visual_capture(
    input wire clk,rst_n,clear,sample_valid,
    input wire signed [15:0] sample,
    input wire snapshot_request,
    output reg snapshot_ready,
    input wire [5:0] read_index,
    output reg [15:0] point_data
);
    (* syn_ramstyle="block_ram" *) reg signed [15:0] history[0:63];
    (* syn_ramstyle="block_ram" *) reg [15:0] frames[0:127];
    reg [5:0] pointer,write_address;
    reg [6:0] fill;
    reg [7:0] index,index_d;
    reg valid_d,allowed,write_bank,read_bank,pending;
    reg signed [15:0] sample_d,lag;
    wire [7:0] x=sample_d[15:8]^8'h80;
    wire [7:0] y=allowed ? (lag[15:8]^8'h80) : 8'd128;
    always @(posedge clk)begin
        if(sample_valid)lag<=history[pointer];
        if(valid_d && !clear && rst_n)begin
            history[write_address]<=sample_d;
            if(index_d[1:0]==0)frames[{write_bank,index_d[7:2]}]<={y,x};
        end
        point_data<=frames[{read_bank,read_index}];
    end
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            pointer<=0;write_address<=0;fill<=0;index<=0;index_d<=0;valid_d<=0;allowed<=0;sample_d<=0;
            write_bank<=0;read_bank<=1;pending<=0;snapshot_ready<=0;
        end else if(clear)begin
            pointer<=0;fill<=0;index<=0;valid_d<=0;allowed<=0;
            write_bank<=0;read_bank<=1;pending<=0;snapshot_ready<=0;
        end else begin
            valid_d<=sample_valid;snapshot_ready<=0;
            if(snapshot_request)pending<=1;
            if(sample_valid)begin
                sample_d<=sample;write_address<=pointer;pointer<=pointer+1'b1;
                index_d<=index;index<=index+1'b1;
                allowed<=fill>=64;if(fill<64)fill<=fill+1'b1;
            end
            if(valid_d && index_d==252 && (pending || snapshot_request))begin
                read_bank<=write_bank;write_bank<=read_bank;
                snapshot_ready<=1;pending<=0;
            end
        end
    end
endmodule
