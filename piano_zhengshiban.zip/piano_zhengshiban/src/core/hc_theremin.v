module hc_theremin(
    input  wire        sys_clk,
    input  wire        sys_rst_n,
    input  wire [15:0] distance_cm,
    input  wire        dist_valid,
    output reg  [31:0] f_car_direct,
    output reg         theremin_gate,
    output wire        theremin_valid,
    output reg  [3:0]  note_number,
    output reg  [3:0]  note_octave
);

wire in_range = (distance_cm >= 16'd5 && distance_cm <= 16'd50);
assign theremin_valid = in_range;

reg [3:0] mapped_note;
reg [3:0] mapped_octave;
reg [31:0] base_word;
reg [31:0] mapped_word;

always @(*) begin
    if      (distance_cm <= 16'd7)  begin mapped_note = 4'd1; mapped_octave = 4'd6; end
    else if (distance_cm <= 16'd10) begin mapped_note = 4'd7; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd13) begin mapped_note = 4'd6; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd16) begin mapped_note = 4'd5; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd19) begin mapped_note = 4'd4; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd22) begin mapped_note = 4'd3; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd25) begin mapped_note = 4'd2; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd28) begin mapped_note = 4'd1; mapped_octave = 4'd5; end
    else if (distance_cm <= 16'd31) begin mapped_note = 4'd7; mapped_octave = 4'd4; end
    else if (distance_cm <= 16'd34) begin mapped_note = 4'd6; mapped_octave = 4'd4; end
    else if (distance_cm <= 16'd37) begin mapped_note = 4'd5; mapped_octave = 4'd4; end
    else if (distance_cm <= 16'd40) begin mapped_note = 4'd4; mapped_octave = 4'd4; end
    else if (distance_cm <= 16'd43) begin mapped_note = 4'd3; mapped_octave = 4'd4; end
    else if (distance_cm <= 16'd46) begin mapped_note = 4'd2; mapped_octave = 4'd4; end
    else                            begin mapped_note = 4'd1; mapped_octave = 4'd4; end

    case (mapped_note)
        4'd1: base_word = 32'd23012828;
        4'd2: base_word = 32'd25831026;
        4'd3: base_word = 32'd28994347;
        4'd4: base_word = 32'd30718440;
        4'd5: base_word = 32'd34480283;
        4'd6: base_word = 32'd38702809;
        4'd7: base_word = 32'd43442435;
        default: base_word = 32'd23012828;
    endcase

    case (mapped_octave)
        4'd6: mapped_word = {base_word[29:0], 2'b00};
        4'd5: mapped_word = {base_word[30:0], 1'b0};
        default: mapped_word = base_word;
    endcase
end

reg [1:0] valid_count;
reg [1:0] invalid_count;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        f_car_direct <= 32'd23012828;
        theremin_gate <= 1'b0;
        note_number <= 4'd0;
        note_octave <= 4'd0;
        valid_count <= 2'd0;
        invalid_count <= 2'd0;
    end
    else if (dist_valid) begin
        if (in_range) begin
            invalid_count <= 2'd0;
            if (valid_count < 2'd2)
                valid_count <= valid_count + 2'd1;
            if (valid_count >= 2'd1)
                theremin_gate <= 1'b1;
            note_number <= mapped_note;
            note_octave <= mapped_octave;
            f_car_direct <= mapped_word;
        end
        else begin
            valid_count <= 2'd0;
            if (invalid_count < 2'd2)
                invalid_count <= invalid_count + 2'd1;
            if (invalid_count >= 2'd1) begin
                theremin_gate <= 1'b0;
                note_number <= 4'd0;
                note_octave <= 4'd0;
            end
        end
    end
end

endmodule
