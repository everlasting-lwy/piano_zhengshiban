// CRC-8/SMBUS: polynomial 0x07, init/xorout 0, no reflection.
function [7:0] bt_crc8_byte;
    input [7:0] crc,value;
    reg [7:0] c;
    integer k;
    begin
        c=crc^value;
        for(k=0;k<8;k=k+1) c=c[7] ? (c<<1)^8'h07 : c<<1;
        bt_crc8_byte=c;
    end
endfunction
