//****************************************************************************************//
// 工程名：ACG525-V2 FPGA 多音色复音电子琴（独立按键版）
// 平台  ：GW5A-LV25UG324C2/I1，50MHz，18个独立音键，MAX98357A(I2S)
// 功能  ：1. 实体18键、手机横屏36键共用4声部；OLED显示实际PCM波形
//         2. 板载 KEY0 循环切换 4 种音色：
//            ① 钢琴近似  ② FM 电钢琴  ③ FM 钟琴  ④ FM 拨弦
//         3. 数码管：右1位音符，右2位音色号；4 个 LED 指示 4 个声部按键状态
// 接线  ：见docs/PINOUT.md，每个音键另一端接GND
//         板载KEY0复位、KEY1音色、KEY2模式，经板级顶层映射到本核心
//****************************************************************************************//

module top_piano_test #(
    parameter integer BT_UART_CYCLES=5208,
    parameter integer BT_MS_CYCLES=50000,
    parameter integer BT_WATCHDOG_MS=2000,
    parameter integer SD_INIT_DIV=125,SD_DATA_DIV=8,
    parameter integer SD_POWERUP_CYCLES=500000,SD_INIT_TIMEOUT_CYCLES=100000000
)(
    input  wire        sys_clk  ,
    input  wire        sys_rst_n,
    input  wire [17:0] key_in,
    input  wire        key0    ,    // 板载 KEY0（音色切换，按下为低）
    input  wire        key1    ,    // 板载 KEY1（音量加）
    input  wire        key2    ,    // 板载 KEY2（音量减）
    input  wire        key3    ,    // 板载 KEY3（八度切换，按下为低）
    input  wire        key4    ,    // 外接独立按键（音源模式切换，按下为低）
    input  wire        uart_rxd,   // HC-05 蓝牙串口 RX（来自 HC-05 模块的 TX）
    output wire        bt_txd,     // Independent framed HC-05 return channel
    input  wire        hc_echo ,   // HC-SR04 回波输入
    output wire        hc_trig ,   // HC-SR04 触发脉冲输出
    output wire [5:0]  seg_sel  ,
    output wire [7:0]  seg_led  ,
    output wire        i2s_bclk ,
    output wire        i2s_lrck ,
    output wire        i2s_din  ,
    output wire [3:0]  led      ,
    input wire [7:0] local_command,
    input wire local_command_valid,
    output wire [31:0] panel_state,
    output reg [2:0] volume_source, // Last actual change:0 init/reset,1 encoder,2 reserved,3 BT,4 key.
    output wire signed [15:0] pcm_frame,
    output wire pcm_frame_valid,
    input wire oled_spectrum_enable,
    output wire [255:0] oled_spectrum_bars,
    output wire oled_spectrum_valid,
    input wire song_toggle,song_restart,
    input wire song_next,song_prev,
    output wire sd_cs_n,sd_clk,sd_mosi,input wire sd_miso,
    output wire sd_busy,sd_selected_valid,
    output wire [4:0] sd_selected_slot,
    output wire [7:0] sd_error,
    output wire song_active,song_loaded,song_loading,song_complete,song_wrong,
    output wire [17:0] song_target,song_physical,
    output wire [11:0] song_step,song_total,
    output wire        uart_txd   // MIDI UART → USB Type-C CH340
);

// Gowin requires these shared nets to be declared before instance connections.
wire sample_tick;
reg [1:0] octave;
reg [3:0] vol;
wire [7:0]  rx_data;
wire        rx_valid;
wire [1:0]  bt_timbre;
wire        bt_timbre_en;
wire [1:0]  bt_octave;
wire        bt_octave_en;
wire [3:0]  bt_vol;
wire        bt_vol_en;
wire [1:0] legacy_timbre,legacy_octave,frame_timbre,frame_octave;
wire [3:0] legacy_vol,frame_vol;
wire legacy_timbre_en,legacy_octave_en,legacy_vol_en;
wire frame_timbre_en,frame_octave_en,frame_vol_en,bt_legacy_ready;
assign bt_timbre_en=frame_timbre_en || legacy_timbre_en;
assign bt_octave_en=frame_octave_en || legacy_octave_en;
assign bt_vol_en=frame_vol_en || legacy_vol_en;
assign bt_timbre=frame_timbre_en ? frame_timbre : legacy_timbre;
assign bt_octave=frame_octave_en ? frame_octave : legacy_octave;
assign bt_vol=frame_vol_en ? frame_vol : legacy_vol;
wire [3:0] effect_reverb,effect_echo,effect_chorus,effect_expression,effect_vibrato;
wire [4:0] effect_bend;
wire [1:0] effect_delay,guide_mode;
reg remote_control_previous;
// Rotary output is registered: remote writes must also win in its generation
// cycle, including no-op writes of the SAME value.
wire local_control_valid=local_command_valid && !remote_control_previous;
assign panel_state={1'b0,effect_delay,effect_chorus,effect_echo,effect_reverb,
                    effect_vibrato,effect_bend,effect_expression,vol};
wire [7:0] bt_effect_command,bt_visual_sequence,bt_visual_tx_sequence,bt_visual_command;
wire bt_effect_en,bt_visual_start,bt_visual_ready,bt_visual_take;
wire [2:0] bt_visual_kind;
wire [31:0] bt_device_millis;
wire [47:0] bt_effect_status,bt_visual_payload;
wire [17:0] guide_target;
wire [4:0] guide_step;
wire guide_wrong;
assign bt_effect_status={8'h31,bt_visual_kind,guide_step,1'b1,2'b00,effect_bend,
    guide_mode,effect_delay,effect_vibrato,effect_expression,effect_chorus,effect_echo,effect_reverb};
panel_parameter_control u_panel(
    .clk(sys_clk),.rst_n(sys_rst_n),
    .command(bt_effect_en ? bt_effect_command : local_command),
    .command_valid(bt_effect_en || local_control_valid),
    .reverb(effect_reverb),.echo(effect_echo),.chorus(effect_chorus),
    .expression(effect_expression),.vibrato(effect_vibrato),.bend(effect_bend),
    .delay_select(effect_delay),.guide(guide_mode));
always @(posedge sys_clk or negedge sys_rst_n)begin
    if(!sys_rst_n)remote_control_previous<=0;
    else remote_control_previous<=bt_effect_en || bt_vol_en;
end


function [4:0] note_from_pitch;
    input [6:0] pitch;
    reg [6:0] semitone;
    begin
        semitone = (pitch >= 7'd72) ? pitch - 7'd72 :
                   (pitch >= 7'd60) ? pitch - 7'd60 : pitch - 7'd48;
        case (semitone)
            7'd0: note_from_pitch = 5'd1;
            7'd1: note_from_pitch = 5'd8;
            7'd2: note_from_pitch = 5'd2;
            7'd3: note_from_pitch = 5'd9;
            7'd4: note_from_pitch = 5'd3;
            7'd5: note_from_pitch = 5'd4;
            7'd6: note_from_pitch = 5'd10;
            7'd7: note_from_pitch = 5'd5;
            7'd8: note_from_pitch = 5'd11;
            7'd9: note_from_pitch = 5'd6;
            7'd10: note_from_pitch = 5'd12;
            7'd11: note_from_pitch = 5'd7;
            7'd12: note_from_pitch = 5'd13;
            7'd13: note_from_pitch = 5'd14;
            7'd14: note_from_pitch = 5'd15;
            7'd15: note_from_pitch = 5'd16;
            7'd16: note_from_pitch = 5'd17;
            7'd17: note_from_pitch = 5'd18;
            default: note_from_pitch = 5'd0;
        endcase
    end
endfunction

function [1:0] octave_from_pitch;
    input [6:0] pitch;
    begin
        octave_from_pitch = (pitch >= 7'd72) ? 2'd1 :
                            (pitch >= 7'd60) ? 2'd0 : 2'd2;
    end
endfunction

//*****************************************************
//**  0. 蓝牙虚拟按键状态（APP 虚拟键盘）
//*****************************************************
wire [35:0] bt_extended_keys;
wire extended_mode;
wire [11:0] bt_keys;     // Checked complete remote key snapshot, fail-safe release.

//*****************************************************
//**  1. 十八路物理键消抖；已校验数字远程键在消抖之后合并
//*****************************************************
wire [17:0] physical_keys;
assign song_physical=physical_keys;
wire song_request,song_response_valid;
wire [7:0] song_request_command,song_response_command;
wire [47:0] song_request_payload,song_response_payload;
wire guide_request,guide_response_valid;
wire [7:0] guide_request_command,guide_response_command;
wire [47:0] guide_request_payload,guide_response_payload;
sd_song_library #(.INIT_DIV(SD_INIT_DIV),.DATA_DIV(SD_DATA_DIV),
    .POWERUP_CYCLES(SD_POWERUP_CYCLES),.INIT_TIMEOUT_CYCLES(SD_INIT_TIMEOUT_CYCLES)) u_sd_library(
    .clk(sys_clk),.rst_n(sys_rst_n),
    .bt_req_valid(song_request),.bt_req_command(song_request_command),.bt_req_payload(song_request_payload),
    .bt_rsp_valid(song_response_valid),.bt_rsp_command(song_response_command),.bt_rsp_payload(song_response_payload),
    .g_req_valid(guide_request),.g_req_command(guide_request_command),.g_req_payload(guide_request_payload),
    .g_rsp_valid(guide_response_valid),.g_rsp_command(guide_response_command),.g_rsp_payload(guide_response_payload),
    .guide_loaded(song_loaded),.guide_loading(song_loading),.guide_active(song_active),.guide_total_steps(song_total),
    .physical_keys(physical_keys),.local_next(song_next),.local_prev(song_prev),
    .sd_busy(sd_busy),.selected_slot(sd_selected_slot),.selected_valid(sd_selected_valid),.sd_error(sd_error),
    .sd_cs_n(sd_cs_n),.sd_clk(sd_clk),.sd_mosi(sd_mosi),.sd_miso(sd_miso));
song_guide u_song_guide(.clk(sys_clk),.rst_n(sys_rst_n),
    .request_valid(guide_request),.request_command(guide_request_command),.request_payload(guide_request_payload),
    .response_valid(guide_response_valid),.response_command(guide_response_command),.response_payload(guide_response_payload),
    .local_toggle(song_toggle),.local_restart(song_restart),.physical_keys(physical_keys),
    .target(song_target),.active(song_active),.loaded(song_loaded),.loading(song_loading),
    .complete(song_complete),.wrong(song_wrong),.step(song_step),.total_steps(song_total));
wire [17:0] keys=physical_keys | {6'd0,bt_keys};
// Legacy panel IDs retain their original natural-note-first wiring order.
function [5:0] physical_offset;
    input integer key_index;
    begin
        case(key_index)
            0:physical_offset=0; 1:physical_offset=2; 2:physical_offset=4;
            3:physical_offset=5; 4:physical_offset=7; 5:physical_offset=9;
            6:physical_offset=11;7:physical_offset=1;8:physical_offset=3;
            9:physical_offset=6;10:physical_offset=8;11:physical_offset=10;
            default:physical_offset=key_index;
        endcase
    end
endfunction
reg [47:0] extended_merged_keys;
integer pitch_key;
integer physical_base;
always @(*) begin
    physical_base=(octave==2'd1) ? 24 : (octave==2'd2) ? 0 : 12;
    extended_merged_keys={12'd0,bt_extended_keys};
    for(pitch_key=0;pitch_key<18;pitch_key=pitch_key+1)
        if(keys[pitch_key])extended_merged_keys[physical_base+physical_offset(pitch_key)]=1'b1;
end


key_direct7 #(.KEY_COUNT(18)) u_key(
    .sys_clk    (sys_clk),
    .sys_rst_n  (sys_rst_n),
    .key_in     (key_in),
    .keys       (physical_keys)
);

//*****************************************************
//**  1.6 key4 音源模式切换（三模式循环）
//**     source_mode[1:0]:
//**       00 = 本地合成（实体/手机按键 → 音色引擎 → I2S → 喇叭）
//**       01 = UART MIDI（gate/note → CH340 → 电脑扬声器）
//**       10 = 超声测距特雷门琴（HC-SR04 → hc_theremin → voice[0] → 喇叭）
//*****************************************************
reg [19:0] key4_cnt;
reg        key4_filt;
reg        key4_edge;
reg        key4_sync1, key4_sync2;
reg [1:0]  source_mode;     // 00=FM, 01=MIDI, 10=Theremin

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        key4_cnt    <= 20'd0;
        key4_filt   <= 1'b1;
        key4_edge   <= 1'b1;
        key4_sync1  <= 1'b1;
        key4_sync2  <= 1'b1;
        source_mode <= 2'd0;   // 开机默认 FM 合成
    end
    else begin
        key4_sync1 <= key4;
        key4_sync2 <= key4_sync1;

        if (key4_sync2 != key4_filt) begin
            if (key4_cnt >= 20'd500000) begin
                key4_filt <= key4_sync2; key4_cnt <= 20'd0;
            end
            else key4_cnt <= key4_cnt + 20'd1;
        end
        else key4_cnt <= 20'd0;

        key4_edge <= key4_filt;
        if (~key4_filt & key4_edge) begin
            // 三模式循环：00 → 01 → 10 → 00 → ...
            source_mode <= (source_mode == 2'd2) ? 2'd0 : source_mode + 2'd1;
        end
    end
end

// 模式别名
wire mode_fm       = (source_mode == 2'd0);
wire mode_midi     = (source_mode == 2'd1);
wire mode_theremin = (source_mode == 2'd2);

// 本地合成和 MIDI 共用实体/手机按键，超声模式独立发声。
wire [17:0] keys_final = mode_theremin ? 18'd0 : keys;
wire [1:0] final_octave = octave;

//*****************************************************
//**  2. 板载 KEY0 切音色（10ms 消抖 + 下降沿检测）
//*****************************************************
reg [19:0] key0_cnt;
reg        key0_filt;
reg        key0_edge;
reg [1:0]  timbre;

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        key0_cnt  <= 20'd0;
        key0_filt  <= 1'b1;
        key0_edge  <= 1'b1;
        timbre     <= 2'd0;
    end
    else begin
        if (key0 != key0_filt) begin
            if (key0_cnt >= 20'd500000) begin
                key0_filt <= key0;
                key0_cnt  <= 20'd0;
            end
            else
                key0_cnt <= key0_cnt + 20'd1;
        end
        else
            key0_cnt <= 20'd0;

        key0_edge <= key0_filt;
        if (bt_timbre_en)
            timbre <= bt_timbre;
        else if (~key0_filt & key0_edge)     // 下降沿 = 按下
            timbre <= timbre + 2'd1;
    end
end

//*****************************************************
//**  3. 板载 KEY3 切八度（10ms 消抖 + 下降沿检测）
//**     octave: 0=原位, 1=升八度(×2), 2=降八度(÷2)
//*****************************************************
reg [19:0] key3_cnt;
reg        key3_filt;
reg        key3_edge;


always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        key3_cnt   <= 20'd0;
        key3_filt  <= 1'b1;
        key3_edge  <= 1'b1;
        octave     <= 2'd0;
    end
    else begin
        if (key3 != key3_filt) begin
            if (key3_cnt >= 20'd500000) begin
                key3_filt <= key3;
                key3_cnt  <= 20'd0;
            end
            else
                key3_cnt <= key3_cnt + 20'd1;
        end
        else
            key3_cnt <= 20'd0;

        key3_edge <= key3_filt;
        if (bt_octave_en)
            octave <= bt_octave;
        else if (~key3_filt & key3_edge) begin   // 下降沿 = 按下
            if (octave == 2'd2)
                octave <= 2'd0;             // 降→原位
            else
                octave <= octave + 2'd1;    // 原位→升→降
        end
    end
end

//*****************************************************
//**  4. 板载 KEY1/KEY2 音量加减（10ms 消抖 + 下降沿）
//**     vol: 0=静音, 1~15=逐级增大, 默认 15(满)
//*****************************************************
reg [19:0] key1_cnt, key2_cnt;
reg        key1_filt, key2_filt;
reg        key1_edge, key2_edge;


always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        key1_cnt  <= 20'd0; key2_cnt  <= 20'd0;
        key1_filt <= 1'b1;  key2_filt <= 1'b1;
        key1_edge <= 1'b1;  key2_edge <= 1'b1;
        vol       <= 4'd15;   // 开机默认满音量
        volume_source<=0;
    end
    else begin
        // KEY1 消抖
        if (key1 != key1_filt) begin
            if (key1_cnt >= 20'd500000) begin key1_filt <= key1; key1_cnt <= 20'd0; end
            else key1_cnt <= key1_cnt + 20'd1;
        end else key1_cnt <= 20'd0;

        // KEY2 消抖
        if (key2 != key2_filt) begin
            if (key2_cnt >= 20'd500000) begin key2_filt <= key2; key2_cnt <= 20'd0; end
            else key2_cnt <= key2_cnt + 20'd1;
        end else key2_cnt <= 20'd0;

        key1_edge <= key1_filt;
        key2_edge <= key2_filt;

        // 下降沿 = 按下 / BT 指令优先
        if (bt_vol_en)begin
            vol <= bt_vol;
            if(vol!=bt_vol)volume_source<=3;
        end else if (local_control_valid && local_command>=8'h80 && local_command<=8'h8f)begin
            vol <= local_command[3:0];
            if(vol!=local_command[3:0])volume_source<=1;
        end
        else if (~key1_filt & key1_edge) begin
            if (vol != 4'd15) begin vol <= vol + 4'd1;volume_source<=4;end
        end
        else if (~key2_filt & key2_edge) begin
            if (vol != 4'd0) begin vol <= vol - 4'd1;volume_source<=4;end
        end
    end
end

//*****************************************************
//**  5. HC-05 蓝牙 UART 接收 + APP 指令解码 + BT 合并
//*****************************************************

uart_rx #(.BIT_CYCLES(BT_UART_CYCLES)) u_uart(
    .sys_clk    (sys_clk),
    .sys_rst_n  (sys_rst_n),
    .uart_rxd   (uart_rxd),
    .rx_data    (rx_data),
    .rx_valid   (rx_valid)
);

uart_cmd_decoder u_dec(
    .sys_clk     (sys_clk),
    .sys_rst_n   (sys_rst_n),
    .rx_data     (rx_data),
    .rx_valid    (rx_valid && bt_legacy_ready &&
                  ((rx_data<=8'h03) || (rx_data>=8'h40 && rx_data<=8'h42) ||
                   (rx_data>=8'h80 && rx_data<=8'h8F))),
    .bt_timbre   (legacy_timbre),
    .bt_timbre_en(legacy_timbre_en),
    .bt_octave   (legacy_octave),
    .bt_octave_en(legacy_octave_en),
    .bt_vol      (legacy_vol),
    .bt_vol_en   (legacy_vol_en),
    .bt_note_on(),.bt_note_idx(),.bt_note_en()
);

//*****************************************************
//**  6. 4 声部分配器（电平边沿检测）
//*****************************************************
wire [4:0] v_note [0:3];
wire [4:0] legacy_note [0:3];
wire [5:0] extended_note [0:3];
wire [6:0] v_pitch [0:3];
wire [3:0] v_gate,legacy_gate,extended_gate;
wire [3:0] v_busy;
wire keyboard_enabled=!mode_theremin;
voice_allocator u_alloc(
    .sys_clk(sys_clk),.sys_rst_n(sys_rst_n && !extended_mode),
    .keys(extended_mode ? 18'd0 : keys_final),
    .busy(extended_mode ? 4'd0 : v_busy),
    .n0(legacy_note[0]),.n1(legacy_note[1]),.n2(legacy_note[2]),.n3(legacy_note[3]),.gate(legacy_gate));
voice_allocator #(.KEY_COUNT(48),.NOTE_WIDTH(6)) u_extended_alloc(
    .sys_clk(sys_clk),.sys_rst_n(sys_rst_n && extended_mode),
    .keys(extended_mode && keyboard_enabled ? extended_merged_keys : 48'd0),
    .busy(extended_mode ? v_busy : 4'd0),
    .n0(extended_note[0]),.n1(extended_note[1]),.n2(extended_note[2]),.n3(extended_note[3]),.gate(extended_gate));
assign v_gate=extended_mode ? extended_gate : legacy_gate;
genvar pitch_voice;
generate for(pitch_voice=0;pitch_voice<4;pitch_voice=pitch_voice+1)begin:G_PITCH
    assign v_pitch[pitch_voice]=extended_mode ? (7'd47+extended_note[pitch_voice]) :
        ((octave==2'd1) ? 7'd72 : (octave==2'd2) ? 7'd48 : 7'd60)+physical_offset(legacy_note[pitch_voice]-1);
    assign v_note[pitch_voice]=extended_mode ?
        (extended_note[pitch_voice]==0 ? 5'd0 : note_from_pitch(v_pitch[pitch_voice])) : legacy_note[pitch_voice];
end endgenerate

//*****************************************************
//**  4. 延迟测量仪（答辩展示：按键→发声的硬件延迟 ms）
//*****************************************************
// Digital latency is verified by decoded I2S regression. The old unconnected
// approximate-ms gate meter was removed rather than display a misleading value.

//*****************************************************
//**  5. HC-SR04 超声波测距 → 特雷门琴
//*****************************************************
wire [15:0] distance_cm;
wire        dist_valid;
wire [31:0] f_car_direct;
wire        theremin_gate;
wire        theremin_valid;
wire [3:0]  theremin_note;
wire [3:0]  theremin_octave;

hc_sr04_driver u_sr04(
    .sys_clk     (sys_clk),
    .sys_rst_n   (sys_rst_n),
    .hc_trig     (hc_trig),
    .hc_echo     (hc_echo),
    .distance_cm (distance_cm),
    .dist_valid  (dist_valid)
);

hc_theremin u_theremin(
    .sys_clk       (sys_clk),
    .sys_rst_n     (sys_rst_n),
    .distance_cm   (distance_cm),
    .dist_valid    (dist_valid),
    .f_car_direct  (f_car_direct),
    .theremin_gate (theremin_gate),
    .theremin_valid(theremin_valid),
    .note_number   (theremin_note),
    .note_octave   (theremin_octave)
);

//*****************************************************
//**  6. 4 个声部引擎并行
//**     本地模式：32路并行谐波钢琴 / 原FM音色
//**     MIDI 模式：全部静音（电脑扬声器发声）
//**     Theremin 模式：voice[0] = theremin，其他静音
//*****************************************************
wire signed [15:0] v_wave [0:3];
reg [1:0] previous_mode;
reg previous_extended_mode;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin previous_mode <= 2'd0;previous_extended_mode<=0;end
    else begin previous_mode <= source_mode;previous_extended_mode<=extended_mode;end
end
wire mode_transition = (source_mode != previous_mode) || (extended_mode != previous_extended_mode);
wire [127:0] additive_phases,additive_increments;
wire [127:0] adjusted_increments;
pitch_expression_bank u_expression(
    .clk(sys_clk),.rst_n(sys_rst_n),.clear(mode_transition),.sample_tick(sample_tick),
    .bend(effect_bend),.vibrato(effect_vibrato),
    .base_all(additive_increments),.adjusted_all(adjusted_increments));
wire [63:0] additive_body,additive_strike;
wire [3:0] additive_valid;
additive32_bank u_additive(
    .clk(sys_clk),.rst_n(sys_rst_n),.clear(mode_transition),.sample_tick(sample_tick),
    .phase_all(additive_phases),.increment_all(adjusted_increments),
    .body_all(additive_body),.strike_all(additive_strike),.result_valid(additive_valid));

// —— gate 路由（三模式）——
wire [3:0] fm_gate = mode_fm ? v_gate : 4'd0;
wire signed [15:0] theremin_wave;
wire theremin_busy;

voice_engine u_theremin_voice(
    .sys_clk       (sys_clk),
    .sys_rst_n     (sys_rst_n),
    .mode_clear    (mode_transition),
    .sample_tick   (sample_tick),
    .gate          (mode_theremin && !mode_transition && theremin_gate),
    .note          (4'd0),
    .timbre        (2'd0),
    .octave        (final_octave),
    .detune_offset (32'sd0),
    .use_override  (mode_theremin),
    .f_car_ext     (f_car_direct),
    .wave          (theremin_wave),
    .busy          (theremin_busy)
);

genvar gi;
generate
    for (gi=0; gi<4; gi=gi+1) begin : G_VOICE
        wire signed [15:0] keyboard_wave;
        wire keyboard_busy;
        keyboard_voice_engine #(.EXPRESSION_ENABLE(1)) u_voice(
            .sys_clk       (sys_clk),
            .sys_rst_n     (sys_rst_n),
            .mode_clear    (mode_transition),
            .sample_tick   (sample_tick),
            .gate          (mode_transition ? 1'b0 : fm_gate[gi]),
            .note          (v_note[gi]),
            .timbre        (timbre),
            .octave        (extended_mode ? octave_from_pitch(v_pitch[gi]) : final_octave),
            .note_level    (16'hFFFF),
            .pitch_increment(adjusted_increments[gi*32+:32]),
            .piano_body    (additive_body[gi*16+:16]),
            .piano_strike  (additive_strike[gi*16+:16]),
            .synth_phase   (additive_phases[gi*32+:32]),
            .synth_increment(additive_increments[gi*32+:32]),
            .wave          (keyboard_wave),
            .busy          (keyboard_busy)
        );
        assign v_wave[gi] = mode_theremin ? ((gi == 0) ? theremin_wave : 16'sd0) :
                                           (keyboard_wave >>> 1);
        assign v_busy[gi] = mode_theremin ? ((gi == 0) ? theremin_busy : 1'b0) : keyboard_busy;
    end
endgenerate

// Legacy status remains12 keys; protocol2 adds absolute36-key status/events.
bt_link #(.UART_CYCLES(BT_UART_CYCLES),.MS_CYCLES(BT_MS_CYCLES),
          .WATCHDOG_MS(BT_WATCHDOG_MS)) u_bt_link(
    .clk(sys_clk),.rst_n(sys_rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
    .timbre(timbre),.octave(octave),.mode(source_mode),.volume(vol),
    .voices(mode_midi ? v_gate : v_busy),.keys(keys[11:0]),
    .extended_keys(extended_merged_keys[35:0]),.remote_extended_keys(bt_extended_keys),.extended_mode(extended_mode),
    .set_timbre(frame_timbre),.set_octave(frame_octave),.set_volume(frame_vol),
    .timbre_en(frame_timbre_en),.octave_en(frame_octave_en),.volume_en(frame_vol_en),
    .effects_status(bt_effect_status),.effect_command(bt_effect_command),.effect_en(bt_effect_en),
    .visual_kind(bt_visual_kind),.visual_start(bt_visual_start),.visual_sequence(bt_visual_sequence),
    .device_millis(bt_device_millis),.visual_ready(bt_visual_ready),.visual_take(bt_visual_take),
    .visual_command(bt_visual_command),.visual_tx_sequence(bt_visual_tx_sequence),.visual_payload(bt_visual_payload),
    .guide_request(song_request),.guide_request_command(song_request_command),.guide_request_payload(song_request_payload),
    .guide_response_valid(song_response_valid),.guide_response_command(song_response_command),.guide_response_payload(song_response_payload),
    .remote_keys(bt_keys),.tx(bt_txd),.legacy_ready(bt_legacy_ready),.event_overflow());

//*****************************************************
//**  5.5 UART MIDI 输出（source_mode=1 时生效）
//**     三层架构（移植自参考工程，握手严谨）：
//**     message_encoder → midi_encoder → uart_tx → USB Type-C CH340 → 电脑扬声器
//*****************************************************
wire [7:0] m_enc_data;
wire       m_enc_start;
wire       m_enc_ready;
wire [7:0] tx_bus;
wire       tx_start;
wire       tx_ready;

// 层 1：gate 边沿 → data 字节 {midi_note[6:0], on_off[0]}
message_encoder #(.USE_DIRECT_PITCH(1)) u_msg(
    .clk      (sys_clk),
    .rst_n    (sys_rst_n),
    .gate     (v_gate),
    .pitch_all({v_pitch[3],v_pitch[2],v_pitch[1],v_pitch[0]}),
    .note_all ({v_note[3], v_note[2], v_note[1], v_note[0]}),  // four packed 5-bit note IDs
    .octave   (octave),
    .midi_en  (mode_midi),
    .mready   (m_enc_ready),
    .data     (m_enc_data),
    .mstart   (m_enc_start)
);

// 层 2：data → 24bit MIDI 消息 → 拆 3 字节
midi_encoder u_mid_enc(
    .clk       (sys_clk),
    .rst_n     (sys_rst_n),
    .data      (m_enc_data),
    .volume_in ({vol, 4'd0}),   // 4bit vol → 8bit velocity (vol=15 → 120)
    .mstart    (m_enc_start),
    .mready    (m_enc_ready),
    .tbus      (tx_bus),
    .tstart    (tx_start),
    .tready    (tx_ready)
);

// 层 3：11bit shift 发 UART 115200bps
uart_tx u_uart_tx(
    .clk    (sys_clk),
    .rst_n  (sys_rst_n),
    .tbus   (tx_bus),
    .start  (tx_start),
    .tx     (uart_txd),
    .ready  (tx_ready)
);

//*****************************************************
//**  5. 饱和混音 + I2S 发送（FM 模式下才输出有效音频）
//*****************************************************
wire signed [15:0] audio_mix;

mixer u_mixer(
    .sys_clk    (sys_clk),
    .sys_rst_n  (sys_rst_n),
    .v0         (mode_midi ? 16'sd0 : v_wave[0]),
    .v1         (mode_fm ? v_wave[1] : 16'sd0),
    .v2         (mode_fm ? v_wave[2] : 16'sd0),
    .v3         (mode_fm ? v_wave[3] : 16'sd0),
    .mix        (audio_mix)
);

// 音量缩放：audio_mix * vol / 16
wire signed [15:0] audio_effected,effect_lag;
wire effect_valid,effect_clip;
audio_effects u_effects(
    .clk(sys_clk),.rst_n(sys_rst_n),.clear(mode_transition),.sample_tick(sample_tick),
    .pcm(audio_mix),.expression(effect_expression),.reverb(effect_reverb),
    .echo(effect_echo),.chorus(effect_chorus),.delay_select(effect_delay),
    .sample(audio_effected),.lag_sample(effect_lag),.sample_valid(effect_valid),.clipped(effect_clip));
wire signed [20:0] vol_mul = audio_effected * $signed({16'd0, vol});
wire signed [15:0] audio_scaled = mode_midi ? 16'sd0 : vol_mul[20:4];
reg visual_sample_valid;
always @(posedge sys_clk or negedge sys_rst_n)begin
    if(!sys_rst_n)visual_sample_valid<=0;
    else visual_sample_valid<=effect_valid && !mode_transition;
end
wire [511:0] spectral_magnitudes;
wire [255:0] spectrum_bars;
wire spectrum_valid;
// Both consumers own their snapshots. One DFT runs while either needs it;
// switching a phone view must not clear an OLED frequency frame.
wire spectrum_enabled=oled_spectrum_enable || bt_visual_kind==2;
assign oled_spectrum_bars=spectrum_bars;
assign oled_spectrum_valid=spectrum_valid;
spectrum32 u_spectrum(
    .clk(sys_clk),.rst_n(sys_rst_n),.clear(mode_transition || !spectrum_enabled),
    .sample_tick(pcm_frame_valid && spectrum_enabled),
    .sample(pcm_frame),.bars(spectrum_bars),.magnitudes(spectral_magnitudes),.frame_valid(spectrum_valid));
practice_guide u_guide(
    .clk(sys_clk),.rst_n(sys_rst_n),.mode(bt_visual_kind==4 ? guide_mode : 2'd0),.keys(physical_keys),
    .target(guide_target),.step(guide_step),.wrong(guide_wrong),.complete());
// Independent Bluetooth snapshots never stall audio or the OLED.
bt_visual_stream #(.MS_CYCLES(BT_MS_CYCLES)) u_bt_visual(
    .clk(sys_clk),.rst_n(sys_rst_n),.clear(mode_transition),
    .sample_valid(visual_sample_valid),.sample(audio_scaled),
    .request_start(bt_visual_start),.request_kind(bt_visual_kind),.request_sequence(bt_visual_sequence),
    .device_millis(bt_device_millis),.spectrum_bars(spectrum_bars),.spectrum_valid(spectrum_valid),
    .physical_keys(physical_keys),.guide_step(guide_step),.guide_mode(guide_mode),.guide_wrong(guide_wrong),
    .tx_ready(bt_visual_ready),.tx_command(bt_visual_command),.tx_sequence(bt_visual_tx_sequence),
    .tx_payload(bt_visual_payload),.tx_take(bt_visual_take));
i2s_tx u_i2s(
    .sys_clk     (sys_clk),
    .sys_rst_n   (sys_rst_n),
    .sample       (audio_scaled),
    .sample_tick (sample_tick),
    .i2s_bclk    (i2s_bclk),
    .i2s_lrck    (i2s_lrck),
    .i2s_din     (i2s_din),
    .pcm_frame(pcm_frame),.pcm_frame_valid(pcm_frame_valid)
);

//*****************************************************
//**  6. 数码管（6 位动态扫描 + 三模式自适应显示）
//**     FM 模式：[1][-][-][八度][音色][音符]
//**     MIDI 模式：[2][-][-][八度][音色][音符]
//**     Theremin 模式：[3][距离十][距离个][实际八度][1][简谱音符]
//*****************************************************
wire [4:0] disp_note = mode_theremin ? (theremin_gate ? {1'b0,theremin_note} : 5'd0) :
                       v_gate[0] ? v_note[0] :
                       v_gate[1] ? v_note[1] :
                       v_gate[2] ? v_note[2] :
                       v_gate[3] ? v_note[3] : 5'd0;
wire [6:0] display_key_pitch=v_gate[0] ? v_pitch[0] : v_gate[1] ? v_pitch[1] :
                             v_gate[2] ? v_pitch[2] : v_gate[3] ? v_pitch[3] : 7'd0;
wire [3:0] disp_octave = mode_theremin ? theremin_octave :
                         (extended_mode && display_key_pitch!=0) ?
                            ((display_key_pitch>=7'd84) ? 4'd6 :
                             (display_key_pitch>=7'd72) ? 4'd5 :
                             (display_key_pitch>=7'd60) ? 4'd4 : 4'd3) :
                         ((octave == 2'd1) ? 4'd5 : (octave == 2'd2) ? 4'd3 : 4'd4) +
                         ((disp_note >= 5'd13) ? 4'd1 : 4'd0);
wire [3:0] disp_timbre = mode_theremin ? 4'd1 : ({2'd0, timbre} + 4'd1);

seg_dual u_seg(
    .sys_clk     (sys_clk),
    .sys_rst_n   (sys_rst_n),
    .mode_sel    (source_mode),
    .octave      (disp_octave),
    .timbre      (disp_timbre),
    .note        (disp_note),
    .distance_cm (distance_cm),
    .seg_sel     (seg_sel),
    .seg_led     (seg_led)
);

// ⭐ LED 音源模式指示（4 bit 三态）：
//   FM 合成       (00)：4 LED = v_gate（正常显示 4 声部）
//   MIDI UART     (01)：最右 LED 常亮 + 其余 3 个 = v_gate[3:1]
//   超声特雷门琴  (10)：最左 LED 常亮 + voice[0] gate + 其余静音
assign led = mode_fm       ? v_gate
           : mode_midi     ? {v_gate[3:1], 1'b1}
           : {1'b1, 2'b0, theremin_gate};

endmodule
