// Streaming256-point rectangular-window DFT, bins0..31. One shared multiplier.
// Accumulators are a shared64x40 block RAM, not2560 routed flip-flops.
// Seven clocks/bin, nine on publication; audio period is1024 clocks.
module spectrum32(
    input wire clk,rst_n,clear,sample_tick,
    input wire signed [15:0] sample,
    output reg [255:0] bars,
    output reg [511:0] magnitudes,
    output reg frame_valid
);
    (* syn_romstyle="block_rom" *) reg signed [15:0] coefficients[0:511];
    initial $readmemh("rom/dft256_twiddle.hex",coefficients);
    reg signed [15:0] coefficient,pcm;
    reg signed [31:0] product,real_product;
    (* syn_ramstyle="block_ram" *) reg signed [39:0] accumulators[0:63];
    reg signed [39:0] accumulator_read,acc_real,acc_imag;
    reg [7:0] n,angle;
    reg [4:0] bin;
    reg [3:0] stage;
    reg running;
    wire [8:0] rom_address={stage>=3,angle};
    always @(posedge clk)if(running && (stage==0 || stage==3))
        coefficient<=coefficients[rom_address];
    wire signed [39:0] real_total=acc_real+{{8{real_product[31]}},real_product};
    wire signed [39:0] imag_total=acc_imag-{{8{product[31]}},product};
    reg [39:0] abs_real,abs_imag;
    reg [40:0] magnitude;
    // Read and write on different clocks, no collision-mode dependency.
    // n==0 ignores old memory after reset/clear/frame wrap.
    always @(posedge clk)if(running && !clear)begin
        if(stage==0 || stage==3)accumulator_read<=accumulators[{bin,(stage==3)}];
        if(stage==5)accumulators[{bin,1'b0}]<=real_total;
        if(stage==6)accumulators[{bin,1'b1}]<=imag_total;
    end
    wire [17:0] normalized=magnitude[40:23];
    wire [15:0] magnitude16=normalized>65535 ? 16'hffff : normalized[15:0];
    wire [7:0] level=magnitude16>16320 ? 8'd255 : magnitude16[13:6];
    reg [255:0] pending_bars;
    reg [511:0] pending_magnitudes;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            bars<=0;magnitudes<=0;pending_bars<=0;pending_magnitudes<=0;
            frame_valid<=0;n<=0;angle<=0;bin<=0;stage<=0;running<=0;
            pcm<=0;product<=0;real_product<=0;acc_real<=0;acc_imag<=0;abs_real<=0;abs_imag<=0;magnitude<=0;
        end else if(clear)begin
            bars<=0;magnitudes<=0;pending_bars<=0;pending_magnitudes<=0;
            frame_valid<=0;n<=0;angle<=0;bin<=0;stage<=0;running<=0;
            acc_real<=0;acc_imag<=0;abs_real<=0;abs_imag<=0;magnitude<=0;
        end else begin
            frame_valid<=0;
            if(sample_tick && !running)begin
                pcm<=sample;running<=1;stage<=0;bin<=0;angle<=0;
            end else if(running)begin
                stage<=stage+1'b1;
                case(stage)
                    1:begin product<=pcm*coefficient;acc_real<=n==0 ? 40'sd0 : accumulator_read;end
                    2:real_product<=product;
                    4:begin product<=pcm*coefficient;acc_imag<=n==0 ? 40'sd0 : accumulator_read;end
                    6:begin
                        if(n==255)begin
                            abs_real<=real_total<0 ? -real_total : real_total;
                            abs_imag<=imag_total<0 ? -imag_total : imag_total;
                        end else begin
                            stage<=0;angle<=angle+n;bin<=bin+1'b1;
                            if(bin==31)begin running<=0;n<=n+1'b1;end
                        end
                    end
                    7:magnitude<={1'b0,abs_real}+{1'b0,abs_imag};
                    8:begin
                        pending_bars[bin*8+:8]<=level;
                        pending_magnitudes[bin*16+:16]<=magnitude16;
                        stage<=0;angle<=angle+n;bin<=bin+1'b1;
                        if(bin==31)begin
                            running<=0;n<=n+1'b1;
                            bars<={level,pending_bars[247:0]};
                            magnitudes<={magnitude16,pending_magnitudes[495:0]};
                            frame_valid<=1;
                        end
                    end
                    default:;
                endcase
            end
        end
    end
endmodule
