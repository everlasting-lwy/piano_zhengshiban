// One shared8192x16 store: multitap room,echo and modulated short-delay chorus.
// A frame is captured at tick+24, published at+40, before I2S load at+64.
module audio_effects(
    input wire clk,rst_n,clear,sample_tick,
    input wire signed [15:0] pcm,
    input wire [3:0] expression,reverb,echo,chorus,
    input wire [1:0] delay_select,
    output reg signed [15:0] sample,lag_sample,
    output reg sample_valid,clipped
);
    (* syn_ramstyle="block_ram" *) reg signed [15:0] history[0:8191];
    reg [12:0] write_pointer;
    reg [13:0] fill_count;
    reg [23:0] lfo;
    reg running;
    reg [5:0] cycle;
    reg [3:0] rev_level,echo_level,chorus_level;
    reg [1:0] delay_latched;
    reg [4:0] gain;
    reg signed [20:0] dry_product,wet_product;
    reg signed [15:0] dry,echo_tap,r1,r2,r3,r4,chorus_tap;
    reg signed [17:0] rev_average;
    reg signed [20:0] echo_wet,rev_wet,chorus_wet;
    reg [12:0] read_delay;
    wire [12:0] read_address=write_pointer-read_delay;
    reg signed [15:0] read_sample;
    reg read_allowed;
    wire [6:0] triangle=lfo[23] ? ~lfo[22:16] : lfo[22:16];
    always @(*)begin
        case(cycle)
            25:read_delay=delay_latched==0 ? 13'd4096 : delay_latched==1 ? 13'd6144 : 13'd8191;
            26:read_delay=13'd1499;
            27:read_delay=13'd2111;
            28:read_delay=13'd3167;
            29:read_delay=13'd4093;
            30:read_delay=13'd448+{6'd0,triangle};
            default:read_delay=13'd64;
        endcase
    end
    // Unreset memory datapath permits block RAM inference. Validity is separate.
    always @(posedge clk)if(running && cycle>=25 && cycle<=31)
        read_sample<=history[read_address];
    wire signed [18:0] rev_sum=
        {{3{r1[15]}},r1}+{{3{r2[15]}},r2}+{{3{r3[15]}},r3}+{{3{r4[15]}},r4};
    wire signed [17:0] wet_source=cycle==34 ? {{2{echo_tap[15]}},echo_tap} :
        cycle==35 ? rev_average : {{2{chorus_tap[15]}},chorus_tap};
    wire signed [4:0] wet_amount=cycle==34 ? $signed({1'b0,echo_level}) :
        cycle==35 ? $signed({1'b0,rev_level}) : $signed({1'b0,chorus_level});
    wire signed [22:0] wet_calculation=wet_source*wet_amount;
    wire signed [21:0] dry_extended={{6{dry[15]}},dry};
    // A concatenation directly in this sum would make the entire expression
    // unsigned, turning negative wet arithmetic shifts into logical shifts.
    wire signed [21:0] wet_sum=
        dry_extended+(echo_wet>>>5)+(rev_wet>>>5)+(chorus_wet>>>5);
    // Truncation toward zero ensures tiny negative feedback also dies away.
    function signed [21:0] divide_zero;
        input signed [21:0] value;input integer shift;
        begin divide_zero=value<0 ? -((-value)>>>shift) : (value>>>shift);end
    endfunction
    wire signed [21:0] feedback_sum=dry_extended+
        (rev_level!=0 ? divide_zero({{4{rev_average[17]}},rev_average},2) : 22'sd0)+
        (echo_level!=0 ? divide_zero({{6{echo_tap[15]}},echo_tap},3) : 22'sd0);
    function signed [15:0] saturate;
        input signed [21:0] value;
        begin saturate=value>32767 ? 16'sh7fff : value < -32768 ? 16'sh8000 : value[15:0];end
    endfunction
    always @(posedge clk)if(running && cycle==39 && !clear)
        history[write_pointer]<=saturate(feedback_sum);
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            write_pointer<=0;fill_count<=0;lfo<=0;running<=0;cycle<=0;
            sample<=0;lag_sample<=0;sample_valid<=0;clipped<=0;
            rev_level<=0;echo_level<=0;chorus_level<=0;delay_latched<=0;gain<=16;
            dry_product<=0;wet_product<=0;dry<=0;echo_tap<=0;r1<=0;r2<=0;r3<=0;r4<=0;
            chorus_tap<=0;rev_average<=0;echo_wet<=0;rev_wet<=0;chorus_wet<=0;read_allowed<=0;
        end else if(clear)begin
            write_pointer<=0;fill_count<=0;lfo<=0;running<=0;cycle<=0;
            sample<=0;lag_sample<=0;sample_valid<=0;clipped<=0;
            dry<=0;echo_tap<=0;r1<=0;r2<=0;r3<=0;r4<=0;chorus_tap<=0;
            echo_wet<=0;rev_wet<=0;chorus_wet<=0;rev_average<=0;read_allowed<=0;
        end else begin
            sample_valid<=0;
            if(sample_tick)begin running<=1;cycle<=0;lfo<=lfo+24'd344;end
            else if(running)begin
                cycle<=cycle+1'b1;
                if(cycle==23)begin
                    gain<=expression==15 ? 5'd16 : {1'b0,expression};
                    rev_level<=reverb;echo_level<=echo;chorus_level<=chorus;delay_latched<=delay_select;
                end
                if(cycle==24)dry_product<=pcm*$signed({1'b0,gain});
                if(cycle==25)dry<=dry_product>>>4;
                if(cycle>=25 && cycle<=31)read_allowed<=fill_count>={1'b0,read_delay};
                case(cycle)
                    26:echo_tap<=read_allowed ? read_sample : 16'sd0;
                    27:r1<=read_allowed ? read_sample : 16'sd0;
                    28:r2<=read_allowed ? read_sample : 16'sd0;
                    29:r3<=read_allowed ? read_sample : 16'sd0;
                    30:r4<=read_allowed ? read_sample : 16'sd0;
                    31:chorus_tap<=read_allowed ? read_sample : 16'sd0;
                    32:lag_sample<=read_allowed ? read_sample : 16'sd0;
                    33:rev_average<=rev_sum>>>2;
                    34:wet_product<=wet_calculation;
                    35:begin echo_wet<=wet_product;wet_product<=wet_calculation;end
                    36:begin rev_wet<=wet_product;wet_product<=wet_calculation;end
                    37:chorus_wet<=wet_product;
                    39:begin
                        sample<=saturate(wet_sum);
                        clipped<=(wet_sum>32767 || wet_sum < -32768);
                        write_pointer<=write_pointer+1'b1;
                        if(fill_count<8192)fill_count<=fill_count+1'b1;
                        sample_valid<=1;running<=0;
                    end
                    default:;
                endcase
            end
        end
    end
endmodule
