//****************************************************************************************//
// 模块名：seg_dual —— 数码管 6 位动态扫描（三模式自适应显示）
// 板载 6 位共阳：位选 seg_sel[5:0] 低电平选通，段选 seg_led[7:0] 低电平点亮
//
// 显示规划（统一布局，6 位从左到右 = seg_sel[5]→seg_sel[0]）：
//   [模式] [距十位] [距个位] [八度] [音色] [音调]
//   模式位：1=FM合成  2=MIDI  3=特雷门琴
//   特雷门琴模式：中间两位显示实际距离 cm
//   FM/MIDI 模式：中间两位显示 "-"（距离无意义）
//   每位 1ms，六位一轮约 167Hz
//****************************************************************************************//

module seg_dual(
    input  wire        sys_clk ,
    input  wire        sys_rst_n,
    input  wire [1:0]  mode_sel,    // 00=FM, 01=MIDI, 10=Theremin
    input  wire [3:0]  octave  ,    // 实际音高所在八度（由顶层按模式选择）
    input  wire [3:0]  timbre  ,    // 音色显示值（1~4）
    input  wire [4:0]  note    ,    // 音符ID 0~18；特雷门琴为简谱1~7
    input  wire [15:0] distance_cm, // 超声距离（999=无效）
    output reg  [5:0]  seg_sel ,
    output reg  [7:0]  seg_led
);

// ======== 扫描计数器 ========
reg [15:0] scan_cnt;
reg [2:0] scan_sel;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        scan_cnt <= 16'd0;
        scan_sel <= 3'd0;
    end
    else if (scan_cnt == 16'd49999) begin
        scan_cnt <= 16'd0;
        scan_sel <= (scan_sel == 3'd5) ? 3'd0 : scan_sel + 3'd1;
    end
    else scan_cnt <= scan_cnt + 16'd1;
end

// ======== 位选 ========
always @(*) begin
    case (scan_sel)
        3'd0:    seg_sel = 6'b111110;   // 最右
        3'd1:    seg_sel = 6'b111101;
        3'd2:    seg_sel = 6'b111011;
        3'd3:    seg_sel = 6'b110111;
        3'd4:    seg_sel = 6'b101111;
        3'd5:    seg_sel = 6'b011111;   // 最左
        default: seg_sel = 6'b111111;
    endcase
end

// ======== 显示规划（统一布局：从左到右 = seg_sel[5]→seg_sel[0]）========
// scan_sel=5 (最左): 模式   1=FM合成  2=MIDI  3=特雷门琴
// scan_sel=4        : 距离十位（特雷门琴模式）/ "-"（其他模式）
// scan_sel=3        : 距离个位（特雷门琴模式）/ "-"（其他模式）
// scan_sel=2        : 实际音高所在八度
// scan_sel=1        : 音色   1~4
// scan_sel=0 (最右) : 音调   0~7（0=静音，1~7=do~si）

// ======== 显示内容选择 ========
wire distance_display_valid = (distance_cm <= 16'd99);
wire [6:0] d = distance_cm[6:0];
wire [3:0] d_ones  = d % 7'd10;
wire [3:0] d_tens  = d / 7'd10;

reg [3:0] disp_val;
reg [3:0] note_digit;
wire note_sharp = (mode_sel != 2'd2 && ((note >= 5'd8 && note <= 5'd12) || note == 5'd14 || note == 5'd16));
always @(*) begin
    case (note)
        5'd8: note_digit = 4'd1;
        5'd9: note_digit = 4'd2;
        5'd10: note_digit = 4'd4;
        5'd11: note_digit = 4'd5;
        5'd12: note_digit = 4'd6;
        5'd13,5'd14: note_digit = 4'd1;
        5'd15,5'd16: note_digit = 4'd2;
        5'd17: note_digit = 4'd3;
        5'd18: note_digit = 4'd4;
        default: note_digit = note[3:0];
    endcase
end
always @(*) begin
    case (scan_sel)
        // —— scan_sel=5 最左：模式 ——
        3'd5: case (mode_sel)
                  2'd0:    disp_val = 4'd1;
                  2'd1:    disp_val = 4'd2;
                  2'd2:    disp_val = 4'd3;
                  default: disp_val = 4'hA;
              endcase
        // —— scan_sel=4：距离十位 ——
        3'd4: disp_val = (mode_sel == 2'd2 && distance_display_valid) ? d_tens : 4'hA;
        // —— scan_sel=3：距离个位 ——
        3'd3: disp_val = (mode_sel == 2'd2 && distance_display_valid) ? d_ones : 4'hA;
        // —— scan_sel=2：八度 ——
        3'd2: disp_val = octave;
        // —— scan_sel=1：音色 ——
        3'd1: disp_val = timbre;
        // —— scan_sel=0 最右：音调（音符）——
        3'd0: disp_val = (mode_sel == 2'd2) ? note[3:0] : note_digit;
        default: disp_val = 4'h0;
    endcase
end

// ======== 段码表（共阳，低电平点亮）========
// 数字 0~9 + 字母（近似显示）+ 空
// 格式：{dp, g, f, e, d, c, b, a}
always @(*) begin
    case (disp_val)
        4'd0:    seg_led = 8'b1100_0000;   // '0'
        4'd1:    seg_led = 8'b1111_1001;   // '1'
        4'd2:    seg_led = 8'b1010_0100;   // '2'
        4'd3:    seg_led = 8'b1011_0000;   // '3'
        4'd4:    seg_led = 8'b1001_1001;   // '4'
        4'd5:    seg_led = 8'b1001_0010;   // '5'
        4'd6:    seg_led = 8'b1000_0010;   // '6'
        4'd7:    seg_led = 8'b1111_1000;   // '7'
        4'd8:    seg_led = 8'b1000_0000;   // '8'
        4'd9:    seg_led = 8'b1001_0000;   // '9'
        // 字母/符号近似显示（7 段管，共阳低电平点亮）
        4'hA:    seg_led = 8'b1011_1111;   // '-' → 只有 g 段亮（中间一横）
        4'hB:    seg_led = 8'b1000_1100;
        4'hC:    seg_led = 8'b1000_1001;   // 'H' → H 近似 (g=c=f=b=e)
        4'hD:    seg_led = 8'b1000_0111;   // 't' → g+f+e+d
        4'hE:    seg_led = 8'b1100_0111;
        4'hF:    seg_led = 8'b1000_1111;   // 'F' → F (g=f=e=b)
        default: seg_led = 8'b1111_1111;   // 全灭（空）
    endcase
    if (scan_sel == 3'd0 && note_sharp)
        seg_led[7] = 1'b0;
end

endmodule
