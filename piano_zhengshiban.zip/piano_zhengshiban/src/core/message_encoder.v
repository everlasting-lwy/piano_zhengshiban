module message_encoder #(parameter integer USE_DIRECT_PITCH=0)(
    input             clk,
    input             rst_n,
    input      [3:0]  gate,
    input      [19:0] note_all,
    input      [27:0] pitch_all,
    input      [1:0]  octave,
    input             midi_en,
    input             mready,
    output reg [7:0]  data,
    output reg        mstart
);

function [6:0] pitch_for_note;
    input [4:0] note;
    input [1:0] selected_octave;
    reg [6:0] base_pitch;
    reg [4:0] offset;
    begin
        case (selected_octave)
            2'd1: base_pitch = 7'd72;
            2'd2: base_pitch = 7'd48;
            default: base_pitch = 7'd60;
        endcase
        case (note)
            5'd1: offset = 5'd0;
            5'd2: offset = 5'd2;
            5'd3: offset = 5'd4;
            5'd4: offset = 5'd5;
            5'd5: offset = 5'd7;
            5'd6: offset = 5'd9;
            5'd7: offset = 5'd11;
            5'd8: offset = 5'd1;
            5'd9: offset = 5'd3;
            5'd10: offset = 5'd6;
            5'd11: offset = 5'd8;
            5'd12: offset = 5'd10;
            5'd13: offset = 5'd12;
            5'd14: offset = 5'd13;
            5'd15: offset = 5'd14;
            5'd16: offset = 5'd15;
            5'd17: offset = 5'd16;
            5'd18: offset = 5'd17;
            default: offset = 5'd0;
        endcase
        pitch_for_note = base_pitch + offset;
    end
endfunction

reg [3:0] sent_gate;
reg [6:0] sent_pitch [0:3];
reg busy_flag;
reg pending;
reg pending_on;
reg [1:0] pending_voice;
reg [6:0] pending_pitch;
reg [4:0] current_note;
reg [6:0] current_pitch;
integer voice_index;

always @(*) begin
    pending = 1'b0;
    pending_on = 1'b0;
    pending_voice = 2'd0;
    pending_pitch = 7'd0;
    current_note = 5'd0;
    current_pitch = 7'd0;

    for (voice_index = 0; voice_index < 4; voice_index = voice_index + 1) begin
        current_note = note_all[voice_index*5 +: 5];
        current_pitch = USE_DIRECT_PITCH ? pitch_all[voice_index*7 +: 7] : pitch_for_note(current_note, octave);
        if (!pending && sent_gate[voice_index] &&
            (!midi_en || !gate[voice_index] || current_note < 5'd1 ||
             current_note > 5'd18 || sent_pitch[voice_index] != current_pitch)) begin
            pending = 1'b1;
            pending_voice = voice_index[1:0];
            pending_pitch = sent_pitch[voice_index];
        end
    end

    for (voice_index = 0; voice_index < 4; voice_index = voice_index + 1) begin
        current_note = note_all[voice_index*5 +: 5];
        if (!pending && midi_en && gate[voice_index] && !sent_gate[voice_index] &&
            current_note >= 5'd1 && current_note <= 5'd18) begin
            pending = 1'b1;
            pending_on = 1'b1;
            pending_voice = voice_index[1:0];
            pending_pitch = USE_DIRECT_PITCH ? pitch_all[voice_index*7 +: 7] : pitch_for_note(current_note, octave);
        end
    end
end

integer reset_index;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        data <= 8'd0;
        mstart <= 1'b0;
        sent_gate <= 4'd0;
        busy_flag <= 1'b0;
        for (reset_index = 0; reset_index < 4; reset_index = reset_index + 1)
            sent_pitch[reset_index] <= 7'd0;
    end
    else begin
        mstart <= 1'b0;
        if (busy_flag && mready)
            busy_flag <= 1'b0;
        else if (!busy_flag && mready && pending) begin
            data <= {pending_pitch, pending_on};
            mstart <= 1'b1;
            busy_flag <= 1'b1;
            sent_gate[pending_voice] <= pending_on;
            if (pending_on)
                sent_pitch[pending_voice] <= pending_pitch;
        end
    end
end

endmodule
