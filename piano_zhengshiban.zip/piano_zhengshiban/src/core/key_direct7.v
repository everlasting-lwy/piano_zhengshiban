// Independent active-low keys; board wrapper already provides two-flop sync.
// At50MHz defaults use one shared10us sampling tick,100 press samples and
// 200 release samples (about1ms/2ms). A bouncing key cannot block another.
// Keep the original module/DEBOUNCE_CYCLES parameter for project compatibility.
module key_direct7 #(
    parameter KEY_COUNT=7,
    parameter DEBOUNCE_CYCLES=50000,
    parameter RELEASE_CYCLES=2*DEBOUNCE_CYCLES,
    parameter SAMPLE_CYCLES=(DEBOUNCE_CYCLES<500) ? 1 : 500
)(
    input wire sys_clk,
    input wire sys_rst_n,
    input wire [KEY_COUNT-1:0] key_in,
    output reg [KEY_COUNT-1:0] keys
);
    localparam PRESS_TICKS=(DEBOUNCE_CYCLES+SAMPLE_CYCLES-1)/SAMPLE_CYCLES;
    localparam RELEASE_TICKS=(RELEASE_CYCLES+SAMPLE_CYCLES-1)/SAMPLE_CYCLES;
    localparam MAX_TICKS=(PRESS_TICKS>RELEASE_TICKS) ? PRESS_TICKS : RELEASE_TICKS;
    localparam COUNT_WIDTH=(MAX_TICKS<2) ? 1 : $clog2(MAX_TICKS+1);
    localparam SAMPLE_WIDTH=(SAMPLE_CYCLES<2) ? 1 : $clog2(SAMPLE_CYCLES);
    reg [SAMPLE_WIDTH-1:0] sample_count;
    reg [COUNT_WIDTH-1:0] stable_count[0:KEY_COUNT-1];
    wire tick=(sample_count==SAMPLE_CYCLES-1);
    wire [KEY_COUNT-1:0] pressed=~key_in;
    integer i;
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            sample_count<=0;keys<=0;
            for(i=0;i<KEY_COUNT;i=i+1)stable_count[i]<=0;
        end else begin
            sample_count<=tick ? {SAMPLE_WIDTH{1'b0}} : sample_count+1'b1;
            for(i=0;i<KEY_COUNT;i=i+1) begin
                // Returning to the accepted level resets even between ticks;
                // old partial counts cannot leak into the next transition.
                if(pressed[i]==keys[i]) stable_count[i]<=0;
                else if(tick) begin
                    if((!keys[i] && stable_count[i]>=PRESS_TICKS-1) ||
                       ( keys[i] && stable_count[i]>=RELEASE_TICKS-1))begin
                        keys[i]<=pressed[i];stable_count[i]<=0;
                    end else stable_count[i]<=stable_count[i]+1'b1;
                end
            end
        end
    end
endmodule
