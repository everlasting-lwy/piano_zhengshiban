// Autonomous bounded FAT32 reader. The phone owns all filesystem mutation.
// P18 bytes are opaque here: sd_song_bridge alone validates and publishes.
// One synchronous sector RAM; no cluster-chain RAM. Root tails and selected
// file chains are range/cycle checked before selected file bytes stream.
module fat32_file_store #(
 parameter IO_TIMEOUT_CYCLES=100000000,
 parameter ROOT_SECTOR_LIMIT=4096,
 parameter FREE_FAT_SECTOR_LIMIT=8192
)(
 input wire clk,rst_n,media_ready,input wire[31:0]media_sectors,input wire[7:0]media_error,
 input wire request,input wire[1:0]operation,input wire[4:0]slot,input wire[15:0]write_size,
 output reg mounted,busy,done,output reg[7:0]error,output reg[15:0]file_size,output reg[31:0]present_slots,
 output reg[7:0]file_attributes,output reg write_locked,
 output reg read_valid,output reg[15:0]read_index,output reg[7:0]read_data,input wire read_ready,
 output wire source_request,output wire[15:0]source_index,input wire source_valid,input wire[7:0]source_data,
 output reg block_start,output wire block_write,output reg[31:0]block_lba,
 input wire block_busy,block_done,input wire[7:0]block_error,
 input wire rd_valid,input wire[8:0]rd_index,input wire[7:0]rd_data,
 input wire wr_request,input wire[8:0]wr_index,output wire wr_valid,output wire[7:0]wr_data
);
 localparam E_MEDIA=1,E_BOOT=2,E_UNSUPPORTED=3,E_GEOMETRY=4,E_CHAIN=5,E_NOT_FOUND=6,E_FILE=7,E_IO=9,E_SEARCH=11,E_TIMEOUT=16;
 localparam IDLE=0,FINISH=1,BOOT_READ=2,BOOT_CHECK=3,GEO_BEGIN=4,GEO_SHIFT=5,GEO_CHECK=6,MOUNT_FAT=7,MOUNT_GOT=8,
  ROOT_BEGIN=9,ROOT_CLUSTER=10,ROOT_SECTOR=11,ENTRY_SET=12,ENTRY_WAIT=13,ENTRY_BYTE=14,ENTRY_CHECK=15,ENTRY_NEXT=16,
  ROOT_FAT=17,ROOT_NEXT=18,ROOT_END=19,FILE_BEGIN=20,FILE_FAT=21,FILE_CHECK=22,READ_BEGIN=23,READ_SECTOR=24,
  READ_SET=25,READ_WAIT=26,READ_BYTE=27,READ_ACK=28,READ_FAT=29,READ_NEXT=30,
  FAT_BASE=31,FAT_INDEX=32,FAT_GOT=33,DATA_SUB=34,DATA_SHIFT=35,DATA_BASE=36,DATA_SECTOR=37,
  IO_START=38,IO_WAIT=39,IO_DRAIN=40,GEO_VALIDATE=41,GEO_FAT_BASE=42,GEO_DATA_BASE=43,
  GEO_LIMIT=44,GEO_OVERHEAD=45,MBR_EXTENT=46,MBR_VALIDATE=47;
 localparam TIMER_BITS=$clog2(IO_TIMEOUT_CYCLES+1);
 reg[5:0]state,io_return,fat_return,data_return;
 reg op;reg[4:0]selected_slot;
 reg[7:0]sector_ram[0:511];reg[8:0]ram_address;reg[7:0]ram_q;
 always @(posedge clk)begin
  ram_q<=sector_ram[ram_address];
  if(rst_n&&state==IO_WAIT&&rd_valid)sector_ram[rd_index]<=rd_data;
 end
 assign block_write=1'b0;assign source_request=1'b0;assign source_index=16'd0;assign wr_valid=1'b0;assign wr_data=8'd0;
 reg[TIMER_BITS-1:0]io_timer;reg[1:0]io_drain;
 reg[31:0]volume_base,volume_size,fat_sectors,fat_base,data_base;
 reg[27:0]max_cluster,root_cluster;
 reg[15:0]reserved_sectors;
 reg[7:0]spc;reg[2:0]spc_shift,shift_left;
 reg spc_ok,fats_ok,two_fats,zero_ok,sector_ok_low,sector_ok_high,jump_ok,sig_low,sig_high,active_fat;
 reg[3:0]active_number;reg mirror_disabled;
 reg partition_found,boot_partition,mbr_candidate;
 reg[32:0]overhead,cluster_count;
 reg[27:0]fat_target,fat_value;reg fat_clean;
 reg[31:0]address_work;
 // MBR fields are dead after mounting. Reuse calculation registers instead
 // of retaining duplicate 32-bit partition/base/extent copies in flip-flops.
 wire[31:0]found_base=address_work,found_size=cluster_count[31:0];
 wire[31:0]partition_size=boot_partition?found_size:media_sectors;
 reg[27:0]current_cluster,tortoise,target_cluster;
 reg[12:0]root_sectors,walk_power,walk_lam;
 reg[7:0]sector_in_cluster;
 reg directory_end,target_found,target_invalid;
 reg[8:0]dir_offset;reg[4:0]entry_byte;
 reg[7:0]entry_prefix,entry_attributes;reg[27:0]entry_cluster;reg[12:0]entry_size;reg entry_high_bad;
 reg entry_name_valid;reg[1:0]entry_tens;reg[5:0]entry_number;
 reg[12:0]target_size,position;reg[8:0]byte_position;
 reg[4:0]file_clusters,clusters_left;
 wire[4:0]file_sectors={1'b0,target_size[12:9]}+(|target_size[8:0]);
 wire[4:0]needed_clusters=spc>=16?5'd1:((file_sectors+{1'b0,spc[3:0]}-5'd1)>>spc_shift);
 wire root_limit_exceeded=({1'b0,root_sectors}+{6'd0,spc})>ROOT_SECTOR_LIMIT;
 wire[27:0]range_cluster=state==GEO_VALIDATE?root_cluster:state==ENTRY_CHECK?entry_cluster:fat_value;
 wire next_in_range=range_cluster>=2&&range_cluster<=max_cluster;
 wire next_eoc=fat_value>=28'hffffff8;
 // Mount and address calculations never overlap. Reuse one carry chain,
 // rather than inferring a wide adder for every FSM expression.
 reg[32:0]alu_a,alu_b;reg alu_sub;
 wire[32:0]alu_result=alu_a+(alu_b^{33{alu_sub}})+alu_sub;
 always @*begin
  alu_a={1'b0,address_work};alu_b=0;alu_sub=0;
  case(state)
   GEO_OVERHEAD:begin alu_a={17'd0,reserved_sectors};alu_b=two_fats?{fat_sectors,1'b0}:{1'b0,fat_sectors};end
   GEO_LIMIT:begin alu_a={1'b0,partition_size};alu_b={1'b0,volume_size};alu_sub=1;end
   MBR_EXTENT:begin alu_a={1'b0,found_base};alu_b={1'b0,found_size};end
   MBR_VALIDATE:begin alu_a={1'b0,media_sectors};alu_b=overhead;alu_sub=1;end
   GEO_BEGIN:begin alu_a={1'b0,volume_size};alu_b=overhead;alu_sub=1;end
   GEO_CHECK:begin alu_a=cluster_count;alu_b=1;end
   GEO_FAT_BASE:begin alu_a={1'b0,volume_base};alu_b={17'd0,reserved_sectors};end
   GEO_DATA_BASE:begin alu_a={1'b0,volume_base};alu_b=overhead;end
   FAT_BASE:begin alu_a={1'b0,fat_base};alu_b=active_fat?{1'b0,fat_sectors}:33'd0;end
   FAT_INDEX:alu_b={12'd0,fat_target[27:7]};
   DATA_SUB:begin alu_a={5'd0,current_cluster};alu_b=2;alu_sub=1;end
   DATA_BASE:alu_b={1'b0,data_base};
   DATA_SECTOR:alu_b={25'd0,sector_in_cluster};
   default:;
  endcase
 end
 task fail;input[7:0]code;begin error<=code;read_valid<=0;state<=FINISH;end endtask
 task read_sector;input[31:0]lba;input[5:0]back;begin block_lba<=lba;io_return<=back;io_timer<=0;state<=IO_START;end endtask
 task get_fat;input[27:0]cluster;input[5:0]back;begin fat_target<=cluster;fat_return<=back;state<=FAT_BASE;end endtask
 task data_sector;input[5:0]back;begin data_return<=back;state<=DATA_SUB;end endtask
 task advance_chain;begin
  current_cluster<=fat_value;sector_in_cluster<=0;
  if(walk_lam+1'b1==walk_power)begin tortoise<=fat_value;walk_power<=walk_power<<1;walk_lam<=0;end
  else walk_lam<=walk_lam+1'b1;
 end endtask
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;mounted<=0;busy<=0;done<=0;error<=0;file_size<=0;present_slots<=0;file_attributes<=0;write_locked<=0;
   read_valid<=0;read_index<=0;read_data<=0;block_start<=0;block_lba<=0;ram_address<=0;io_timer<=0;io_drain<=0;
   op<=0;selected_slot<=0;volume_base<=0;volume_size<=0;fat_sectors<=0;fat_base<=0;data_base<=0;max_cluster<=0;root_cluster<=0;
   partition_found<=0;boot_partition<=0;spc<=0;spc_shift<=0;reserved_sectors<=0;active_fat<=0;
   spc_ok<=0;fats_ok<=0;zero_ok<=0;sector_ok_low<=0;sector_ok_high<=0;jump_ok<=0;sig_low<=0;sig_high<=0;two_fats<=0;active_number<=0;mirror_disabled<=0;
   fat_target<=0;fat_value<=0;fat_clean<=0;current_cluster<=0;target_cluster<=0;tortoise<=0;root_sectors<=0;walk_power<=0;walk_lam<=0;
   sector_in_cluster<=0;directory_end<=0;target_found<=0;target_invalid<=0;dir_offset<=0;entry_byte<=0;entry_prefix<=0;entry_attributes<=0;entry_cluster<=0;entry_size<=0;
   entry_name_valid<=0;entry_tens<=0;entry_number<=0;target_size<=0;position<=0;byte_position<=0;file_clusters<=0;clusters_left<=0;
  end else begin
   done<=0;block_start<=0;
   if(state==IO_WAIT&&rd_valid)begin
    if(rd_index[8:2]==fat_target[6:0])case(rd_index[1:0])
     0:fat_value[7:0]<=rd_data;1:fat_value[15:8]<=rd_data;2:fat_value[23:16]<=rd_data;3:begin fat_value[27:24]<=rd_data[3:0];fat_clean<=rd_data[3];end
    endcase
    if(io_return==BOOT_CHECK)begin
     case(rd_index)
      0:jump_ok<=rd_data==8'heb||rd_data==8'he9;
      11:sector_ok_low<=rd_data==0;12:sector_ok_high<=rd_data==2;
      13:begin
       spc<=rd_data;spc_ok<=1;
       case(rd_data)1:spc_shift<=0;2:spc_shift<=1;4:spc_shift<=2;8:spc_shift<=3;16:spc_shift<=4;32:spc_shift<=5;64:spc_shift<=6;128:spc_shift<=7;default:spc_ok<=0;endcase
      end
      14:reserved_sectors[7:0]<=rd_data;15:reserved_sectors[15:8]<=rd_data;
      16:begin fats_ok<=rd_data==1||rd_data==2;two_fats<=rd_data==2;end
      17,18,19,20,22,23,42,43:if(rd_data!=0)zero_ok<=0;
      32:volume_size[7:0]<=rd_data;33:volume_size[15:8]<=rd_data;34:volume_size[23:16]<=rd_data;35:volume_size[31:24]<=rd_data;
      36:fat_sectors[7:0]<=rd_data;37:fat_sectors[15:8]<=rd_data;38:fat_sectors[23:16]<=rd_data;39:fat_sectors[31:24]<=rd_data;
      40:begin mirror_disabled<=rd_data[7];active_number<=rd_data[3:0];end
      44:root_cluster[7:0]<=rd_data;45:root_cluster[15:8]<=rd_data;46:root_cluster[23:16]<=rd_data;
      47:begin root_cluster[27:24]<=rd_data[3:0];if(rd_data[7:4]!=0)zero_ok<=0;end
      510:sig_low<=rd_data==8'h55;511:sig_high<=rd_data==8'haa;
     endcase
     if(!boot_partition&&rd_index>=446&&rd_index<=509)case((rd_index-446)&15)
      4:mbr_candidate<=rd_data==8'h0b||rd_data==8'h0c;
      8,9,10,11:if(!partition_found&&mbr_candidate)case(rd_index[1:0])
       2:address_work[7:0]<=rd_data;3:address_work[15:8]<=rd_data;0:address_work[23:16]<=rd_data;1:address_work[31:24]<=rd_data;
      endcase
      12,13,14,15:if(!partition_found&&mbr_candidate)begin
       case(rd_index[1:0])2:cluster_count[7:0]<=rd_data;3:cluster_count[15:8]<=rd_data;0:cluster_count[23:16]<=rd_data;1:cluster_count[31:24]<=rd_data;endcase
       if(rd_index[1:0]==1)partition_found<=1;
      end
     endcase
    end
   end
   if(!media_ready&&state!=IDLE&&state!=FINISH)begin mounted<=0;fail(E_MEDIA);end
   else case(state)
    IDLE:begin
     busy<=0;if(!media_ready)mounted<=0;
     if(request)begin
      busy<=1;error<=0;op<=operation[0];selected_slot<=slot;read_valid<=0;file_attributes<=0;
      if(operation[1])fail(E_UNSUPPORTED);
      else if(!media_ready)fail(E_MEDIA);
      else if(operation==0)begin mounted<=0;present_slots<=0;volume_base<=0;partition_found<=0;boot_partition<=0;state<=BOOT_READ;end
      else if(!mounted)fail(E_BOOT);
      else state<=ROOT_BEGIN;
     end
    end
    FINISH:begin busy<=0;done<=1;state<=IDLE;end
    BOOT_READ:begin zero_ok<=1;read_sector(volume_base,BOOT_CHECK);end
    BOOT_CHECK:begin
     if(!sig_low||!sig_high)fail(E_BOOT);
     else if(sector_ok_low&&sector_ok_high&&jump_ok)begin
      if(!spc_ok||reserved_sectors==0||!fats_ok||!zero_ok||fat_sectors==0||volume_size==0||
       (mirror_disabled&&(active_number>1||(active_number==1&&!two_fats))))fail(E_GEOMETRY);
      else begin active_fat<=mirror_disabled&&active_number[0];state<=GEO_LIMIT;end
     end else if(!boot_partition&&partition_found&&found_base!=0&&found_size!=0)state<=MBR_EXTENT;
     else fail(E_UNSUPPORTED);
    end
    MBR_EXTENT:begin overhead<=alu_result;state<=MBR_VALIDATE;end
    MBR_VALIDATE:begin
     if(overhead[32]||alu_result[32])fail(E_GEOMETRY);
     else begin volume_base<=found_base;boot_partition<=1;state<=BOOT_READ;end
    end
    GEO_LIMIT:if(alu_result[32])fail(E_GEOMETRY);else state<=GEO_OVERHEAD;
    GEO_OVERHEAD:begin overhead<=alu_result;state<=GEO_BEGIN;end
    GEO_BEGIN:begin
     if(overhead[32]||alu_result[32]||alu_result==0)fail(E_GEOMETRY);
     else begin cluster_count<=alu_result;shift_left<=spc_shift;state<=GEO_SHIFT;end
    end
    GEO_SHIFT:if(shift_left==0)state<=GEO_CHECK;else begin cluster_count<=cluster_count>>1;shift_left<=shift_left-1'b1;end
    GEO_CHECK:begin
     if(cluster_count<65525||cluster_count>33'h0ffffff3)fail(E_GEOMETRY);
     else begin max_cluster<=alu_result[27:0];state<=GEO_VALIDATE;end
    end
    GEO_VALIDATE:begin
     if({fat_sectors,7'b0}<={11'd0,max_cluster}||!next_in_range)fail(E_GEOMETRY);
     else state<=GEO_FAT_BASE;
    end
    GEO_FAT_BASE:begin fat_base<=alu_result[31:0];state<=GEO_DATA_BASE;end
    GEO_DATA_BASE:begin data_base<=alu_result[31:0];state<=MOUNT_FAT;end
    MOUNT_FAT:get_fat(1,MOUNT_GOT);
    MOUNT_GOT:begin if(!fat_clean)write_locked<=1;state<=ROOT_BEGIN;end
    ROOT_BEGIN:begin
     current_cluster<=root_cluster;tortoise<=root_cluster;walk_power<=1;walk_lam<=0;root_sectors<=0;sector_in_cluster<=0;
     directory_end<=0;target_found<=0;target_invalid<=0;state<=ROOT_CLUSTER;
    end
    ROOT_CLUSTER:begin
     if(root_limit_exceeded)begin mounted<=0;fail(E_SEARCH);end
     else begin root_sectors<=root_sectors+spc;if(directory_end)state<=ROOT_FAT;else state<=ROOT_SECTOR;end
    end
    ROOT_SECTOR:begin dir_offset<=0;entry_byte<=0;data_sector(ENTRY_SET);end
    ENTRY_SET:begin ram_address<={dir_offset[8:5],entry_byte};state<=ENTRY_WAIT;end
    ENTRY_WAIT:state<=ENTRY_BYTE;
    ENTRY_BYTE:begin
     case(entry_byte)
      0:begin entry_prefix<=ram_q;entry_name_valid<=1;entry_high_bad<=0;end
      1,2,3,4,5:if(ram_q!=8'h30)entry_name_valid<=0;
      6:begin entry_tens<=ram_q[1:0];if(ram_q<8'h30||ram_q>8'h33)entry_name_valid<=0;end
      7:begin entry_number<=({4'd0,entry_tens}<<3)+({4'd0,entry_tens}<<1)+{2'd0,ram_q[3:0]};if(ram_q<8'h30||ram_q>8'h39)entry_name_valid<=0;end
      8:if(ram_q!=8'h50)entry_name_valid<=0;9:if(ram_q!=8'h31)entry_name_valid<=0;10:if(ram_q!=8'h38)entry_name_valid<=0;
      11:entry_attributes<=ram_q;
      20:entry_cluster[23:16]<=ram_q;
      21:begin entry_cluster[27:24]<=ram_q[3:0];if(ram_q[7:4]!=0)entry_high_bad<=1;end
      26:entry_cluster[7:0]<=ram_q;27:entry_cluster[15:8]<=ram_q;
      28:entry_size[7:0]<=ram_q;
      29:begin entry_size[12:8]<=ram_q[4:0];if(ram_q[7:5]!=0)entry_high_bad<=1;end
      30,31:if(ram_q!=0)entry_high_bad<=1;
     endcase
     if(entry_byte==31)state<=ENTRY_CHECK;else begin entry_byte<=entry_byte+1'b1;state<=ENTRY_SET;end
    end
    ENTRY_CHECK:begin
     state<=ENTRY_NEXT;
     if(entry_prefix==0)begin directory_end<=1;state<=ROOT_FAT;end
     else if(entry_prefix!=8'he5&&entry_name_valid&&entry_number<32)begin
      if(entry_prefix==8'h54)write_locked<=1;
      else if(entry_prefix==8'h50)begin
       if(!entry_high_bad&&(entry_attributes&8'h18)==0&&entry_size>=67&&entry_size<=6208&&next_in_range)present_slots[entry_number[4:0]]<=1;
       if(op&&entry_number==selected_slot)begin
        if(target_found)begin target_invalid<=1;write_locked<=1;end
        else begin target_found<=1;target_cluster<=entry_cluster;target_size<=entry_size;file_attributes<=entry_attributes;
         target_invalid<=entry_high_bad||(entry_attributes&8'h18)!=0||entry_size<67||entry_size>6208||!next_in_range;end
       end
      end
     end
    end
    ENTRY_NEXT:begin
     if(dir_offset==480)begin
      if(sector_in_cluster+1'b1<spc)begin sector_in_cluster<=sector_in_cluster+1'b1;state<=ROOT_SECTOR;end else state<=ROOT_FAT;
     end else begin dir_offset<=dir_offset+9'd32;entry_byte<=0;state<=ENTRY_SET;end
    end
    ROOT_FAT:get_fat(current_cluster,ROOT_NEXT);
    ROOT_NEXT:begin
     if(next_eoc)state<=ROOT_END;
     else if(!next_in_range||fat_value==tortoise)begin mounted<=0;fail(E_CHAIN);end
     else begin advance_chain;state<=ROOT_CLUSTER;end
    end
    ROOT_END:begin
     if(!op)begin mounted<=1;state<=FINISH;end
     else if(!target_found)fail(E_NOT_FOUND);
     else if(target_invalid)fail(E_FILE);
     else begin file_size<={3'd0,target_size};state<=FILE_BEGIN;end
    end
    FILE_BEGIN:begin
     current_cluster<=target_cluster;tortoise<=target_cluster;walk_power<=1;walk_lam<=0;
     file_clusters<=needed_clusters;clusters_left<=needed_clusters;state<=FILE_FAT;
    end
    FILE_FAT:get_fat(current_cluster,FILE_CHECK);
    FILE_CHECK:begin
     if(clusters_left==1)begin if(next_eoc)state<=READ_BEGIN;else fail(E_CHAIN);end
     else if(!next_in_range||fat_value==tortoise||clusters_left==0)fail(E_CHAIN);
     else begin advance_chain;clusters_left<=clusters_left-1'b1;state<=FILE_FAT;end
    end
    READ_BEGIN:begin current_cluster<=target_cluster;tortoise<=target_cluster;walk_power<=1;walk_lam<=0;clusters_left<=file_clusters;sector_in_cluster<=0;position<=0;state<=READ_SECTOR;end
    READ_SECTOR:begin byte_position<=0;data_sector(READ_SET);end
    READ_SET:begin ram_address<=byte_position;state<=READ_WAIT;end
    READ_WAIT:state<=READ_BYTE;
    READ_BYTE:begin read_data<=ram_q;read_index<={3'd0,position};read_valid<=1;state<=READ_ACK;end
    READ_ACK:if(read_valid&&read_ready)begin
     read_valid<=0;position<=position+1'b1;
     if(position+1'b1==target_size)state<=FINISH;
     else if(byte_position==511)begin
      if(sector_in_cluster+1'b1<spc)begin sector_in_cluster<=sector_in_cluster+1'b1;state<=READ_SECTOR;end else state<=READ_FAT;
     end else begin byte_position<=byte_position+1'b1;state<=READ_SET;end
    end
    READ_FAT:get_fat(current_cluster,READ_NEXT);
    READ_NEXT:begin
     if(!next_in_range||fat_value==tortoise||clusters_left<=1)fail(E_CHAIN);
     else begin advance_chain;clusters_left<=clusters_left-1'b1;state<=READ_SECTOR;end
    end
    FAT_BASE:begin address_work<=alu_result[31:0];state<=FAT_INDEX;end
    FAT_INDEX:read_sector(alu_result[31:0],FAT_GOT);
    FAT_GOT:state<=fat_return;
    DATA_SUB:begin address_work<=alu_result[31:0];shift_left<=spc_shift;state<=DATA_SHIFT;end
    DATA_SHIFT:if(shift_left==0)state<=DATA_BASE;else begin address_work<=address_work<<1;shift_left<=shift_left-1'b1;end
    DATA_BASE:begin address_work<=alu_result[31:0];state<=DATA_SECTOR;end
    DATA_SECTOR:read_sector(alu_result[31:0],data_return);
    IO_START:begin
     if(!block_busy)begin
      if(block_lba>=media_sectors)fail(E_GEOMETRY);
      else begin block_start<=1;io_timer<=0;state<=IO_WAIT;end
     end else if(io_timer>=IO_TIMEOUT_CYCLES)fail(E_TIMEOUT);else io_timer<=io_timer+1'b1;
    end
    IO_WAIT:begin
     io_timer<=io_timer+1'b1;
     if(block_done)begin if(block_error!=0)fail(E_IO);else begin io_drain<=0;state<=IO_DRAIN;end end
     else if(io_timer>=IO_TIMEOUT_CYCLES)fail(E_TIMEOUT);
    end
    IO_DRAIN:if(io_drain==2)state<=io_return;else io_drain<=io_drain+1'b1;
    default:fail(E_BOOT);
   endcase
  end
 end
endmodule
