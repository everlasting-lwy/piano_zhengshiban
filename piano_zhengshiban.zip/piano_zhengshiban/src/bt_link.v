// HC-05 framed control, fail-safe remote keys and timestamped event return.
module bt_link #(
    parameter integer UART_CYCLES=5208,
    parameter integer MS_CYCLES=50000,
    parameter integer WATCHDOG_MS=2000,
    parameter integer RX_TIMEOUT_CYCLES=5000000
)(
    input wire clk,rst_n,
    input wire [7:0] rx_data,
    input wire rx_valid,
    input wire [1:0] timbre,octave,mode,
    input wire [3:0] volume,voices,
    input wire [11:0] keys,
    input wire [35:0] extended_keys,
    output reg [35:0] remote_extended_keys,
    output reg extended_mode,
    output reg [1:0] set_timbre,set_octave,
    output reg [3:0] set_volume,
    output reg timbre_en,octave_en,volume_en,
    output reg [11:0] remote_keys,
    output wire tx,legacy_ready,
    output reg event_overflow,
    input wire [47:0] effects_status,
    output reg [7:0] effect_command,
    output reg effect_en,
    output reg [2:0] visual_kind,
    output reg visual_start,
    output reg [7:0] visual_sequence,
    output wire [31:0] device_millis,
    input wire visual_ready,
    input wire [7:0] visual_command,visual_tx_sequence,
    input wire [47:0] visual_payload,
    output wire visual_take,
    output reg guide_request,
    output reg [7:0] guide_request_command,
    output reg [47:0] guide_request_payload,
    input wire guide_response_valid,
    input wire [7:0] guide_response_command,
    input wire [47:0] guide_response_payload
);
    `include "bt_crc8.vh"
    wire frame_valid;
    wire [7:0] request_seq,request_command;
    wire [47:0] request_payload;
    bt_frame_rx #(.TIMEOUT_CYCLES(RX_TIMEOUT_CYCLES)) u_frame(
        .clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
        .frame_valid(frame_valid),.seq(request_seq),.command(request_command),
        .payload(request_payload),.legacy_valid(),.legacy_data(),.frame_error(),
        .legacy_ready(legacy_ready));
    wire clear_overflow=frame_valid && request_command==8'h08 && request_payload==0;

    reg [15:0] ms_divider,hold_age;
    reg [31:0] millis;
    assign device_millis=millis;
    wire ms_tick=(ms_divider==MS_CYCLES-1);
    reg ack_pending,status_pending,status_extended,status_effects;
    reg [7:0] ack_seq,ack_command,ack_code,status_seq,event_seq;
    reg guide_waiting,guide_pending;
    reg [3:0] guide_wait_cycles;
    reg [7:0] guide_request_seq,guide_reply_seq,guide_reply_command;
    reg [47:0] guide_reply_payload;
    wire valid_guide_request=frame_valid && ((request_command>=8'h0f && request_command<=8'h1b)||
        (request_command>=8'h20 && request_command<=8'h26)||request_command==8'h28);

    reg [48:0] event_fifo[0:15];
    wire [47:0] extended_payload={event_overflow,3'b010,2'b00,mode,voices,extended_keys};
    reg [3:0] write_pointer,read_pointer;
    reg [4:0] event_count;
    reg [11:0] previous_keys;
    reg [35:0] previous_extended_keys;
    reg previous_extended_mode;
    reg tx_active;
    wire event_push=extended_mode ? (!previous_extended_mode || extended_keys!=previous_extended_keys) :
        (keys!=previous_keys);
    wire event_pop=!tx_active && !ack_pending && !status_pending && !guide_pending &&
        !guide_waiting && !valid_guide_request && event_count!=0;
    wire event_accept=event_push && (event_count<16 || event_pop);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            write_pointer<=0;read_pointer<=0;event_count<=0;
            previous_keys<=0;previous_extended_keys<=0;previous_extended_mode<=0;event_overflow<=0;
        end else begin
            previous_keys<=keys;
            previous_extended_keys<=extended_keys;previous_extended_mode<=extended_mode;
            if(clear_overflow) event_overflow<=0;
            if(event_push && !event_accept) event_overflow<=1;
            if(event_accept) begin
                // Timestamp the control event now, not when UART eventually sends it.
                event_fifo[write_pointer]<=extended_mode ? {1'b1,extended_payload} : {1'b0,voices,keys,millis};
                write_pointer<=write_pointer+1'b1;
            end
            if(event_pop) read_pointer<=read_pointer+1'b1;
            case({event_accept,event_pop})
                2'b10:event_count<=event_count+1'b1;
                2'b01:event_count<=event_count-1'b1;
                default:;
            endcase
        end
    end

    wire valid_visual_request=frame_valid && request_command==8'h0e &&
        request_payload[47:8]==0 && request_payload[7:0]<=4;
    // Reserve replies/events first; never consume a stale chunk while accepting cancellation.
    assign visual_take=!tx_active && !ack_pending && !status_pending && !guide_pending &&
        !guide_waiting && !valid_guide_request && event_count==0 && visual_ready && !valid_visual_request;
    function [7:0] effect_code;
        input [2:0] id;input [7:0] value;
        begin case(id)
            0:effect_code=8'h10+value;1:effect_code=8'h20+value;
            2:effect_code=8'h30+value;3:effect_code=8'ha0+value;
            4:effect_code=8'hb0+value;5:effect_code=8'hd0+value;
            6:effect_code=8'h50+value;default:effect_code=8'h70+value;
        endcase end
    endfunction
    wire valid_effect_request=request_payload[47:16]==0 && request_payload[7:0]<=7 &&
        (request_payload[7:0]==4 ? request_payload[15:8]<=16 :
         request_payload[7:0]>=6 ? request_payload[15:8]<=2 : request_payload[15:8]<=15);

    reg [3:0] tx_index;
    reg [7:0] tx_seq,tx_command,tx_crc,tx_data;
    reg [47:0] tx_payload;
    reg tx_start;
    wire tx_ready;
    reg [7:0] next_byte;
    always @(*) begin
        case(tx_index)
            0:next_byte=8'hA5;
            1:next_byte=8'h5A;
            2:next_byte=tx_seq;
            3:next_byte=tx_command;
            10:next_byte=tx_crc;
            11:next_byte=8'h0D;
            default:next_byte=tx_payload[(tx_index-4)*8 +:8];
        endcase
    end
    uart_tx #(.CD_MAX(UART_CYCLES),.CD_WIDTH(13),.STOP_BITS(1)) u_tx(
        .clk(clk),.rst_n(rst_n),.tbus(tx_data),.start(tx_start),.tx(tx),.ready(tx_ready));

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            set_timbre<=0;set_octave<=0;set_volume<=0;
            timbre_en<=0;octave_en<=0;volume_en<=0;remote_keys<=0;remote_extended_keys<=0;extended_mode<=0;
            ms_divider<=0;millis<=0;hold_age<=0;
            ack_pending<=0;status_pending<=0;status_extended<=0;status_effects<=0;
            ack_seq<=0;ack_command<=0;ack_code<=0;status_seq<=0;event_seq<=0;
            tx_active<=0;tx_index<=0;tx_seq<=0;tx_command<=0;tx_crc<=0;
            tx_payload<=0;tx_data<=0;tx_start<=0;
            effect_command<=0;effect_en<=0;visual_kind<=0;visual_start<=0;visual_sequence<=0;
            guide_request<=0;guide_request_command<=0;guide_request_payload<=0;
            guide_waiting<=0;guide_pending<=0;guide_wait_cycles<=0;guide_request_seq<=0;
            guide_reply_seq<=0;guide_reply_command<=0;guide_reply_payload<=0;
        end else begin
            timbre_en<=0;octave_en<=0;volume_en<=0;tx_start<=0;effect_en<=0;visual_start<=0;
            guide_request<=0;
            // A response pulse is captured together with the request's saved SEQ.
            // The strict comparison ignores an unconnected extension in old users.
            if(guide_waiting)begin
                if(guide_response_valid===1'b1)begin
                    guide_pending<=1;guide_waiting<=0;guide_reply_seq<=guide_request_seq;
                    guide_reply_command<=guide_response_command;guide_reply_payload<=guide_response_payload;
                end else if(guide_wait_cycles==11)begin
                    // Legacy standalone instances have no guide module. Their new
                    // command requests still get the previous unsupported ACK.
                    guide_pending<=1;guide_waiting<=0;guide_reply_seq<=guide_request_seq;
                    guide_reply_command<=8'h80;
                    guide_reply_payload<={24'd0,8'd1,8'd2,guide_request_command};
                end else guide_wait_cycles<=guide_wait_cycles+1'b1;
            end
            if(ms_tick) begin
                ms_divider<=0;millis<=millis+1'b1;
                if(remote_keys!=0 || remote_extended_keys!=0) begin
                    if(hold_age==WATCHDOG_MS-1) begin remote_keys<=0;remote_extended_keys<=0;hold_age<=0;end
                    else hold_age<=hold_age+1'b1;
                end
            end else ms_divider<=ms_divider+1'b1;

            if(!tx_active) begin
                tx_index<=0;tx_crc<=0;
                if(ack_pending) begin
                    tx_active<=1;tx_seq<=ack_seq;tx_command<=8'h80;
                    tx_payload<={16'd0,7'd0,event_overflow,8'd1,ack_code,ack_command};
                    ack_pending<=0;
                end else if(status_pending) begin
                    tx_active<=1;tx_seq<=status_seq;tx_command<=status_effects ? 8'h85 : status_extended ? 8'h83 : 8'h81;
                    tx_payload<=status_effects ? effects_status : status_extended ? extended_payload :
                                  {voices,keys,{event_overflow,5'd0,mode},
                                   6'd0,octave,4'd0,volume,6'd0,timbre};
                    status_pending<=0;
                end else if(guide_pending)begin
                    tx_active<=1;tx_seq<=guide_reply_seq;tx_command<=guide_reply_command;
                    tx_payload<=guide_reply_payload;guide_pending<=0;
                end else if(event_pop) begin
                    tx_active<=1;tx_seq<=event_seq;tx_command<=event_fifo[read_pointer][48] ? 8'h84 : 8'h82;
                    tx_payload<=event_fifo[read_pointer][47:0];event_seq<=event_seq+1'b1;
                end else if(visual_take)begin
                    tx_active<=1;tx_seq<=visual_tx_sequence;tx_command<=visual_command;
                    tx_payload<=visual_payload;
                end
            end else if(tx_ready && !tx_start) begin
                tx_data<=next_byte;tx_start<=1;
                if(tx_index>=2 && tx_index<=9) tx_crc<=bt_crc8_byte(tx_crc,next_byte);
                if(tx_index==11) tx_active<=0;
                else tx_index<=tx_index+1'b1;
            end

            // Stop-and-wait host: one reply slot; all setters/full key masks are idempotent.
            // Decode after reply consumption so a concurrent new request is retained.
            if(frame_valid) begin
                ack_pending<=1;ack_seq<=request_seq;ack_command<=request_command;ack_code<=0;
                case(request_command)
                    8'h01: begin
                        if(request_payload[47:8]==0 && request_payload[7:0]<=3) begin
                            set_timbre<=request_payload[1:0];timbre_en<=1;
                        end else ack_code<=1;
                    end
                    8'h02: begin
                        if(request_payload[47:8]==0 && request_payload[7:0]<=15) begin
                            set_volume<=request_payload[3:0];volume_en<=1;
                        end else ack_code<=1;
                    end
                    8'h03: begin
                        if(request_payload[47:8]==0 && request_payload[7:0]<=2) begin
                            set_octave<=request_payload[1:0];octave_en<=1;
                        end else ack_code<=1;
                    end
                    8'h04,8'h07: begin
                        if(request_payload[47:12]==0) begin
                            remote_keys<=request_payload[11:0];remote_extended_keys<=0;extended_mode<=0;hold_age<=0;
                        end else ack_code<=1;
                    end
                    8'h05: begin
                        if(request_payload==0) begin remote_keys<=0;remote_extended_keys<=0;hold_age<=0;end
                        else ack_code<=1;
                    end
                    8'h06: begin
                        if(request_payload==0) begin
                            status_pending<=1;status_extended<=0;status_effects<=0;status_seq<=request_seq;ack_pending<=0;
                        end else ack_code<=1;
                    end
                    8'h08: if(request_payload!=0) ack_code<=1;
                    8'h09,8'h0A: begin
                        if(request_payload[47:36]==0) begin
                            remote_extended_keys<=request_payload[35:0];remote_keys<=0;
                            extended_mode<=1;hold_age<=0;
                        end else ack_code<=1;
                    end
                    8'h0B: begin
                        if(request_payload==0) begin
                            status_pending<=1;status_extended<=1;status_effects<=0;status_seq<=request_seq;ack_pending<=0;
                        end else ack_code<=1;
                    end
                    8'h0c:begin
                        if(request_payload==0)begin
                            status_pending<=1;status_effects<=1;status_seq<=request_seq;ack_pending<=0;
                        end else ack_code<=1;
                    end
                    8'h0d:begin
                        if(valid_effect_request)begin
                            effect_command<=effect_code(request_payload[2:0],request_payload[15:8]);effect_en<=1;
                        end else ack_code<=1;
                    end
                    8'h0e:begin
                        if(valid_visual_request)begin
                            visual_kind<=request_payload[2:0];visual_start<=1;visual_sequence<=request_seq;
                        end else ack_code<=1;
                    end
                    8'h0f,8'h10,8'h11,8'h12,8'h13,8'h14,8'h15,
                    8'h16,8'h17,8'h18,8'h19,8'h1a,8'h1b,
                    8'h20,8'h21,8'h22,8'h23,8'h24,8'h25,8'h26,8'h28:begin
                        if(guide_waiting || guide_pending)ack_code<=3;
                        else begin
                            ack_pending<=0;guide_request<=1;guide_request_command<=request_command;
                            guide_request_payload<=request_payload;guide_request_seq<=request_seq;
                            guide_waiting<=1;guide_wait_cycles<=0;
                        end
                    end
                    default:ack_code<=2;
                endcase
            end
        end
    end
endmodule
