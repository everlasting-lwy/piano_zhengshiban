module bt_frame_rx #(
    parameter integer TIMEOUT_CYCLES=5000000
)(
    input wire clk,rst_n,
    input wire [7:0] rx_data,
    input wire rx_valid,
    output reg frame_valid,
    output reg [7:0] seq,command,
    output reg [47:0] payload,
    output reg legacy_valid,
    output reg [7:0] legacy_data,
    output reg frame_error,
    output wire legacy_ready
);
    `include "bt_crc8.vh"
    reg [2:0] state;
    reg [2:0] index;
    reg [22:0] idle_count;
    reg [7:0] crc,received_crc,seq_buf,command_buf;
    reg [47:0] payload_buf;
    reg framed_mode;
    assign legacy_ready=!framed_mode && state==0;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=0;index<=0;idle_count<=0;crc<=0;received_crc<=0;
            seq_buf<=0;command_buf<=0;payload_buf<=0;framed_mode<=0;
            frame_valid<=0;seq<=0;command<=0;payload<=0;
            legacy_valid<=0;legacy_data<=0;frame_error<=0;
        end else begin
            frame_valid<=0;legacy_valid<=0;frame_error<=0;
            if(state!=0 && !rx_valid) begin
                if(idle_count==TIMEOUT_CYCLES-1) begin
                    state<=0;idle_count<=0;frame_error<=1;
                end else idle_count<=idle_count+1'b1;
            end
            if(rx_valid) begin
                idle_count<=0;
                case(state)
                    0: begin
                        if(rx_data==8'hA5) state<=1;
                        else if(!framed_mode && ((rx_data<=8'h03) ||
                                (rx_data>=8'h40 && rx_data<=8'h42) ||
                                (rx_data>=8'h80 && rx_data<=8'h8F))) begin
                            legacy_data<=rx_data;legacy_valid<=1;
                        end
                    end
                    1: begin
                        if(rx_data==8'h5A) begin
                            state<=2;index<=0;crc<=0;framed_mode<=1;
                        end else if(rx_data!=8'hA5) state<=0;
                    end
                    2: begin
                        crc<=bt_crc8_byte(crc,rx_data);
                        case(index)
                            0:seq_buf<=rx_data;
                            1:command_buf<=rx_data;
                            default:payload_buf[(index-2)*8 +:8]<=rx_data;
                        endcase
                        if(index==7) state<=3;
                        else index<=index+1'b1;
                    end
                    3: begin received_crc<=rx_data;state<=4;end
                    4: begin
                        state<=0;
                        if(rx_data==8'h0D && received_crc==crc) begin
                            seq<=seq_buf;command<=command_buf;payload<=payload_buf;frame_valid<=1;
                        end else frame_error<=1;
                    end
                    default:state<=0;
                endcase
            end
        end
    end
endmodule
