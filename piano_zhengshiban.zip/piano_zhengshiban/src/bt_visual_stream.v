// One requested visual snapshot at a time. Packet bytes are D0 in bits 7:0.
// The capture RAM belongs to this reader; the TJC renderer never swaps its bank.
module bt_visual_stream #(
    parameter MS_CYCLES=50000
)(
    input wire clk,rst_n,clear,sample_valid,
    input wire signed [15:0] sample,
    input wire request_start,
    input wire [2:0] request_kind,
    input wire [7:0] request_sequence,
    input wire [31:0] device_millis,
    input wire [255:0] spectrum_bars,
    input wire spectrum_valid,
    input wire [17:0] physical_keys,
    input wire [4:0] guide_step,
    input wire [1:0] guide_mode,
    input wire guide_wrong,
    output reg tx_ready,
    output reg [7:0] tx_command,tx_sequence,
    output reg [47:0] tx_payload,
    input wire tx_take
);
    localparam IDLE=4'd0,ARM_PCM=4'd1,WAIT_PCM=4'd2,WAIT_SPECTRUM=4'd3,
               REARM_GUIDE=4'd4,METADATA=4'd5,READ_WAIT=4'd6,
               READ_POINT=4'd7,CHUNK=4'd8;
    reg [3:0] state;
    // Retain the selected kind after the one-shot stream ends. A clear can then
    // acquire another snapshot, while no unsolicited periodic stream is sent.
    reg [2:0] kind;
    reg [5:0] read_index,chunk_index;
    reg [1:0] point_in_chunk;
    reg [31:0] chunk_data,guide_data;
    // All 32 DFT bars must be latched on the same valid edge. PCM is kept in RAM.
    reg [255:0] spectrum_frame;
    wire capture_ready;
    wire [15:0] capture_point;
    wire pcm_kind=(kind==3'd1 || kind==3'd3);
    wire capture_clear=clear || request_start;
    wire capture_request=(state==ARM_PCM) && !capture_clear;
    wire [7:0] kind_byte={5'd0,kind};
    wire [7:0] last_chunk=(kind==3'd1) ? 8'd15 : (kind==3'd2) ? 8'd7 :
                           (kind==3'd3) ? 8'd31 : 8'd0;
    wire [31:0] guide_now={{3'd0,guide_step},
                          {3'd0,guide_wrong,guide_mode,physical_keys[17:16]},
                          physical_keys[15:8],physical_keys[7:0]};

    visual_capture capture(
        .clk(clk),.rst_n(rst_n),.clear(capture_clear),
        .sample_valid(sample_valid && pcm_kind),.sample(sample),
        .snapshot_request(capture_request),.snapshot_ready(capture_ready),
        .read_index(read_index),.point_data(capture_point)
    );

    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=IDLE;kind<=0;read_index<=0;chunk_index<=0;point_in_chunk<=0;
            chunk_data<=0;guide_data<=0;spectrum_frame<=0;
            tx_ready<=0;tx_command<=0;tx_sequence<=0;tx_payload<=0;
        end else if(request_start)begin
            // Cancellation wins over a simultaneous take. bt_link holds any
            // packet it already accepted, so an in-flight UART packet is safe.
            kind<=request_kind;tx_sequence<=request_sequence;tx_ready<=0;
            read_index<=0;chunk_index<=0;point_in_chunk<=0;chunk_data<=0;
            case(request_kind)
                3'd1,3'd3:state<=ARM_PCM;
                3'd2:state<=WAIT_SPECTRUM;
                3'd4:begin
                    guide_data<=guide_now;
                    tx_payload<={device_millis,8'd1,8'd4};
                    tx_command<=8'h86;tx_ready<=1;state<=METADATA;
                end
                default:state<=IDLE;
            endcase
        end else if(clear)begin
            tx_ready<=0;read_index<=0;chunk_index<=0;point_in_chunk<=0;chunk_data<=0;
            case(kind)
                3'd1,3'd3:state<=ARM_PCM;
                3'd2:state<=WAIT_SPECTRUM;
                3'd4:state<=REARM_GUIDE;
                default:state<=IDLE;
            endcase
        end else begin
            case(state)
                ARM_PCM:state<=WAIT_PCM;
                WAIT_PCM:if(capture_ready)begin
                    tx_payload<={device_millis,(kind==3'd1 ? 8'd16 : 8'd32),kind_byte};
                    tx_command<=8'h86;tx_ready<=1;state<=METADATA;
                end
                WAIT_SPECTRUM:if(spectrum_valid)begin
                    spectrum_frame<=spectrum_bars;
                    tx_payload<={device_millis,8'd8,8'd2};
                    tx_command<=8'h86;tx_ready<=1;state<=METADATA;
                end
                REARM_GUIDE:begin
                    guide_data<=guide_now;
                    tx_payload<={device_millis,8'd1,8'd4};
                    tx_command<=8'h86;tx_ready<=1;state<=METADATA;
                end
                METADATA:if(tx_take)begin
                    chunk_index<=0;tx_command<=8'h87;
                    if(kind==3'd4)begin
                        tx_payload<={guide_data,8'd0,8'd4};state<=CHUNK;
                    end else if(kind==3'd2)begin
                        tx_payload<={spectrum_frame[31:0],8'd0,8'd2};state<=CHUNK;
                    end else begin
                        tx_ready<=0;read_index<=0;point_in_chunk<=0;chunk_data<=0;state<=READ_WAIT;
                    end
                end
                // visual_capture has a synchronous RAM output. One full wait
                // edge after changing its address makes each read unambiguous.
                READ_WAIT:state<=READ_POINT;
                READ_POINT:begin
                    if(kind==3'd1)begin
                        if(point_in_chunk==3)begin
                            tx_payload<={capture_point[7:0],chunk_data[23:0],{2'd0,chunk_index},kind_byte};
                            tx_ready<=1;state<=CHUNK;
                        end else begin
                            chunk_data[point_in_chunk*8+:8]<=capture_point[7:0];
                            point_in_chunk<=point_in_chunk+1'b1;
                            read_index<=read_index+1'b1;state<=READ_WAIT;
                        end
                    end else begin
                        if(point_in_chunk==1)begin
                            tx_payload<={capture_point,chunk_data[15:0],{2'd0,chunk_index},kind_byte};
                            tx_ready<=1;state<=CHUNK;
                        end else begin
                            chunk_data[15:0]<=capture_point;point_in_chunk<=1;
                            read_index<=read_index+1'b1;state<=READ_WAIT;
                        end
                    end
                end
                CHUNK:if(tx_take)begin
                    if({2'd0,chunk_index}==last_chunk)begin
                        tx_ready<=0;state<=IDLE;
                    end else begin
                        chunk_index<=chunk_index+1'b1;
                        if(kind==3'd2)
                            tx_payload<={spectrum_frame[(chunk_index+1'b1)*32+:32],
                                         (8'd1+{2'd0,chunk_index}),8'd2};
                        else begin
                            tx_ready<=0;read_index<=read_index+1'b1;
                            point_in_chunk<=0;chunk_data<=0;state<=READ_WAIT;
                        end
                    end
                end
                default:begin end
            endcase
        end
    end
endmodule
