// Proportional C4..F5 keyboard, physical wiring masks (not chromatic bit order).
// 11 white keys, width11/height44;7 black keys, width7/height27.
module oled_guide_keyboard(
 input wire [6:0] x,input wire [2:0] page,
 input wire [17:0] target,physical,output reg [7:0] pixels
);
 integer white_id,white_left,black_id,black_left,i,j,y,boundary;
 reg value;
 always @(*)begin
  white_id=0;white_left=3;black_id=-1;black_left=0;boundary=0;
  for(i=0;i<11;i=i+1)if(x>=3+i*11 && x<=13+i*11)begin
   white_left=3+i*11;
   case(i)
    0:white_id=0;1:white_id=1;2:white_id=2;3:white_id=3;
    4:white_id=4;5:white_id=5;6:white_id=6;7:white_id=12;
    8:white_id=14;9:white_id=16;default:white_id=17;
   endcase
  end
  for(i=0;i<7;i=i+1)begin
   case(i)0:boundary=14;1:boundary=25;2:boundary=47;3:boundary=58;
    4:boundary=69;5:boundary=91;default:boundary=102;endcase
   if(x>=boundary-3 && x<=boundary+3)begin
    black_left=boundary-3;
    case(i)0:black_id=7;1:black_id=8;2:black_id=9;3:black_id=10;
     4:black_id=11;5:black_id=13;default:black_id=15;endcase
   end
  end
  pixels=0;value=0;y=0;
  for(j=0;j<8;j=j+1)begin
   y=page*8+j;value=0;
   if(x>=3 && x<=123 && y>=20)begin
    value=(x==white_left || x==white_left+10 || y==20 || y==63) || target[white_id];
    if(physical[white_id] && (y==60 || y==61) && x>=white_left+4 && x<=white_left+6)value=1;
    // Short keys occlude white keys only in their upper27 rows.
    if(black_id>=0 && y<=46)begin
     value=(x==black_left || x==black_left+6 || y==20 || y==46) || target[black_id];
     if(physical[black_id] && (y==43 || y==44) && x>=black_left+2 && x<=black_left+4)value=1;
    end
   end
   pixels[j]=value;
  end
 end
endmodule
