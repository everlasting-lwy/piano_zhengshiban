// Production ACG525 board top: onboard WM8960 LEFT speaker.
module top_piano_wm8960_acg525 #(
    parameter integer WM_I2C_DIV=125,
    parameter integer WM_BOOT_CYCLES=5000000,
    parameter integer WM_RESET_CYCLES=5000,
    parameter integer WM_BIAS_CYCLES=10000000,
    parameter integer WM_RETRY_CYCLES=2500000,
    parameter integer WM_TIMEOUT_CYCLES=50000,
    parameter integer ENABLE_VOLUME_KEYS=0,
    parameter integer ENC_INITIAL_SELECTION=7,
    parameter integer ENC_SAMPLE_CYCLES=500,
    parameter integer ENC_AB_FILTER_SAMPLES=10,
    parameter integer ENC_SW_FILTER_SAMPLES=500,
    parameter integer ENC_LONG_PRESS_SAMPLES=100000,
    parameter integer ENC_TRANSITIONS_PER_STEP=4,
    parameter integer ENC_REVERSE=0,
    parameter integer OLED_I2C_DIV=40,
    parameter integer OLED_BOOT_CYCLES=5000000,
    parameter integer OLED_REFRESH_CYCLES=5000000,
    parameter integer OLED_RETRY_CYCLES=50000000,
    parameter integer OLED_TIMEOUT_CYCLES=50000,
    parameter integer OLED_COLUMN_OFFSET=0,
    parameter integer VISUAL_I2C_DIV=40,
    parameter integer VISUAL_BOOT_CYCLES=5000000,
    parameter integer VISUAL_REFRESH_CYCLES=500000,
    parameter integer VISUAL_RETRY_CYCLES=50000000,
    parameter integer VISUAL_TIMEOUT_CYCLES=50000,
    parameter integer VISUAL_COLUMN_OFFSET=2,
    parameter integer VISUAL_SH1106=1,
    parameter integer BT_UART_CYCLES=5208,
    parameter integer BT_MS_CYCLES=50000,
    parameter integer BT_WATCHDOG_MS=2000,
    parameter integer SD_INIT_DIV=125,SD_DATA_DIV=8,
    parameter integer SD_POWERUP_CYCLES=500000,SD_INIT_TIMEOUT_CYCLES=100000000
)(
 input wire encoder_a,encoder_b,encoder_sw_n,
 inout wire oled_scl,oled_sda,
 input wire visual_encoder_a,visual_encoder_b,visual_encoder_sw_n,
 inout wire visual_oled_scl,visual_oled_sda,
 output wire sd_cs_n,sd_clk,sd_mosi,input wire sd_miso,
 input wire sys_clk,sys_rst_n,
 input wire [17:0] key_in,
 input wire key_timbre,key_mode,key_vol_up,key_vol_down,key_octave,
 input wire bt_rxd,hc_echo,
 output wire bt_txd,hc_trig,i2s_bclk,i2s_lrck,i2s_din,
 output wire wm8960_mclk,
 inout wire wm8960_scl,wm8960_sda,
 output wire [3:0] led,
 output wire uart_txd,seg_ds,seg_sh_cp,seg_st_cp
);

 // Separate board shell preserves the fully tested synthesis/control core.
 reg [15:0] reset_pipe=0;
 always @(posedge sys_clk or negedge sys_rst_n)
  if(!sys_rst_n)reset_pipe<=0;
  else reset_pipe<={reset_pipe[14:0],1'b1};
 wire rst_n=reset_pipe[15];
 reg [1:0] mclk_div;
 always @(posedge sys_clk or negedge rst_n)
  if(!rst_n)mclk_div<=0;else mclk_div<=mclk_div+1'b1;
 assign wm8960_mclk=mclk_div[1]; // 50 MHz / 4, no new PLL or RAM.
 wire codec_ready,codec_fault;
 wire [6:0] codec_failed_reg;
 wm8960_playback #(.I2C_DIV(WM_I2C_DIV),.BOOT_CYCLES(WM_BOOT_CYCLES),
  .RESET_CYCLES(WM_RESET_CYCLES),.BIAS_CYCLES(WM_BIAS_CYCLES),
  .RETRY_CYCLES(WM_RETRY_CYCLES),.TIMEOUT_CYCLES(WM_TIMEOUT_CYCLES)) u_codec(
  .clk(sys_clk),.rst_n(rst_n),.scl(wm8960_scl),.sda(wm8960_sda),
  .ready(codec_ready),.fault(codec_fault),.failed_reg(codec_failed_reg));
 wire raw_dac_data;
 reg lrck_prev,audio_enabled;
 always @(posedge sys_clk or negedge rst_n)begin
  if(!rst_n)begin lrck_prev<=1;audio_enabled<=0;end
  else begin
   lrck_prev<=i2s_lrck;
   if(!codec_ready)audio_enabled<=0;
   // Rising LRCK starts a complete right+left frame in the existing transmitter.
   // Enable during its I2S delay bit; never expose half an audio frame.
   else if(i2s_lrck && !lrck_prev)audio_enabled<=1;
  end
 end
 assign i2s_din=audio_enabled ? raw_dac_data : 1'b0;
 top_piano_acg525 #(
  .ENABLE_VOLUME_KEYS(ENABLE_VOLUME_KEYS),
  .ENC_INITIAL_SELECTION(ENC_INITIAL_SELECTION),
  .ENC_SAMPLE_CYCLES(ENC_SAMPLE_CYCLES),
  .ENC_AB_FILTER_SAMPLES(ENC_AB_FILTER_SAMPLES),
  .ENC_SW_FILTER_SAMPLES(ENC_SW_FILTER_SAMPLES),
  .ENC_LONG_PRESS_SAMPLES(ENC_LONG_PRESS_SAMPLES),
  .ENC_TRANSITIONS_PER_STEP(ENC_TRANSITIONS_PER_STEP),
  .ENC_REVERSE(ENC_REVERSE),
  .OLED_I2C_DIV(OLED_I2C_DIV),
  .OLED_BOOT_CYCLES(OLED_BOOT_CYCLES),
  .OLED_REFRESH_CYCLES(OLED_REFRESH_CYCLES),
  .OLED_RETRY_CYCLES(OLED_RETRY_CYCLES),
  .OLED_TIMEOUT_CYCLES(OLED_TIMEOUT_CYCLES),
  .OLED_COLUMN_OFFSET(OLED_COLUMN_OFFSET),
  .VISUAL_I2C_DIV(VISUAL_I2C_DIV),
  .VISUAL_BOOT_CYCLES(VISUAL_BOOT_CYCLES),
  .VISUAL_REFRESH_CYCLES(VISUAL_REFRESH_CYCLES),
  .VISUAL_RETRY_CYCLES(VISUAL_RETRY_CYCLES),
  .VISUAL_TIMEOUT_CYCLES(VISUAL_TIMEOUT_CYCLES),
  .VISUAL_COLUMN_OFFSET(VISUAL_COLUMN_OFFSET),
  .VISUAL_SH1106(VISUAL_SH1106),
  .BT_UART_CYCLES(BT_UART_CYCLES),
  .BT_MS_CYCLES(BT_MS_CYCLES),
  .BT_WATCHDOG_MS(BT_WATCHDOG_MS),
  .SD_INIT_DIV(SD_INIT_DIV),.SD_DATA_DIV(SD_DATA_DIV),
  .SD_POWERUP_CYCLES(SD_POWERUP_CYCLES),.SD_INIT_TIMEOUT_CYCLES(SD_INIT_TIMEOUT_CYCLES)) u_board(
  .encoder_a(encoder_a),.encoder_b(encoder_b),.encoder_sw_n(encoder_sw_n),
  .oled_scl(oled_scl),.oled_sda(oled_sda),
  .visual_encoder_a(visual_encoder_a),.visual_encoder_b(visual_encoder_b),.visual_encoder_sw_n(visual_encoder_sw_n),
  .visual_oled_scl(visual_oled_scl),.visual_oled_sda(visual_oled_sda),
  .sd_cs_n(sd_cs_n),.sd_clk(sd_clk),.sd_mosi(sd_mosi),.sd_miso(sd_miso),
  .sys_clk(sys_clk),.sys_rst_n(sys_rst_n),.key_in(key_in),
  .key_timbre(key_timbre),.key_mode(key_mode),.key_vol_up(key_vol_up),.key_vol_down(key_vol_down),.key_octave(key_octave),
  .bt_rxd(bt_rxd),.bt_txd(bt_txd),.hc_echo(hc_echo),.hc_trig(hc_trig),
  .i2s_bclk(i2s_bclk),.i2s_lrck(i2s_lrck),.i2s_din(raw_dac_data),.led(led),
  .uart_txd(uart_txd),.seg_ds(seg_ds),.seg_sh_cp(seg_sh_cp),.seg_st_cp(seg_st_cp)
);
endmodule
