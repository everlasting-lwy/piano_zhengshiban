// Independent display-only encoder; filtering follows the verified audio encoder.
module visual_rotary_control #(
 parameter integer SAMPLE_CYCLES=500,
 parameter integer AB_FILTER_SAMPLES=10,
 parameter integer SW_FILTER_SAMPLES=500,
 parameter integer LONG_PRESS_SAMPLES=100000,
 parameter integer TRANSITIONS_PER_STEP=4,
 parameter integer REVERSE=0
)(
 input wire clk,rst_n,a,b,sw_n,
 input wire guide_active,
 output reg guide_toggle,guide_restart,guide_next,guide_prev,
 output reg [1:0] view,
 output reg [2:0] gain_shift
);
 reg [2:0] gains[0:2];
 reg [2:0] meta,sync;
 reg [15:0] sample_count,sw_count;
 reg [19:0] hold_count;
 reg [1:0] previous;
 localparam AB_COUNT_WIDTH=AB_FILTER_SAMPLES<2 ? 1 : $clog2(AB_FILTER_SAMPLES+1);
 reg [AB_COUNT_WIDTH-1:0] ab_count;
 reg [1:0] ab_candidate;
 reg ab_initialized;
 reg sw_stable,long_sent;
 reg signed [3:0] accumulated;
 reg signed [1:0] direction;
 wire tick=sample_count==SAMPLE_CYCLES-1;
 wire signed [4:0] next_sum=$signed(accumulated)+$signed(direction);
 always @(*)begin
  case({previous,sync[2:1]})
   4'b1110,4'b1000,4'b0001,4'b0111:direction=REVERSE ? -2'sd1 : 2'sd1;
   4'b1101,4'b0100,4'b0010,4'b1011:direction=REVERSE ? 2'sd1 : -2'sd1;
   default:direction=0;
  endcase
  case(view)
   0:gain_shift=gains[0];
   1:gain_shift=gains[1];
   2:gain_shift=gains[2];
   default:gain_shift=0;
  endcase
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   meta<=7;sync<=7;sample_count<=0;sw_count<=0;hold_count<=0;
   previous<=3;sw_stable<=1;long_sent<=0;accumulated<=0;
   ab_count<=0;ab_candidate<=3;ab_initialized<=0;
   view<=0;gains[0]<=2;gains[1]<=0;gains[2]<=2;guide_toggle<=0;guide_restart<=0;guide_next<=0;guide_prev<=0;
  end else begin
   guide_toggle<=0;guide_restart<=0;guide_next<=0;guide_prev<=0;
   meta<={a,b,sw_n};sync<=meta;
   sample_count<=tick ? 16'd0 : sample_count+1'b1;
   if(tick)begin
    // Sampling alone does not debounce A/B. Learn the initial resting phase,
    // then accept only a phase held stable for the configured sample count.
    if(sync[2:1]!=ab_candidate)begin ab_candidate<=sync[2:1];ab_count<=1;end
    else if(ab_count<AB_FILTER_SAMPLES)ab_count<=ab_count+1'b1;
    if(AB_FILTER_SAMPLES<=1 ||
       (sync[2:1]==ab_candidate && ab_count>=AB_FILTER_SAMPLES-1))begin
     previous<=sync[2:1];
     if(!ab_initialized)begin ab_initialized<=1;accumulated<=0;end
     else if(previous!=sync[2:1])begin
     if(direction==0)accumulated<=0;
     else if(next_sum>=TRANSITIONS_PER_STEP)begin
      accumulated<=0;
      if(guide_active)guide_next<=1;
      else if(gain_shift<4)gains[view]<=gain_shift+1'b1;
     end else if(next_sum<=-TRANSITIONS_PER_STEP)begin
      accumulated<=0;
      if(guide_active)guide_prev<=1;
      else if(gain_shift!=0)gains[view]<=gain_shift-1'b1;
     end else accumulated<=next_sum[3:0];
     end
    end
    if(sync[0]!=sw_stable)begin
     if(sw_count==SW_FILTER_SAMPLES-1)begin
      sw_stable<=sync[0];sw_count<=0;
      if(sync[0])begin
       if(!long_sent)begin
        if(guide_active)guide_restart<=1;
        else view<=(view==2) ? 0 : view+1'b1;
       end
       hold_count<=0;long_sent<=0;
      end
     end else sw_count<=sw_count+1'b1;
    end else sw_count<=0;
    if(!sw_stable && !long_sent && !sync[0])begin
     if(hold_count==LONG_PRESS_SAMPLES-1)begin
      guide_toggle<=1;long_sent<=1;
     end else hold_count<=hold_count+1'b1;
    end
   end
  end
 end
endmodule
