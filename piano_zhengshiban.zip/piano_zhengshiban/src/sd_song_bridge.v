// Autonomous P18 catalog and loader. Filesystem writes are delegated to the
// phone's sector session. One synchronous RAM holds catalog/title staging;
// P18 data is validated and staged into song_guide's existing inactive bank.
module sd_song_bridge #(parameter integer MAX_STEPS=2048)(
 input wire clk,input wire rst_n,
 input wire remote_active,remote_uncertain,output wire storage_idle,
 input wire bt_req_valid,input wire [7:0] bt_req_command,input wire [47:0] bt_req_payload,
 output reg bt_rsp_valid,output reg [7:0] bt_rsp_command,output reg [47:0] bt_rsp_payload,
 output reg g_req_valid,output wire [7:0] g_req_command,output reg [47:0] g_req_payload,
 input wire g_rsp_valid,input wire [7:0] g_rsp_command,input wire [47:0] g_rsp_payload,
 input wire guide_loaded,input wire guide_loading,input wire guide_active,input wire [11:0] guide_total_steps,
 input wire [17:0] physical_keys,input wire local_next,input wire local_prev,
 output wire sd_busy,output reg [4:0] selected_slot,output reg selected_valid,output reg [7:0] sd_error,
 input wire media_ready,input wire media_busy,input wire [7:0] media_error,output reg media_reinit,
 output reg file_request,output reg [1:0] file_operation,output reg [4:0] file_slot,output reg [15:0] file_write_size,
 input wire file_mounted,input wire file_busy,input wire file_done,input wire [7:0] file_error,input wire [15:0] file_size,
 input wire [31:0] present_slots,input wire write_locked,input wire [7:0] file_attributes,
 input wire read_valid,input wire [15:0] read_index,input wire [7:0] read_data,output wire read_ready,
 input wire source_request,input wire [15:0] source_index,output wire source_valid,output wire [7:0] source_data
);
 localparam IDLE=0,DISPATCH=1,WAIT_MEDIA=2,SCAN_START=3,SCAN_WAIT=4,SCAN_PICK=5,
  READ_START=6,READ_RUN=7,LOAD_BEGIN=8,LOAD_BEGIN_WAIT=9,STEP_SEND=10,STEP_WAIT=11,
  READ_FINISH=12,COMMIT_SEND=13,COMMIT_WAIT=14,ABORT_SEND=15,ABORT_WAIT=16,
  COPY_SET=17,COPY_GET=18,FINISH=19;
 localparam E_P18=32,E_GUIDE=34;
 reg [4:0] state;reg local_busy;
 assign sd_busy=local_busy||remote_active;
 assign source_valid=1'b0;assign source_data=8'd0;
 reg [31:0] valid_slots,scan_valid;
 reg catalog_ready,query_valid;
 reg [7:0] catalog_revision;
 reg [31:0] operation_token;reg [7:0] operation_action,operation_slot;
 reg operation_success,unsupported,start_pending,boot_pending,boot_load,scanning;
 reg [4:0] work_slot;reg [7:0] operation_error;
 reg local_pending;reg [4:0] local_slot;
 reg [11:0] score_steps;
 reg [15:0] score_crc,running_crc;reg [7:0] expected_header_crc;
 reg [5:0] title_length;
 reg [1:0] utf_need;reg [7:0] utf_low,utf_high;reg utf_bad;
 reg [12:0] rx_position;reg [11:0] rx_steps;reg [1:0] mask_byte;
 reg [15:0] mask_low;reg [17:0] pending_mask;
 reg parse_bad,load_started,read_finished;reg [7:0] read_error;
 reg [5:0] index_byte;reg [1:0] mem_delay;
 // The RAM has no reset or asynchronous reads, allowing one 18-kbit BSRAM.
 // Titles occupy 0..1023, packed four-byte metadata records 1024..1151,
 // transaction header 1280..1343. Power-of-two addressing saves fabric adders.
 reg [7:0] catalog_ram[0:2047];
 reg [10:0] main_address,mem_write_address;reg [7:0] mem_write_data,mem_q;reg mem_write;
 reg [3:0] query_phase;reg [2:0] query_length;reg [4:0] query_slot;reg [4:0] query_offset;
 reg query_title;reg [10:0] query_address;
 wire query_active=query_phase!=0;
 wire query_new=bt_req_valid&&(bt_req_command==8'h19||bt_req_command==8'h1a);
 wire [10:0] memory_address=query_active?query_address:main_address;
 always @(posedge clk)begin
  mem_q<=catalog_ram[memory_address];
  if(mem_write)catalog_ram[mem_write_address]<=mem_write_data;
 end
 function [10:0] catalog_base;input [4:0] slotn;begin catalog_base={1'b0,slotn,5'b0};end endfunction
 function [10:0] metadata_base;input [4:0] slotn;begin metadata_base={4'b1000,slotn,2'b0};end endfunction
 function [15:0] crc16;input [15:0] old;input [7:0] value;integer i;reg [15:0] c;
  begin c=old^{value,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc16=c;end
 endfunction
 function [4:0] popcount;input [17:0] mask;integer i;begin popcount=0;for(i=0;i<18;i=i+1)popcount=popcount+mask[i];end endfunction
 function [7:0] magic;input [2:0] n;begin case(n)
  0:magic="P";1:magic="1";2:magic="8";3:magic="G";4:magic="U";5:magic="I";6:magic="D";7:magic="E";
 endcase end endfunction
 wire [15:0] next_crc=crc16(running_crc,read_data);
 wire [23:0] received_mask={read_data,mask_low};
 wire header_valid=!parse_bad&&score_steps!=0&&score_steps<=MAX_STEPS&&title_length<=32&&
  file_size==16'd64+{4'd0,score_steps}+({4'd0,score_steps}<<1)&&utf_need==0&&!utf_bad;
 assign read_ready=state==READ_RUN;

 // One outstanding guide request. External requests win every idle grant;
 // ownership stays latched through the delayed three-phase STEP replies.
 reg [1:0] guide_owner;
 reg ext_pending;reg [7:0] ext_command;reg [47:0] ext_payload;
 reg int_pending,int_done;reg [1:0] int_kind;reg [7:0] int_rsp_command;
 reg [7:0] int_error;
 assign g_req_command=guide_owner==2?{6'h04,int_kind}:ext_command;
 reg [7:0] status_state;
 reg [4:0] candidate;reg [5:0] candidate_count;reg candidate_reverse;integer k;
 assign storage_idle=state==IDLE&&!local_busy&&!start_pending&&!local_pending&&!boot_pending&&candidate_count==0&&!file_request&&
  !((local_next||local_prev)&&guide_active&&physical_keys==0);
 always @*begin
  status_state=sd_busy?2:unsupported?3:sd_error!=0?4:file_mounted?1:0;
 end
 task acknowledge;input [7:0] c;input [7:0] e;begin
  bt_rsp_valid<=1;bt_rsp_command<=8'h80;bt_rsp_payload<={24'd0,(c>=8'h16 ? 8'd2:8'd1),e,c};
 end endtask
 task accept_operation;begin
  acknowledge(8'h17,0);operation_token<=bt_req_payload[47:16];operation_action<=bt_req_payload[7:0];operation_slot<=bt_req_payload[15:8];
  work_slot<=bt_req_payload[12:8];local_busy<=1;sd_error<=0;operation_error<=0;operation_success<=0;unsupported<=0;start_pending<=1;boot_pending<=0;
 end endtask
 task internal_request;input [1:0] kind;begin int_kind<=kind;int_pending<=1;int_done<=0;end endtask
 task fail_operation;input [7:0] e;begin operation_error<=e;state<=FINISH;end endtask
 // Validate canonical UTF8 and title padding while streaming the header.
 // First-continuation bounds reject overlong,
 // surrogate and >U+10FFFF encodings without a second title buffer.
 task title_byte;input [7:0] value;begin
  if(utf_need!=0)begin
   if(value<utf_low||value>utf_high)utf_bad<=1;
   utf_need<=utf_need-1'b1;utf_low<=8'h80;utf_high<=8'hbf;
  end else if(value>=8'h80)begin
   utf_low<=8'h80;utf_high<=8'hbf;
   if(value>=8'hc2&&value<=8'hdf)utf_need<=1;
   else if(value>=8'he0&&value<=8'hef)begin utf_need<=2;if(value==8'he0)utf_low<=8'ha0;if(value==8'hed)utf_high<=8'h9f;end
   else if(value>=8'hf0&&value<=8'hf4)begin utf_need<=3;if(value==8'hf0)utf_low<=8'h90;if(value==8'hf4)utf_high<=8'h8f;end
   else utf_bad<=1;
  end
 end endtask

 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;local_busy<=0;sd_error<=0;selected_slot<=0;selected_valid<=0;valid_slots<=0;
   catalog_ready<=0;query_valid<=0;
   scan_valid<=0;catalog_revision<=0;
   operation_token<=0;operation_action<=0;operation_slot<=8'hff;operation_success<=0;operation_error<=0;
   unsupported<=0;start_pending<=0;boot_pending<=1;boot_load<=0;scanning<=0;work_slot<=0;local_pending<=0;local_slot<=0;
   bt_rsp_valid<=0;bt_rsp_command<=0;bt_rsp_payload<=0;g_req_valid<=0;g_req_payload<=0;
   guide_owner<=0;ext_pending<=0;ext_command<=0;ext_payload<=0;int_pending<=0;int_done<=0;int_kind<=0;int_rsp_command<=0;int_error<=0;
   file_request<=0;file_operation<=0;file_slot<=0;file_write_size<=0;media_reinit<=0;
   score_steps<=0;score_crc<=0;running_crc<=16'hffff;expected_header_crc<=0;
   title_length<=0;utf_need<=0;utf_low<=8'h80;utf_high<=8'hbf;utf_bad<=0;
   rx_position<=0;rx_steps<=0;mask_byte<=0;mask_low<=0;pending_mask<=0;parse_bad<=0;load_started<=0;read_finished<=0;read_error<=0;
   index_byte<=0;mem_delay<=0;main_address<=0;mem_write<=0;mem_write_address<=0;mem_write_data<=0;
   query_phase<=0;query_length<=0;query_slot<=0;query_offset<=0;query_title<=0;query_address<=0;
   candidate<=0;candidate_count<=0;candidate_reverse<=0;
  end else begin
   bt_rsp_valid<=0;g_req_valid<=0;file_request<=0;media_reinit<=0;mem_write<=0;int_done<=0;
   if(g_rsp_valid&&guide_owner!=0)begin
    guide_owner<=0;
     if(guide_owner==1)begin
      bt_rsp_valid<=1;bt_rsp_command<=g_rsp_command;bt_rsp_payload<=g_rsp_payload;
      // Ordinary RAM publication/deletion has no known SD source identity.
      if(g_rsp_command==8'h80&&g_rsp_payload[15:8]==0&&
       (ext_command==8'h12||(ext_command==8'h13&&ext_payload[7:0]==3)))selected_valid<=0;
     end
    else begin int_done<=1;int_rsp_command<=g_rsp_command;int_error<=g_rsp_payload[15:8];end
   end
   if(guide_owner==0)begin
    if(ext_pending)begin
     ext_pending<=0;guide_owner<=1;g_req_valid<=1;g_req_payload<=ext_payload;
    end else if(int_pending&&!bt_req_valid)begin
     int_pending<=0;guide_owner<=2;g_req_valid<=1;g_req_payload<=0;
     case(int_kind)
      0:g_req_payload<={16'd1,score_crc,4'd0,score_steps};
      1:g_req_payload<={8'd0,6'd0,pending_mask,4'd0,rx_steps-12'd1};
      2:g_req_payload<=0;
      default:g_req_payload<=48'd4;
     endcase
    end
   end
   // Catalog replies have a fixed one-cycle RAM pipeline followed by one byte
   // per clock. Both five-byte title and info replies finish within 8 clocks.
   if(query_active)begin
    query_phase<=query_phase+1'b1;
    query_address<=query_address+1'b1;
    if(query_phase>=2)begin
     if(query_title)begin
      case(query_phase)
       2:bt_rsp_payload[15:8]<=query_valid?mem_q:8'd0;
       3:bt_rsp_payload[23:16]<=(query_offset<31&&query_valid)?mem_q:8'd0;
       4:bt_rsp_payload[31:24]<=(query_offset<30&&query_valid)?mem_q:8'd0;
       5:bt_rsp_payload[39:32]<=(query_offset<29&&query_valid)?mem_q:8'd0;
       default:;
      endcase
     end else begin
      if(query_phase==2)bt_rsp_payload[23:16]<=query_valid?mem_q:8'd0;
      if(query_phase==3)bt_rsp_payload[31:24]<=query_valid?mem_q:8'd0;
      if(query_phase==4)bt_rsp_payload[39:32]<=query_valid?mem_q:8'd0;
     end
     if(query_phase==query_length+1)begin
      query_phase<=0;bt_rsp_valid<=1;bt_rsp_command<=query_title?8'h8d:8'h8c;
      if(query_title)bt_rsp_payload[40+:8]<=(query_offset<28&&query_valid)?mem_q:8'd0;
      else begin bt_rsp_payload[15:8]<=catalog_ready?{5'd0,mem_q[2:1],query_valid}:8'd0;bt_rsp_payload[47:40]<=catalog_revision;end
     end
    end
   end
   if(bt_req_valid)begin
    if(bt_req_command>=8'h0f&&bt_req_command<=8'h15)begin
     if(local_busy&&(bt_req_command==8'h10||bt_req_command==8'h11||bt_req_command==8'h12||
      (bt_req_command==8'h13&&(bt_req_payload[7:0]==3||bt_req_payload[7:0]==4))))acknowledge(bt_req_command,3);
     else begin ext_pending<=1;ext_command<=bt_req_command;ext_payload<=bt_req_payload;end
    end else case(bt_req_command)
     8'h16:if(bt_req_payload!=0)acknowledge(8'h16,1);else begin
      bt_rsp_valid<=1;bt_rsp_command<=8'h8b;
      bt_rsp_payload<={3'd0,(write_locked||remote_uncertain),operation_success,sd_busy,file_mounted,media_ready,
       selected_valid?{3'd0,selected_slot}:8'hff,sd_busy?8'd0:8'd100,sd_error,status_state,8'd2};
     end
     8'h17:begin
      if(bt_req_payload[47:16]==0||bt_req_payload[7:0]>3||
       (bt_req_payload[7:0]==0?bt_req_payload[15:8]!=8'hff:bt_req_payload[15:8]>31))acknowledge(8'h17,1);
      else if(bt_req_payload[7:0]==1||bt_req_payload[7:0]==3)acknowledge(8'h17,2);
      else if(remote_active)acknowledge(8'h17,3);
      else if(bt_req_payload[47:16]==operation_token)begin
       if(bt_req_payload[7:0]==operation_action&&bt_req_payload[15:8]==operation_slot)acknowledge(8'h17,0);
       else acknowledge(8'h17,1);
      end else if(sd_busy||guide_loading||ext_pending||guide_owner==1||(bt_req_payload[7:0]==0&&media_busy))acknowledge(8'h17,3);
      else if(bt_req_payload[7:0]!=0&&(!file_mounted||!media_ready))acknowledge(8'h17,2);
      else if(bt_req_payload[7:0]==2&&!valid_slots[bt_req_payload[12:8]])acknowledge(8'h17,1);
      else accept_operation;
     end
     8'h18:acknowledge(8'h18,2);
     8'h19,8'h1a:begin
      if(bt_req_payload[7:0]>31||(bt_req_command==8'h19 ? bt_req_payload[47:8]!=0:
       (bt_req_payload[15:8]>31||bt_req_payload[47:16]!=0)))acknowledge(bt_req_command,1);
      else begin
       query_slot<=bt_req_payload[4:0];query_title<=bt_req_command==8'h1a;query_offset<=bt_req_payload[12:8];
       query_length<=bt_req_command==8'h1a ? 5:4;query_phase<=1;query_valid<=valid_slots[bt_req_payload[4:0]];
       query_address<=bt_req_command==8'h1a ? {1'b0,bt_req_payload[4:0],bt_req_payload[12:8]}:metadata_base(bt_req_payload[4:0]);
       bt_rsp_payload<=bt_req_command==8'h1a ? {40'd0,bt_req_payload[15:8]}:{catalog_revision,32'd0,bt_req_payload[7:0]};
      end
     end
     8'h1b:if(bt_req_payload!=0)acknowledge(8'h1b,1);else begin bt_rsp_valid<=1;bt_rsp_command<=8'h8e;bt_rsp_payload<={operation_slot,operation_action,operation_token};end
     default:acknowledge(bt_req_command,2);
    endcase
   end
   if((local_next||local_prev)&&guide_active&&physical_keys==0)begin
    candidate<=local_prev?selected_slot-1'b1:selected_slot+1'b1;candidate_reverse<=local_prev;candidate_count<=32;
   end else if(candidate_count!=0)begin
    if(valid_slots[candidate])begin
      selected_slot<=candidate;selected_valid<=0;local_slot<=candidate;local_pending<=1;candidate_count<=0;
    end else begin candidate<=candidate_reverse?candidate-1'b1:candidate+1'b1;candidate_count<=candidate_count-1'b1;end
   end
   if(file_done&&(state==READ_RUN||state==LOAD_BEGIN||state==LOAD_BEGIN_WAIT||state==STEP_SEND||state==STEP_WAIT))begin
    read_finished<=1;read_error<=file_error;
   end
   // Stream validation. Never publish until header, mask, length and both CRCs
   // have succeeded. A bad stream is drained before aborting the inactive bank.
   if(read_valid&&read_ready)begin
    rx_position<=rx_position+1'b1;
    if(read_index!=rx_position)parse_bad<=1;
    if(read_index<64)begin
     mem_write<=1;mem_write_address<=11'd1280+read_index[5:0];mem_write_data<=read_data;
     if(read_index<62)running_crc<=next_crc;
     if(read_index<8&&read_data!=magic(read_index[2:0]))parse_bad<=1;
     case(read_index)
      8:if(read_data!=1)parse_bad<=1;
      9:begin title_length<=read_data[5:0];if(read_data>32)parse_bad<=1;end
      10:score_steps[7:0]<=read_data;
      11:begin score_steps[11:8]<=read_data[3:0];if(read_data[7:4]!=0)parse_bad<=1;end
      12:score_crc[7:0]<=read_data;13:score_crc[15:8]<=read_data;
      62:expected_header_crc<=read_data;
      63:begin
       if(!header_valid||{read_data,expected_header_crc}!=running_crc)parse_bad<=1;
       else if(!scanning)state<=LOAD_BEGIN;
       running_crc<=16'hffff;
      end
      default:;
     endcase
     if((read_index==14||read_index==15||(read_index>=48&&read_index<62))&&read_data!=0)parse_bad<=1;
     if(read_index>=16&&read_index<48)begin
      if(read_index-16<title_length)begin if(read_data==0)parse_bad<=1;title_byte(read_data);end
      else if(read_data!=0)parse_bad<=1;
     end
    end else begin
     running_crc<=next_crc;
     if(mask_byte==0)begin mask_low[7:0]<=read_data;mask_byte<=1;end
     else if(mask_byte==1)begin mask_low[15:8]<=read_data;mask_byte<=2;end
     else begin
      mask_byte<=0;rx_steps<=rx_steps+1'b1;pending_mask<=received_mask[17:0];
      if(received_mask==0||received_mask[23:18]!=0||popcount(received_mask[17:0])>4)parse_bad<=1;
      else if(!scanning&&!parse_bad&&load_started)state<=STEP_SEND;
     end
    end
   end

   case(state)
    IDLE:begin
     if(start_pending&&!remote_active)begin start_pending<=0;state<=DISPATCH;end
     else if(boot_pending&&!remote_active&&media_ready&&!file_busy&&!bt_req_valid&&!guide_loading&&!ext_pending&&guide_owner!=1)begin
      boot_pending<=0;boot_load<=1;operation_token<=0;operation_action<=0;operation_slot<=8'hff;
      local_busy<=1;operation_error<=0;operation_success<=0;sd_error<=0;state<=SCAN_START;
     end else if(local_pending&&!remote_active&&!bt_req_valid&&!guide_loading&&!ext_pending&&guide_owner!=1)begin
      local_pending<=0;operation_token<=0;operation_action<=2;operation_slot<={3'd0,local_slot};work_slot<=local_slot;
      local_busy<=1;operation_error<=0;operation_success<=0;sd_error<=0;scanning<=0;state<=READ_START;
     end else if(!media_ready)begin boot_pending<=1;if(media_error!=0)sd_error<=media_error;end
    end
    DISPATCH:case(operation_action)
     0:begin if(!media_ready)begin media_reinit<=1;state<=WAIT_MEDIA;end else state<=SCAN_START;end
     2:begin scanning<=0;selected_slot<=work_slot;selected_valid<=0;state<=READ_START;end
    endcase
    WAIT_MEDIA:if(media_ready)state<=SCAN_START;else if(!media_busy&&media_error!=0&&!media_reinit)fail_operation(media_error);
    SCAN_START:if(!file_busy&&!remote_active)begin
     valid_slots<=0;catalog_ready<=0;selected_valid<=0;
     scan_valid<=0;scanning<=1;file_request<=1;file_operation<=0;state<=SCAN_WAIT;
    end
    SCAN_WAIT:if(file_done)begin
     if(file_error!=0)begin unsupported<=file_error==3;fail_operation(file_error);end
     else begin work_slot<=0;state<=READ_START;end
    end
    READ_START:if(!file_busy&&!remote_active)begin
     if(!scanning)selected_valid<=0;
     file_request<=1;file_operation<=1;file_slot<=work_slot;
     running_crc<=16'hffff;expected_header_crc<=0;score_crc<=0;score_steps<=0;title_length<=0;
     parse_bad<=0;rx_position<=0;rx_steps<=0;mask_byte<=0;load_started<=0;read_finished<=0;read_error<=0;
     utf_need<=0;utf_bad<=0;utf_low<=8'h80;utf_high<=8'hbf;state<=READ_RUN;
    end
    READ_RUN:if(read_finished)state<=READ_FINISH;
    LOAD_BEGIN:begin internal_request(0);state<=LOAD_BEGIN_WAIT;end
    LOAD_BEGIN_WAIT:if(int_done)begin
     if(int_rsp_command!=8'h80||int_error!=0)begin parse_bad<=1;end else load_started<=1;
     state<=READ_RUN;
    end
    STEP_SEND:begin internal_request(1);state<=STEP_WAIT;end
    STEP_WAIT:if(int_done)begin if(int_rsp_command!=8'h80||int_error!=0)parse_bad<=1;state<=READ_RUN;end
    READ_FINISH:begin
     if(scanning)begin
      if(read_error==6)begin mem_write<=1;mem_write_address<=metadata_base(work_slot)+11'd3;mem_write_data<=0;state<=SCAN_PICK;end
      else if(read_error!=0||parse_bad||rx_position!=file_size||mask_byte!=0||rx_steps!=score_steps||running_crc!=score_crc||rx_position<67)begin
       mem_write<=1;mem_write_address<=metadata_base(work_slot)+11'd3;mem_write_data<=4;
       if(read_error!=0&&read_error!=7&&operation_error==0)operation_error<=read_error;state<=SCAN_PICK;
      end else begin scan_valid[work_slot]<=1;index_byte<=0;state<=COPY_SET;end
     end else if(read_error!=0||parse_bad||rx_position!=file_size||mask_byte!=0||rx_steps!=score_steps||running_crc!=score_crc||!load_started)begin
      operation_error<=read_error!=0?read_error:E_P18;
      if(load_started)state<=ABORT_SEND;else state<=FINISH;
     end else state<=COMMIT_SEND;
    end
    COMMIT_SEND:begin internal_request(2);state<=COMMIT_WAIT;end
    COMMIT_WAIT:if(int_done)begin
     if(int_rsp_command!=8'h80||int_error!=0)begin operation_error<=E_GUIDE;state<=ABORT_SEND;end
     else begin if(!local_pending)begin selected_slot<=work_slot;selected_valid<=1;end state<=FINISH;end
    end
    ABORT_SEND:begin internal_request(3);state<=ABORT_WAIT;end
    ABORT_WAIT:if(int_done)state<=FINISH;
    COPY_SET:if(!query_active&&!query_new)begin main_address<=11'd1296+index_byte;mem_delay<=2;state<=COPY_GET;end
    COPY_GET:if(query_active||query_new)mem_delay<=2;else if(mem_delay!=0)mem_delay<=mem_delay-1'b1;else begin
     mem_write<=1;mem_write_address<=index_byte<32?{1'b0,work_slot,index_byte[4:0]}:
      (metadata_base(work_slot)+{9'd0,index_byte[1:0]});mem_write_data<=mem_q;
     if(index_byte==31)begin
      index_byte<=32;state<=COPY_SET;
     end else if(index_byte==32)begin mem_write_data<=score_steps[7:0];index_byte<=33;state<=COPY_SET;end
     else if(index_byte==33)begin mem_write_data<={4'd0,score_steps[11:8]};index_byte<=34;state<=COPY_SET;end
     else if(index_byte==34)begin mem_write_data<=title_length;index_byte<=35;state<=COPY_SET;end
     else if(index_byte==35)begin
      mem_write_data<={6'd0,scanning&&file_attributes[0],1'b1};
      state<=SCAN_PICK;
     end else begin index_byte<=index_byte+1'b1;state<=COPY_SET;end
    end
    SCAN_PICK:begin
     if(work_slot==31)begin
      valid_slots<=scan_valid;catalog_ready<=1;catalog_revision<=catalog_revision+1'b1;scanning<=0;
      selected_valid<=0;
      // Scans move the directory cursor, but only boot will load that choice.
      for(k=31;k>=0;k=k-1)if(scan_valid[k])begin selected_slot<=k;selected_valid<=0;end
      state<=FINISH;
     end else begin work_slot<=work_slot+1'b1;state<=READ_START;end
    end
    FINISH:begin
     local_busy<=0;operation_success<=operation_error==0;sd_error<=operation_error;state<=IDLE;
     if(boot_load)begin
      boot_load<=0;
      if(operation_error==0&&valid_slots!=0)begin
       operation_token<=0;operation_action<=2;operation_slot<={3'd0,selected_slot};work_slot<=selected_slot;
       local_busy<=1;scanning<=0;state<=READ_START;
      end
     end else if(local_pending&&!remote_active)begin
      local_pending<=0;operation_token<=0;operation_action<=2;operation_slot<={3'd0,local_slot};work_slot<=local_slot;
      local_busy<=1;operation_error<=0;operation_success<=0;sd_error<=0;scanning<=0;state<=READ_START;
     end
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
