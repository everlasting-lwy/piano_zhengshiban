// Service-owned sector window. Every write is read back before completion.
// One synchronous512-byte RAM; file reader and RPC never own the card together.
module sd_sector_rpc #(parameter integer LEASE_CYCLES=1500000000)(
 input wire clk,rst_n,
 input wire bt_req_valid,input wire[7:0]bt_req_command,input wire[47:0]bt_req_payload,
 output reg bt_rsp_valid,output reg[7:0]bt_rsp_command,output reg[47:0]bt_rsp_payload,
 output reg session_active,write_uncertain,input wire file_idle,
 input wire media_ready,input wire[31:0]media_sectors,input wire media_busy,input wire[7:0]media_error,
 output reg block_start,block_write,output reg[31:0]block_lba,
 input wire block_done,input wire[7:0]block_error,
 input wire rd_valid,input wire[8:0]rd_index,input wire[7:0]rd_data,
 input wire wr_request,input wire[8:0]wr_index,output wire wr_valid,output wire[7:0]wr_data
);
 localparam IDLE=0,READ_START=1,READ_RUN=2,WRITE_START=3,WRITE_RUN=4,VERIFY_START=5,VERIFY_RUN=6,DRAIN=7;
 reg[2:0]state;
 reg[31:0]token;
 localparam LEASE_WIDTH=$clog2(LEASE_CYCLES+1);
 reg[LEASE_WIDTH-1:0]lease_count;
 reg[7:0]operation_error,saved_error;
 reg cache_valid,last_write,prepared,last_chunk_valid;
 reg[15:0]last_id,prepared_id,staged_crc,last_crc;
 reg[31:0]last_lba;
 reg[9:0]write_count,read_count,verify_count;
 reg[2:0]fill_remaining;
 reg[8:0]fill_address,last_offset;
 reg[31:0]fill_bytes,last_chunk;
 reg verify_bad,verify_valid_d;reg[7:0]verify_data_d;
 reg[1:0]drain_count;
 reg[2:0]query_phase;reg[8:0]query_address,query_base;reg[23:0]query_data;
 reg[8:0]wr_previous;reg[1:0]wr_delay;
 (* syn_ramstyle="block_ram" *)reg[7:0]sector[0:511];reg[7:0]ram_q;
 wire[8:0]ram_address=wr_request?wr_index:(state==VERIFY_RUN&&rd_valid)?rd_index:query_address;
 assign wr_valid=session_active&&wr_request&&wr_delay==2&&wr_previous==wr_index;
 assign wr_data=ram_q;
 always @(posedge clk)begin
  ram_q<=sector[ram_address];
  if(rst_n&&state==READ_RUN&&rd_valid)sector[rd_index]<=rd_data;
  else if(rst_n&&fill_remaining!=0)sector[fill_address]<=fill_bytes[7:0];
 end
 function[15:0]crc16;input[15:0]c;input[7:0]d;integer i;reg[15:0]v;begin
  v=c^{d,8'd0};for(i=0;i<8;i=i+1)v=v[15]?(v<<1)^16'h1021:v<<1;crc16=v;
 end endfunction
 wire local_busy=state!=IDLE||fill_remaining!=0||query_phase!=0;
 wire[7:0]status_state=(state==READ_START||state==READ_RUN)?8'd1:state!=IDLE?8'd2:operation_error!=0?8'd3:8'd0;
 task ack;input[7:0]code;begin bt_rsp_valid<=1;bt_rsp_command<=8'h80;bt_rsp_payload<={24'd0,8'd2,code,bt_req_command};end endtask
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;token<=0;lease_count<=0;session_active<=0;write_uncertain<=0;
   bt_rsp_valid<=0;bt_rsp_command<=0;bt_rsp_payload<=0;block_start<=0;block_write<=0;block_lba<=0;
   operation_error<=0;saved_error<=0;cache_valid<=0;last_write<=0;prepared<=0;last_chunk_valid<=0;
   last_id<=0;prepared_id<=0;staged_crc<=16'hffff;last_crc<=0;last_lba<=0;
   write_count<=0;read_count<=0;verify_count<=0;fill_remaining<=0;fill_address<=0;fill_bytes<=0;last_offset<=0;last_chunk<=0;
   verify_bad<=0;verify_valid_d<=0;verify_data_d<=0;drain_count<=0;
   query_phase<=0;query_address<=0;query_base<=0;query_data<=0;wr_previous<=0;wr_delay<=0;
  end else begin
   bt_rsp_valid<=0;block_start<=0;
   if(!wr_request||wr_previous!=wr_index)begin wr_previous<=wr_index;wr_delay<=0;end
   else if(wr_delay<2)wr_delay<=wr_delay+1'b1;
   verify_valid_d<=state==VERIFY_RUN&&rd_valid;verify_data_d<=rd_data;
   if(verify_valid_d&&ram_q!=verify_data_d)verify_bad<=1;
   if(!session_active||bt_req_valid||local_busy)lease_count<=0;
   else if(lease_count>=LEASE_CYCLES-1)begin
    session_active<=0;cache_valid<=0;prepared<=0;write_count<=0;lease_count<=0;
   end else lease_count<=lease_count+1'b1;
   if(fill_remaining!=0)begin
    staged_crc<=crc16(staged_crc,fill_bytes[7:0]);write_count<=write_count+1'b1;
    fill_address<=fill_address+1'b1;fill_bytes<=fill_bytes>>8;fill_remaining<=fill_remaining-1'b1;
    if(fill_remaining==1)begin bt_rsp_valid<=1;bt_rsp_command<=8'h80;bt_rsp_payload<=48'h000000020022;last_chunk_valid<=1;end
   end
   if(query_phase!=0)begin
    query_phase<=query_phase+1'b1;
    case(query_phase)
     1:query_address<=query_base+9'd1;
     2:begin query_data[7:0]<=ram_q;query_address<=query_base+9'd2;end
     3:begin query_data[15:8]<=ram_q;query_address<=query_base+9'd3;end
     4:query_data[23:16]<=ram_q;
     5:begin query_phase<=0;bt_rsp_valid<=1;bt_rsp_command<=8'h91;bt_rsp_payload<={ram_q,query_data,7'd0,query_base};end
     default:;
    endcase
   end
   if(bt_req_valid)case(bt_req_command)
    8'h20:begin
     if(bt_req_payload[47:40]!=0||bt_req_payload[39:8]==0||bt_req_payload[7:0]>1)ack(1);
     else if(session_active&&bt_req_payload[39:8]!=token)ack(3);
     else if(bt_req_payload[7:0]==0&&session_active)ack(0);
     else if(local_busy||media_busy)ack(3);
     else if(bt_req_payload[7:0]==1)begin
      if(bt_req_payload[39:8]!=token)ack(1);
      else begin session_active<=0;cache_valid<=0;prepared<=0;write_count<=0;ack(0);end
     end else if(!media_ready)ack(2);
     else if(!file_idle)ack(3);
     else begin
      session_active<=1;token<=bt_req_payload[39:8];cache_valid<=0;prepared<=0;write_count<=0;
      last_id<=0;last_write<=0;operation_error<=0;last_chunk_valid<=0;ack(0);
     end
    end
    8'h21:begin
     if(bt_req_payload[47:32]==0)ack(1);
     else if(!session_active)ack(2);
     else if(bt_req_payload[47:32]==last_id)begin
      if(!last_write&&bt_req_payload[31:0]==last_lba)ack(0);else ack(1);
     end else if(local_busy||media_busy)ack(3);
     else if(!media_ready)ack(2);
     else if(bt_req_payload[31:0]>=media_sectors)ack(1);
     else begin
      last_id<=bt_req_payload[47:32];last_lba<=bt_req_payload[31:0];last_write<=0;
      block_lba<=bt_req_payload[31:0];state<=READ_START;cache_valid<=0;prepared<=0;write_count<=0;operation_error<=0;read_count<=0;ack(0);
     end
    end
    8'h22:begin
     if(bt_req_payload[15:9]!=0||bt_req_payload[1:0]!=0)ack(1);
     else if(!session_active||!prepared)ack(2);
     else if(local_busy||media_busy)ack(3);
     else if(last_chunk_valid&&bt_req_payload[8:0]==last_offset)begin
      if(bt_req_payload[47:16]==last_chunk)ack(0);else ack(1);
     end else if({1'b0,bt_req_payload[8:0]}!=write_count)ack(1);
     else begin
      fill_remaining<=4;fill_address<=bt_req_payload[8:0];fill_bytes<=bt_req_payload[47:16];
      last_offset<=bt_req_payload[8:0];last_chunk<=bt_req_payload[47:16];last_chunk_valid<=0;
     end
    end
    8'h23:begin
     if(!session_active||!prepared)ack(2);
     else if(prepared_id==last_id)begin
      if(last_write&&last_lba==bt_req_payload[31:0]&&last_crc==bt_req_payload[47:32])ack(0);else ack(1);
     end else if(local_busy||media_busy)ack(3);
     else if(!media_ready||write_uncertain)ack(2);
     else if(write_count!=512||staged_crc!=bt_req_payload[47:32]||bt_req_payload[31:0]>=media_sectors)ack(1);
     else begin
      last_id<=prepared_id;last_lba<=bt_req_payload[31:0];last_crc<=bt_req_payload[47:32];last_write<=1;
      block_lba<=bt_req_payload[31:0];state<=WRITE_START;cache_valid<=0;operation_error<=0;ack(0);
     end
    end
    8'h24:begin
     if(bt_req_payload[47:16]!=0||bt_req_payload[15:0]==0)ack(1);
     else if(!session_active)ack(2);
     else if(prepared&&prepared_id==bt_req_payload[15:0])ack(0);
     else if(local_busy||media_busy)ack(3);
     else if(bt_req_payload[15:0]==last_id)ack(1);
     else begin
      prepared<=1;prepared_id<=bt_req_payload[15:0];write_count<=0;staged_crc<=16'hffff;
      cache_valid<=0;last_chunk_valid<=0;ack(0);
     end
    end
    8'h25:begin
     if(bt_req_payload[47:9]!=0||bt_req_payload[1:0]!=0)ack(1);
     else if(!session_active||!cache_valid)ack(2);
     else if(local_busy||media_busy)ack(3);
     else begin query_base<=bt_req_payload[8:0];query_address<=bt_req_payload[8:0];query_phase<=1;end
    end
    8'h26:if(bt_req_payload!=0)ack(1);else begin
     bt_rsp_valid<=1;bt_rsp_command<=8'h92;
     bt_rsp_payload<={8'd0,last_id,3'd0,write_uncertain,media_ready,(write_count==512),cache_valid,session_active,operation_error,status_state};
    end
    8'h28:if(bt_req_payload!=0)ack(1);else begin
     bt_rsp_valid<=1;bt_rsp_command<=8'h93;bt_rsp_payload<={8'd2,{7'd0,media_ready},media_sectors};
    end
    default:ack(2);
   endcase
   case(state)
    READ_START:if(!media_busy)begin block_write<=0;block_start<=1;state<=READ_RUN;end
    READ_RUN:begin
     if(rd_valid)begin if({1'b0,rd_index}!=read_count)operation_error<=16;read_count<=read_count+1'b1;end
     if(block_done)begin
      if(block_error!=0)operation_error<=block_error;
      else if(read_count!=512)operation_error<=16;
      else if(operation_error==0)cache_valid<=1;
      state<=IDLE;
     end
    end
    WRITE_START:if(!media_busy)begin block_write<=1;block_start<=1;state<=WRITE_RUN;end
    WRITE_RUN:if(block_done)begin
     if(block_error!=0)begin operation_error<=block_error;write_uncertain<=1;state<=IDLE;end
     else state<=VERIFY_START;
    end
    VERIFY_START:if(!media_busy)begin
     block_write<=0;block_start<=1;verify_count<=0;verify_bad<=0;state<=VERIFY_RUN;
    end
    VERIFY_RUN:begin
     if(rd_valid)begin if({1'b0,rd_index}!=verify_count)verify_bad<=1;verify_count<=verify_count+1'b1;end
     if(block_done)begin saved_error<=block_error;drain_count<=2;state<=DRAIN;end
    end
    DRAIN:if(drain_count!=0)drain_count<=drain_count-1'b1;else begin
     if(saved_error!=0||verify_bad||verify_count!=512)begin operation_error<=saved_error!=0?saved_error:8'd13;write_uncertain<=1;end
     else begin operation_error<=0;cache_valid<=1;end
     state<=IDLE;
    end
    default:;
   endcase
  end
 end
endmodule
