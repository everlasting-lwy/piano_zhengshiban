// Shared sound parameters, controlled only by checked BT commands or the encoder.
module panel_parameter_control(
 input wire clk,rst_n,
 input wire [7:0] command,
 input wire command_valid,
 output reg [3:0] reverb,echo,chorus,expression,vibrato,
 output reg [4:0] bend,
 output reg [1:0] delay_select,guide
);
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   reverb<=0;echo<=0;chorus<=0;expression<=15;vibrato<=0;bend<=8;delay_select<=0;guide<=0;
  end else if(command_valid)begin
   case(command[7:4])
    1:reverb<=command[3:0];
    2:echo<=command[3:0];
    3:chorus<=command[3:0];
    5:if(command<=8'h52)delay_select<=command[1:0];
    7:if(command<=8'h72)guide<=command[1:0];
    10:expression<=command[3:0];
    11,12:if(command<=8'hc0)bend<=command-8'hb0;
    13:vibrato<=command[3:0];
    default:;
   endcase
  end
 end
endmodule
