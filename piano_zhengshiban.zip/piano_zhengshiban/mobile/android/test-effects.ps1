param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/effects-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$testSources=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session','EffectsState','VisualFrames','VisualPoller') | ForEach-Object { $path=Join-Path $PSScriptRoot "src/org/pianolink/$_.java"; if(Test-Path -LiteralPath $path){$path} }
$testSources+=Join-Path $PSScriptRoot 'test/org/pianolink/EffectsTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @testSources
if($LASTEXITCODE -ne 0){throw 'Effects tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.EffectsTest
if($LASTEXITCODE -ne 0){throw 'Effects behavior tests failed'}
