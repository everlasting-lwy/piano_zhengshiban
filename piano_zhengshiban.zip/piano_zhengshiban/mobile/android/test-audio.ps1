param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/audio-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$names=@('AudioDsp','AudioPcmSink','PcmWavReader','PcmByteDecoder','BasicPitchWindowing','PitchPostprocessor','SongData','Recording','Protocol')
$sources=@($names | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"})
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/AudioTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/PitchFixtureCli.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 -d $testOut @sources
if($LASTEXITCODE -ne 0){throw 'Audio tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.AudioTest
if($LASTEXITCODE -ne 0){throw 'Audio test failed'}
