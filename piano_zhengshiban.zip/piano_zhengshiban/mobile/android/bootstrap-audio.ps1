param([string]$Cache='', [switch]$ReadOnly)
$ErrorActionPreference='Stop'
if(!$Cache){$Cache=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../tmp/audio_deps'))}
if (!$ReadOnly) { New-Item -ItemType Directory -Force -Path $Cache | Out-Null }
$commit='fa5997af0a8210982619003269994a1be25eddf3'
$artifacts=@(
    @{Name='litert';Sha1='7d56d65bea6eab856c924c19cdf3c34d61bc76a4'},
    @{Name='litert-api';Sha1='5fe427c2280937eec7d22370da7463814d99273c'}
)
foreach($artifact in $artifacts){
    $file=Join-Path $Cache ($artifact.Name+'-1.4.2.aar')
    if(!(Test-Path -LiteralPath $file)){
        if ($ReadOnly) { throw "Read-only audio cache is incomplete: $file" }
        $uri='https://dl.google.com/dl/android/maven2/com/google/ai/edge/litert/'+$artifact.Name+'/1.4.2/'+$artifact.Name+'-1.4.2.aar'
        Invoke-WebRequest -Uri $uri -OutFile $file -TimeoutSec 120
    }
    if((Get-FileHash -LiteralPath $file -Algorithm SHA1).Hash -ine $artifact.Sha1){throw "Official Maven checksum mismatch: $file"}
    # Expand-Archive accepts ZIP names in both Windows PowerShell and PowerShell7.
    if (!$ReadOnly) {
        $zip=Join-Path $Cache ($artifact.Name+'-1.4.2.zip')
        Copy-Item -LiteralPath $file -Destination $zip -Force
        Expand-Archive -LiteralPath $zip -DestinationPath (Join-Path $Cache ($artifact.Name+'-1.4.2')) -Force
    }
    if (!(Test-Path -LiteralPath (Join-Path $Cache ($artifact.Name+'-1.4.2/classes.jar')))) { throw 'Audio cache has no extracted classes.jar' }
}
$model=Join-Path $Cache 'basic_pitch.tflite'
if ($ReadOnly -and !(Test-Path -LiteralPath $model)) { throw 'Read-only audio cache has no Basic Pitch model' }
if(!(Test-Path -LiteralPath $model)){Invoke-WebRequest -Uri ('https://raw.githubusercontent.com/spotify/basic-pitch/'+$commit+'/basic_pitch/saved_models/icassp_2022/nmp.tflite') -OutFile $model -TimeoutSec 120}
if((Get-FileHash -LiteralPath $model -Algorithm SHA256).Hash -ine '3db297d54af8e01c6e5618245c956b1d71b6a2b978cb2dedb527173186552676'){throw 'Basic Pitch model checksum mismatch'}
$license=Join-Path $Cache 'BASIC_PITCH_LICENSE'
if ($ReadOnly -and !(Test-Path -LiteralPath $license)) { throw 'Read-only audio cache has no Basic Pitch license' }
if(!(Test-Path -LiteralPath $license)){Invoke-WebRequest -Uri ('https://raw.githubusercontent.com/spotify/basic-pitch/'+$commit+'/LICENSE') -OutFile $license -TimeoutSec 60}
$assets=Join-Path $PSScriptRoot 'assets'
New-Item -ItemType Directory -Force -Path $assets | Out-Null
Copy-Item -LiteralPath $model -Destination (Join-Path $assets 'basic_pitch.tflite') -Force
Copy-Item -LiteralPath $license -Destination (Join-Path $assets 'BASIC_PITCH_LICENSE.txt') -Force
Copy-Item -LiteralPath (Join-Path $Cache 'litert-1.4.2/LICENSE') -Destination (Join-Path $assets 'LITERT_LICENSE.txt') -Force
Write-Output "Verified LiteRT1.4.2 / Basic Pitch model: $Cache"
