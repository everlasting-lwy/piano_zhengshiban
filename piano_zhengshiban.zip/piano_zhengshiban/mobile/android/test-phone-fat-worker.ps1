param([string]$Jdk='C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'build/phone-fat-worker-test';New-Item -ItemType Directory -Force -Path $out|Out-Null
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java'|ForEach-Object FullName)
$sources+=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','Session','SectorRpcClient','LinkController','LinkSession','VisualFrames','VisualPoller')|ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$fat=Join-Path $PSScriptRoot 'src/org/pianolink/Fat32Store.java';if(Test-Path -LiteralPath $fat){$sources+=$fat}
$sources+=@('SectorRpcTest','PhoneFatWorkerTest')|ForEach-Object {Join-Path $PSScriptRoot "test/org/pianolink/$_.java"}
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $out @sources;if($LASTEXITCODE -ne 0){throw 'Phone FAT worker compile failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.PhoneFatWorkerTest;if($LASTEXITCODE -ne 0){throw 'Phone FAT worker test failed'}
