param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/sd-ui-test'
$stubRoot=Join-Path $PSScriptRoot 'build/oled-idle-poll-test/stubs'
if(!(Test-Path -LiteralPath $stubRoot)){& (Join-Path $PSScriptRoot 'test-oled-idle-poll.ps1') -Jdk $Jdk}
New-Item -ItemType Directory -Force -Path $testOut|Out-Null
$sources=@(Get-ChildItem -LiteralPath $stubRoot -Recurse -Filter '*.java'|ForEach-Object FullName)
$sources+=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java'|ForEach-Object FullName)
$sources+=@('Protocol','MockFpga','OledGuideProtocol','Session','Recording','SongData','GuideSong','OledGuideSong','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store')|ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$ui=Join-Path $PSScriptRoot 'src/org/pianolink/SdLibraryUi.java';if(Test-Path -LiteralPath $ui){$sources+=$ui}
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/SdLibraryUiTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @sources
if($LASTEXITCODE -ne 0){throw 'SD panel tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.SdLibraryUiTest
if($LASTEXITCODE -ne 0){throw 'SD panel tests failed'}
