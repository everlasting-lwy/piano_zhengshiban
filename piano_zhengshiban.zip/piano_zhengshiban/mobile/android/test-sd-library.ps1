param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/sd-library-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java' | ForEach-Object {$_.FullName})
$sources+=@('Protocol','MockFpga','OledGuideProtocol','Session','VisualFrames','VisualPoller','LinkController','LinkSession') | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
foreach($name in @('SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store')){$path=Join-Path $PSScriptRoot "src/org/pianolink/$name.java";if(Test-Path -LiteralPath $path){$sources+=$path}}
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/SdLibraryTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/P18FileTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/SdLibraryTransportTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @sources
if($LASTEXITCODE -ne 0){throw 'SD tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.SdLibraryTest
if($LASTEXITCODE -ne 0){throw 'SD library tests failed'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.P18FileTest
if($LASTEXITCODE -ne 0){throw 'P18 tests failed'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.SdLibraryTransportTest
if($LASTEXITCODE -ne 0){throw 'SD transport tests failed'}
