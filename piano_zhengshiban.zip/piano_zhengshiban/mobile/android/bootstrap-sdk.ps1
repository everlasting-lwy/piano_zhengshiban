param([string]$Destination = '')
$ErrorActionPreference='Stop'
if (!$Destination) { $Destination=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../tmp/android-sdk')) }
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
# Official Google repository2-3.xml, stable API 35 revision 2 and build tools 35.0.0.
$packages=@(
    @{Name='platform-35_r02.zip';Sha1='0bb560a90a7a2cbd0dd8348224d518b638fe7949'},
    @{Name='build-tools_r35_windows.zip';Sha1='af059bb67cf7786f45ee0db85e2d24985df1b4b6'}
)
foreach ($package in $packages) {
    $zip=Join-Path $Destination $package.Name
    if (!(Test-Path -LiteralPath $zip)) { Invoke-WebRequest -Uri ('https://dl.google.com/android/repository/'+$package.Name) -OutFile $zip -TimeoutSec 300 }
    if ((Get-FileHash -LiteralPath $zip -Algorithm SHA1).Hash -ne $package.Sha1) { throw "Checksum mismatch: $zip" }
    Expand-Archive -LiteralPath $zip -DestinationPath $Destination -Force
}
Write-Output "SDK ready: $Destination"
