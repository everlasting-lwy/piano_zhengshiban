param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot',
      [string]$Python = (Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'))
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/fat32-store-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$sources=@('Protocol','OledGuideProtocol','SdLibraryProtocol','P18File') | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$fatSource=Join-Path $PSScriptRoot 'src/org/pianolink/Fat32Store.java'
if(Test-Path -LiteralPath $fatSource){$sources+=$fatSource}
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/Fat32StoreTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @sources
if($LASTEXITCODE -ne 0){throw 'FAT32 tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.Fat32StoreTest (Join-Path $testOut 'images')
if($LASTEXITCODE -ne 0){throw 'FAT32 transaction tests failed'}
& $Python (Join-Path $PSScriptRoot 'test/check_fat32_images.py') (Join-Path $testOut 'images')
if($LASTEXITCODE -ne 0){throw 'Independent FAT32/P18 image verification failed'}
