param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference = 'Stop'
$testRoot = Join-Path $PSScriptRoot 'build/guide-ui-test'
$stubRoot = Join-Path $testRoot 'src'
$classes = Join-Path $testRoot 'classes'
$stubs = @{
'android/content/Context.java' = 'package android.content; public class Context {public android.content.res.Resources getResources(){return new android.content.res.Resources();}}'
'android/content/res/Resources.java' = 'package android.content.res; public class Resources {public android.util.DisplayMetrics getDisplayMetrics(){return new android.util.DisplayMetrics();}}'
'android/util/DisplayMetrics.java' = 'package android.util; public class DisplayMetrics {public float density=1,scaledDensity=1;}'
'android/app/Activity.java' = 'package android.app; public class Activity extends android.content.Context {}'
'android/os/Looper.java' = 'package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}'
'android/os/SystemClock.java' = 'package android.os; public class SystemClock {public static long now=1000; public static long elapsedRealtime(){return now;}}'
'android/os/Handler.java' = 'package android.os; public class Handler {public int pending; public Handler(Looper l){} public boolean post(Runnable r){pending++;return true;} public boolean postDelayed(Runnable r,long d){pending++;return true;} public void removeCallbacks(Runnable r){pending=0;} public void removeCallbacksAndMessages(Object o){pending=0;}}'
'android/view/Gravity.java' = 'package android.view; public class Gravity {public static final int CENTER=17,CENTER_VERTICAL=16,RIGHT=5;}'
'android/view/WindowInsets.java' = 'package android.view; public class WindowInsets {public int getSystemWindowInsetLeft(){return 0;}public int getSystemWindowInsetRight(){return 0;}public int getSystemWindowInsetTop(){return 0;}public int getSystemWindowInsetBottom(){return 0;}}'
'android/view/ViewParent.java' = 'package android.view; public interface ViewParent {void requestDisallowInterceptTouchEvent(boolean b);}'
'android/view/View.java' = @'
package android.view;
public class View {
 private final android.content.Context context; private OnClickListener click; private int width=840,height=320; private boolean enabled=true;
 public View(android.content.Context c){context=c;} public android.content.res.Resources getResources(){return context.getResources();}
 public interface OnClickListener{void onClick(View v);} public interface OnApplyWindowInsetsListener{WindowInsets onApplyWindowInsets(View v,WindowInsets i);}
 public void setOnClickListener(OnClickListener l){click=l;} public boolean performClick(){if(enabled&&click!=null)click.onClick(this);return true;}
 public void setOnApplyWindowInsetsListener(OnApplyWindowInsetsListener l){} public void setFocusable(boolean b){} public void setContentDescription(CharSequence s){}
 public void setBackgroundColor(int c){} public void setBackground(Object d){} public void setPadding(int l,int t,int r,int b){} public void setAlpha(float v){}
 public void setEnabled(boolean v){enabled=v;} public boolean isEnabled(){return enabled;} public void invalidate(){} public ViewParent getParent(){return null;}
 public int getWidth(){return width;}public int getHeight(){return height;} public void setSize(int w,int h){int ow=width,oh=height;width=w;height=h;onSizeChanged(w,h,ow,oh);}
 protected void onSizeChanged(int w,int h,int ow,int oh){} protected void onDraw(android.graphics.Canvas c){} public boolean onTouchEvent(MotionEvent e){return false;}
}
'@
'android/view/MotionEvent.java' = 'package android.view; public class MotionEvent {public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_MOVE=2,ACTION_CANCEL=3,ACTION_POINTER_DOWN=5,ACTION_POINTER_UP=6;private int a;private float x,y;public MotionEvent(int a,float x,float y){this.a=a;this.x=x;this.y=y;}public int getActionMasked(){return a;}public int getActionIndex(){return 0;}public int getPointerId(int i){return i;}public int getPointerCount(){return 1;}public float getX(int i){return x;}public float getY(int i){return y;}}'
'android/widget/LinearLayout.java' = 'package android.widget; public class LinearLayout extends android.view.View {public static final int VERTICAL=1,HORIZONTAL=0;public LinearLayout(android.content.Context c){super(c);}public void setOrientation(int o){}public void setGravity(int g){}public void addView(android.view.View v){}public void addView(android.view.View v,LayoutParams p){}public static class LayoutParams{public int width,height,rightMargin;public float weight;public LayoutParams(int w,int h){width=w;height=h;}public LayoutParams(int w,int h,float f){this(w,h);weight=f;}}}'
'android/widget/TextView.java' = 'package android.widget;public class TextView extends android.view.View {private CharSequence text="";public TextView(android.content.Context c){super(c);}public void setText(CharSequence s){text=s;}public CharSequence getText(){return text;}public void setTextSize(float s){}public void setTextColor(int c){}public void setTypeface(Object t){}public void setSingleLine(boolean b){}public void setMaxLines(int n){}public void setEllipsize(Object o){}public void setGravity(int g){}public void setIncludeFontPadding(boolean b){}}'
'android/widget/ProgressBar.java' = 'package android.widget;public class ProgressBar extends android.view.View {public ProgressBar(android.content.Context c,Object a,int s){super(c);}public void setMax(int n){}public void setProgress(int n){}}'
'android/graphics/Typeface.java' = 'package android.graphics;public class Typeface {public static final Typeface DEFAULT_BOLD=new Typeface();}'
'android/graphics/drawable/GradientDrawable.java' = 'package android.graphics.drawable;public class GradientDrawable {public void setColor(int c){}public void setCornerRadius(float r){}}'
'android/text/TextUtils.java' = 'package android.text;public class TextUtils {public enum TruncateAt {END}}'
'android/R.java' = 'package android;public class R {public static class attr {public static final int progressBarStyleHorizontal=1;}}'
'android/graphics/Paint.java' = 'package android.graphics;public class Paint {public enum Style {FILL,STROKE}public enum Align{LEFT,CENTER,RIGHT}int color=0xff000000;float size=12,stroke=1;Style style=Style.FILL;Align align=Align.LEFT;public Paint(int n){}public void setStyle(Style s){style=s;}public void setColor(int c){color=c;}public void setAlpha(int a){color=(color&0xffffff)|(a<<24);}public void setTextSize(float s){size=s;}public void setTextAlign(Align a){align=a;}public void setStrokeWidth(float w){stroke=w;}}'
'android/graphics/Canvas.java' = @'
package android.graphics;
public class Canvas {
 public int primitives;private final java.awt.image.BufferedImage image;private final java.awt.Graphics2D g;
 public Canvas(){this(840,320);}public Canvas(int w,int h){image=new java.awt.image.BufferedImage(w,h,java.awt.image.BufferedImage.TYPE_INT_ARGB);g=image.createGraphics();g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,java.awt.RenderingHints.VALUE_ANTIALIAS_ON);}
 private void paint(Paint p){g.setColor(new java.awt.Color(p.color,true));g.setStroke(new java.awt.BasicStroke(p.stroke));}
 public void drawColor(int c){g.setColor(new java.awt.Color(c,true));g.fillRect(0,0,image.getWidth(),image.getHeight());}
 public void drawRect(float l,float t,float r,float b,Paint p){primitives++;if(Float.isNaN(l+t+r+b))throw new AssertionError("NaN geometry");paint(p);java.awt.geom.Rectangle2D shape=new java.awt.geom.Rectangle2D.Float(l,t,r-l,b-t);if(p.style==Paint.Style.FILL)g.fill(shape);else g.draw(shape);}
 public void drawRoundRect(float l,float t,float r,float b,float x,float y,Paint p){primitives++;paint(p);java.awt.geom.RoundRectangle2D shape=new java.awt.geom.RoundRectangle2D.Float(l,t,r-l,b-t,x*2,y*2);if(p.style==Paint.Style.FILL)g.fill(shape);else g.draw(shape);}
 public void drawLine(float x,float y,float z,float w,Paint p){primitives++;paint(p);g.draw(new java.awt.geom.Line2D.Float(x,y,z,w));}
 public void drawText(String s,float x,float y,Paint p){primitives++;paint(p);g.setFont(new java.awt.Font("Microsoft YaHei UI",java.awt.Font.PLAIN,Math.max(1,(int)p.size)));float width=g.getFontMetrics().stringWidth(s);if(p.align==Paint.Align.CENTER)x-=width/2;else if(p.align==Paint.Align.RIGHT)x-=width;g.drawString(s,x,y);}
 public void save(String path)throws Exception{javax.imageio.ImageIO.write(image,"png",new java.io.File(path));}
}
'@
}
foreach ($entry in $stubs.GetEnumerator()) {
    $path = Join-Path $stubRoot $entry.Key
    New-Item -ItemType Directory -Force -Path (Split-Path $path) | Out-Null
    [IO.File]::WriteAllText($path, $entry.Value, [Text.UTF8Encoding]::new($false))
}
$sourceRoot = Join-Path $PSScriptRoot 'src/org/pianolink'
$harness = Join-Path $stubRoot 'org/pianolink/GuideUiHarness.java'
New-Item -ItemType Directory -Force -Path (Split-Path $harness),$classes | Out-Null
[IO.File]::WriteAllText($harness, @'
package org.pianolink;
import android.app.Activity;import android.os.SystemClock;import android.view.View;import android.view.MotionEvent;import android.widget.TextView;import android.graphics.Canvas;import java.lang.reflect.*;import java.util.*;
public final class GuideUiHarness {
 static int assertions;static void check(boolean v,String m){assertions++;if(!v)throw new AssertionError(m);}
 static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void click(Object o,String n)throws Exception{((View)field(o,n)).performClick();}
 static GuideEngine engine(SongGuideUi ui)throws Exception{return (GuideEngine)field(ui,"engine");}
 static void touch(SongGuideUi ui,long mask)throws Exception{Method m=SongGuideUi.class.getDeclaredMethod("touched",long.class);m.setAccessible(true);m.invoke(ui,mask);}
 static void animate(SongGuideUi ui)throws Exception{((Runnable)field(ui,"animate")).run();}
 static SongData one(){return new SongData(SongData.Format.ABSOLUTE36,Arrays.asList(new SongData.Event(0,1L<<12,1),new SongData.Event(1200,0,0)),false);}
 static class Host implements SongGuideUi.Host{SongGuideUi ui;int keys,releases;long mask;boolean audio;public void back(){}public void keys(long m){keys++;mask=m;}public void release(){releases++;if(ui!=null)ui.releaseKeys();}public void localAudio(boolean v){audio=v;if(ui!=null)ui.localAudio(v);}}
 static SongGuideUi fresh(Host host){SystemClock.now=1000;SongGuideUi ui=new SongGuideUi(new Activity(),host);host.ui=ui;ui.load(one(),"test");ui.active(true);return ui;}
 public static void main(String[] args)throws Exception {
  Host h=new Host();SongGuideUi ui=fresh(h);check(((View)field(ui,"startButton")).isEnabled(),"offline PHONE can start");click(ui,"startButton");SystemClock.now=4000;touch(ui,1L<<12);check(h.mask==(1L<<12)&&engine(ui).hitCount()==1,"manual phone touch scores and routes offline");
  ui.confirmed(0);ui.confirmed(1L<<14);check(engine(ui).wrongCount()==0,"device reports cannot judge PHONE");int releases=h.releases,keys=h.keys;ui.releaseKeys();check(h.releases==releases&&h.keys==keys,"host release cannot recurse or send keys");ui.active(false);check(engine(ui).state()==GuideEngine.State.PAUSED,"inactive pauses");ui.confirmed(1L<<13);check(engine(ui).hitCount()==1,"inactive callback cannot score");ui.close();check(((android.os.Handler)field(ui,"main")).pending==0,"close clears all callbacks");
  h=new Host();ui=fresh(h);click(ui,"sourceButton");check(!((View)field(ui,"startButton")).isEnabled(),"PHYSICAL blocked without ready36");keys=h.keys;touch(ui,1L<<12);check(h.keys==keys,"PHYSICAL cannot transmit phone keys");ui.connection(true,false,false);check(!((View)field(ui,"startButton")).isEnabled(),"legacy connection cannot start physical judge");ui.connection(true,false,true);check(!((View)field(ui,"startButton")).isEnabled(),"physical start waits for a fresh baseline");click(ui,"startButton");check(engine(ui).state()!=GuideEngine.State.RUNNING,"cannot start while baseline unknown");ui.confirmed(1L<<12);check(((View)field(ui,"startButton")).isEnabled(),"baseline receipt enables physical start");click(ui,"startButton");SystemClock.now=4000;ui.confirmed(1L<<12);check(engine(ui).hitCount()==0,"preheld device key never scores");ui.confirmed(0);ui.confirmed(1L<<12);check(engine(ui).hitCount()==1,"release/repress device edge scores");ui.confirmed(1L<<12);check(engine(ui).hitCount()==1&&engine(ui).wrongCount()==0,"poll/ACK duplicate has no second edge");
  ui.connection(false,false,false);check(engine(ui).state()==GuideEngine.State.PAUSED,"connection loss pauses");ui.confirmed(1L<<13);check(engine(ui).wrongCount()==0,"disconnected callbacks ignored");ui.connection(true,false,true);ui.confirmed(1L<<12);click(ui,"startButton");ui.confirmed(1L<<12);check(engine(ui).hitCount()==1,"reconnect baseline preserved");ui.close();
  h=new Host();ui=fresh(h);ui.connection(true,false,true);click(ui,"sourceButton");click(ui,"sourceButton");ui.confirmed(0);click(ui,"startButton");SystemClock.now=4000;touch(ui,1L<<12);check(engine(ui).hitCount()==0,"MERGED never scores inferred local source");ui.confirmed(1L<<12);check(engine(ui).hitCount()==1,"MERGED scores only actual OR stream");touch(ui,0);ui.confirmed(1L<<12);check(engine(ui).hitCount()==1&&engine(ui).wrongCount()==0,"local release cannot fake OR release");
  SystemClock.now=4400;long position=engine(ui).positionMs(SystemClock.now);click(ui,"speedButton");check(engine(ui).positionMs(SystemClock.now)==position,"speed change does not jump clock");SystemClock.now=10000;animate(ui);check(engine(ui).state()==GuideEngine.State.FINISHED,"timeline finishes");click(ui,"startButton");check(engine(ui).state()==GuideEngine.State.RUNNING&&engine(ui).positionMs(SystemClock.now)==-3000,"finished button restarts attempt");releases=h.releases;click(ui,"sourceButton");check(engine(ui).state()==GuideEngine.State.PAUSED,"source change pauses active attempt");check(h.releases>releases,"source change releases shared remote and local keys");ui.close();
  h=new Host();ui=fresh(h);click(ui,"audioButton");check(h.audio&&((TextView)field(ui,"audioButton")).getText().toString().contains("开"),"local phone audio toggle synchronizes through Host");click(ui,"sourceButton");ui.deviceStatus(2,2);check(((TextView)field(ui,"details")).getText().toString().contains("C3—F4"),"lowered physical range shown honestly");ui.connection(true,false,true);check(((TextView)field(ui,"connection")).getText().toString().contains("超声波"),"ultrasonic mode warning visible in status text");ui.load(new SongData(SongData.Format.ABSOLUTE36,Arrays.asList(new SongData.Event(0,0,0)),false),"empty");check(engine(ui)==null&&!((View)field(ui,"startButton")).isEnabled(),"empty score fails safely");check(((TextView)field(ui,"details")).getText().toString().contains("没有"),"invalid score reports reason");ui.close();
  final long all=(1L<<36)-1;ArrayList<SongData.Event> events=new ArrayList<SongData.Event>();for(int i=0;i<2777;i++){events.add(new SongData.Event(i*2,all,15));events.add(new SongData.Event(i*2+1,0,0));}events.add(new SongData.Event(5554,(1L<<28)-1,15));events.add(new SongData.Event(5555,0,0));GuideEngine dense=new GuideEngine(GuideSong.from(new SongData(SongData.Format.ABSOLUTE36,events,false)));check(dense.song.notes.size()==100000,"dense stress has 100000 notes");
  FallingNotesView roll=new FallingNotesView(new Activity(),m->{});roll.engine(dense);roll.setSize(840,176);roll.frame(2000);Method draw=FallingNotesView.class.getDeclaredMethod("onDraw",Canvas.class);draw.setAccessible(true);Canvas canvas=new Canvas();draw.invoke(roll,canvas);check(canvas.primitives<5000,"dense draw bounded independent of total score: "+canvas.primitives);check((Boolean)field(roll,"dense"),"dense aggregation visible");
  float top=(Float)field(roll,"keyboardTop");check(top>80&&176-top>=70,"840x320 screen leaves fall area and keyboard");roll.setSize(640,96);top=(Float)field(roll,"keyboardTop");check(top>50&&96-top>=40,"640x240 short landscape geometry remains finite");roll.playable(true,"");final long[] touched={0};FallingNotesView piano=new FallingNotesView(new Activity(),m->touched[0]=m);piano.setSize(840,176);piano.playable(true,"");piano.onTouchEvent(new MotionEvent(MotionEvent.ACTION_DOWN,300,170));check(touched[0]==1L<<12,"C4 white-key touch matches roll center");piano.onTouchEvent(new MotionEvent(MotionEvent.ACTION_UP,300,170));check(touched[0]==0,"finger-up releases key");
  check(PianoTouch.left(13,840)==(8-.32f)*40,"C sharp lane uses touch geometry");
  SongData visual=new SongData(SongData.Format.ABSOLUTE36,Arrays.asList(new SongData.Event(0,(1L<<12)|(1L<<13),3),new SongData.Event(600,(1L<<12)|(1L<<13)|(1L<<16)|(1L<<19),15),new SongData.Event(1200,(1L<<12)|(1L<<13)|(1L<<16)|(1L<<19)|(1L<<24),15),new SongData.Event(1800,0,0)),false);
  GuideEngine preview=new GuideEngine(GuideSong.from(visual));preview.start(1000);preview.input(1L<<12,4000);preview.tick(4400);roll.engine(preview);roll.frame(400);roll.setSize(840,176);roll.device(1L<<13);roll.playable(true,"");roll.onTouchEvent(new MotionEvent(MotionEvent.ACTION_DOWN,300,170));Canvas large=new Canvas(840,176);draw.invoke(roll,large);large.save(args[0]+"/task2-renderer-840x320.png");
  roll.setSize(640,96);Canvas small=new Canvas(640,96);draw.invoke(roll,small);small.save(args[0]+"/task2-renderer-640x240.png");
  System.out.println("Task2 UI harness passed: "+assertions+" assertions; 100000-note dense Canvas primitives="+canvas.primitives);
 }
}
'@,[Text.UTF8Encoding]::new($false))
$sources = @(Get-ChildItem -LiteralPath $stubRoot -Recurse -Filter '*.java' | ForEach-Object FullName)
$sources += @('SongGuideUi','FallingNotesView','GuideSong','GuideEngine','SongData','Recording','Protocol','PianoTouch') | ForEach-Object { Join-Path $sourceRoot "$_.java" }
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw "UI harness javac failed: $LASTEXITCODE" }
& "$Jdk/bin/java.exe" '-Djava.awt.headless=true' -cp $classes org.pianolink.GuideUiHarness $testRoot
if ($LASTEXITCODE -ne 0) { throw "UI harness failed: $LASTEXITCODE" }
