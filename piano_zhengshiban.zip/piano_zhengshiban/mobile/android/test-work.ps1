param([string]$Jdk='C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'build/work-test'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$sources=@((Join-Path $PSScriptRoot 'test/org/pianolink/LibraryWorkTest.java'))
$impl=Join-Path $PSScriptRoot 'src/org/pianolink/LibraryWork.java'
if(Test-Path -LiteralPath $impl){$sources+=$impl}
$pending=Join-Path $PSScriptRoot 'src/org/pianolink/PendingCsvExport.java'
if(Test-Path -LiteralPath $pending){$sources+=$pending}
& "$Jdk/bin/javac.exe" -encoding UTF-8 -d $out @sources
if($LASTEXITCODE -ne 0){throw 'Work test compile failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.LibraryWorkTest
if($LASTEXITCODE -ne 0){throw 'Work test failed'}
