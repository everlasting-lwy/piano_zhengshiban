param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference = 'Stop'
$testOut = Join-Path $PSScriptRoot 'build/guide-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$testSources = @('Protocol', 'Recording', 'SongData', 'GuideSong', 'GuideEngine') | ForEach-Object {
    Join-Path $PSScriptRoot "src/org/pianolink/$_.java"
}
$testSources += Join-Path $PSScriptRoot 'test/org/pianolink/GuideTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @testSources
if ($LASTEXITCODE -ne 0) { throw 'Guide tests did not compile' }
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.GuideTest
if ($LASTEXITCODE -ne 0) { throw 'Guide tests failed' }
