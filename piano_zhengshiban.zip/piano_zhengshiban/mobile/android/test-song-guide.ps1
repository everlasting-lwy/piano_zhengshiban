param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/song-guide-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$testSources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java' | ForEach-Object {$_.FullName})
$testSources+=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session','Recording','SongData','GuideSong','OledGuideSong','VisualFrames','VisualPoller','LinkController','LinkSession') | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$testSources+=Join-Path $PSScriptRoot 'test/org/pianolink/OledSongGuideTest.java'
$testSources+=Join-Path $PSScriptRoot 'test/org/pianolink/OledGuideTransportTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @testSources
if($LASTEXITCODE -ne 0){throw 'OLED song-guide tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.OledSongGuideTest
if($LASTEXITCODE -ne 0){throw 'OLED song-guide tests failed'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.OledGuideTransportTest
if($LASTEXITCODE -ne 0){throw 'OLED song-guide service transport tests failed'}
& (Join-Path $PSScriptRoot 'test-oled-idle-poll.ps1') -Jdk $Jdk
