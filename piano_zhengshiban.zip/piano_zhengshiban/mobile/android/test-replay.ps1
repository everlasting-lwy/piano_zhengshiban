param([string]$Jdk='C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'build/replay-test'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$names=@('Protocol','MockFpga','OledGuideProtocol','Recording','SongData','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session')
$sources=@($names | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"})
$timeline=Join-Path $PSScriptRoot 'src/org/pianolink/SongReplay.java'
if(Test-Path -LiteralPath $timeline){$sources+=$timeline}
& "$Jdk/bin/javac.exe" -encoding UTF-8 -d $out @sources (Join-Path $PSScriptRoot 'test/org/pianolink/ReplayTest.java')
if($LASTEXITCODE -ne 0){throw 'Replay javac failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.ReplayTest
if($LASTEXITCODE -ne 0){throw 'Replay test failed'}
