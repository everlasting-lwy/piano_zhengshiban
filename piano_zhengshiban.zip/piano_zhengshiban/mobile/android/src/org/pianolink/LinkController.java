package org.pianolink;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.io.*;
import java.util.UUID;
import java.util.concurrent.*;

/** Socket I/O, retries and packet serialization always run outside the Android UI thread. */
public final class LinkController {
    public interface Listener {
        void connected(boolean simulated);
        void frame(Protocol.Frame frame);
        void message(String text);
        void ended(String reason);
        default void visual(VisualFrames.Snapshot snapshot){}
        default void guide(Session.GuideState snapshot){}
        default void sd(SdLibraryFlow.State snapshot){}
    }
    private final Listener listener;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService fatWorker=Executors.newSingleThreadExecutor(r->new Thread(r,"PianoLink-FAT32"));
    private final Session session=new Session();
    private final Protocol.Decoder decoder=new Protocol.Decoder();
    private final VisualPoller visuals=new VisualPoller();private volatile long visualEpoch;
    private int selectedVisual;private boolean visualActive;
    private final boolean simulated;
    private final MockFpga.SdCard simulatedCard;
    private volatile BluetoothSocket socket;
    private volatile boolean closing,ready,transportOpen,extendedSupported;
    private OutputStream output;
    private MockFpga mock;
    private long lastStatus,lastEffectsStatus,origin,lastGuideStatus,guideRevision=-1,lastSdStatus,sdRevision=-1;

    public LinkController(boolean simulated,Listener listener){this(simulated,listener,new MockFpga.SdCard());}
    LinkController(boolean simulated,Listener listener,MockFpga.SdCard card){this.simulated=simulated;this.listener=listener;simulatedCard=card;}
    private void post(Runnable action){main.post(()->{if(!closing)action.run();});}
    public void connect(BluetoothDevice device){connect(device,false);}
    /** Explicit selection: compatible RFCOMM is not an automatic downgrade of secure mode. */
    public void connect(BluetoothDevice device,boolean secure){
        if(simulated){worker.execute(()->{if(closing)return;mock=new MockFpga(simulatedCard,2);begin();});return;}
        new Thread(()->{
            ScheduledFuture<?> deadline=null;
            try {
                UUID spp=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                BluetoothSocket candidate=secure?device.createRfcommSocketToServiceRecord(spp):device.createInsecureRfcommSocketToServiceRecord(spp);
                socket=candidate;if(closing){candidate.close();return;}
                post(()->listener.message((secure?"安全":"兼容")+" SPP 正在连接；如有配对提示请确认。请先断开其他串口调试器。"));
                deadline=worker.schedule(()->fail("SPP 连接超过 45 秒：检查配对提示、模块供电和其他 APP 占用。"),45,TimeUnit.SECONDS);
                candidate.connect();deadline.cancel(false);
                if(closing){candidate.close();return;}
                InputStream input=candidate.getInputStream();OutputStream out=candidate.getOutputStream();
                worker.execute(()->{if(!closing){output=out;begin();}});
                byte[] buffer=new byte[256];int count;
                while(!closing&&(count=input.read(buffer))!=-1){
                    for(int i=0;i<count;i++){Protocol.Frame frame=decoder.feed(buffer[i]);if(frame!=null){final Protocol.Frame delivered=frame;worker.execute(()->receive(delivered));}}
                }
                if(!closing)fail("蓝牙设备已断开");
            }catch(Exception e){if(!closing)fail((transportOpen?"SPP 数据连接中断：":"SPP 连接失败（"+(secure?"安全":"兼容")+"）：")+e.getMessage());}
            finally{if(deadline!=null)deadline.cancel(false);}
        },"PianoLink-Bluetooth").start();
    }
    private void begin(){
        transportOpen=true;origin=SystemClock.elapsedRealtime();session.release();session.control(6,0);
        post(()->listener.message(simulated?"模拟链路已建立，等待状态…":"SPP 已连通，等待 FPGA 应答；数据 UART 应为 9600 / 8N1。"));
        worker.scheduleAtFixedRate(this::tick,0,20,TimeUnit.MILLISECONDS);
    }
    private void tick(){
        if(closing||!transportOpen)return;
        try {
            long now=SystemClock.elapsedRealtime();
            if(now-lastStatus>=1000){session.control(6,0);if(extendedSupported)session.control(11,0);lastStatus=now;}
            if(ready&&visuals.supported()&&now-lastEffectsStatus>=1500){session.control(12,0);lastEffectsStatus=now;}
            if(ready){
                int kind;long epoch;
                // Capture selection and its generation atomically, then release this
                // lock before entering Session or performing any socket I/O.
                synchronized(this){epoch=visualEpoch;kind=visuals.next(now);}
                if(kind>=0)session.queueVisual(epoch,kind);
            }
            if(ready&&now-lastGuideStatus>=1000){Session.GuideState guide=session.guideState();if(guide.capability>0&&guide.busy==0)session.guideRefresh();lastGuideStatus=now;}
            if(ready&&now-lastSdStatus>=1000){session.sdRefresh();lastSdStatus=now;}
            Session.Send send=session.tick(now);if(send!=null)write(send.frame.bytes());
            if(mock!=null){mock.tick(now-origin);byte[] event;while((event=mock.pollEvent())!=null)receive(Protocol.decode(event));}
            Session.GuideState guide=session.guideState();if(guide.revision!=guideRevision){guideRevision=guide.revision;post(()->listener.guide(guide));}
            SdLibraryFlow.State sd=session.sdState();if(sd.revision!=sdRevision){sdRevision=sd.revision;post(()->listener.sd(sd));}
        }catch(Exception e){fail((ready?"FPGA 通信停止：":"SPP 已连通，但 FPGA 未完成应答：")+e.getMessage());}
    }
    private void write(byte[] packet)throws IOException{
        Protocol.Frame outgoing=Protocol.decode(packet);if(outgoing!=null&&outgoing.cmd==14)visuals.sent(outgoing.seq,outgoing.d[0],SystemClock.elapsedRealtime());
        if(mock!=null){byte[] response=mock.accept(packet,SystemClock.elapsedRealtime()-origin);if(response!=null)receive(Protocol.decode(response));}
        else if(output!=null){output.write(packet);output.flush();}
    }
    private void receive(Protocol.Frame frame){
        if(closing||frame==null)return;
        if((frame.cmd==0x83||frame.cmd==0x84)&&!frame.isExtendedState())return;
        if(frame.cmd==0x85&&!frame.isEffectsState())return;
        boolean matched=session.receive(frame);
        if(frame.cmd==0x83&&matched)extendedSupported=true;
        if(frame.cmd==0x81&&matched&&!ready){
            if(frame.d[0]>3||frame.d[1]>15||frame.d[2]>2){fail("SPP 已连通，但 FPGA 状态参数无效，请核对固件协议。");return;}
            ready=true;session.control(12,0);session.guideRefresh();session.sdRefresh();lastSdStatus=lastEffectsStatus=SystemClock.elapsedRealtime();post(()->listener.connected(simulated));
        }
        if(frame.cmd==0x85){if(!matched)return;visuals.supported(true);}
        if(frame.cmd==0x80&&matched&&frame.d[0]==12&&frame.d[1]!=0)visuals.supported(false);
        if(frame.cmd==0x80&&matched&&frame.d[0]==13&&frame.d[1]==0)session.control(12,0);
        if(frame.cmd==0x86||frame.cmd==0x87){VisualFrames.Snapshot snapshot=visuals.receive(frame,SystemClock.elapsedRealtime());if(snapshot!=null){final long epoch=visualEpoch;post(()->{if(epoch==visualEpoch)listener.visual(snapshot);});}}
        if(frame.cmd==0x80&&matched&&frame.d[1]!=0)post(()->listener.message("设备拒绝命令 "+frame.d[0]+"，错误码 "+frame.d[1]));
        if(frame.cmd>=0x80&&frame.cmd<=0x87)post(()->listener.frame(frame));
    }
    public void keys(int mask){if(!closing)session.setMask(mask);}
    public void resetLegacy(){if(!closing)session.resetLegacy();}
    public void extendedKeys(long mask){if(!closing)session.setExtendedMask(mask);}
    public boolean offerPlaybackMask(long mask,boolean absolute){return !closing&&ready&&session.offerPlaybackMask(mask,absolute);}
    public boolean playbackPending(){return !closing&&session.playbackPending();}
    public boolean guideDownload(int[] masks){return !closing&&ready&&session.guideDownload(masks);}
    public boolean guideAction(int action){return !closing&&ready&&session.guideAction(action);}
    public void guideCancel(){if(!closing&&ready)session.guideCancel();}
    public void guideRefresh(){if(!closing&&ready)session.guideRefresh();}
    public Session.GuideState guideState(){return session.guideState();}
    public boolean sdScan(){return !closing&&ready&&session.sdScan();}
    public boolean sdLoad(int slot){return !closing&&ready&&session.sdLoad(slot);}
    public boolean sdDelete(int slot){return !closing&&ready&&(session.sdState().version==2?phoneOperation(3,slot,null):session.sdDelete(slot));}
    public boolean sdSave(int slot,String title,int[] masks){return !closing&&ready&&(session.sdState().version==2?phoneOperation(1,slot,P18File.encode(title,masks)):session.sdSave(slot,title,masks));}
    private static String storageFailure(Exception error){if(error instanceof Fat32Store.StoreException){Fat32Store.Reason reason=((Fat32Store.StoreException)error).reason;String text;switch(reason){case PARAMETER:text="槽位或曲谱参数无效";break;case MEDIA:text="SD介质未就绪";break;case UNSUPPORTED:text="SD格式不支持，请使用FAT32";break;case GEOMETRY:text="FAT32卷参数或容量无效";break;case CHAIN:text="FAT簇链损坏、循环或交叉链接";break;case NOT_FOUND:text="所选槽位文件不存在";break;case INVALID_FILE:text="文件不是有效P18曲谱";break;case PROTECTED:text="目标只读、目录冲突或存在残留暂存文件";break;case FULL:text="SD可用空间不足";break;case SEARCH_LIMIT:text="空闲簇搜索范围不足";break;case DIRECTORY_FULL:text="根目录空间不足";break;case VERIFY:text="写后校验失败，结果未确认";break;case WRITE_LOCKED:text="上次写入未确认或卡未干净卸载，请在电脑检查";break;default:text="SD读写失败";}return text+"（"+reason+"）："+error.getMessage();}return error.getMessage()==null?error.getClass().getSimpleName():error.getMessage();}
    private boolean phoneOperation(int action,int slot,byte[] file){if(!session.sdPhoneBegin(action,slot,file))return false;try{fatWorker.execute(()->{String failure=null;SectorRpcClient rpc=new SectorRpcClient(session,(writing,lba,chunks)->session.sdPhoneProgress(writing,lba,chunks));boolean opened=false;try{rpc.open();opened=true;Fat32Store store=new Fat32Store(new Fat32Store.BlockDevice(){public long sectorCount(){return rpc.sectorCount();}public byte[] read(long lba)throws IOException{return rpc.read(lba);}public void write(long lba,byte[] sector)throws IOException{rpc.write(lba,sector);}});if(action==1)store.save(slot,file);else store.delete(slot);}catch(IOException|RuntimeException e){failure=storageFailure(e);}finally{if(opened)try{rpc.close();}catch(IOException e){failure=(failure==null?"":failure+"；")+"结束SD会话失败，结果未确认："+e.getMessage();}}if(!closing)session.sdPhoneFinished(failure);});return true;}catch(RejectedExecutionException e){session.sdPhoneFinished("FAT工作线程已停止");return false;}}
    public void sdRefresh(){if(!closing&&ready)session.sdRefresh();}
    public SdLibraryFlow.State sdState(){return session.sdState();}
    public void control(int cmd,int value){if(!closing)session.control(cmd,value);}
    public void effect(int id,int value){if(!closing&&ready&&visuals.supported())session.control(13,(id<<8)|value);}
    public synchronized void visual(int kind,boolean active){if(closing||selectedVisual==kind&&visualActive==active)return;selectedVisual=kind;visualActive=active;++visualEpoch;session.cancelVisual(visualEpoch);visuals.select(kind,active);if((!active||kind==0)&&ready&&visuals.supported())session.queueVisual(visualEpoch,0);}
    public void release(){if(!closing)session.release();}
    public boolean ready(){return ready&&!closing;}
    private void fail(String reason){if(closing)return;main.post(()->listener.ended(reason));close();}
    public void close(){
        if(closing)return;closing=true;ready=false;session.guideInterrupted();fatWorker.shutdownNow();
        // Release is serialized behind any in-progress write; socket close bounds teardown time.
        try{worker.execute(()->{try{session.release();Session.Send send=session.tick(SystemClock.elapsedRealtime());if(send!=null)write(send.frame.bytes());}catch(Exception ignored){}});}catch(RejectedExecutionException ignored){}
        new Thread(()->{
            try{Thread.sleep(180);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
            BluetoothSocket old=socket;if(old!=null)try{old.close();}catch(IOException ignored){}
            worker.shutdownNow();
        },"PianoLink-Close").start();
    }
}
