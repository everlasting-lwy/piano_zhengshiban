package org.pianolink;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

/** Each committed entry is an immutable CSV plus an independently atomic metadata file. */
public final class SongLibrary {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MAX_METADATA_BYTES = 16384;
    private static final int MAX_NAME_LENGTH = 120;
    private static final String ID_PATTERN = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
    private final File directory;

    public static final class Entry {
        public final String id, name;
        public final long durationMs;
        public final int eventCount;
        public final SongData.Format format;
        private Entry(String id, String name, SongData song) {
            this.id = id;
            this.name = name;
            durationMs = song.durationMs();
            eventCount = song.events.size();
            format = song.format;
        }
    }

    public SongLibrary(File directory) throws IOException {
        if (directory == null) throw new IllegalArgumentException("曲库目录为空");
        this.directory = directory.getCanonicalFile();
        if (!this.directory.isDirectory() && !this.directory.mkdirs())
            throw new IOException("无法创建曲库目录");
        recover();
    }

    public synchronized List<Entry> list() throws IOException {
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("无法读取曲库目录");
        ArrayList<Entry> result = new ArrayList<Entry>();
        for (File file : files) {
            String name = file.getName();
            if (!name.endsWith(".meta")) continue;
            String id = name.substring(0, name.length() - 5);
            if (!validId(id)) continue;
            try { result.add(readEntry(id)); }
            catch (IOException damagedEntry) { /* Isolate one damaged entry, retain other songs. */ }
        }
        Collections.sort(result, new Comparator<Entry>() {
            public int compare(Entry left, Entry right) {
                int names = left.name.compareToIgnoreCase(right.name);
                if (names == 0) names = left.name.compareTo(right.name);
                return names != 0 ? names : left.id.compareTo(right.id);
            }
        });
        return result;
    }

    public synchronized Entry add(String name, SongData song) throws IOException {
        if (song == null) throw new IllegalArgumentException("曲目为空");
        name = uniqueName(normalizeName(name), null);
        String id;
        do { id = UUID.randomUUID().toString(); }
        while (path(id, ".csv").exists() || path(id, ".meta").exists() || path(id, ".deleted").exists());
        byte[] csv = song.toCsv().getBytes(UTF8);
        File csvFile = path(id, ".csv");
        File csvTemporary = path(id, ".csv.tmp");
        boolean committed = false;
        try {
            writeSynced(csvTemporary, csv);
            move(csvTemporary, csvFile);
            commitMetadata(id, metadata(id, name, song, csv));
            committed = true;
            return new Entry(id, name, song);
        } finally {
            if (!committed) {
                csvTemporary.delete();
                path(id, ".meta.tmp").delete();
                if (!path(id, ".meta").exists()) csvFile.delete();
            }
        }
    }

    public synchronized SongData load(String id) throws IOException {
        checkId(id);
        readEntry(id);
        return readSong(path(id, ".csv"));
    }

    public synchronized Entry rename(String id, String name) throws IOException {
        checkId(id);
        Entry existing = readEntry(id);
        name = uniqueName(normalizeName(name), id);
        if (existing.name.equals(name)) return existing;
        byte[] csv = readBounded(path(id, ".csv"), SongData.MAX_CSV_BYTES);
        SongData song = parseSong(csv);
        commitMetadata(id, metadata(id, name, song, csv));
        return new Entry(id, name, song);
    }

    public synchronized void delete(String id) throws IOException {
        checkId(id);
        File metadata = path(id, ".meta");
        File deleted = path(id, ".deleted");
        if (!committedDeletion(id)) {
            if (!metadata.isFile()) throw new IOException("曲目不存在");
            if (deleted.exists() && !deleted.delete()) throw new IOException("无法清理损坏的删除标记");
            move(metadata, deleted);
        }
        // The tombstone is the commit: failed cleanup never makes the song visible again.
        cleanupDeleted(id);
    }

    private String uniqueName(String wanted, String excludedId) throws IOException {
        Set<String> names = new HashSet<String>();
        for (Entry entry : list()) if (!entry.id.equals(excludedId)) names.add(entry.name);
        if (!names.contains(wanted)) return wanted;
        for (int suffix = 2; ; suffix++) {
            String tail = " (" + suffix + ")";
            String base = wanted.substring(0, Math.min(wanted.length(), MAX_NAME_LENGTH - tail.length()));
            String candidate = base + tail;
            if (!names.contains(candidate)) return candidate;
        }
    }

    private static String normalizeName(String name) {
        if (name == null || name.trim().length() == 0) return "未命名曲目";
        name = name.trim();
        if (name.length() > MAX_NAME_LENGTH) throw new IllegalArgumentException("曲名不能超过120个字符");
        for (int i = 0; i < name.length(); i++)
            if (Character.isISOControl(name.charAt(i))) throw new IllegalArgumentException("曲名含有控制字符");
        return name;
    }

    private Entry readEntry(String id) throws IOException {
        if (committedDeletion(id)) throw new IOException("曲目已删除");
        return readEntry(id, path(id, ".meta"));
    }

    private Entry readEntry(String id, File metadata) throws IOException {
        Properties fields = new Properties();
        try {
            fields.load(new ByteArrayInputStream(readBounded(metadata, MAX_METADATA_BYTES)));
            String name = fields.getProperty("name");
            if (!"1".equals(fields.getProperty("version")) || !id.equals(fields.getProperty("id"))
                    || name == null || !name.equals(normalizeName(name))) throw new IllegalArgumentException();
            byte[] csv = readBounded(path(id, ".csv"), SongData.MAX_CSV_BYTES);
            if (!digest(csv).equals(fields.getProperty("sha256"))) throw new IllegalArgumentException();
            SongData song = parseSong(csv);
            if (!song.format.name().equals(fields.getProperty("format"))
                    || song.durationMs() != Long.parseLong(fields.getProperty("durationMs"))
                    || song.events.size() != Integer.parseInt(fields.getProperty("eventCount")))
                throw new IllegalArgumentException();
            return new Entry(id, name, song);
        } catch (IllegalArgumentException invalid) {
            throw new IOException("曲目元数据或CSV损坏", invalid);
        }
    }

    private SongData readSong(File file) throws IOException {
        return parseSong(readBounded(file, SongData.MAX_CSV_BYTES));
    }

    private static SongData parseSong(byte[] csv) throws IOException {
        try { return SongData.fromCsv(new String(csv, UTF8)); }
        catch (IllegalArgumentException invalid) { throw new IOException("曲目CSV损坏", invalid); }
    }

    private static byte[] metadata(String id, String name, SongData song, byte[] csv) throws IOException {
        Properties fields = new Properties();
        fields.setProperty("version", "1");
        fields.setProperty("id", id);
        fields.setProperty("name", name);
        fields.setProperty("format", song.format.name());
        fields.setProperty("durationMs", Long.toString(song.durationMs()));
        fields.setProperty("eventCount", Integer.toString(song.events.size()));
        fields.setProperty("sha256", digest(csv));
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        fields.store(output, "PianoLink song metadata");
        return output.toByteArray();
    }

    private void commitMetadata(String id, byte[] data) throws IOException {
        File destination = path(id, ".meta");
        File temporary = path(id, ".meta.tmp");
        File backup = path(id, ".meta.bak");
        writeSynced(temporary, data);
        boolean hadPrevious = destination.exists();
        if (hadPrevious) {
            if (backup.exists() && !backup.delete()) throw new IOException("无法清理旧曲目备份");
            move(destination, backup);
        }
        try { move(temporary, destination); }
        catch (IOException failure) {
            if (hadPrevious && !backup.renameTo(destination))
                failure.addSuppressed(new IOException("重启曲库后将恢复上次保存的元数据"));
            throw failure;
        }
        backup.delete();
    }

    private void recover() throws IOException {
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("无法读取曲库目录");
        for (File file : files) {
            String name = file.getName();
            if (name.endsWith(".deleted")) {
                String id = name.substring(0, name.length() - 8);
                if (validId(id) && committedDeletion(id)) {
                    try { cleanupDeleted(id); }
                    catch (IOException isolatedEntry) { /* Damaged paths cannot prevent other recovery. */ }
                }
            }
        }
        for (File file : files) {
            String name = file.getName();
            if (!name.endsWith(".meta.bak")) continue;
            String id = name.substring(0, name.length() - 9);
            if (!validId(id)) continue;
            try {
                if (committedDeletion(id)) continue;
                File metadata = path(id, ".meta");
                try { readEntry(id, metadata); path(id, ".meta.bak").delete(); }
                catch (IOException badFinal) {
                    readEntry(id, path(id, ".meta.bak"));
                    if (metadata.exists() && !metadata.delete()) continue;
                    move(path(id, ".meta.bak"), metadata);
                }
            } catch (IOException isolatedEntry) { /* Other committed songs remain available. */ }
        }
        // Uncommitted .tmp and orphan CSV files are ignored, never promoted to visible entries.
    }

    private void cleanupDeleted(String id) throws IOException {
        boolean removed = true;
        for (String suffix : new String[] { ".meta", ".meta.bak", ".meta.tmp", ".csv", ".csv.tmp" }) {
            File file = path(id, suffix);
            if (file.exists() && !file.delete()) removed = false;
        }
        if (removed) path(id, ".deleted").delete();
    }

    private boolean committedDeletion(String id) {
        try {
            Properties marker = new Properties();
            marker.load(new ByteArrayInputStream(readBounded(path(id, ".deleted"), MAX_METADATA_BYTES)));
            String name = marker.getProperty("name");
            String hash = marker.getProperty("sha256");
            SongData.Format format = SongData.Format.valueOf(marker.getProperty("format", ""));
            long duration = Long.parseLong(marker.getProperty("durationMs", "-1"));
            int count = Integer.parseInt(marker.getProperty("eventCount", "-1"));
            boolean valid = "1".equals(marker.getProperty("version")) && id.equals(marker.getProperty("id"))
                    && name != null && name.equals(normalizeName(name))
                    && hash != null && hash.matches("[0-9a-f]{64}")
                    && duration >= 0 && duration <= SongData.MAX_MS && count > 0 && count <= SongData.MAX_EVENTS;
            if (!valid) return false;
            // Delete commits by moving .meta to .deleted: a surviving .meta contradicts that commit.
            if (path(id, ".meta").exists()) return false;
            File csvFile = path(id, ".csv");
            if (csvFile.exists()) {
                byte[] csv = readBounded(csvFile, SongData.MAX_CSV_BYTES);
                if (!hash.equals(digest(csv))) return false;
                SongData song = parseSong(csv);
                if (song.format != format || song.durationMs() != duration || song.events.size() != count) return false;
            }
            // Once CSV removal completed, only marker/backup cleanup remains; no playback data survives.
            return true;
        } catch (IOException damagedMarker) { return false; }
        catch (IllegalArgumentException damagedMarker) { return false; }
    }

    private static void writeSynced(File file, byte[] data) throws IOException {
        FileOutputStream output = new FileOutputStream(file);
        try { output.write(data); output.getFD().sync(); }
        finally { output.close(); }
    }

    private static byte[] readBounded(File file, int maximum) throws IOException {
        if (!file.isFile() || file.length() > maximum) throw new IOException("曲目文件不存在或过大");
        ByteArrayOutputStream result = new ByteArrayOutputStream((int) Math.min(file.length(), 8192));
        FileInputStream input = new FileInputStream(file);
        try {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (result.size() > maximum - count) throw new IOException("曲目文件超过大小限制");
                result.write(buffer, 0, count);
            }
        } finally { input.close(); }
        return result.toByteArray();
    }

    private static void move(File from, File to) throws IOException {
        if (!from.renameTo(to)) throw new IOException("无法原子保存曲目文件");
    }

    private File path(String id, String suffix) throws IOException {
        checkId(id);
        File file = new File(directory, id + suffix);
        if (!file.getCanonicalPath().equals(file.getAbsolutePath())) throw new IOException("曲库文件路径无效");
        return file;
    }

    private static boolean validId(String id) { return id != null && id.matches(ID_PATTERN); }
    private static void checkId(String id) {
        if (!validId(id)) throw new IllegalArgumentException("曲目ID无效");
    }

    private static String digest(byte[] bytes) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder result = new StringBuilder(64);
            for (byte value : hash) result.append(Character.forDigit((value >>> 4) & 15, 16)).append(Character.forDigit(value & 15, 16));
            return result.toString();
        } catch (NoSuchAlgorithmException unavailable) { throw new AssertionError(unavailable); }
    }
}
