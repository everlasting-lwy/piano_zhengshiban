package org.pianolink;

import java.util.*;

/** Streaming note/onset decoder and 50 ms link adaptation, independent of Android/JNI. */
public final class PitchPostprocessor {
    public static final class Note {
        public final double startMs,endMs; public final int midi; public final float confidence;
        public Note(double startMs,double endMs,int midi,float confidence) {
            this.startMs=startMs;this.endMs=endMs;this.midi=midi;this.confidence=confidence;
        }
    }
    public static final class Result {
        public final SongData song; public final List<Note> notes;
        public final int detectedNotes,outOfRange,polyphonyReduced,tooFast;
        Result(SongData song,List<Note> notes,int outOfRange,int polyphonyReduced,int tooFast) {
            this.song=song;this.notes=Collections.unmodifiableList(new ArrayList<>(notes));detectedNotes=notes.size();
            this.outOfRange=outOfRange;this.polyphonyReduced=polyphonyReduced;this.tooFast=tooFast;
        }
    }
    private static final double FRAME_MS=256000.0/22050,MIN_NOTE_MS=40;
    private static final float FRAME_THRESHOLD=0.3f,ONSET_THRESHOLD=0.5f;
    private final int maxVoices;
    private final ArrayList<Note> decoded=new ArrayList<>();
    private final boolean[] active=new boolean[88];
    private final double[] starts=new double[88],lastAbove=new double[88],energy=new double[88],candidateStarts=new double[88];
    private final int[] counts=new int[88],lowFrames=new int[88],candidateFrames=new int[88];
    private float[] previousNote,previousOnset;
    private final float[] leftOnset=new float[88];
    private double previousTime=-1;
    private int shortNotes;
    private boolean finished;
    public PitchPostprocessor(boolean polyphonic) {maxVoices=polyphonic?4:1;}
    public void acceptFrame(double timeMs,float[] note,float[] onset) {
        if(finished)throw new IllegalStateException("postprocessor already finished");
        if(Double.isNaN(timeMs)||Double.isInfinite(timeMs)||timeMs<0||timeMs<=previousTime)throw new IllegalArgumentException("模型帧时间无效");
        validate(note);validate(onset);
        if(previousNote!=null)processPrevious(onset);
        previousNote=note.clone();previousOnset=onset.clone();previousTime=timeMs;
    }
    private static void validate(float[] values) {
        if(values.length!=88)throw new IllegalArgumentException("Basic Pitch 输出需要 88 个音高");
        for(float value:values)if(Float.isNaN(value)||Float.isInfinite(value)||value<0||value>1.01f)
            throw new IllegalArgumentException("模型输出含无效置信度");
    }
    private void processPrevious(float[] nextOnsets) {
        for(int p=0;p<88;p++) {
            float value=previousNote[p],onset=previousOnset[p];
            boolean peak=onset>=ONSET_THRESHOLD&&onset>leftOnset[p]&&onset>=nextOnsets[p];
            if(peak) {
                if(active[p])close(p,previousTime);
                begin(p,previousTime);
            }
            if(!active[p]) {
                if(value>=FRAME_THRESHOLD) {
                    if(candidateFrames[p]++==0)candidateStarts[p]=previousTime;
                    // Frame-only recovery keeps a missed onset without accepting a one-frame spike.
                    if(candidateFrames[p]>=3)begin(p,candidateStarts[p]);
                } else candidateFrames[p]=0;
            }
            if(active[p]) {
                if(value>=FRAME_THRESHOLD) {lastAbove[p]=previousTime;lowFrames[p]=0;}
                else lowFrames[p]++;
                energy[p]+=value;counts[p]++;
                if(lowFrames[p]>=4)close(p,lastAbove[p]+FRAME_MS);
            }
            leftOnset[p]=onset;
        }
    }
    private void begin(int pitch,double time) {
        active[pitch]=true;starts[pitch]=time;lastAbove[pitch]=time;
        energy[pitch]=0;counts[pitch]=0;lowFrames[pitch]=0;candidateFrames[pitch]=0;
    }
    private void close(int pitch,double time) {
        if(!active[pitch])return;
        double end=Math.min(time,lastAbove[pitch]+FRAME_MS);
        if(end-starts[pitch]>=MIN_NOTE_MS) {
            if(decoded.size()>=100000)throw new IllegalArgumentException("识别音符超过 100000 上限，请缩短音频");
            decoded.add(new Note(starts[pitch],end,pitch+21,counts[pitch]==0?0:(float)(energy[pitch]/counts[pitch])));
        } else shortNotes++;
        active[pitch]=false;candidateFrames[pitch]=0;
    }
    private static final class Quantized {
        final Note note;final int start;int end;boolean reduced;
        Quantized(Note note,int start,int end){this.note=note;this.start=start;this.end=end;}
    }
    public Result finish(double lengthMs) {
        if(finished)throw new IllegalStateException("postprocessor already finished");
        if(Double.isNaN(lengthMs)||Double.isInfinite(lengthMs)||lengthMs<0||lengthMs>600001)throw new IllegalArgumentException("音频长度无效");
        if(previousNote!=null)processPrevious(new float[88]);
        for(int p=0;p<88;p++)close(p,lengthMs);
        finished=true;
        Collections.sort(decoded,new Comparator<Note>() {
            public int compare(Note a,Note b){int time=Double.compare(a.startMs,b.startMs);return time!=0?time:Integer.compare(a.midi,b.midi);}
        });
        ArrayList<Quantized> usable=new ArrayList<>();Quantized[] previous=new Quantized[36];
        int outside=0,fast=shortNotes;
        for(Note note:decoded) {
            if(note.midi<48||note.midi>83){outside++;continue;}
            int start=(int)Math.round(note.startMs/50),end=(int)Math.round(note.endMs/50);
            if(end<=start){fast++;continue;}
            Quantized last=previous[note.midi-48];
            if(last!=null) {
                if(start-last.start<2){fast++;continue;}
                // A held key needs a full sendable release tick before another onset.
                if(last.end>=start)last.end=start-1;
            }
            Quantized next=new Quantized(note,start,end);usable.add(next);previous[note.midi-48]=next;
        }
        TreeMap<Integer,ArrayList<Quantized>> startsAt=new TreeMap<>(),endsAt=new TreeMap<>();
        for(Quantized note:usable) {
            addAt(startsAt,note.start,note);addAt(endsAt,note.end,note);
        }
        TreeSet<Integer> ticks=new TreeSet<>();ticks.addAll(startsAt.keySet());ticks.addAll(endsAt.keySet());
        ArrayList<Quantized> sounding=new ArrayList<>();ArrayList<SongData.Event> events=new ArrayList<>();
        long previousMask=0;
        for(int tick:ticks) {
            if(endsAt.containsKey(tick))sounding.removeAll(endsAt.get(tick));
            if(startsAt.containsKey(tick))sounding.addAll(startsAt.get(tick));
            Collections.sort(sounding,new Comparator<Quantized>() {
                public int compare(Quantized a,Quantized b){int strength=Float.compare(b.note.confidence,a.note.confidence);return strength!=0?strength:Integer.compare(a.note.midi,b.note.midi);}
            });
            long mask=0;int chosen=0;
            for(Quantized note:sounding) {
                if(chosen<maxVoices){mask|=1L<<(note.note.midi-48);chosen++;}
                else note.reduced=true;
            }
            if(mask!=previousMask) {
                if(events.isEmpty()&&tick>0)events.add(new SongData.Event(0,0,0));
                int voiceCount=Long.bitCount(mask);
                events.add(new SongData.Event(tick*50L,mask,(1<<voiceCount)-1));previousMask=mask;
            }
        }
        int reduced=0;for(Quantized note:usable)if(note.reduced)reduced++;
        SongData song=events.isEmpty()?null:new SongData(SongData.Format.ABSOLUTE36,events,false);
        return new Result(song,decoded,outside,reduced,fast);
    }
    private static void addAt(TreeMap<Integer,ArrayList<Quantized>> map,int tick,Quantized note) {
        ArrayList<Quantized> values=map.get(tick);
        if(values==null){values=new ArrayList<>();map.put(tick,values);}values.add(note);
    }
}
