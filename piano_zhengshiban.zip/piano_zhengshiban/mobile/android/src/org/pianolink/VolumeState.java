package org.pianolink;

/** User selection and asynchronous device reports are separate state. */
public final class VolumeState {
    private int selected,reported=-1;
    private boolean dragging,dirty,readySent;
    public VolumeState(int saved){selected=clamp(saved);}
    private static int clamp(int value){return Math.max(0,Math.min(15,value));}
    public int selected(){return selected;}
    public int reported(){return reported;}
    public void report(int value){if(value>=0&&value<=15)reported=value;}
    public void beginDrag(){dragging=true;dirty=false;}
    public int change(int value,boolean user){
        if(!user)return -1;
        value=clamp(value);if(value==selected)return -1;
        selected=value;if(dragging){dirty=true;return -1;}return selected;
    }
    public int endDrag(){boolean send=dragging&&dirty;dragging=false;dirty=false;return send?selected:-1;}
    public int ready(){if(readySent)return -1;readySent=true;return selected;}
    public void disconnected(){readySent=false;reported=-1;}
}
