package org.pianolink;

/** Timeline queues every due transition; ACK congestion stretches playback instead of dropping edges. */
public final class SongReplay {
    public interface Sink {boolean offer(long mask,boolean absolute);boolean pending();void release();}
    private final SongData song;private final Sink sink;private int next;
    private long start,delay,blockedAt=-1;private boolean active,delayed;
    public SongReplay(SongData song,Sink sink){if(song==null||sink==null)throw new IllegalArgumentException();this.song=song;this.sink=sink;}
    public void start(long now){sink.release();next=0;delay=0;blockedAt=-1;delayed=false;start=now;active=true;}
    public boolean tick(long now){
        if(!active)return false;
        long base=song.events.get(0).ms;
        while(next<song.events.size()&&song.events.get(next).ms-base<=Math.max(0,now-start-delay)){
            if(!sink.offer(song.events.get(next).mask,song.format==SongData.Format.ABSOLUTE36)){
                if(blockedAt<0)blockedAt=now;delayed=true;return true;
            }
            if(blockedAt>=0){delay+=Math.max(0,now-blockedAt);blockedAt=-1;}
            next++;
        }
        if(next==song.events.size()&&now-start-delay>=song.durationMs()-base+100&&!sink.pending())stop();
        return active;
    }
    public void stop(){if(active){active=false;sink.release();}}
    public boolean isActive(){return active;}
    public boolean isDelayed(){return delayed;}
    public int queuedEvents(){return next;}
    public long positionMs(long now){return Math.min(song.durationMs(),Math.max(0,now-start-delay));}
}
