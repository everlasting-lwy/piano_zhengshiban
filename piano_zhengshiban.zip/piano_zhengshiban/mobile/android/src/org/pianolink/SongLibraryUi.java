package org.pianolink;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Song/file UI is separate from connection ownership. Library and codec work stay off UI. */
public final class SongLibraryUi {
    public interface Host {
        void message(String text);void stopPlayback();boolean recordingActive();
        SongData recordingSnapshot();void selected(SongLibrary.Entry entry,SongData song);void playSelected();
    }
    private static final int IMPORT=101,EXPORT=102,AUDIO=103;
    private final Activity activity;private final Host host;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final LibraryWork selections=new LibraryWork(),conversions=new LibraryWork();
    private final SharedPreferences preferences;
    private final File libraryDirectory;private final PendingCsvExport pendingExport;
    private volatile SongLibrary library;private SongLibrary.Entry selected;
    private TextView label;private Button libraryButton;
    private volatile boolean destroyed;private boolean converting;
    private LibraryWork.Token conversionToken;private ProgressDialog progress;

    public SongLibraryUi(Activity activity,LinearLayout column,Host host){
        this.activity=activity;this.host=host;preferences=activity.getSharedPreferences("song_library",Context.MODE_PRIVATE);
        libraryDirectory=new File(activity.getFilesDir(),"songs");pendingExport=new PendingCsvExport(activity.getFilesDir());
        label=new TextView(activity);label.setTextColor(0xff9be6d8);label.setTextSize(14);label.setPadding(0,8,0,8);column.addView(label);
        LinearLayout buttons=row();libraryButton=button(buttons,"曲库",()->showLibrary());button(buttons,"保存录制",()->saveRecording());button(buttons,"音频转CSV",()->chooseAudio());column.addView(buttons);
        render();initialize();
    }
    private LinearLayout row(){LinearLayout view=new LinearLayout(activity);view.setOrientation(LinearLayout.HORIZONTAL);return view;}
    private Button button(LinearLayout row,String text,Runnable action){Button button=new Button(activity);button.setText(text);button.setTextSize(12);button.setAllCaps(false);button.setOnClickListener(v->action.run());row.addView(button,new LinearLayout.LayoutParams(0,dp(52),1));return button;}
    private int dp(int value){return (int)(value*activity.getResources().getDisplayMetrics().density+.5f);}
    private void render(){label.setText(selected==null?"当前曲目：未选择（录制后可保存到曲库）":"当前曲目："+selected.name+" · "+duration(selected.durationMs)+" · "+format(selected.format));}
    private static String duration(long ms){return String.format(Locale.ROOT,"%d:%02d",ms/60000,(ms/1000)%60);}
    private static String format(SongData.Format value){return value==SongData.Format.ABSOLUTE36?"36键C3～B5":"原12键";}
    private void initialize(){
        final String remembered=preferences.getString("selected_id","");
        final LibraryWork.Token token=selections.begin();
        worker.execute(()->{
            try{final SongLibrary loaded=requireLibrary();final List<SongLibrary.Entry> entries=loaded.list();SongLibrary.Entry choice=null;
                for(SongLibrary.Entry entry:entries)if(entry.id.equals(remembered)){choice=entry;break;}
                final SongLibrary.Entry restore=choice;final SongData data=choice==null?null:loaded.load(choice.id);
                main.post(()->{if(!destroyed){library=loaded;libraryButton.setText("曲库（"+entries.size()+"）");if(selections.owns(token)&&restore!=null)select(restore,data);}});
            }catch(Exception e){main.post(()->{if(!destroyed)host.message("曲库读取失败："+e.getMessage());});}
        });
    }
    private boolean available(){if(library!=null)return true;host.message("曲库正在载入；若读取失败，请重新打开APP。");return false;}
    private SongLibrary requireLibrary()throws IOException{if(library==null)library=new SongLibrary(libraryDirectory);return library;}
    private boolean canChange(){if(converting){host.message("音频正在转换，请先等待或取消。");return false;}if(host.recordingActive()){host.message("请先停止录制。");return false;}return true;}
    private interface Task<T>{T run(SongLibrary library)throws Exception;}
    private interface Done<T>{void run(T value);}
    private interface Written<T>{void run(T value,boolean currentSelection);}
    private <T>void write(Task<T> task,Written<T> done){
        final LibraryWork.Token token=selections.begin();
        worker.execute(()->{try{final T value=task.run(requireLibrary());main.post(()->{if(!destroyed&&selections.mayDeliverMutation())done.run(value,selections.owns(token));});}
            catch(Exception e){main.post(()->{if(!destroyed&&selections.mayDeliverMutation())host.message("曲库写入失败："+e.getMessage());});}});
    }
    private <T>void work(Task<T> task,Done<T> done){
        final LibraryWork.Token token=selections.begin();
        worker.execute(()->{try{final T value=task.run(requireLibrary());main.post(()->{if(!destroyed&&selections.owns(token))done.run(value);});}
            catch(Exception e){main.post(()->{if(!destroyed&&selections.owns(token))host.message("曲库操作失败："+e.getMessage());});}});
    }
    private void select(SongLibrary.Entry entry,SongData song){selected=entry;preferences.edit().putString("selected_id",entry.id).apply();render();host.selected(entry,song);}
    private void refreshCount(){final SongLibrary target=library;if(target==null)return;worker.execute(()->{try{final int count=target.list().size();main.post(()->{if(!destroyed)libraryButton.setText("曲库（"+count+"）");});}catch(IOException ignored){}});}
    public boolean isConverting(){return converting;}
    public String selectedName(){return selected==null?null:selected.name;}
    public void recordingStarted(){selections.cancel();selected=null;preferences.edit().remove("selected_id").apply();render();host.selected(null,null);}
    public void showLibrary(){if(!canChange())return;host.stopPlayback();work(lib->lib.list(),this::showList);}
    private void showList(List<SongLibrary.Entry> entries){
        if(entries.isEmpty()){host.message("曲库为空：可导入CSV、保存录制，或将MP3/WAV转换成曲目。");return;}
        LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);
        ListView list=new ListView(activity);list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);String[] labels=new String[entries.size()];final int[] index={0};
        for(int i=0;i<entries.size();i++){SongLibrary.Entry entry=entries.get(i);labels[i]=entry.name+"\n"+duration(entry.durationMs)+" · "+format(entry.format)+" · "+entry.eventCount+"状态";if(selected!=null&&entry.id.equals(selected.id))index[0]=i;}
        list.setAdapter(new ArrayAdapter<>(activity,android.R.layout.simple_list_item_single_choice,labels));list.setItemChecked(index[0],true);list.setOnItemClickListener((p,v,position,id)->index[0]=position);box.addView(list,new LinearLayout.LayoutParams(-1,dp(250)));
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("本地曲库 · "+entries.size()+"首").setView(box).setNegativeButton("关闭",null).create();
        LinearLayout actions=row();button(actions,"载入",()->{dialog.dismiss();load(entries.get(index[0]),false);});button(actions,"载入播放",()->{dialog.dismiss();load(entries.get(index[0]),true);});box.addView(actions);
        LinearLayout manage=row();button(manage,"重命名",()->{dialog.dismiss();rename(entries.get(index[0]));});button(manage,"删除",()->{dialog.dismiss();delete(entries.get(index[0]));});box.addView(manage);dialog.show();
    }
    private void load(SongLibrary.Entry entry,boolean play){host.stopPlayback();work(lib->lib.load(entry.id),song->{select(entry,song);host.message("已载入："+entry.name+" · "+format(song.format)+(song.incomplete?" · 原记录不完整":""));if(play)host.playSelected();});}
    private void rename(SongLibrary.Entry entry){EditText name=new EditText(activity);name.setSingleLine(true);name.setText(entry.name);new AlertDialog.Builder(activity).setTitle("重命名曲目").setView(name).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{final String value=name.getText().toString();write(lib->lib.rename(entry.id,value),(renamed,current)->{if(selected!=null&&selected.id.equals(renamed.id)){selected=renamed;render();}host.message("已重命名为："+renamed.name);});}).show();}
    private void delete(SongLibrary.Entry entry){new AlertDialog.Builder(activity).setTitle("删除曲库中的曲目？").setMessage(entry.name+"\n只删除APP内保存的副本，不修改原导入文件。").setNegativeButton("取消",null).setPositiveButton("删除",(d,w)->{
        host.stopPlayback();write(lib->{lib.delete(entry.id);return lib.list().size();},(count,current)->{if(selected!=null&&selected.id.equals(entry.id)){selected=null;preferences.edit().remove("selected_id").apply();render();host.selected(null,null);}libraryButton.setText("曲库（"+count+"）");host.message("曲库副本已删除。");});}).show();}
    private void saveRecording(){if(!canChange()||!available())return;final SongData snapshot;try{snapshot=host.recordingSnapshot();}catch(Exception e){host.message("没有可保存的录制："+e.getMessage());return;}EditText name=new EditText(activity);name.setSingleLine(true);name.setText("录制 "+new java.text.SimpleDateFormat("MMdd-HHmmss",Locale.ROOT).format(new Date()));new AlertDialog.Builder(activity).setTitle("保存录制到曲库").setView(name).setNegativeButton("取消",null).setPositiveButton("保存",(d,w)->{final String value=name.getText().toString();write(lib->lib.add(value,snapshot),(entry,current)->{if(current)select(entry,snapshot);host.message("录制已保存，重新打开APP仍可选择。");refreshCount();});}).show();}
    public void importCsv(){if(!canChange()||!available())return;host.stopPlayback();Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true).putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/plain","text/comma-separated-values","application/octet-stream","application/vnd.ms-excel"});activity.startActivityForResult(intent,IMPORT);}
    public void exportCsv(){if(!canChange())return;try{final SongData snapshot=selected==null?host.recordingSnapshot():null;final String id=selected==null?null:selected.id;work(lib->{pendingExport.save((snapshot==null?lib.load(id):snapshot).toCsv());return true;},ignored->openExport());}catch(Exception e){host.message("请先选择曲目或录制："+e.getMessage());}}
    private void openExport(){String title=selected==null?"PianoLink-recording.csv":selected.name.replaceAll("[\\\\/:*?\"<>|]","_")+".csv";activity.startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,title),EXPORT);}
    private static String readCsv(Context context,Uri uri)throws IOException{try(InputStream input=context.getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(input==null)throw new IOException("文件不可读");byte[] block=new byte[8192];int n;while((n=input.read(block))!=-1){if(out.size()+n>SongData.MAX_CSV_BYTES)throw new IOException("CSV超过8MB");out.write(block,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
    private static String displayName(Context context,Uri uri){try(Cursor cursor=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(cursor!=null&&cursor.moveToFirst()){String name=cursor.getString(0);if(name!=null&&!name.trim().isEmpty())return name.replaceFirst("(?i)\\.csv$","");}}catch(Exception ignored){}return "导入曲目";}
    public boolean onActivityResult(int request,int result,Intent data){
        if(request!=IMPORT&&request!=EXPORT&&request!=AUDIO)return false;
        if(result!=Activity.RESULT_OK||data==null)return true;
        if(request==AUDIO){if(data.getData()!=null)audioOptions(data.getData());return true;}
        if(request==EXPORT){final Uri uri=data.getData();if(uri==null)return true;final Context app=activity.getApplicationContext();worker.execute(()->{try{String csv=pendingExport.load();try(OutputStream out=app.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("文件不可写");out.write(csv.getBytes(StandardCharsets.UTF_8));}pendingExport.clear();main.post(()->{if(!destroyed)host.message("CSV已导出。");});}catch(Exception e){main.post(()->{if(!destroyed)host.message("导出失败："+e.getMessage());});}});return true;}
        ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){ClipData clips=data.getClipData();if(clips.getItemCount()>100){host.message("每次最多导入100个CSV，请分批选择。");return true;}for(int i=0;i<clips.getItemCount();i++)uris.add(clips.getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());
        final Context app=activity.getApplicationContext();write(lib->{ImportResult imported=new ImportResult();for(Uri uri:uris){try{SongData song=SongData.fromCsv(readCsv(app,uri));SongLibrary.Entry entry=lib.add(displayName(app,uri),song);imported.entry=entry;imported.song=song;imported.count++;}catch(Exception e){imported.failures.add(e.getMessage());}}imported.total=lib.list().size();return imported;},(imported,current)->{if(current&&imported.entry!=null)select(imported.entry,imported.song);libraryButton.setText("曲库（"+imported.total+"）");host.message("已保存"+imported.count+"首到曲库"+(imported.failures.isEmpty()?"，连接保留，可选择播放。":"；失败"+imported.failures.size()+"份："+imported.failures.get(0)));});return true;
    }
    private static final class ImportResult {SongLibrary.Entry entry;SongData song;int count,total;final ArrayList<String> failures=new ArrayList<>();}
    private void chooseAudio(){if(!canChange()||!available())return;host.stopPlayback();activity.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*"),AUDIO);}
    private void audioOptions(Uri uri){if(destroyed||!canChange())return;LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),0,dp(12),0);EditText name=new EditText(activity);name.setSingleLine(true);name.setText("音频转谱 "+new java.text.SimpleDateFormat("MMdd-HHmmss",Locale.ROOT).format(new Date()));box.addView(name);
        RadioGroup mode=new RadioGroup(activity);RadioButton mono=new RadioButton(activity);mono.setId(2001);mono.setText("单旋律（最多1音）");RadioButton poly=new RadioButton(activity);poly.setId(2002);poly.setText("纯钢琴和弦（最多4音）");mode.addView(mono);mode.addView(poly);mode.check(2002);box.addView(mode);TextView hint=new TextView(activity);hint.setText("手机离线识别MP3/PCM WAV，生成36键C3～B5曲目。超音域省略并统计；先用短录音试听。上限100MB/10分钟。转换时保持此页面，离开会取消，蓝牙仍保留。");box.addView(hint);
        new AlertDialog.Builder(activity).setTitle("音频转CSV").setView(box).setNegativeButton("取消",null).setPositiveButton("开始转换",(d,w)->startConversion(uri,name.getText().toString(),mode.getCheckedRadioButtonId()==2002)).show();}
    private void startConversion(Uri uri,String name,boolean polyphonic){if(!canChange()||!available())return;host.stopPlayback();selections.cancel();conversionToken=conversions.begin();converting=true;progress=new ProgressDialog(activity);progress.setTitle("手机离线转谱");progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);progress.setMax(100);progress.setMessage("准备解码…");progress.setCancelable(false);progress.setButton(DialogInterface.BUTTON_NEGATIVE,"取消",(d,w)->cancelConversion());progress.show();if(progress.getWindow()!=null)progress.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        worker.execute(new AudioTask(activity.getApplicationContext(),new WeakReference<>(this),library,uri,name,polyphonic,conversionToken));}
    private void cancelConversion(){if(!converting||conversionToken==null)return;boolean canceled=conversionToken.cancel();if(canceled){converting=false;dismissProgress();host.message("转换已取消，未保存半首曲目；蓝牙连接保留。");}else host.message("结果正在完整保存，请稍候。");}
    private void dismissProgress(){if(progress!=null){progress.dismiss();progress=null;}}
    private static final class AudioTask implements Runnable {
        final Context app;final WeakReference<SongLibraryUi> owner;final SongLibrary library;final Uri uri;final String name;final boolean poly;final LibraryWork.Token token;
        AudioTask(Context app,WeakReference<SongLibraryUi> owner,SongLibrary library,Uri uri,String name,boolean poly,LibraryWork.Token token){this.app=app;this.owner=owner;this.library=library;this.uri=uri;this.name=name;this.poly=poly;this.token=token;}
        public void run(){try{
            AudioTranscriber.Result result=AudioTranscriber.convert(app,uri,poly,new AudioTranscriber.Callbacks(){public boolean cancelled(){return token.cancelled()||Thread.currentThread().isInterrupted();}public void progress(String stage,int percent){new Handler(Looper.getMainLooper()).post(()->{SongLibraryUi ui=owner.get();if(ui!=null&&!ui.destroyed&&ui.conversions.owns(token)&&ui.progress!=null){ui.progress.setMessage(stage);ui.progress.setProgress(percent);}});}});
            if(!token.claimCommit())return;final SongLibrary.Entry entry=library.add(name,result.song);token.finish();new Handler(Looper.getMainLooper()).post(()->{SongLibraryUi ui=owner.get();if(ui!=null&&!ui.destroyed&&ui.conversions.owns(token)){ui.converting=false;ui.dismissProgress();ui.select(entry,result.song);ui.host.message(result.summary+"；已保存到曲库，可试听/导出。");ui.refreshCount();}});
        }catch(Exception e){new Handler(Looper.getMainLooper()).post(()->{SongLibraryUi ui=owner.get();if(ui!=null&&!ui.destroyed&&ui.conversions.owns(token)){ui.converting=false;ui.dismissProgress();ui.host.message("音频转换失败："+e.getMessage());}});}}
    }
    public void onStop(){if(converting)cancelConversion();}
    public void close(){destroyed=true;conversions.close();selections.close();dismissProgress();worker.shutdownNow();}
}
