package org.pianolink;
import java.util.*;
public final class Protocol {
    public static final long EXTENDED_MASK=0xfffffffffL;
    public static int crc(byte[] b,int start,int count){
        int value=0; for(int i=start;i<start+count;i++){value^=b[i]&255;for(int bit=0;bit<8;bit++)value=((value<<1)^((value&128)!=0?7:0))&255;}return value;
    }
    public static byte[] encode(int seq,int cmd,int... d){
        if(d.length!=6)throw new IllegalArgumentException("six data bytes required");
        byte[] b=new byte[12];b[0]=(byte)0xa5;b[1]=0x5a;b[2]=(byte)seq;b[3]=(byte)cmd;
        for(int i=0;i<6;i++)b[i+4]=(byte)d[i];b[10]=(byte)crc(b,2,8);b[11]=13;return b;
    }
    public static Frame decode(byte[] b){
        if(b==null||b.length!=12||(b[0]&255)!=0xa5||b[1]!=0x5a||b[11]!=13||(b[10]&255)!=crc(b,2,8))return null;
        int[] d=new int[6];for(int i=0;i<6;i++)d[i]=b[4+i]&255;return new Frame(b[2]&255,b[3]&255,d);
    }
    public static final class Frame {
        public final int seq,cmd; public final int[] d;
        public Frame(int seq,int cmd,int[] d){if(d.length!=6)throw new IllegalArgumentException();this.seq=seq&255;this.cmd=cmd&255;this.d=d.clone();}
        public int mask(){return cmd==0x82?(d[4]|((d[5]&15)<<8)):(d[0]|((d[1]&15)<<8));}
        public int voices(){return (d[5]>>>4)&15;}
        /** Absolute C3..B5 state in the version2 status83/event84 payload. */
        public long extendedMask(){return (long)d[0]|((long)d[1]<<8)|((long)d[2]<<16)|((long)d[3]<<24)|((long)(d[4]&15)<<32);}
        public int extendedVoices(){return (d[4]>>>4)&15;}
        public boolean isExtendedState(){return (cmd==0x83||cmd==0x84)&&(d[5]&0x7c)==0x20;}
        public boolean isEffectsState(){return cmd==0x85&&d[5]==0x31&&(d[3]&0xe0)==0x80&&(d[3]&31)<=16&&((d[2]>>>4)&3)<=2&&(d[2]>>>6)<=2&&(d[4]>>>5)<=4&&(d[4]&31)<=17;}
        public byte[] bytes(){return encode(seq,cmd,d);}
    }
    public static final class Decoder {
        private final byte[] window=new byte[12];private int count;private long last;
        public Frame feed(byte b){return feed(b,System.nanoTime()/1000000L);}
        public Frame feed(byte b,long now){
            if(count>0&&now-last>300)count=0;last=now;
            if(count==12){System.arraycopy(window,1,window,0,11);count=11;}
            window[count++]=b;
            if(count<12)return null;Frame frame=decode(window);if(frame!=null)count=0;return frame;
        }
    }
}
