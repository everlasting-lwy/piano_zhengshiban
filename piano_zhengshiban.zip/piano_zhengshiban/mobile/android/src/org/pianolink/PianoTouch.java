package org.pianolink;
import java.util.HashMap;

/** Absolute chromatic C3..B5 touch geometry, independent of Android. */
public final class PianoTouch {
    private final HashMap<Integer,Integer> fingers=new HashMap<>();
    private static final int[] WHITE={0,2,4,5,7,9,11};
    private static final int[] BOUNDARY={0,1,0,2,0,0,4,0,5,0,6,0};
    public int keyAt(float x,float y,float width,float height){
        if(width<=0||height<=0||x<0||y<0||x>=width||y>=height)return -1;
        if(y<height*.62f)for(int key=0;key<36;key++)if(black(key)&&x>=left(key,width)&&x<right(key,width))return key;
        int white=(int)(x/(width/21f));return white/7*12+WHITE[white%7];
    }
    public void down(int id,int key){fingers.put(id,key>=0&&key<36?key:-1);}
    public void move(int id,int key){if(fingers.containsKey(id))down(id,key);}
    public void up(int id){fingers.remove(id);}
    public void cancel(){fingers.clear();}
    public long mask(){long result=0;for(int key:fingers.values())if(key>=0)result|=1L<<key;return result;}
    public static boolean black(int key){int note=key%12;return note==1||note==3||note==6||note==8||note==10;}
    private static int whiteIndex(int key){int note=key%12;for(int i=0;i<7;i++)if(WHITE[i]==note)return key/12*7+i;return key/12*7+BOUNDARY[note];}
    public static float left(int key,float width){float unit=width/21f;return (whiteIndex(key)-(black(key)?.32f:0))*unit;}
    public static float right(int key,float width){float unit=width/21f;return (whiteIndex(key)+(black(key)?.32f:1))*unit;}
}
