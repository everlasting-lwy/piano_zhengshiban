package org.pianolink;

/** A UI job may be canceled until its atomic save starts; stale pages never receive its result. */
public final class LibraryWork {
    public static final class Token {
        private boolean canceled,committing,finished;
        public synchronized boolean cancelled(){return canceled;}
        public synchronized boolean cancel(){if(committing||finished)return false;canceled=true;return true;}
        public synchronized boolean claimCommit(){if(canceled||committing||finished)return false;committing=true;return true;}
        public synchronized void finish(){finished=true;}
    }
    private Token current;private boolean closed;
    public synchronized Token begin(){if(closed)throw new IllegalStateException("页面已关闭");if(current!=null)current.cancel();current=new Token();return current;}
    public synchronized boolean owns(Token token){return !closed&&current==token&&!token.cancelled();}
    /** A committed mutation must reconcile even if a later read now owns selection. */
    public synchronized boolean mayDeliverMutation(){return !closed;}
    public synchronized void cancel(){if(current!=null)current.cancel();}
    public synchronized void close(){closed=true;cancel();}
}
