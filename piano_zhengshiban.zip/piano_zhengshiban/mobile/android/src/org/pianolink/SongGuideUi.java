package org.pianolink;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.Locale;

/** Fixed-time practice UI. Device OR reports are never split into invented sources. */
public final class SongGuideUi {
    public interface Host { void back(); void keys(long mask); void release(); void localAudio(boolean enabled); }
    private enum Source { PHONE, PHYSICAL, MERGED }
    private static final long MASK36 = (1L << 36) - 1;
    private static final double[] SPEEDS = {.5, .75, 1, 1.25, 1.5};
    private final Activity activity;
    private final Host host;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinearLayout root;
    private final TextView title, connection, details, counts, timing;
    private final TextView startButton, restartButton, sourceButton, speedButton, audioButton;
    private final ProgressBar progress;
    private final FallingNotesView roll;
    private GuideEngine engine;
    private Source source = Source.PHONE;
    private int speedIndex = 2, octave = -1, deviceMode = -1;
    private long localMask, deviceMask, lastTextAt;
    private boolean active, closed, ready, simulated, extendedSupported, audioEnabled, suppressTouch;
    private boolean deviceBaselinePending = true;
    private String loadError = "", songFacts = "";
    private final Runnable animate = new Runnable() {
        @Override public void run() {
            if (!active || closed) return;
            long now = SystemClock.elapsedRealtime();
            if (engine != null) { engine.tick(now); roll.frame(engine.positionMs(now)); }
            if (now - lastTextAt >= 100 || (engine != null && engine.state() == GuideEngine.State.FINISHED)) {
                lastTextAt = now; updateProgress(now);
            }
            if (engine != null && engine.state() == GuideEngine.State.RUNNING) main.postDelayed(this, 33);
        }
    };

    public SongGuideUi(Activity activity, Host host) {
        this.activity = activity; this.host = host;
        root = new LinearLayout(activity); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xff0b1321);
        root.setPadding(dp(8), dp(3), dp(8), dp(3));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft() + dp(8), insets.getSystemWindowInsetTop() + dp(3), insets.getSystemWindowInsetRight() + dp(8), insets.getSystemWindowInsetBottom() + dp(3));
            return insets;
        });
        LinearLayout top = row();
        TextView back = button("‹ 返回", v -> { pauseForInterruption(); host.back(); }); add(top, back, 57);
        title = text("乐曲引导", 15, 0xffe8f0ff); title.setTypeface(Typeface.DEFAULT_BOLD); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        audioButton = button("手机音效 关", v -> host.localAudio(!audioEnabled)); add(top, audioButton, 98);
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(33)));

        LinearLayout controls = row();
        startButton = button("开始", v -> toggle()); add(controls, startButton, 64);
        restartButton = button("重来", v -> restart()); add(controls, restartButton, 55);
        sourceButton = button("手机 ▾", v -> changeSource()); add(controls, sourceButton, 82);
        sourceButton.setContentDescription("切换跟弹输入：手机、实体、设备合并。切换会暂停并释放手机键。");
        speedButton = button("1.00× ▾", v -> changeSpeed()); add(controls, speedButton, 75);
        speedButton.setContentDescription("切换速度，0.5、0.75、1、1.25、1.5 倍。时间位置保持连续。");
        timing = text("00:00 / 00:00", 12, 0xffb9cbe3); timing.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        controls.addView(timing, new LinearLayout.LayoutParams(0, -1, 1));
        root.addView(controls, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout status = row();
        connection = text("未连接 · 手机可本地练习", 11, 0xffb9cbe3); connection.setSingleLine(true); connection.setEllipsize(TextUtils.TruncateAt.END);
        status.addView(connection, new LinearLayout.LayoutParams(0, dp(20), 1));
        counts = text("命中 0  漏弹 0  错音 0", 11, 0xffdfe9f8); counts.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        status.addView(counts, new LinearLayout.LayoutParams(-2, dp(20))); root.addView(status);
        details = text("", 10, 0xff91a8c5); details.setMaxLines(2); details.setEllipsize(TextUtils.TruncateAt.END); root.addView(details, new LinearLayout.LayoutParams(-1, dp(30)));
        progress = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal); progress.setMax(1000); root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        roll = new FallingNotesView(activity, mask -> touched(mask)); root.addView(roll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView legend = text("蓝 目标 · 绿 命中 · 红 漏弹　|　青 手机触摸 · 金框 设备OR　|　长条提示时长", 10, 0xffa7bad3);
        legend.setSingleLine(true); legend.setEllipsize(TextUtils.TruncateAt.END); root.addView(legend, new LinearLayout.LayoutParams(-1, dp(18)));
        audioButton.setContentDescription("仅手机触摸的本地演示音；不含 FPGA 音效。与面板本地音效开关同步。");
        load(null, "自编短练习曲");
    }

    public View view() { return root; }
    private int dp(float value) { return (int)(value * activity.getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout row() { LinearLayout value = new LinearLayout(activity); value.setOrientation(LinearLayout.HORIZONTAL); value.setGravity(Gravity.CENTER_VERTICAL); return value; }
    private TextView text(String value, int size, int color) {
        TextView text = new TextView(activity); text.setText(value); text.setTextSize(size); text.setTextColor(color); text.setGravity(Gravity.CENTER_VERTICAL); text.setIncludeFontPadding(false); return text;
    }
    private TextView button(String label, View.OnClickListener click) {
        TextView value = text(label, 12, 0xffdceaff); value.setGravity(Gravity.CENTER); value.setPadding(dp(4), 0, dp(4), 0);
        GradientDrawable background = new GradientDrawable(); background.setColor(0xff1c2d45); background.setCornerRadius(dp(5)); value.setBackground(background); value.setOnClickListener(click); value.setFocusable(true); return value;
    }
    private void add(LinearLayout row, View view, int width) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(width), dp(29)); params.rightMargin = dp(5); row.addView(view, params);
    }

    public void load(SongData data, String name) {
        if (closed) return;
        pauseAndRelease(); main.removeCallbacks(animate); deviceMask = 0; deviceBaselinePending = true;
        title.setText("乐曲引导 · " + (name == null || name.trim().length() == 0 ? "未命名曲目" : name));
        engine = null; loadError = ""; songFacts = "";
        try {
            GuideSong song = data == null ? GuideSong.demo() : GuideSong.from(data);
            engine = new GuideEngine(song); engine.setSpeed(SPEEDS[speedIndex], SystemClock.elapsedRealtime());
            StringBuilder facts = new StringBuilder();
            if (data == null) facts.append("自编示例 · ");
            if (data != null && data.format == SongData.Format.LEGACY12) facts.append("v1 无原始八度→C4 · ");
            if (song.incomplete) facts.append("源谱不完整 · ");
            if (song.tailPatched) facts.append("补尾500ms · ");
            if (song.outOfPhysicalRange > 0) facts.append("原位18键外 ").append(song.outOfPhysicalRange).append(" 音 · ");
            if (song.peakPolyphony > 4) facts.append("峰值 ").append(song.peakPolyphony).append(" 音>四声部 · ");
            facts.append(song.notes.size()).append(" 音符"); songFacts = facts.toString();
        } catch (IllegalArgumentException invalid) {
            loadError = "无法引导：" + (invalid.getMessage() == null ? "曲谱无效" : invalid.getMessage());
        }
        roll.engine(engine); roll.device(0); rebase(); updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }

    public void active(boolean value) {
        if (closed || active == value) return;
        active = value; main.removeCallbacks(animate); deviceMask = 0; deviceBaselinePending = true; roll.device(0);
        if (!value) pauseAndRelease(); else rebase();
        updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    public void connection(boolean isReady, boolean mock, boolean keys36) {
        if (closed) return;
        boolean lost = ready && (!isReady || (extendedSupported && !keys36));
        boolean changed = ready != isReady || simulated != mock || extendedSupported != keys36;
        ready = isReady; simulated = mock; extendedSupported = keys36;
        if (changed) { deviceMask = 0; deviceBaselinePending = true; roll.device(0); }
        if (lost) pauseAndRelease();
        rebase(); updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    public void confirmed(long mask) {
        if (closed || !active || !ready || !extendedSupported) return;
        deviceMask = mask & MASK36; roll.device(deviceMask);
        if (source == Source.PHONE || engine == null) return;
        if (deviceBaselinePending) { deviceBaselinePending = false; engine.rebaseInput(deviceMask); updateControls(); }
        else engine.input(deviceMask, SystemClock.elapsedRealtime());
        updateProgress(SystemClock.elapsedRealtime());
    }
    public void deviceStatus(int value, int mode) {
        if (closed) return; octave = value; deviceMode = mode; updateControls();
    }
    /** Called by the host's shared release path. Never call the host back from here. */
    public void releaseKeys() {
        suppressTouch = true;
        try { roll.release(); } finally { suppressTouch = false; }
        localMask = 0;
        rebase();
    }
    public void pauseForInterruption() {
        if (closed) return; pauseAndRelease(); updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    public void localAudio(boolean enabled) {
        audioEnabled = enabled; audioButton.setText(enabled ? "手机音效 开" : "手机音效 关");
    }
    public void close() {
        if (closed) return;
        active = false; pauseAndRelease(); closed = true; main.removeCallbacksAndMessages(null); roll.engine(null);
    }

    private void touched(long mask) {
        if (suppressTouch || closed || !active || source == Source.PHYSICAL) return;
        localMask = mask & MASK36;
        host.keys(localMask); // Manual touch is the sole path to Host.keys.
        if (engine != null && source == Source.PHONE) engine.input(localMask, SystemClock.elapsedRealtime());
        updateProgress(SystemClock.elapsedRealtime());
    }
    private long selectedMask() { return source == Source.PHONE ? localMask : deviceMask; }
    private void rebase() { if (engine != null) engine.rebaseInput(selectedMask()); }
    private void pauseAndRelease() {
        main.removeCallbacks(animate);
        if (engine != null) engine.pause(SystemClock.elapsedRealtime());
        releaseKeys(); host.release();
    }
    private boolean canStart() { return active && engine != null && (source == Source.PHONE || ready && extendedSupported && !deviceBaselinePending); }
    private void toggle() {
        if (!canStart()) return;
        long now = SystemClock.elapsedRealtime();
        if (engine.state() == GuideEngine.State.RUNNING) pauseAndRelease();
        else {
            rebase();
            if (engine.state() == GuideEngine.State.PAUSED) engine.resume(now);
            else if (engine.state() == GuideEngine.State.FINISHED) engine.restart(now);
            else engine.start(now);
            main.removeCallbacks(animate); main.post(animate);
        }
        updateControls(); updateProgress(now);
    }
    private void restart() {
        if (!canStart()) return;
        pauseAndRelease(); rebase(); engine.restart(SystemClock.elapsedRealtime()); main.post(animate); updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    private void changeSource() {
        pauseAndRelease(); source = Source.values()[(source.ordinal() + 1) % Source.values().length];
        deviceBaselinePending = true; rebase(); updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    private void changeSpeed() {
        speedIndex = (speedIndex + 1) % SPEEDS.length;
        if (engine != null) engine.setSpeed(SPEEDS[speedIndex], SystemClock.elapsedRealtime());
        updateControls(); updateProgress(SystemClock.elapsedRealtime());
    }
    private void updateControls() {
        if (closed) return;
        sourceButton.setText(source == Source.PHONE ? "手机 ▾" : source == Source.PHYSICAL ? "实体 ▾" : "合并 ▾");
        speedButton.setText(String.format(Locale.ROOT, "%.2f× ▾", SPEEDS[speedIndex]));
        boolean running = engine != null && engine.state() == GuideEngine.State.RUNNING;
        startButton.setText(running ? "暂停" : engine != null && engine.state() == GuideEngine.State.PAUSED ? "继续" : engine != null && engine.state() == GuideEngine.State.FINISHED ? "再练" : "开始");
        startButton.setEnabled(canStart()); startButton.setAlpha(canStart() ? 1 : .45f); restartButton.setEnabled(canStart()); restartButton.setAlpha(canStart() ? 1 : .45f);
        String link = !ready ? "未连接" : simulated ? "模拟设备" : "FPGA 已连接";
        if (ready && !extendedSupported) link += " · 等待36键确认";
        String input = source == Source.PHONE ? "手机可无蓝牙练习" : source == Source.PHYSICAL ? "手机键禁用" : "同音须全部松开重按";
        String warning = ready && octave == 1 ? " · 升八度6键无回报，请用原位" : ready && octave == 2 ? " · 降八度：实体键位已改变" : "";
        if (source == Source.PHYSICAL && engine != null && engine.song.outOfPhysicalRange > 0) warning += " · " + engine.song.outOfPhysicalRange + "音不在原位18键";
        if (ready && octave < 0) warning += " · 设备八度待确认";
        if (ready && deviceMode == 1) warning += " · 设备为MIDI模式";
        if (ready && deviceMode == 2) warning += " · 超声波模式，请切回本地键盘";
        if (source != Source.PHONE && ready && extendedSupported && deviceBaselinePending) warning = " · 等待设备按键基线，请先松键" + warning;
        connection.setText(link + warning + " · " + input);
        connection.setTextColor(warning.length() > 0 || source != Source.PHONE && (!ready || !extendedSupported) ? 0xffffc879 : 0xffb9cbe3);
        String caption = source == Source.PHONE ? "手机按下窗口 ±300ms 曲目时间 · 长条只提示时长" : "设备OR到达时刻粗略判定 ±300ms · 非设备精确计时 · 长条只提示时长";
        String range = source != Source.PHYSICAL ? "" : octave == 2 ? "实体C3—F4（降八度） · " : octave == 1 ? "实体C5—F6（6键无回报） · " : "原位实体C4—F5 · ";
        details.setText(loadError.length() > 0 ? loadError : caption + "\n" + range + songFacts);
        details.setContentDescription(details.getText()); connection.setContentDescription(connection.getText());
        details.setTextColor(loadError.length() > 0 ? 0xffff8c8e : 0xff91a8c5);
        roll.playable(active && source != Source.PHYSICAL, source == Source.PHYSICAL ? "实体模式：手机键已禁用；用设备实体键跟弹" : active ? "" : "页面已暂停");
    }
    private void updateProgress(long now) {
        if (engine == null) { timing.setText("曲谱不可用"); counts.setText("命中 0  漏弹 0  错音 0"); progress.setProgress(0); return; }
        long position = engine.positionMs(now), length = engine.song.durationMs;
        timing.setText(position < 0 ? "预备 " + String.format(Locale.ROOT, "%.1fs", -position / 1000.0) : time(position) + " / " + time(length));
        counts.setText("命中 " + engine.hitCount() + "  漏弹 " + engine.missCount() + "  错音 " + engine.wrongCount());
        progress.setProgress(length <= 0 ? 0 : (int)Math.min(1000, Math.max(0, position) * 1000 / length));
        roll.frame(position);
        if (engine.state() == GuideEngine.State.FINISHED) updateControls();
    }
    private static String time(long ms) { long seconds = Math.max(0, ms) / 1000; return String.format(Locale.ROOT, "%02d:%02d", seconds / 60, seconds % 60); }
}
