package org.pianolink;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Immutable note spans for the guide; keys are chromatic C3 (0) through B5 (35). */
public final class GuideSong {
    public static final int MAX_NOTES = 100000;
    private static final int[] LEGACY_KEYS = {12,14,16,17,19,21,23,13,15,18,20,22};

    public static final class Note {
        public final int id, key;
        public final long startMs, endMs;
        private Note(int id, int key, long startMs, long endMs) {
            this.id = id;
            this.key = key;
            this.startMs = startMs;
            this.endMs = endMs;
        }
    }

    /** Chronological by onset, then key; each note's id is its list index. */
    public final List<Note> notes;
    public final long durationMs;
    public final boolean tailPatched, incomplete;
    public final int peakPolyphony, outOfPhysicalRange;

    private GuideSong(List<Note> notes, long durationMs, boolean tailPatched,
                      boolean incomplete, int peakPolyphony, int outOfPhysicalRange) {
        this.notes = Collections.unmodifiableList(notes);
        this.durationMs = durationMs;
        this.tailPatched = tailPatched;
        this.incomplete = incomplete;
        this.peakPolyphony = peakPolyphony;
        this.outOfPhysicalRange = outOfPhysicalRange;
    }

    public static GuideSong from(SongData source) {
        if (source == null) throw new IllegalArgumentException("曲目为空");
        ArrayList<Note> notes = new ArrayList<Note>();
        long[] starts = new long[36];
        int[] ids = new int[36];
        long held = 0;
        int count = 0, peak = 0, outside = 0;
        long lastMs = 0;
        for (int i = 0; i < source.events.size();) {
            SongData.Event event = source.events.get(i++);
            // Full snapshots at one instant have only one observable final state.
            while (i < source.events.size() && source.events.get(i).ms == event.ms)
                event = source.events.get(i++);
            lastMs = event.ms;
            long mask = absoluteMask(source.format, event.mask);
            long released = held & ~mask;
            while (released != 0) {
                int key = Long.numberOfTrailingZeros(released);
                notes.add(new Note(ids[key], key, starts[key], event.ms));
                released &= released - 1;
            }
            long pressed = mask & ~held;
            while (pressed != 0) {
                int key = Long.numberOfTrailingZeros(pressed);
                if (count == MAX_NOTES) throw new IllegalArgumentException("曲目超过100000个音符");
                starts[key] = event.ms;
                ids[key] = count++;
                if (key < 12 || key > 29) outside++;
                pressed &= pressed - 1;
            }
            held = mask;
            peak = Math.max(peak, Long.bitCount(mask));
        }
        boolean patched = held != 0;
        long duration = lastMs;
        if (patched) {
            duration += 500;
            while (held != 0) {
                int key = Long.numberOfTrailingZeros(held);
                notes.add(new Note(ids[key], key, starts[key], duration));
                held &= held - 1;
            }
        }
        if (notes.isEmpty()) throw new IllegalArgumentException("曲目没有可引导的音符");
        // Onset ids were assigned before release order could reorder overlapping spans.
        Collections.sort(notes, new Comparator<Note>() {
            public int compare(Note left, Note right) { return Integer.compare(left.id, right.id); }
        });
        return new GuideSong(notes, duration, patched, source.incomplete, peak, outside);
    }

    private static long absoluteMask(SongData.Format format, long mask) {
        if (format == SongData.Format.ABSOLUTE36) return mask;
        long absolute = 0;
        for (int key = 0; key < LEGACY_KEYS.length; key++)
            if ((mask & (1L << key)) != 0) absolute |= 1L << LEGACY_KEYS[key];
        return absolute;
    }

    /** Original short example, independent of the user's library or device playback. */
    public static GuideSong demo() {
        return from(new SongData(SongData.Format.ABSOLUTE36, Arrays.asList(
                new SongData.Event(0, 4096, 1),
                new SongData.Event(350, 0, 0),
                new SongData.Event(500, 16384, 1),
                new SongData.Event(850, 0, 0),
                new SongData.Event(1000, 65536, 1),
                new SongData.Event(1350, 0, 0),
                new SongData.Event(1500, 593920, 3),
                new SongData.Event(2400, 0, 0)), false));
    }
}
