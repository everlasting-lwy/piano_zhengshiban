package org.pianolink;
import java.io.*;
import java.nio.charset.StandardCharsets;

/** Picker transactions survive Activity replacement without retaining an Activity or URI. */
public final class PendingCsvExport {
    private final File file,temp;
    public PendingCsvExport(File directory){file=new File(directory,"pending-export.csv");temp=new File(directory,"pending-export.tmp");}
    public synchronized void save(String csv)throws IOException{
        byte[] bytes=csv.getBytes(StandardCharsets.UTF_8);if(bytes.length>8*1024*1024)throw new IOException("导出CSV超过8MB");
        try(FileOutputStream out=new FileOutputStream(temp)){out.write(bytes);out.getFD().sync();}
        if(file.exists()&&!file.delete())throw new IOException("旧导出快照无法替换");
        if(!temp.renameTo(file))throw new IOException("导出快照保存失败");
    }
    public synchronized String load()throws IOException{
        try(InputStream input=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] block=new byte[8192];int n;while((n=input.read(block))!=-1){if(out.size()+n>8*1024*1024)throw new IOException("导出快照超过8MB");out.write(block,0,n);}
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }catch(FileNotFoundException e){throw new IOException("待导出的曲目快照已失效，请返回APP重新导出",e);}
    }
    public synchronized void clear(){file.delete();temp.delete();}
}
