package org.pianolink;
import java.util.*;
import java.io.IOException;
import java.util.concurrent.*;
public final class Session {
    public static final class Send {public final Protocol.Frame frame;public Send(Protocol.Frame f){frame=f;}}
    private final LinkedHashMap<Integer,Integer> controls=new LinkedHashMap<>();private long mask;private int sequence,attempts,keyBurst,guideBurst;private boolean dirty,release,extended;
    private Protocol.Frame pending;private long sent=-1000,lastWrite=-1000,lastRefresh=-1000;private int visual=-1;private long visualGeneration;
    private static final class Snapshot {final long mask;final boolean absolute;Snapshot(long mask,boolean absolute){this.mask=mask;this.absolute=absolute;}}
    private final ArrayDeque<Snapshot> playback=new ArrayDeque<>();private boolean pendingPlayback;
    private final GuideFlow guide=new GuideFlow();
    private final SdLibraryFlow sd=new SdLibraryFlow();private long sdUpload;
    private static final class RpcFuture extends FutureTask<Protocol.Frame>{RpcFuture(){super(()->null);}void complete(Protocol.Frame value){set(value);}void fail(Exception error){setException(error);}}
    private static final class RpcRequest {final Protocol.Frame frame;final RpcFuture future=new RpcFuture();RpcRequest(int cmd,int[] data){frame=new Protocol.Frame(0,cmd,data);}}
    private final ArrayDeque<RpcRequest> rpcQueue=new ArrayDeque<>();private RpcRequest pendingRpc;private boolean rpcClosed;
    static boolean isBlockRpc(int cmd){return cmd>=0x20&&cmd<=0x26||cmd==0x28;}
    /** A bounded future queue. Only tick/receive touches the wire; callers wait on a separate FAT worker. */
    public synchronized Future<Protocol.Frame> blockRpc(int command,int[] data){if(!isBlockRpc(command)||data==null||data.length!=6)throw new IllegalArgumentException("invalid block RPC");for(int value:data)if(value<0||value>255)throw new IllegalArgumentException("invalid RPC payload");RpcRequest request=new RpcRequest(command,data.clone());if(rpcClosed||rpcQueue.size()>=4)request.future.fail(new IOException(rpcClosed?"蓝牙连接已中断":"扇区请求队列已满"));else rpcQueue.add(request);return request.future;}
    private void interruptRpc(){rpcClosed=true;IOException error=new IOException("SD扇区连接中断；写入结果可能未知，请重新查询，不自动重试事务");if(pendingRpc!=null){pendingRpc.future.fail(error);pendingRpc=null;}while(!rpcQueue.isEmpty())rpcQueue.remove().future.fail(error);}
    /** Read-only transfer progress and the last validated FPGA report; never predicted from local actions. */
    public static final class GuideState {
        public final int capability,capacity,reported,step,total,flags,target,physical,busy,cancellable,uploaded,uploadTotal;public final long revision;public final String message;
        private GuideState(GuideFlow g){capability=g.capability;capacity=g.capacity;reported=g.reported;step=g.step;total=g.total;flags=g.flags;target=g.target;physical=g.physical;busy=g.phase!=0&&(!g.readOnly||g.queued)?1:0;cancellable=(g.queued&&g.queuedMasks!=null)||(g.phase!=0&&!g.readOnly&&g.masks!=null&&!g.commitSent&&!g.cancel)?1:0;uploaded=g.uploaded;uploadTotal=g.uploadTotal;message=g.message;revision=g.revision;}
    }
    public synchronized GuideState guideState(){return new GuideState(guide);}
    public synchronized boolean guideDownload(int[] masks){return !sd.mutating()&&(sd.flags&4)==0&&guide.download(masks);}
    public synchronized boolean guideAction(int action){if(action<0||action>4)throw new IllegalArgumentException();if(sd.mutating()||(sd.flags&4)!=0)return false;if(action==4){guideCancel();return true;}return guide.start(null,action);}
    public synchronized void guideCancel(){guide.cancel();}
    /** Read-only polling stays interactive; an accepted user intent waits for its current reply pair. */
    public synchronized void guideRefresh(){guide.refresh();}
    public synchronized void guideInterrupted(){guide.finish("连接中断；未提交的暂存不会替换上一首。设备状态需重新查询。");guide.reported=0;sd.interrupted();sdUpload=0;interruptRpc();if(pending!=null&&(pending.cmd>=0x0f&&pending.cmd<=0x1b||isBlockRpc(pending.cmd)))pending=null;}
    public synchronized SdLibraryFlow.State sdState(){return sd.snapshot();}
    public synchronized void sdRefresh(){sd.refresh();}
    public synchronized boolean sdScan(){return guide.phase!=0&&!guide.readOnly?false:sd.start(0,255);}
    public synchronized boolean sdLoad(int slot){return guide.phase!=0&&!guide.readOnly?false:sd.start(2,slot);}
    public synchronized boolean sdDelete(int slot){return guide.phase!=0&&!guide.readOnly?false:sd.start(3,slot);}
    public synchronized boolean sdSave(int slot,String title,int[] masks){if(guide.phase!=0&&!guide.readOnly)return false;if(masks==null||masks.length==0||masks.length>2048)throw new IllegalArgumentException("引导须为1至2048步");OledGuideProtocol.crcMasks(masks);if(!sd.reserveSave(slot,title))return false;if(!guide.download(masks)){sd.uploadFinished(false);return false;}sdUpload=guide.uploadGeneration;return true;}
    public synchronized boolean sdPhoneBegin(int action,int slot,byte[] file){return !rpcClosed&&(guide.phase==0||guide.readOnly)&&sd.reservePhone(action,slot,file);}
    public synchronized void sdPhoneFinished(String failure){sd.phoneFinished(failure);}
    public synchronized void sdPhoneProgress(boolean writing,long lba,int chunks){sd.phoneProgress(writing,lba,chunks);}
    /** Playback preserves edges; live touch still uses the coalescing setters below. */
    public synchronized boolean offerPlaybackMask(long value,boolean absolute){
        if(value<0||(value&~(absolute?Protocol.EXTENDED_MASK:4095L))!=0)throw new IllegalArgumentException("playback mask out of range");
        if(playback.size()>=8)return false;playback.add(new Snapshot(value,absolute));return true;
    }
    public synchronized boolean playbackPending(){return pendingPlayback||!playback.isEmpty();}
    public synchronized void setMask(int mask){long next=mask&4095;if(this.mask!=next||extended){this.mask=next;dirty=true;}extended=false;}
    public synchronized void resetLegacy(){setMask(0);}
    public synchronized void setExtendedMask(long mask){if((mask&~Protocol.EXTENDED_MASK)!=0)throw new IllegalArgumentException("36-key mask out of range");if(this.mask!=mask||!extended){this.mask=mask;dirty=true;}extended=true;}
    /** CMD13 uses packed id<<8|value internally; the wire still carries separate D0/D1. */
    public synchronized void control(int cmd,int value){
        if(cmd==13){int id=value>>>8,level=value&255;int max=id==4?16:id==6||id==7?2:15;if(id>7||level>max||value<0)throw new IllegalArgumentException();controls.put(256+id,level);return;}
        if(cmd==14){if(value<0||value>4)throw new IllegalArgumentException();visual=value;return;}
        if(cmd<1||cmd>12||cmd==4||cmd==5||cmd==7||cmd==9||cmd==10)throw new IllegalArgumentException();controls.put(cmd,value);
    }
    public synchronized void cancelVisual(){visual=-1;}
    /** UI selection invalidates any worker decision not yet enqueued. */
    public synchronized void cancelVisual(long generation){visualGeneration=generation;visual=-1;}
    public synchronized boolean queueVisual(long generation,int kind){
        if(generation!=visualGeneration)return false;
        if(kind<0||kind>4)throw new IllegalArgumentException();
        visual=kind;return true;
    }
    public synchronized void release(){mask=0;dirty=false;release=true;if(pendingRpc==null&&(pending==null||pending.cmd<0x0f||pending.cmd>0x1b))pending=null;pendingPlayback=false;playback.clear();}
    public synchronized Send tick(long now){
        while(!rpcQueue.isEmpty()&&rpcQueue.peek().future.isCancelled())rpcQueue.remove();
        if(sdUpload!=0&&guide.completedUploadGeneration==sdUpload){sd.uploadFinished(guide.completedUploadResult==1);sdUpload=0;}
        if(sd.loadCompleted){sd.loadCompleted=false;guide.refresh();}
        if(pending!=null){if(now-sent<500)return null;if(attempts>=3){guideInterrupted();throw new IllegalStateException("设备 1500ms 未响应，已停止发送");}attempts++;sent=now;lastWrite=now;return new Send(pending);}
        int cmd;long value=0;boolean fromPlayback=false;if(release){cmd=5;release=false;}
        else {if(now-lastWrite<40)return null;
            if(guide.phase!=0&&now-lastRefresh<250&&(controls.isEmpty()||guideBurst<3)){Protocol.Frame request=guide.request();guideBurst++;pending=new Protocol.Frame(sequence++&255,request.cmd,request.d);pendingPlayback=false;attempts=1;sent=now;lastWrite=now;return new Send(pending);}
            if(sd.active()&&visual!=0&&now-lastRefresh<250&&(guideBurst<3||!dirty&&playback.isEmpty()&&controls.isEmpty()&&visual<0)){Protocol.Frame request=sd.request();guideBurst++;pending=new Protocol.Frame(sequence++&255,request.cmd,request.d);pendingPlayback=false;attempts=1;sent=now;lastWrite=now;return new Send(pending);}
            if(!rpcQueue.isEmpty()&&visual!=0&&now-lastRefresh<250&&(guideBurst<3||!dirty&&playback.isEmpty()&&controls.isEmpty()&&visual<0)){pendingRpc=rpcQueue.remove();guideBurst++;pending=new Protocol.Frame(sequence++&255,pendingRpc.frame.cmd,pendingRpc.frame.d);pendingPlayback=false;attempts=1;sent=now;lastWrite=now;return new Send(pending);}
            if(!playback.isEmpty()&&(controls.isEmpty()||keyBurst<3)){Snapshot next=playback.remove();mask=next.mask;extended=next.absolute;dirty=false;cmd=extended?9:4;value=mask;fromPlayback=true;}
            else if(dirty&&(controls.isEmpty()||keyBurst<3)){cmd=extended?9:4;value=mask;dirty=false;}
            else if(now-lastRefresh>=250){cmd=extended?10:7;value=mask;}
            else if(!controls.isEmpty()){Map.Entry<Integer,Integer> entry=controls.entrySet().iterator().next();cmd=entry.getKey();value=entry.getValue();controls.remove(cmd);if(cmd>=256){value=((long)(cmd-256)<<8)|value;cmd=13;}}
            else if(visual>=0){cmd=14;value=visual;visual=-1;}
            else return null;
        }
        int[] d=new int[6];d[0]=(int)value&255;if(cmd==4||cmd==7)d[1]=(int)(value>>>8)&15;
        if(cmd==13){d[0]=(int)(value>>>8);d[1]=(int)value&255;}
        if(cmd==9||cmd==10){d[1]=(int)(value>>>8)&255;d[2]=(int)(value>>>16)&255;d[3]=(int)(value>>>24)&255;d[4]=(int)(value>>>32)&15;}
        // At most three changing-key packets before a queued control gets a slot.
        keyBurst=(cmd==4||cmd==9)?Math.min(3,keyBurst+1):0;
        if(cmd!=7&&cmd!=10)guideBurst=0;
        pending=new Protocol.Frame(sequence++&255,cmd,d);pendingPlayback=fromPlayback;attempts=1;sent=now;lastWrite=now;if(cmd==4||cmd==7||cmd==9||cmd==10||cmd==5)lastRefresh=now;return new Send(pending);
    }
    public synchronized boolean receive(Protocol.Frame f){
        if(pending==null||f.seq!=pending.seq)return false;
        if(pendingRpc!=null){boolean ack=f.cmd==0x80&&f.d[0]==pending.cmd&&f.d[1]<=3&&f.d[2]==2&&f.d[3]==0&&f.d[4]==0&&f.d[5]==0;boolean query=pending.cmd==0x25&&f.cmd==0x91&&f.d[0]==pending.d[0]&&f.d[1]==pending.d[1]||pending.cmd==0x26&&f.cmd==0x92&&f.d[0]<=3&&(f.d[2]&~31)==0&&f.d[5]==0||pending.cmd==0x28&&f.cmd==0x93&&f.d[4]<=1&&f.d[5]==2;if(!ack&&!query)return false;RpcRequest request=pendingRpc;pendingRpc=null;pending=null;pendingPlayback=false;request.future.complete(f);return true;}
        if(pending.cmd>=0x16&&pending.cmd<=0x1b){int expected=pending.cmd==0x16?0x8b:pending.cmd==0x19?0x8c:pending.cmd==0x1a?0x8d:pending.cmd==0x1b?0x8e:0x80;boolean ack=f.cmd==0x80&&f.d[0]==pending.cmd&&f.d[1]<=3&&(f.d[2]==1||f.d[2]==2)&&f.d[3]==0&&f.d[4]==0&&f.d[5]==0;if(f.cmd!=expected&&!ack)return false;if(f.cmd==0x80&&!ack)return false;Protocol.Frame request=pending;pending=null;pendingPlayback=false;sd.receive(request,f);return true;}
        if(pending.cmd>=0x0f&&pending.cmd<=0x15){int expected=pending.cmd==0x0f?0x88:pending.cmd==0x14?0x89:pending.cmd==0x15?0x8a:0x80;boolean ack=f.cmd==0x80&&f.d[0]==pending.cmd&&f.d[1]<=3&&f.d[2]==1&&f.d[3]==0&&f.d[4]==0&&f.d[5]==0;if(f.cmd!=expected&&!ack)return false;if(f.cmd==0x80&&!ack)return false;Protocol.Frame request=pending;pending=null;pendingPlayback=false;guide.receive(request,f);return true;}
        if((pending.cmd==6&&f.cmd==0x81)||(pending.cmd==11&&f.cmd==0x83&&f.isExtendedState())||(pending.cmd==12&&f.isEffectsState())||(f.cmd==0x80&&f.d[0]==pending.cmd)){pending=null;pendingPlayback=false;return true;}return false;
    }
    private static final class GuideFlow {
        int capability,capacity=2048,reported,step,total,flags,target,physical,uploaded,uploadTotal,phase,action=-1;
        int stagedStep,stagedTotal,stagedFlags,queuedAction;int[] masks,queuedMasks;boolean cancel,commitSent,readOnly,queued;long revision,uploadGeneration,activeUploadGeneration,queuedUploadGeneration,completedUploadGeneration;int completedUploadResult;String message="OLED曲谱：等待设备能力确认",failure;
        boolean download(int[] data){if(data==null||data.length==0||data.length>2048)throw new IllegalArgumentException("引导须为1至2048步，请裁剪曲目");OledGuideProtocol.crcMasks(data);if(!start(data.clone(),-1))return false;uploadGeneration++;if(queued)queuedUploadGeneration=uploadGeneration;else activeUploadGeneration=uploadGeneration;return true;}
        boolean start(int[] data,int control){
            if(phase!=0){
                if(!readOnly)return false;
                // Never replace the in-flight request or its sequence. Only the newest
                // user intent is retained, and it begins after the read-only pair ends.
                queued=true;queuedMasks=data;queuedAction=control;uploaded=0;uploadTotal=data==null?0:data.length;
                message=data==null?"等待当前状态查询完成，准备执行操作…":"等待当前状态查询完成，准备下载…";revision++;return true;
            }
            readOnly=false;masks=data;action=control;uploaded=0;uploadTotal=data==null?0:data.length;cancel=false;commitSent=false;failure=null;phase=1;message=data==null?"正在查询FPGA引导状态…":"确认能力与状态，准备下载…";revision++;return true;
        }
        void refresh(){
            if(phase!=0)return;
            readOnly=true;masks=null;action=-1;cancel=false;commitSent=false;failure=null;
            // Capability is immutable for this connection. Poll only status and keys;
            // keep the last validated report, progress and message visible meanwhile.
            phase=capability==1?2:1;
        }
        void cancel(){
            if(readOnly){if(queued&&queuedMasks!=null){completedUploadGeneration=queuedUploadGeneration;completedUploadResult=-1;queuedUploadGeneration=0;queued=false;queuedMasks=null;uploaded=0;uploadTotal=0;message="下载已取消；上一首保留";revision++;}return;}
            if(phase!=0){if(commitSent){message="COMMIT已发送，取消已不可用；正在确认FPGA最终状态…";revision++;return;}cancel=true;failure="下载已取消；上一首保留";message="正在取消暂存…";revision++;}
        }
        void finish(String text){finish(text,false);}
        void finish(String text,boolean success){if(activeUploadGeneration!=0){completedUploadGeneration=activeUploadGeneration;completedUploadResult=success?1:-1;activeUploadGeneration=0;}else if(queuedUploadGeneration!=0){completedUploadGeneration=queuedUploadGeneration;completedUploadResult=-1;}queuedUploadGeneration=0;phase=0;cancel=false;readOnly=false;queued=false;queuedMasks=null;message=text;revision++;}
        Protocol.Frame request(){if(cancel&&phase!=7&&phase!=8){phase=6;action=4;}int cmd;int[] d=new int[6];switch(phase){case 1:cmd=0x0f;break;case 2:case 7:cmd=0x14;break;case 3:cmd=0x10;int crc=OledGuideProtocol.crcMasks(masks);d[0]=masks.length&255;d[1]=masks.length>>>8;d[2]=crc&255;d[3]=crc>>>8;d[4]=1;break;case 4:cmd=0x11;d[0]=uploaded&255;d[1]=uploaded>>>8;d[2]=masks[uploaded]&255;d[3]=(masks[uploaded]>>>8)&255;d[4]=masks[uploaded]>>>16;break;case 5:cmd=0x12;commitSent=true;revision++;break;case 9:cmd=0x13;d[0]=4;break;case 6:cmd=0x13;d[0]=action;break;default:cmd=0x15;}return new Protocol.Frame(0,cmd,d);}
        void receive(Protocol.Frame request,Protocol.Frame f){
            if(!readOnly)revision++;
            if(f.cmd==0x80&&f.d[1]!=0){if(request.cmd==0x0f){capability=-1;finish("设备不支持OLED整曲引导；请使用配套FPGA固件");return;}failure="设备拒绝引导命令 "+Integer.toHexString(request.cmd)+"，错误 "+f.d[1];if(masks!=null&&request.cmd!=0x13){cancel=true;message=failure+"；取消暂存…";}else finish(failure);return;}
            if(request.cmd==0x0f){if(!OledGuideProtocol.capability(f)){capability=-1;finish("FPGA引导能力无效，停止下载");return;}int nextCapacity=f.d[2]|f.d[3]<<8;if(readOnly&&(capability!=1||capacity!=nextCapacity))revision++;capability=1;capacity=nextCapacity;if(masks!=null&&masks.length>capacity){finish("曲目超过设备容量 "+capacity+" 步，请裁剪后下载");return;}phase=2;}
            else if(request.cmd==0x14){if(!OledGuideProtocol.status(f,capacity)){reported=0;finish("FPGA引导状态无效，已停止操作");return;}stagedStep=f.d[0]|f.d[1]<<8;stagedTotal=f.d[2]|f.d[3]<<8;stagedFlags=f.d[4];if(phase==2){phase=masks!=null?((stagedFlags&8)!=0?9:3):action>=0?6:8;if(phase==9)message="设备有未提交暂存，先取消旧暂存再重新下载…";}else phase=8;}
            else if(request.cmd==0x10){phase=4;message="下载 0 / "+masks.length+" 步…";}
            else if(request.cmd==0x11){uploaded++;phase=uploaded==masks.length?5:4;message="下载 "+uploaded+" / "+masks.length+" 步…";}
            else if(request.cmd==0x12){phase=7;message="整曲已提交，读取设备状态…";}
            else if(request.cmd==0x13){if(phase==9){phase=3;message="旧暂存已取消，开始整曲下载…";}else{cancel=false;phase=7;}}
            else if(request.cmd==0x15){
                if(!OledGuideProtocol.keys(f)){reported=0;finish("FPGA目标/实体键报告无效");return;}
                int nextTarget=f.d[0]|f.d[1]<<8|f.d[2]<<16,nextPhysical=f.d[3]|f.d[4]<<8|f.d[5]<<16;
                boolean changed=reported==0||step!=stagedStep||total!=stagedTotal||flags!=stagedFlags||target!=nextTarget||physical!=nextPhysical;
                boolean first=reported==0;reported=1;step=stagedStep;total=stagedTotal;flags=stagedFlags;target=nextTarget;physical=nextPhysical;
                if(readOnly){
                    phase=0;readOnly=false;
                    if(queued){int[] nextMasks=queuedMasks;int nextAction=queuedAction;queued=false;queuedMasks=null;activeUploadGeneration=queuedUploadGeneration;queuedUploadGeneration=0;start(nextMasks,nextAction);}
                    else {if(first){message="FPGA引导状态已更新";changed=true;}if(changed)revision++;}
                }else {boolean uploadedOk=failure==null&&masks!=null&&commitSent&&(flags&1)!=0&&(flags&8)==0&&total==masks.length;finish(failure!=null?failure:masks!=null?(uploadedOk?"整曲下载完成（FPGA RAM）":"RAM提交后的设备状态未确认本次曲谱"):action==3?"FPGA曲谱已删除；手机曲库保留":"FPGA引导状态已更新",uploadedOk);}
            }
        }
    }
}
