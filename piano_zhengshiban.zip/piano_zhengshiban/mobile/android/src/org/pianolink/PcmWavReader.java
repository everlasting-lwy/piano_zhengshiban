package org.pianolink;

import java.io.*;

/** Bounded streaming reader for PCM/IEEE-float RIFF WAVE. */
public final class PcmWavReader implements Closeable {
    public interface MonoSink { void samples(float[] samples,int length) throws IOException; }
    public final int sampleRate,channels;
    public final long frameCount;
    private final RandomAccessFile input;
    private final long dataOffset,dataBytes;
    private final int encoding,bits,blockAlign;
    public PcmWavReader(File source) throws IOException {
        RandomAccessFile file=new RandomAccessFile(source,"r");
        try {
            if(file.length()>100L*1024*1024)throw new IOException("音频超过 100 MB 上限");
            if(file.length()<12||file.readInt()!=0x52494646)throw new IOException("WAV 缺少 RIFF 标识");
            long riffEnd=u32(file)+8;
            if(file.readInt()!=0x57415645||riffEnd>file.length()||riffEnd<12)throw new IOException("WAV 文件损坏或已截断");
            int format=0,channelCount=0,rate=0,width=0,align=0;
            long offset=-1,length=-1;
            while(file.getFilePointer()+8<=riffEnd) {
                int kind=file.readInt();long bytes=u32(file),start=file.getFilePointer();
                long next=start+bytes+(bytes&1);
                if(next>riffEnd||next<start)throw new IOException("WAV 数据块已截断");
                if(kind==0x666d7420) {
                    if(format!=0||bytes<16)throw new IOException("WAV 格式块无效");
                    format=u16(file);channelCount=u16(file);long hz=u32(file);u32(file);
                    align=u16(file);width=u16(file);
                    if(hz>384000)throw new IOException("WAV 采样率不支持");rate=(int)hz;
                    if(format==0xfffe) {
                        if(bytes<40||u16(file)<22)throw new IOException("WAV 扩展格式块无效");
                        int validBits=u16(file);u32(file);
                        long subformat=u32(file);byte[] guidTail=new byte[12];file.readFully(guidTail);
                        byte[] expected={0,0,16,0,(byte)128,0,0,(byte)170,0,56,(byte)155,113};
                        if(!java.util.Arrays.equals(guidTail,expected)||subformat>3||validBits!=width)
                            throw new IOException("不支持此 WAV 扩展编码，请使用 PCM WAV");
                        format=(int)subformat;
                    }
                } else if(kind==0x64617461) {
                    if(offset>=0)throw new IOException("不支持多个 WAV data 块");
                    offset=start;length=bytes;
                }
                file.seek(next);
            }
            if(offset<0||format==0||channelCount<1||channelCount>8||rate<8000||rate>384000)
                throw new IOException("WAV 缺少有效音轨或采样率不支持");
            if((format!=1&&format!=3)||(format==3&&width!=32)
                    ||(format==1&&width!=8&&width!=16&&width!=24&&width!=32))
                throw new IOException("不支持此 WAV 编码，请使用 8/16/24/32 位 PCM WAV");
            if(align!=channelCount*(width/8)||length%align!=0)throw new IOException("WAV PCM 帧长度无效");
            if(length/align>rate*600L)throw new IOException("音频超过 10 分钟上限");
            input=file;encoding=format;channels=channelCount;sampleRate=rate;bits=width;
            blockAlign=align;dataOffset=offset;dataBytes=length;frameCount=length/align;
        } catch(IOException|RuntimeException failure) {file.close();throw failure;}
    }
    public void decode(MonoSink sink, AudioDsp.Cancellation cancellation) throws IOException {
        input.seek(dataOffset);long left=dataBytes;
        byte[] block=new byte[4096*blockAlign];float[] mono=new float[4096];
        while(left>0) {
            AudioDsp.checkCancelled(cancellation);
            int bytes=(int)Math.min(left,block.length);input.readFully(block,0,bytes);left-=bytes;
            int frames=bytes/blockAlign,bytesPerSample=bits/8;
            for(int frame=0;frame<frames;frame++) {
                double total=0;
                for(int channel=0;channel<channels;channel++) {
                    int at=frame*blockAlign+channel*bytesPerSample;
                    int raw=block[at]&255;
                    for(int j=1;j<bytesPerSample;j++)raw|=(block[at+j]&255)<<(8*j);
                    float value;
                    if(encoding==3)value=Float.intBitsToFloat(raw);
                    else if(bits==8)value=(raw-128)/128f;
                    else if(bits==16)value=(short)raw/32768f;
                    else if(bits==24)value=(raw<<8>>8)/8388608f;
                    else value=(float)(raw/2147483648.0);
                    if(Float.isNaN(value)||Float.isInfinite(value))throw new IOException("WAV 含无效浮点采样");
                    total+=Math.max(-1,Math.min(1,value));
                }
                mono[frame]=(float)(total/channels);
            }
            sink.samples(mono,frames);
        }
        AudioDsp.checkCancelled(cancellation);
    }
    private static int u16(RandomAccessFile in) throws IOException {return in.readUnsignedByte()|(in.readUnsignedByte()<<8);}
    private static long u32(RandomAccessFile in) throws IOException {return (u16(in)&65535L)|((u16(in)&65535L)<<16);}
    public void close() throws IOException {input.close();}
}
