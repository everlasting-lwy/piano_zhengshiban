package org.pianolink;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/** A future piano roll and manual keyboard. Drawing never emits target notes. */
public final class FallingNotesView extends View {
    public interface Listener { void changed(long mask); }
    private static final long MASK36 = (1L << 36) - 1;
    private static final long LOOKAHEAD_MS = 3000, RECENT_MS = 650;
    private static final int MAX_BARS_PER_KEY = 64;
    private static final int BLUE = 0xff78acff, GREEN = 0xff58d69c, RED = 0xffff777b;
    private static final String[] NAMES = {"C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"};
    private final Paint paint = new Paint(3);
    private final PianoTouch touch = new PianoTouch();
    private final Listener listener;
    private final int[][] noteIds = new int[36][];
    private GuideEngine engine;
    private long position, localMask, deviceMask;
    private boolean playable, dense;
    private float keyboardTop;
    private String disabledReason = "";

    public FallingNotesView(Context context, Listener listener) {
        super(context);
        this.listener = listener;
        setFocusable(true);
        setContentDescription("下落谱面与三十六键手机钢琴，C3 到 B5。蓝色目标，绿色命中，红色漏弹。青色手机触摸，金框设备合并反馈。长条只提示保持时长。");
    }

    /** The only full-score scan happens when loading a new immutable song. */
    public void engine(GuideEngine value) {
        engine = value;
        int[] counts = new int[36];
        if (value != null) for (GuideSong.Note note : value.song.notes) counts[note.key]++;
        for (int key = 0; key < 36; key++) noteIds[key] = new int[counts[key]];
        if (value != null) {
            int[] offsets = new int[36];
            for (GuideSong.Note note : value.song.notes) noteIds[note.key][offsets[note.key]++] = note.id;
        }
        position = -LOOKAHEAD_MS;
        invalidate();
    }

    public void frame(long value) { position = value; invalidate(); }
    public void device(long mask) { deviceMask = mask & MASK36; invalidate(); }
    public void playable(boolean value, String reason) {
        playable = value;
        disabledReason = reason == null ? "" : reason;
        if (!value) release();
        invalidate();
    }
    public void release() {
        touch.cancel();
        if (localMask != 0) { localMask = 0; listener.changed(0); }
        invalidate();
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
    private void fill(int color) { paint.setStyle(Paint.Style.FILL); paint.setColor(color); paint.setAlpha(255); }
    private void label(Canvas canvas, String text, float x, float y, float size, int color, Paint.Align align) {
        fill(color); paint.setTextSize(dp(size)); paint.setTextAlign(align); canvas.drawText(text, x, y, paint);
    }
    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float keyboardHeight = Math.min(dp(126), Math.max(dp(70), h * .40f));
        if (h < dp(150)) keyboardHeight = h * .43f;
        keyboardTop = Math.max(1, h - keyboardHeight);
    }
    private GuideSong.Note note(int id) { return engine.song.notes.get(id); }
    private int lowerBoundEnd(int[] ids, long time) {
        int low = 0, high = ids.length;
        while (low < high) { int middle = (low + high) >>> 1; if (note(ids[middle]).endMs < time) low = middle + 1; else high = middle; }
        return low;
    }
    private int upperBoundStart(int[] ids, long time) {
        int low = 0, high = ids.length;
        while (low < high) { int middle = (low + high) >>> 1; if (note(ids[middle]).startMs <= time) low = middle + 1; else high = middle; }
        return low;
    }
    private float y(long songTime) { return keyboardTop - (songTime - position) * keyboardTop / LOOKAHEAD_MS; }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(0xff0b1321);
        float width = getWidth(), height = getHeight(), unit = width / 21f;
        if (width <= 0 || height <= 0) return;
        // Natural-key boundaries and sharp-key columns use the exact touch keyboard geometry.
        for (int key = 0; key < 36; key++) {
            float left = PianoTouch.left(key, width), right = PianoTouch.right(key, width);
            if (PianoTouch.black(key)) { fill(0xff101c2e); canvas.drawRect(left, 0, right, keyboardTop, paint); }
            else { fill(key % 12 == 0 ? 0xff33435b : 0xff1f2d42); canvas.drawLine(left, 0, left, keyboardTop, paint); }
        }
        fill(0xff24364c);
        for (int second = 1; second <= 3; second++) {
            float line = keyboardTop - second * keyboardTop / 3;
            canvas.drawLine(0, line, width, line, paint);
        }
        long targets = 0;
        dense = false;
        if (engine != null) {
            for (int pass = 0; pass < 2; pass++) for (int key = 0; key < 36; key++) {
                if (PianoTouch.black(key) != (pass == 1)) continue;
                int[] ids = noteIds[key];
                int first = lowerBoundEnd(ids, position - RECENT_MS);
                int end = upperBoundStart(ids, position + LOOKAHEAD_MS);
                int count = end - first;
                if (count <= 0) continue;
                float center = (PianoTouch.left(key, width) + PianoTouch.right(key, width)) * .5f;
                float half = unit * (pass == 1 ? .21f : .23f);
                if (count > MAX_BARS_PER_KEY) {
                    // A pathological dense 3-second window is shown in bounded neutral groups.
                    // Neutral groups deliberately make no claim about mixed hit/miss results.
                    dense = true;
                    for (int group = 0; group < MAX_BARS_PER_KEY; group++) {
                        int a = first + (int)((long) count * group / MAX_BARS_PER_KEY);
                        int b = first + (int)((long) count * (group + 1) / MAX_BARS_PER_KEY) - 1;
                        float top = Math.max(0, y(note(ids[b]).endMs));
                        float bottom = Math.min(keyboardTop, y(note(ids[a]).startMs));
                        if (bottom > top) { fill(0xff8a85b8); canvas.drawRect(center - half, top, center + half, Math.max(top + 1, bottom), paint); }
                    }
                    continue;
                }
                for (int i = first; i < end; i++) {
                    GuideSong.Note note = note(ids[i]);
                    int result = engine.result(note.id);
                    int tint = result == GuideEngine.HIT ? GREEN : result == GuideEngine.MISS ? RED : BLUE;
                    float top = Math.max(0, y(note.endMs));
                    float bottom = Math.min(keyboardTop, y(note.startMs));
                    if (bottom > top) {
                        fill(tint); canvas.drawRoundRect(center - half, top, center + half, Math.max(top + dp(2), bottom), dp(2), dp(2), paint);
                        fill(0x55ffffff); canvas.drawRect(center - half + 1, Math.max(top, bottom - dp(2)), center + half - 1, bottom, paint);
                    }
                    if (result != GuideEngine.PENDING && position >= note.startMs - 300 && position <= note.startMs + RECENT_MS) {
                        fill(tint); canvas.drawRect(center - half, keyboardTop - dp(7), center + half, keyboardTop - dp(2), paint);
                    }
                    if (result == GuideEngine.PENDING && Math.abs(note.startMs - position) <= 300) targets |= 1L << key;
                }
            }
        }
        // Onset (the lower end of a future duration bar) reaches this line at its score time.
        fill(0xff7db7ff); canvas.drawRect(0, keyboardTop - dp(2), width, keyboardTop, paint);
        for (int pass = 0; pass < 2; pass++) for (int key = 0; key < 36; key++) {
            if (PianoTouch.black(key) != (pass == 1)) continue;
            boolean black = pass == 1;
            float left = PianoTouch.left(key, width), right = PianoTouch.right(key, width);
            float bottom = keyboardTop + (height - keyboardTop) * (black ? .62f : 1);
            boolean local = (localMask & (1L << key)) != 0;
            fill(local ? 0xff35bfb8 : black ? 0xff1b293f : 0xffe8edf4);
            canvas.drawRect(left + 1, keyboardTop + 1, right - 1, bottom - 1, paint);
            if ((targets & (1L << key)) != 0) { fill(BLUE); canvas.drawRect(left + 2, keyboardTop + 2, right - 2, keyboardTop + dp(5), paint); }
            if ((deviceMask & (1L << key)) != 0) {
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setColor(0xffffc66e);
                canvas.drawRect(left + 3, keyboardTop + 3, right - 3, bottom - 3, paint);
            }
            float textSize = Math.min(dp(10), (right - left) * (black ? .46f : .5f));
            fill(black ? 0xffd4e1f4 : 0xff263951); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(textSize);
            canvas.drawText(NAMES[key % 12] + (key / 12 + 3), (left + right) / 2, bottom - dp(6), paint);
        }
        if (!playable && disabledReason.length() != 0) {
            fill(0xa90b1321); canvas.drawRect(0, keyboardTop + (height - keyboardTop) * .68f, width, height, paint);
            label(canvas, disabledReason, width / 2, height - dp(9), 11, 0xffe4edf9, Paint.Align.CENTER);
        }
        if (engine != null) {
            GuideEngine.State state = engine.state();
            if (state == GuideEngine.State.RUNNING && position < 0) {
                label(canvas, String.valueOf(Math.max(1, (int)Math.ceil(-position / 1000.0))), width / 2, keyboardTop * .60f, 36, 0xffe6efff, Paint.Align.CENTER);
                label(canvas, "准备 · 音符到线时按键", width / 2, keyboardTop * .60f + dp(21), 11, 0xffb8c9e0, Paint.Align.CENTER);
            } else if (state != GuideEngine.State.RUNNING) {
                String hint = state == GuideEngine.State.PAUSED ? "已暂停 · 点继续保持原位置" : state == GuideEngine.State.FINISHED ? "练习结束 · 可重来" : "点开始 · 3 秒预备";
                label(canvas, hint, width / 2, Math.max(dp(28), keyboardTop * .46f), 15, 0xffe6efff, Paint.Align.CENTER);
            }
        }
        if (dense) label(canvas, "密集谱面合并显示 · 统计仍逐音符", width - dp(8), dp(16), 10, 0xffc3b9e6, Paint.Align.RIGHT);
    }

    private int hit(MotionEvent event, int index) {
        return touch.keyAt(event.getX(index), event.getY(index) - keyboardTop, getWidth(), getHeight() - keyboardTop);
    }
    private void publish() {
        long value = touch.mask();
        if (value != localMask) { localMask = value; listener.changed(value); invalidate(); }
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!playable) return true;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        int action = event.getActionMasked(), index = event.getActionIndex();
        if (action == MotionEvent.ACTION_CANCEL) { release(); return true; }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) touch.down(event.getPointerId(index), hit(event, index));
        else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) touch.up(event.getPointerId(index));
        else if (action == MotionEvent.ACTION_MOVE) for (int i = 0; i < event.getPointerCount(); i++) touch.move(event.getPointerId(i), hit(event, i));
        publish();
        if (action == MotionEvent.ACTION_UP) performClick();
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
}
