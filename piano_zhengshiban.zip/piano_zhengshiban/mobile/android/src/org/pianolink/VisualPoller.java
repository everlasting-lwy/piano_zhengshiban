package org.pianolink;

/** Bounded one-shot requests; the serial worker owns this gate, never a UI timer. */
public final class VisualPoller {
    private final VisualFrames frames=new VisualFrames();private boolean supported,active,queued;private int kind;private long lastStart=-10000;
    public synchronized void supported(boolean value){supported=value;if(!value){queued=false;frames.clear();}}
    public synchronized boolean supported(){return supported;}
    public synchronized void select(int value,boolean foreground){if(value<0||value>4)throw new IllegalArgumentException();if(kind!=value||active!=foreground){frames.clear();queued=false;lastStart=-10000;}kind=value;active=foreground;}
    public synchronized int next(long now){long interval=kind==1?600:kind==2?400:kind==3?700:500;if(!supported||!active||kind==0||queued||frames.busy(now)||now-lastStart<interval)return -1;queued=true;return kind;}
    public synchronized void sent(int seq,int requested,long now){if(requested==kind&&active&&supported&&requested!=0){queued=false;lastStart=now;frames.begin(seq,requested,now);}}
    public synchronized VisualFrames.Snapshot receive(Protocol.Frame frame,long now){return frames.receive(frame,now);}
}
