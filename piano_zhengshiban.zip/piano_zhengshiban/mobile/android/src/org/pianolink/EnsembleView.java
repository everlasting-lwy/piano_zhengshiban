package org.pianolink;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.*;
import java.util.ArrayList;

/** Three-octave keyboard and an immediate, non-recording live piano roll. */
public final class EnsembleView extends View {
    public interface Listener{void changed(long mask);}
    private final PianoTouch touch=new PianoTouch();
    private final Listener listener;
    private final boolean showHistory;
    private final Paint paint=new Paint(3);
    private final ArrayList<Span> history=new ArrayList<>();
    private long deviceMask,touchMask;
    private boolean playable;
    private float keyboardTop;
    private static final long WINDOW=6000;
    private static final String[] NAMES={"C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"};
    private static final class Span{final int key;final boolean device;final long start;long end;Span(int k,boolean d,long s){key=k;device=d;start=s;}}
    public EnsembleView(Context context,Listener listener){this(context,listener,true);}
    public EnsembleView(Context context,Listener listener,boolean history){super(context);this.listener=listener;showHistory=history;setFocusable(true);setContentDescription("三十六键多点钢琴 C3 到 B5。青色为手机触摸，金色边框为设备合并反馈。共用四个声部。");}
    public void playable(boolean value){playable=value;if(!value)release();invalidate();}
    public void confirmed(long mask){record(deviceMask,mask,true);deviceMask=mask;invalidate();}
    public void release(){touch.cancel();publish();}
    private void record(long old,long value,boolean device){
        long now=SystemClock.elapsedRealtime();
        for(int i=history.size()-1;i>=0;i--){Span span=history.get(i);if(span.end!=0&&now-span.end>WINDOW)history.remove(i);}
        for(Span span:history)if(span.device==device&&span.end==0&&(value&(1L<<span.key))==0)span.end=now;
        for(int n=0;n<36;n++)if((value&(1L<<n))!=0&&(old&(1L<<n))==0)history.add(new Span(n,device,now));
    }
    private void publish(){long value=touch.mask();record(touchMask,value,false);touchMask=value;listener.changed(value);invalidate();}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){keyboardTop=showHistory?h*.46f:0;}
    private void color(int color){paint.setColor(color);paint.setStyle(Paint.Style.FILL);}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);canvas.drawColor(0xff111926);long now=SystemClock.elapsedRealtime();float width=getWidth(),height=getHeight()-keyboardTop;
        for(int key=0;key<36;key++)if(!PianoTouch.black(key)){color(0xff26364a);canvas.drawLine(PianoTouch.left(key,width),0,PianoTouch.left(key,width),keyboardTop,paint);}
        for(int i=history.size()-1;i>=0;i--){Span span=history.get(i);if(span.end!=0&&now-span.end>WINDOW){history.remove(i);continue;}
            float bottom=keyboardTop-(now-(span.end==0?now:span.end))*keyboardTop/WINDOW;
            float top=Math.max(0,keyboardTop-(now-span.start)*keyboardTop/WINDOW);
            color(span.device?0xffd9ab58:0xff38c7c3);paint.setAlpha(span.device?150:210);
            float left=PianoTouch.left(span.key,width),right=PianoTouch.right(span.key,width);
            if(span.device){left+=(right-left)*.35f;right-=2;}else right=left+(right-left)*.52f;
            canvas.drawRect(left+1,top,right,bottom,paint);paint.setAlpha(255);
        }
        for(int pass=0;pass<2;pass++)for(int key=0;key<36;key++)if(PianoTouch.black(key)==(pass==1)){
            boolean black=pass==1,down=(touchMask&(1L<<key))!=0;float left=PianoTouch.left(key,width),right=PianoTouch.right(key,width);
            float bottom=keyboardTop+height*(black?.62f:1);
            color(down?0xff38c7c3:black?0xff243249:0xffedf1f5);canvas.drawRect(left+1,keyboardTop+1,right-1,bottom-1,paint);
            if((deviceMask&(1L<<key))!=0){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setColor(0xffffc566);canvas.drawRect(left+3,keyboardTop+3,right-3,bottom-3,paint);paint.setStyle(Paint.Style.FILL);}
            color(black?Color.WHITE:0xff182c43);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(Math.min(13*getResources().getDisplayMetrics().scaledDensity,(right-left)*.55f));
            canvas.drawText(NAMES[key%12]+(key/12+3),(left+right)/2,bottom-9,paint);
        }
        if(!playable){color(0x880e1725);canvas.drawRect(0,keyboardTop,width,getHeight(),paint);color(Color.WHITE);paint.setTextSize(14*getResources().getDisplayMetrics().scaledDensity);paint.setTextAlign(Paint.Align.CENTER);canvas.drawText("连接并确认 36 键固件后可演奏",width/2,keyboardTop+height*.85f,paint);}
        if(!history.isEmpty()&&isShown())postInvalidateDelayed(33);
    }
    private int hit(MotionEvent event,int index){return touch.keyAt(event.getX(index),event.getY(index)-keyboardTop,getWidth(),getHeight()-keyboardTop);}
    @Override public boolean onTouchEvent(MotionEvent event){
        if(!playable)return true;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
        int action=event.getActionMasked(),index=event.getActionIndex();
        if(action==MotionEvent.ACTION_CANCEL){release();return true;}
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN)touch.down(event.getPointerId(index),hit(event,index));
        else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP)touch.up(event.getPointerId(index));
        else if(action==MotionEvent.ACTION_MOVE)for(int i=0;i<event.getPointerCount();i++)touch.move(event.getPointerId(i),hit(event,i));
        publish();if(action==MotionEvent.ACTION_UP)performClick();return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
