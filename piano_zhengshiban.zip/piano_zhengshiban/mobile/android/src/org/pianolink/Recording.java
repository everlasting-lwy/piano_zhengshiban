package org.pianolink;
import java.util.*;
public final class Recording {
    public static final class Event {public final long ms;public final int mask,voices;public Event(long t,int m,int v){ms=t;mask=m;voices=v;}}
    public static final int MAX_EVENTS=100000;public static final long MAX_MS=86400000;
    private final ArrayList<Event> data=new ArrayList<>();private boolean active;private boolean incomplete;private long previous=-1,elapsed;
    public synchronized void start(){data.clear();active=true;incomplete=false;previous=-1;elapsed=0;}
    public synchronized void stop(){active=false;}
    public synchronized boolean isActive(){return active;}
    public synchronized boolean isIncomplete(){return incomplete;}
    public synchronized void markIncomplete(){incomplete=true;}
    public synchronized void accept(Protocol.Frame f){
        if(!active||f.cmd!=0x82)return;
        long timestamp=(f.d[0]|((long)f.d[1]<<8)|((long)f.d[2]<<16)|((long)f.d[3]<<24));
        if(previous!=-1){long delta=(timestamp-previous)&0xffffffffL;if(delta>0x7fffffffL){incomplete=true;return;}elapsed+=delta;}
        previous=timestamp;if(data.size()>=MAX_EVENTS||elapsed>MAX_MS){incomplete=true;active=false;return;}
        data.add(new Event(elapsed,f.mask(),f.voices()));
    }
    public synchronized List<Event> events(){return new ArrayList<>(data);}
    public synchronized int count(){return data.size();}
    public synchronized long duration(){return data.isEmpty()?0:data.get(data.size()-1).ms;}
    public synchronized String toCsv(){StringBuilder s=new StringBuilder("# PianoLink v1; incomplete="+incomplete+"\ntime_ms,mask,voices\n");for(Event e:data)s.append(e.ms).append(',').append(e.mask).append(',').append(e.voices).append('\n');return s.toString();}
    public synchronized void fromCsv(String text){
        if(active)throw new IllegalArgumentException("请先停止录制");
        ArrayList<Event> loaded=new ArrayList<>();boolean header=false,flag=false;long last=-1;
        for(String line:text.split("\\r?\\n")){
            line=line.trim();if(line.isEmpty())continue;if(line.startsWith("#")){if(line.contains("incomplete=true"))flag=true;continue;}
            if(!header){if(!line.equals("time_ms,mask,voices"))throw new IllegalArgumentException("CSV 表头应为 time_ms,mask,voices");header=true;continue;}
            String[] columns=line.split(",",-1);if(columns.length!=3)throw new IllegalArgumentException("CSV 每行需要三列");
            long t;int m,v;try{t=Long.parseLong(columns[0].trim());m=Integer.parseInt(columns[1].trim());v=Integer.parseInt(columns[2].trim());}catch(NumberFormatException e){throw new IllegalArgumentException("CSV 数字无效");}
            if(t<0||t>MAX_MS||t<last||m<0||m>4095||v<0||v>15||loaded.size()>=MAX_EVENTS)throw new IllegalArgumentException("CSV 时间、键位或声部超出范围");
            loaded.add(new Event(t,m,v));last=t;
        }
        if(!header||loaded.isEmpty())throw new IllegalArgumentException("CSV 没有事件");
        data.clear();data.addAll(loaded);incomplete=flag;
    }
}
