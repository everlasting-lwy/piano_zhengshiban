package org.pianolink;

import java.io.*;

/** Temporary little-endian mono22050 spool; never retains a whole recording in memory. */
public final class AudioPcmSink implements Closeable,PcmWavReader.MonoSink {
    private final OutputStream output;
    private final AudioDsp.Cancellation cancellation;
    private AudioDsp.Resampler resampler;
    private int sampleRate;
    private double durationSeconds;
    private long count;
    private boolean closed;
    public AudioPcmSink(File destination,AudioDsp.Cancellation cancellation) throws IOException {
        output=new BufferedOutputStream(new FileOutputStream(destination),32768);this.cancellation=cancellation;
    }
    public void setSampleRate(int rate) throws IOException {
        AudioDsp.checkCancelled(cancellation);
        if(rate==sampleRate)return;
        if(resampler!=null)resampler.finish(this::writeSample);
        resampler=new AudioDsp.Resampler(rate,BasicPitchWindowing.SAMPLE_RATE);sampleRate=rate;
    }
    public void samples(float[] samples,int length) throws IOException {
        AudioDsp.checkCancelled(cancellation);
        if(closed||resampler==null)throw new IOException("PCM 输出未初始化或已关闭");
        durationSeconds+=length/(double)sampleRate;
        if(durationSeconds>600.00001)throw new IOException("音频超过 10 分钟上限");
        resampler.accept(samples,0,length,this::writeSample);
    }
    private void writeSample(float value) throws IOException {
        if((count&4095)==0)AudioDsp.checkCancelled(cancellation);
        if(count>=600L*BasicPitchWindowing.SAMPLE_RATE)throw new IOException("音频超过 10 分钟上限");
        int bits=Float.floatToIntBits(value);
        output.write(bits);output.write(bits>>>8);output.write(bits>>>16);output.write(bits>>>24);count++;
    }
    public long sampleCount(){return count;}
    public void close() throws IOException {
        if(closed)return;
        try {
            AudioDsp.checkCancelled(cancellation);
            if(resampler!=null)resampler.finish(this::writeSample);
        } finally {closed=true;output.close();}
    }
}
