package org.pianolink;

import java.io.*;

/** Interleaved codec PCM with carry for output buffers ending inside a sample/frame. */
public final class PcmByteDecoder {
    private final int channels,encoding,width;
    private final byte[] frame;
    private int carry;
    public PcmByteDecoder(int channels,int encoding) throws IOException {
        if(channels<1||channels>8)throw new IOException("解码器声道数不支持");
        this.channels=channels;this.encoding=encoding;
        switch(encoding){case 3:width=1;break;case 2:width=2;break;case 21:width=3;break;case 4:case 22:width=4;break;
            default:throw new IOException("系统解码器 PCM 编码不支持："+encoding);}
        frame=new byte[width*channels];
    }
    public void accept(byte[] data,int offset,int length,PcmWavReader.MonoSink sink) throws IOException {
        if(offset<0||length<0||offset>data.length-length)throw new IndexOutOfBoundsException();
        float[] mono=new float[4096];int count=0;
        for(int at=offset;at<offset+length;) {
            int bytes=Math.min(frame.length-carry,offset+length-at);
            System.arraycopy(data,at,frame,carry,bytes);carry+=bytes;at+=bytes;
            if(carry<frame.length)continue;
            double sum=0;
            for(int channel=0;channel<channels;channel++) {
                int p=channel*width,raw=frame[p]&255;
                for(int b=1;b<width;b++)raw|=(frame[p+b]&255)<<(8*b);
                float value;
                switch(encoding) {
                    case 3:value=(raw-128)/128f;break;
                    case 2:value=(short)raw/32768f;break;
                    case 21:value=(raw<<8>>8)/8388608f;break;
                    case 4:value=Float.intBitsToFloat(raw);break;
                    default:value=(float)(raw/2147483648.0);
                }
                if(Float.isNaN(value)||Float.isInfinite(value))throw new IOException("系统解码器返回无效 PCM");
                sum+=Math.max(-1,Math.min(1,value));
            }
            mono[count++]=(float)(sum/channels);carry=0;
            if(count==mono.length){sink.samples(mono,count);count=0;}
        }
        if(count>0)sink.samples(mono,count);
    }
    public void finish() throws IOException {if(carry!=0)throw new IOException("系统解码 PCM 已截断");}
}
