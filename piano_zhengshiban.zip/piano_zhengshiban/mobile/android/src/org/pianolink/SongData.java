package org.pianolink;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable, explicitly versioned note snapshots shared by storage and playback. */
public final class SongData {
    public enum Format { LEGACY12, ABSOLUTE36 }
    public static final int MAX_EVENTS = 100000;
    public static final long MAX_MS = 86400000L;
    public static final int MAX_CSV_BYTES = 8 * 1024 * 1024;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    public static final class Event {
        public final long ms, mask;
        public final int voices;
        public Event(long ms, long mask, int voices) {
            this.ms = ms;
            this.mask = mask;
            this.voices = voices;
        }
    }

    public final Format format;
    public final List<Event> events;
    public final boolean incomplete;

    public SongData(Format format, List<Event> events, boolean incomplete) {
        if (format == null || events == null || events.isEmpty())
            throw new IllegalArgumentException("曲目没有事件或格式无效");
        if (events.size() > MAX_EVENTS)
            throw new IllegalArgumentException("曲目超过100000个事件");
        long last = -1;
        long maximum = format == Format.LEGACY12 ? 4095L : 68719476735L;
        ArrayList<Event> copy = new ArrayList<Event>(events.size());
        for (Event event : events) {
            if (event == null || event.ms < 0 || event.ms > MAX_MS || event.ms < last
                    || event.mask < 0 || event.mask > maximum || event.voices < 0 || event.voices > 15)
                throw new IllegalArgumentException("曲目时间、键位或声部超出范围");
            copy.add(event);
            last = event.ms;
        }
        this.format = format;
        this.events = Collections.unmodifiableList(copy);
        this.incomplete = incomplete;
    }

    public long durationMs() { return events.get(events.size() - 1).ms; }

    public String toCsv() {
        StringBuilder csv = new StringBuilder();
        csv.append("# PianoLink ").append(format == Format.LEGACY12 ? "v1" : "v2")
                .append("; incomplete=").append(incomplete).append('\n');
        csv.append(format == Format.LEGACY12 ? "time_ms,mask,voices\n" : "time_ms,mask36,voices\n");
        for (Event event : events)
            csv.append(event.ms).append(',').append(event.mask).append(',').append(event.voices).append('\n');
        return csv.toString();
    }

    public static SongData fromCsv(String text) {
        if (text == null || text.length() > MAX_CSV_BYTES || text.getBytes(UTF8).length > MAX_CSV_BYTES)
            throw new IllegalArgumentException("CSV为空或超过8MB");
        ArrayList<Event> events = new ArrayList<Event>();
        Format format = null;
        boolean incomplete = false;
        BufferedReader reader = new BufferedReader(new StringReader(text));
        try {
            String line;
            boolean first = true;
            while ((line = reader.readLine()) != null) {
                if (first && line.startsWith("\ufeff")) line = line.substring(1);
                first = false;
                line = line.trim();
                if (line.length() == 0) continue;
                if (line.startsWith("#")) {
                    if (line.matches(".*(?:^|[ ;])incomplete=true(?:[ ;].*)?$")) incomplete = true;
                    continue;
                }
                if (format == null) {
                    if (line.equals("time_ms,mask,voices")) format = Format.LEGACY12;
                    else if (line.equals("time_ms,mask36,voices")) format = Format.ABSOLUTE36;
                    else throw new IllegalArgumentException("CSV表头应为time_ms,mask,voices或time_ms,mask36,voices");
                    continue;
                }
                if (events.size() >= MAX_EVENTS) throw new IllegalArgumentException("CSV超过100000个事件");
                String[] columns = line.split(",", -1);
                if (columns.length != 3) throw new IllegalArgumentException("CSV每行需要三列");
                long ms = decimal(columns[0]);
                long mask = decimal(columns[1]);
                long voices = decimal(columns[2]);
                if (voices > 15) throw new IllegalArgumentException("CSV声部超出范围");
                events.add(new Event(ms, mask, (int) voices));
            }
        } catch (IOException impossible) {
            throw new IllegalArgumentException("无法读取CSV", impossible);
        }
        return new SongData(format, events, incomplete);
    }

    private static long decimal(String text) {
        text = text.trim();
        if (text.length() == 0) throw new IllegalArgumentException("CSV数字无效");
        for (int i = 0; i < text.length(); i++)
            if (text.charAt(i) < '0' || text.charAt(i) > '9') throw new IllegalArgumentException("CSV需要非负十进制整数");
        try { return Long.parseLong(text); }
        catch (NumberFormatException invalid) { throw new IllegalArgumentException("CSV数字超出范围", invalid); }
    }

    public static SongData fromRecording(Recording recording) {
        if (recording == null) throw new IllegalArgumentException("录制为空");
        synchronized (recording) {
            ArrayList<Event> events = new ArrayList<Event>();
            for (Recording.Event event : recording.events()) events.add(new Event(event.ms, event.mask, event.voices));
            return new SongData(Format.LEGACY12, events, recording.isIncomplete());
        }
    }
}
