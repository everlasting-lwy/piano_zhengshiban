package org.pianolink;
import java.util.*;

/** Byte-stream device model. Physical/remote keys share pitches and four voices. */
public final class MockFpga {
    /** In-memory ordinary-file persistence model, NOT SPI/FAT32 or real hardware. */
    public static final class SdCard {
        private final byte[][] files=new byte[32][];private final HashMap<Long,byte[]> sectors=new HashMap<>();private final long capacity=66586;
        public SdCard(){byte[] boot=new byte[512];boot[0]=(byte)0xeb;boot[1]=0x58;boot[2]=(byte)0x90;put(boot,11,512,2);boot[13]=1;put(boot,14,32,2);boot[16]=2;boot[21]=(byte)0xf8;put(boot,32,capacity,4);put(boot,36,512,4);put(boot,44,2,4);put(boot,48,1,2);put(boot,50,6,2);boot[66]=0x29;System.arraycopy("FAT32   ".getBytes(java.nio.charset.StandardCharsets.US_ASCII),0,boot,82,8);boot[510]=85;boot[511]=(byte)170;sectors.put(0L,boot);sectors.put(6L,boot.clone());byte[] info=new byte[512];put(info,0,0x41615252L,4);put(info,484,0x61417272L,4);put(info,488,0xffffffffL,4);put(info,492,0xffffffffL,4);put(info,508,0xaa550000L,4);sectors.put(1L,info);sectors.put(7L,info.clone());byte[] fat=new byte[512];put(fat,0,0xaffffff8L,4);put(fat,4,0xafffffffL,4);put(fat,8,0xafffffffL,4);sectors.put(32L,fat);sectors.put(544L,fat.clone());}
        private byte[] read(long lba){byte[] value=sectors.get(lba);return value==null?new byte[512]:value.clone();}
        private void write(long lba,byte[] data){sectors.put(lba,data.clone());}
    }
    private static void put(byte[] bytes,int offset,long value,int count){for(int i=0;i<count;i++)bytes[offset+i]=(byte)(value>>>(i*8));}
    private static long uint(byte[] bytes,int offset,int count){long value=0;for(int i=0;i<count;i++)value|=(bytes[offset+i]&255L)<<(i*8);return value;}
    private final int sdVersion;
    private final SdCard sdCard;private final byte[] sdTitle=new byte[32];private byte[] savedFile;
    private int sdState=1,sdError,sdProgress,sdSelected=255,sdFlags=3,sdAction,sdSlot=255,sdRevision;private long sdToken,sdDoneAt;
    private boolean rpcActive,rpcUncertain,rpcCacheValid,rpcWriteOperation;private long rpcToken,rpcActivity,rpcDoneAt,rpcLba;private int rpcState,rpcError,rpcId,rpcPreparedId,rpcFill,rpcLastFill=-4,rpcCrc;private byte[] rpcBuffer=new byte[512],rpcLastData;
    public MockFpga(){this(new SdCard(),1);}
    public MockFpga(SdCard card){this(card,1);}
    public MockFpga(SdCard card,int version){if(card==null||version<1||version>2)throw new IllegalArgumentException();sdCard=card;sdVersion=version;if(version==2)scanSectorFiles();for(int i=0;i<32;i++)if(card.files[i]!=null){try{song=P18File.decode(card.files[i]).masks;sdSelected=i;songRestart();break;}catch(IllegalArgumentException ignored){}}}
    private static final int[] SEMITONES={0,2,4,5,7,9,11,1,3,6,8,10};
    private int timbre,volume=8,octave,legacyRemote,eventSeq,previousLegacy;
    private long physicalMask,remoteMask,previousAbsolute,refreshed;
    private boolean extended,previousExtended,overflow;
    private final ArrayDeque<byte[]> events=new ArrayDeque<>();
    private final ArrayDeque<byte[]> visuals=new ArrayDeque<>();
    private final int[] effects={0,0,0,15,8,0,0,0};private int visualKind,guideStep;
    private boolean guideAwait,guideWrong;
    private int[] song=new int[0],staging;private int songIndex,stageCount,stageCrc;
    private boolean songActive,songWrong,songArmed;private int stageReceived;private boolean committedRetry;
    private long absolute(){
        long remote=remoteMask;
        if(!extended){remote=0;int shift=octave==1?24:octave==2?0:12;
            for(int n=0;n<12;n++)if((legacyRemote&(1<<n))!=0)remote|=1L<<(shift+SEMITONES[n]);}
        return physicalMask|remote;
    }
    private int legacy(){
        int bits=extended?0:legacyRemote;
        for(int n=0;n<12;n++)if((physicalMask&(1L<<(12+SEMITONES[n])))!=0)bits|=1<<n;
        return bits;
    }
    private int voices(){return (1<<Math.min(4,Long.bitCount(absolute())))-1;}
    private byte[] state36(int seq,int command){long keys=absolute()&Protocol.EXTENDED_MASK;
        return Protocol.encode(seq,command,(int)keys&255,(int)(keys>>>8)&255,(int)(keys>>>16)&255,(int)(keys>>>24)&255,((int)(keys>>>32)&15)|(voices()<<4),0x20|(overflow?128:0));}
    private void publish(long now){
        long keys=absolute()&Protocol.EXTENDED_MASK;int low=legacy();
        boolean changed=extended?(keys!=previousAbsolute||!previousExtended):(low!=previousLegacy||previousExtended);
        if(changed){byte[] event=extended?state36(eventSeq++,0x84):Protocol.encode(eventSeq++,0x82,(int)now,(int)(now>>>8),(int)(now>>>16),(int)(now>>>24),low&255,(low>>>8)|(voices()<<4));
            if(events.size()==16)overflow=true;else events.add(event);}
        previousAbsolute=keys;previousLegacy=low;previousExtended=extended;
    }
    /** Host simulation hook; absolute bit0=MIDI48. No Android or serial side effects. */
    public void physicalKeys(long mask,long now){if((mask&~0xffffffffffffL)!=0)throw new IllegalArgumentException();physicalMask=mask;
        int physical=physicalBits();if(songActive){if(physical==0){songArmed=true;songWrong=false;}else if(songArmed&&songIndex<song.length){int target=song[songIndex];if((physical&~target)!=0)songWrong=true;else if(!songWrong&&physical==target){songIndex++;songArmed=false;}}}
        if(effects[7]!=0&&visualKind==4){int bits=physicalBits(),target=guideTarget();if(bits==0){if(guideAwait)guideStep=(guideStep+1)%(effects[7]==1?8:18);guideAwait=false;guideWrong=false;}else if(bits!=target){guideWrong=true;guideAwait=false;}else if(!guideWrong)guideAwait=true;}
        publish(now);}
    private int physicalBits(){int bits=0;for(int i=0;i<18;i++){int offset=i<12?SEMITONES[i]:i;if((physicalMask&(1L<<(12+offset)))!=0)bits|=1<<i;}return bits;}
    private int guideTarget(){if(effects[7]==0)return 0;if(effects[7]==1)return 1<<(guideStep==7?12:guideStep);int[] order={0,7,1,8,2,3,9,4,10,5,11,6,12,13,14,15,16,17};return 1<<order[guideStep];}
    private byte[] effectsState(int seq){return Protocol.encode(seq,0x85,(effects[1]<<4)|effects[0],(effects[3]<<4)|effects[2],(effects[7]<<6)|(effects[6]<<4)|effects[5],0x80|effects[4],(visualKind<<5)|guideStep,0x31);}
    /** Synthetic drawings exercise transport/rendering only; they are not FPGA DSP or audio. */
    private void visual(int seq,int kind,long now){visuals.clear();visualKind=kind;if(kind==0)return;int count=kind==1?16:kind==2?8:kind==3?32:1;
        visuals.add(Protocol.encode(seq,0x86,kind,count,(int)now,(int)(now>>>8),(int)(now>>>16),(int)(now>>>24)));
        for(int i=0;i<count;i++){int[] points=new int[4];for(int n=0;n<4;n++){int index=i*4+n;points[n]=kind==2?(int)(210*Math.exp(-index*.17)*(0.4+0.6*Math.abs(Math.sin(index+now*.001)))):(int)(128+95*Math.sin(index*(kind==3?.17:.25)+now*.002));}
            if(kind==4){int bits=physicalBits();points=new int[]{bits&255,(bits>>>8)&255,((bits>>>16)&3)|(effects[7]<<2)|((physicalBits()!=0&&(physicalBits()!=guideTarget()||guideWrong))?16:0),guideStep};}
            visuals.add(Protocol.encode(seq,0x87,kind,i,points[0],points[1],points[2],points[3]));}}
    public byte[] accept(byte[] b,long now){
        Protocol.Frame f=Protocol.decode(b);if(f==null)return null;int cmd=f.cmd,status=0;
        sdTick(now);
        rpcTick(now);
        if(Session.isBlockRpc(cmd))return sdVersion==2?rpcRequest(f,now):Protocol.encode(f.seq,0x80,cmd,2,1,0,0,0);
        if(cmd>=0x16&&cmd<=0x1b)return sdRequest(f,now);
        if(sdState==2&&(cmd==0x10||cmd==0x11||cmd==0x12||cmd==0x13&&(f.d[0]==3||f.d[0]==4)))return Protocol.encode(f.seq,0x80,cmd,3,1,0,0,0);
        if(cmd>=0x0f&&cmd<=0x15)return songRequest(f);
        int firstReserved=(cmd==4||cmd==7||cmd==13)?2:(cmd==9||cmd==10)?5:(cmd>=1&&cmd<=3)||cmd==14?1:0;
        for(int i=firstReserved;i<6;i++)if(f.d[i]!=0)status=1;
        if((cmd==1&&f.d[0]>3)||(cmd==2&&f.d[0]>15)||(cmd==3&&f.d[0]>2)||((cmd==4||cmd==7)&&f.d[1]>15)||((cmd==9||cmd==10)&&f.d[4]>15))status=1;
        if(cmd==13&&(f.d[0]>7||f.d[1]>(f.d[0]==4?16:f.d[0]>=6?2:15)))status=1;
        if(cmd==14&&f.d[0]>4)status=1;
        if(cmd<1||cmd>14)status=2;
        if(status==0)switch(cmd){
            case 1:timbre=f.d[0];break;case 2:volume=f.d[0];break;case 3:octave=f.d[0];break;
            case 4:case 7:legacyRemote=f.mask();remoteMask=0;extended=false;refreshed=now;break;
            case 9:case 10:remoteMask=f.extendedMask();legacyRemote=0;extended=true;refreshed=now;break;
            case 5:legacyRemote=0;remoteMask=0;refreshed=now;break;
            case 8:overflow=false;break;
            case 13:effects[f.d[0]]=f.d[1];if(f.d[0]==7){guideStep=0;guideAwait=false;guideWrong=false;}break;
            case 14:visual(f.seq,f.d[0],now);break;
        }
        publish(now);
        if(cmd==6&&status==0){int keys=legacy();return Protocol.encode(f.seq,0x81,timbre,volume,octave,overflow?128:0,keys&255,(keys>>>8)|(voices()<<4));}
        if(cmd==11&&status==0)return state36(f.seq,0x83);
        if(cmd==12&&status==0)return effectsState(f.seq);
        return Protocol.encode(f.seq,0x80,cmd,status,1,overflow?1:0,0,0);
    }
    public byte[] pollEvent(){byte[] event=events.poll();return event!=null?event:visuals.poll();}
    public void tick(long now){sdTick(now);rpcTick(now);if((legacyRemote!=0||remoteMask!=0)&&now-refreshed>=2000){legacyRemote=0;remoteMask=0;publish(now);}}
    private void sdTick(long now){if(sdState!=2||now<sdDoneAt)return;sdState=1;sdProgress=100;sdFlags=11;sdError=0;try{if(sdAction==1){sdCard.files[sdSlot]=savedFile;sdSelected=sdSlot;sdRevision=(sdRevision+1)&255;}else if(sdAction==2){if(sdCard.files[sdSlot]==null)throw new IllegalArgumentException();song=P18File.decode(sdCard.files[sdSlot]).masks;sdSelected=sdSlot;songRestart();}else if(sdAction==3){sdCard.files[sdSlot]=null;sdRevision=(sdRevision+1)&255;}else{if(sdVersion==2&&!scanSectorFiles())throw new IllegalArgumentException();sdRevision=(sdRevision+1)&255;}}catch(IllegalArgumentException e){sdState=4;sdFlags=3;sdError=32;}savedFile=null;}
    private byte[] sdRequest(Protocol.Frame f,long now){int cmd=f.cmd,status=0;int[] d=f.d;
        if(cmd==0x17){int op=d[0],slot=d[1];long token=SdLibraryProtocol.token(d,2);if(sdVersion==2&&(op==1||op==3))status=2;else if(op>3||token==0||(op==0?slot!=255:slot>=32))status=1;else if(rpcActive)status=3;else if(token==sdToken){if(op!=sdAction||slot!=sdSlot)status=1;}else if(sdState==2||staging!=null)status=3;else if(op==1&&song.length==0)status=1;else{if(op==1){int length=0;while(length<32&&sdTitle[length]!=0)length++;try{savedFile=P18File.encode(SdLibraryProtocol.decodeTitle(sdTitle,length),song);}catch(IllegalArgumentException e){status=1;}}if(status==0){sdToken=token;sdAction=op;sdSlot=slot;sdState=2;sdError=0;sdProgress=0;sdFlags=7;sdDoneAt=now+600;}}}
        else if(cmd==0x18){int offset=d[0];if(sdVersion==2)status=2;else if(offset>30||offset%5!=0)status=1;else if(sdState==2)status=3;else{for(int i=0;i<5;i++)if(offset+i>=32&&d[i+1]!=0)status=1;if(status==0)for(int i=0;i<5&&offset+i<32;i++)sdTitle[offset+i]=(byte)d[i+1];}}
        else{int reserved=cmd==0x19?1:cmd==0x1a?2:0;for(int i=reserved;i<6;i++)if(d[i]!=0)status=1;if((cmd==0x19||cmd==0x1a)&&d[0]>=32)status=1;if(cmd==0x1a&&d[1]>31)status=1;
            if(status==0){if(cmd==0x16)return Protocol.encode(f.seq,0x8b,sdVersion,rpcActive?2:sdState,sdError,sdProgress,sdSelected,(sdFlags&~4)|(rpcActive||sdState==2?4:0)|(rpcUncertain?16:0));if(cmd==0x1b)return Protocol.encode(f.seq,0x8e,(int)sdToken&255,(int)(sdToken>>>8)&255,(int)(sdToken>>>16)&255,(int)(sdToken>>>24)&255,sdAction,sdSlot);
                byte[] file=sdCard.files[d[0]];P18File score=null;if(file!=null)try{score=P18File.decode(file);}catch(IllegalArgumentException ignored){}
                if(cmd==0x19){int count=score==null?0:score.masks.length;return Protocol.encode(f.seq,0x8c,d[0],score!=null?1:file!=null?4:0,count&255,count>>>8,score==null?0:file[9]&255,sdRevision);}
                if(cmd==0x1a){int[] out=new int[6];out[0]=d[1];for(int i=0;i<5;i++)if(score!=null&&d[1]+i<32)out[i+1]=file[16+d[1]+i]&255;return new Protocol.Frame(f.seq,0x8d,out).bytes();}}}
        return Protocol.encode(f.seq,0x80,cmd,status,sdVersion,0,0,0);
    }
    private void rpcTick(long now){if(rpcState==1||rpcState==2){if(now>=rpcDoneAt){if(rpcState==1)rpcBuffer=sdCard.read(rpcLba);else{sdCard.write(rpcLba,rpcBuffer);if(!Arrays.equals(sdCard.read(rpcLba),rpcBuffer)){rpcError=13;rpcUncertain=true;rpcState=3;return;}}rpcState=0;rpcError=0;rpcCacheValid=true;}}else if(rpcActive&&now-rpcActivity>=30000){rpcActive=false;rpcCacheValid=false;rpcFill=0;}}
    private byte[] rpcRequest(Protocol.Frame f,long now){int cmd=f.cmd,status=0;int[] d=f.d;boolean busy=rpcState==1||rpcState==2;long lba=SdLibraryProtocol.token(d,0);int id=d[4]|d[5]<<8;
        if(cmd==0x20){long token=SdLibraryProtocol.token(d,1);if(d[0]>1||token==0||d[5]!=0)status=1;else if(d[0]==0){if(rpcActive&&rpcToken==token){}else if(rpcActive||busy||sdState==2)status=3;else if(rpcUncertain)status=2;else{rpcActive=true;rpcToken=token;rpcCacheValid=false;rpcFill=0;rpcId=0;rpcError=0;rpcState=0;rpcPreparedId=0;rpcLastFill=-4;rpcWriteOperation=false;}}else if(token!=rpcToken)status=1;else if(busy)status=3;else{rpcActive=false;rpcCacheValid=false;rpcFill=0;}}
        else if(cmd==0x26){for(int value:d)if(value!=0)status=1;if(status==0)return Protocol.encode(f.seq,0x92,rpcState,rpcError,(rpcActive?1:0)|(rpcCacheValid?2:0)|(rpcFill==512?4:0)|8|(rpcUncertain?16:0),rpcId&255,rpcId>>>8,0);}
        else if(cmd==0x28){for(int value:d)if(value!=0)status=1;if(status==0)return Protocol.encode(f.seq,0x93,(int)sdCard.capacity&255,(int)(sdCard.capacity>>>8)&255,(int)(sdCard.capacity>>>16)&255,(int)(sdCard.capacity>>>24)&255,1,2);}
        else if(!rpcActive)status=2;
        else if(cmd==0x21){if(id==0||lba>=sdCard.capacity)status=1;else if(id==rpcId){if(rpcWriteOperation||lba!=rpcLba)status=1;}else if(busy)status=3;else{rpcId=id;rpcLba=lba;rpcWriteOperation=false;rpcState=1;rpcError=0;rpcCacheValid=false;rpcDoneAt=now+80;}}
        else if(cmd==0x24){int prepared=d[0]|d[1]<<8;for(int i=2;i<6;i++)if(d[i]!=0)status=1;if(prepared==0)status=1;if(busy)status=3;if(status==0&&prepared!=rpcPreparedId){rpcPreparedId=prepared;rpcBuffer=new byte[512];rpcFill=0;rpcLastFill=-4;rpcCacheValid=false;}}
        else if(cmd==0x22){int offset=d[0]|d[1]<<8;byte[] data={(byte)d[2],(byte)d[3],(byte)d[4],(byte)d[5]};if(busy)status=3;else if(rpcPreparedId==0||offset>508||offset%4!=0)status=1;else if(offset==rpcLastFill&&Arrays.equals(data,rpcLastData)){}else if(offset!=rpcFill)status=1;else{System.arraycopy(data,0,rpcBuffer,offset,4);rpcLastFill=offset;rpcLastData=data;rpcFill+=4;}}
        else if(cmd==0x23){int crc=d[4]|d[5]<<8;if(rpcPreparedId==rpcId){if(!rpcWriteOperation||rpcLba!=lba||rpcCrc!=crc)status=1;}else if(busy)status=3;else if(rpcUncertain)status=2;else if(lba>=sdCard.capacity||rpcPreparedId==0||rpcFill!=512||crc!=OledGuideProtocol.crc16(rpcBuffer))status=1;else{rpcId=rpcPreparedId;rpcCrc=crc;rpcLba=lba;rpcWriteOperation=true;rpcState=2;rpcError=0;rpcCacheValid=false;rpcDoneAt=now+80;}}
        else if(cmd==0x25){int offset=d[0]|d[1]<<8;for(int i=2;i<6;i++)if(d[i]!=0)status=1;if(offset>508||offset%4!=0)status=1;if(!rpcCacheValid||busy)status=3;if(status==0){rpcActivity=now;return Protocol.encode(f.seq,0x91,d[0],d[1],rpcBuffer[offset]&255,rpcBuffer[offset+1]&255,rpcBuffer[offset+2]&255,rpcBuffer[offset+3]&255);}}
        if(rpcActive)rpcActivity=now;return Protocol.encode(f.seq,0x80,cmd,status,2,0,0,0);
    }
    /** Independent bounded file reader for the sector simulator, not an FPGA FAT validation claim. */
    private boolean scanSectorFiles(){Arrays.fill(sdCard.files,null);try{byte[] boot=sdCard.read(0);if(uint(boot,11,2)!=512||boot[13]!=1||uint(boot,14,2)!=32||uint(boot,36,4)!=512||boot[16]!=2)return false;if((uint(sdCard.read(32),4,4)&0x0c000000L)!=0x0c000000L)return false;long cluster=uint(boot,44,4);HashSet<Long> roots=new HashSet<>();while(cluster>=2&&cluster<65532){if(!roots.add(cluster)||roots.size()>4096)return false;byte[] root=sdCard.read(1056+cluster-2);for(int offset=0;offset<512;offset+=32){if(root[offset]==0)return true;if((root[offset]&255)==229||root[offset+11]==15||(root[offset+11]&0x18)!=0)continue;String name=new String(root,offset,11,java.nio.charset.StandardCharsets.US_ASCII);if(!name.matches("P00000(?:0[0-9]|[12][0-9]|3[01])P18"))continue;int slot=Integer.parseInt(name.substring(1,8));int length=(int)uint(root,offset+28,4);if(length<67||length>6208)continue;long first=uint(root,offset+26,2)|(uint(root,offset+20,2)<<16);byte[] file=new byte[length];int copied=0;HashSet<Long> chain=new HashSet<>();while(copied<length){if(first<2||first>=65532||!chain.add(first)||chain.size()>13)throw new IllegalArgumentException();byte[] sector=sdCard.read(1056+first-2);int count=Math.min(512,length-copied);System.arraycopy(sector,0,file,copied,count);copied+=count;first=uint(sdCard.read(32+first/128),(int)(first%128)*4,4)&0x0fffffffL;}sdCard.files[slot]=file;}cluster=uint(sdCard.read(32+cluster/128),(int)(cluster%128)*4,4)&0x0fffffffL;if(cluster>=0x0ffffff8L)return true;}return false;}catch(RuntimeException error){return false;}}
    private void songRestart(){songIndex=0;songWrong=false;songArmed=physicalBits()==0;}
    private byte[] songRequest(Protocol.Frame f){int cmd=f.cmd,status=0;int[] d=f.d;
        if(cmd==0x10){int count=d[0]|d[1]<<8,c=d[2]|d[3]<<8;if(count<1||count>2048||d[4]!=1||d[5]!=0)status=1;
            else if(staging==null||stageCount!=count||stageCrc!=c){staging=new int[count];stageCount=count;stageCrc=c;stageReceived=0;committedRetry=false;}}
        else if(cmd==0x11){int index=d[0]|d[1]<<8,mask=d[2]|d[3]<<8|d[4]<<16;if(!OledGuideProtocol.validMask(mask)||d[5]!=0)status=1;else if(staging==null)status=3;else if(index==stageReceived&&index<stageCount){staging[index]=mask;stageReceived++;}else if(index!=stageReceived-1||staging[index]!=mask)status=3;}
        else if(cmd==0x13){for(int i=1;i<6;i++)if(d[i]!=0)status=1;if(d[0]>4)status=1;if(status==0)switch(d[0]){case 0:songActive=false;songWrong=false;break;case 1:songActive=true;songRestart();break;case 2:songRestart();break;case 3:song=new int[0];staging=null;committedRetry=false;songRestart();break;case 4:staging=null;committedRetry=false;break;}}
        else {for(int value:d)if(value!=0)status=1;
            if(status==0){if(cmd==0x0f)return Protocol.encode(f.seq,0x88,0x47,1,0,8,18,4);
                if(cmd==0x12){if(staging==null){if(!committedRetry)status=3;}else if(stageReceived!=stageCount)status=3;else if(OledGuideProtocol.crcMasks(staging)!=stageCrc){status=1;staging=null;}else {song=staging;staging=null;committedRetry=true;songRestart();}}
                if(cmd==0x14)return Protocol.encode(f.seq,0x89,songIndex&255,songIndex>>>8,song.length&255,song.length>>>8,(song.length>0?1:0)|(songActive?2:0)|(song.length>0&&songIndex==song.length?4:0)|(staging!=null?8:0)|(songWrong?16:0),1);
                if(cmd==0x15){int target=songIndex<song.length?song[songIndex]:0,physical=physicalBits();return Protocol.encode(f.seq,0x8a,target&255,(target>>>8)&255,target>>>16,physical&255,(physical>>>8)&255,physical>>>16);}}}
        return Protocol.encode(f.seq,0x80,cmd,status,1,0,0,0);
    }
}
