package org.pianolink;
import java.util.Arrays;

/** Ordinary P18 file codec shared with the explicitly simulated SD card. */
public final class P18File {
    public final String title;public final int[] masks;
    private P18File(String title,int[] masks){this.title=title;this.masks=masks;}
    public static byte[] encode(String title,int[] masks){if(masks==null||masks.length<1||masks.length>2048)throw new IllegalArgumentException("P18须为1至2048步");int crc=OledGuideProtocol.crcMasks(masks);byte[] data=new byte[64+masks.length*3];System.arraycopy(new byte[]{80,49,56,71,85,73,68,69},0,data,0,8);data[8]=1;byte[] name=SdLibraryProtocol.title(title);int length=0;while(length<32&&name[length]!=0)length++;data[9]=(byte)length;put16(data,10,masks.length);put16(data,12,crc);System.arraycopy(name,0,data,16,32);put16(data,62,OledGuideProtocol.crc16(Arrays.copyOf(data,62)));for(int i=0;i<masks.length;i++)for(int b=0;b<3;b++)data[64+i*3+b]=(byte)(masks[i]>>>(b*8));return data;}
    private static void put16(byte[] bytes,int index,int value){bytes[index]=(byte)value;bytes[index+1]=(byte)(value>>>8);}
    private static int u16(byte[] bytes,int index){return (bytes[index]&255)|(bytes[index+1]&255)<<8;}
    public static P18File decode(byte[] data){if(data==null||data.length<67||data.length>6208||!Arrays.equals(Arrays.copyOf(data,8),new byte[]{80,49,56,71,85,73,68,69})||data[8]!=1)throw new IllegalArgumentException("P18文件头无效");int length=data[9]&255,count=u16(data,10);if(length>32||count<1||count>2048||data.length!=64+3*count)throw new IllegalArgumentException("P18长度无效");if(data[14]!=0||data[15]!=0)throw new IllegalArgumentException("P18保留字节无效");for(int i=16+length;i<62;i++)if(data[i]!=0)throw new IllegalArgumentException("P18标题填充/保留字节无效");if(u16(data,62)!=OledGuideProtocol.crc16(Arrays.copyOf(data,62))||u16(data,12)!=OledGuideProtocol.crc16(Arrays.copyOfRange(data,64,data.length)))throw new IllegalArgumentException("P18 CRC错误");String title=SdLibraryProtocol.decodeTitle(Arrays.copyOfRange(data,16,48),length);int[] masks=new int[count];for(int i=0;i<count;i++){masks[i]=(data[64+i*3]&255)|(data[65+i*3]&255)<<8|(data[66+i*3]&255)<<16;if(!OledGuideProtocol.validMask(masks[i]))throw new IllegalArgumentException("P18实体键无效");}return new P18File(title,masks);}
}
