package org.pianolink;

import android.app.*;
import android.os.*;
import android.widget.*;
import java.util.concurrent.*;

/** 32 ordinary-file slots. Read-only polls never disable actions or rewrite identical text. */
public final class SdLibraryUi {
    public interface Host {SongData selected();String name();boolean save(int slot,String title,int[] masks);boolean load(int slot);boolean delete(int slot);boolean scan();void refresh();void message(String text);}
    private final Activity activity;private final Host host;private final Handler main=new Handler(Looper.getMainLooper());private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final TextView status,selection;private final Button save,load,delete,scan,refresh;private final Button[] slots=new Button[32];
    private SdLibraryFlow.State latest;private boolean connected,simulated,preparing,destroyed;private int selected;
    public SdLibraryUi(Activity activity,LinearLayout column,Host host){this.activity=activity;this.host=host;
        TextView title=new TextView(activity);title.setText("SD · FAT32 曲库（32槽）");title.setTextSize(17);title.setTextColor(0xff65ded6);column.addView(title);
        status=new TextView(activity);status.setTextColor(0xffe5edf6);column.addView(status);selection=new TextView(activity);selection.setTextColor(0xfff6cc7d);column.addView(selection);
        LinearLayout first=row(column);save=button(first,"保存所选曲目",()->preview());load=button(first,"载入槽位",()->{if(!host.load(selected))host.message("SD未就绪或设备事务忙，请等待后重试。");});delete=button(first,"删除槽位",()->confirmDelete());
        LinearLayout second=row(column);scan=button(second,"重新扫描SD",()->{if(!host.scan())host.message("设备事务忙或不支持SD，请等待后重试。");});refresh=button(second,"查询状态",()->host.refresh());
        for(int i=0;i<32;i+=2){LinearLayout line=row(column);for(int j=i;j<i+2;j++){final int slot=j;slots[j]=button(line,"",()->{selected=slot;render();});}}
        TextView help=new TextView(activity);help.setText("只管理根目录 P0000000.P18—P0000031.P18。电脑复制/删除后重新扫描。9600蓝牙传输可能需要数分钟，请保持连接。SD操作开始后不可取消，等待完成再拔卡/断电。切后台会继续传输。P18存目标步骤，不是自动演奏。");help.setTextColor(0xffc0ccda);help.setTextSize(12);column.addView(help);render();
    }
    private LinearLayout row(LinearLayout parent){LinearLayout row=new LinearLayout(activity);row.setOrientation(LinearLayout.HORIZONTAL);parent.addView(row);return row;}
    private Button button(LinearLayout row,String name,Runnable action){Button button=new Button(activity);button.setText(name);button.setTextSize(12);button.setAllCaps(false);button.setOnClickListener(v->action.run());row.addView(button,new LinearLayout.LayoutParams(0,-2,1));return button;}
    public void connection(boolean value,boolean simulation){connected=value;simulated=simulation;if(!value)latest=null;render();}
    public void snapshot(SdLibraryFlow.State value){latest=value;render();}
    private void confirmDelete(){final int target=selected;new AlertDialog.Builder(activity).setTitle("删除SD槽位 "+target+"？").setMessage("删除设备上的普通P18文件；手机原曲目保留。操作开始后不可取消。").setNegativeButton("保留",null).setPositiveButton("删除",(dialog,which)->{if(!host.delete(target))host.message("SD未就绪或设备事务忙。");}).show();}
    private void preview(){final SongData source=host.selected();if(source==null){host.message("请先在手机曲库选择一首已载入曲目。");return;}final String name=host.name();final int target=selected;final boolean direct=latest!=null&&latest.version==2;preparing=true;render();worker.execute(()->{try{OledGuideSong song=OledGuideSong.from(source);main.post(()->{if(destroyed)return;preparing=false;render();new AlertDialog.Builder(activity).setTitle("保存到SD槽位 "+target+" · "+name).setMessage(song.size()+" 步；折回八度 "+song.foldedNotes+" 音，合并 "+song.mergedNotes+" 音，舍去 "+song.droppedNotes+" 个低音（每步最高4音）。\n"+(direct?"直接保存普通P18文件，结束后由FPGA重新扫描确认。":"先完成本次RAM上传，再保存到SD。")+"已有槽位会被替换；设备完成前不会显示成功。SD写入开始后不可取消。").setNegativeButton("返回",null).setPositiveButton(direct?"保存到SD":"上传并保存",(dialog,which)->{if(!host.save(target,name,song.masks()))host.message("SD未就绪或事务忙；尚未开始保存。");}).show();});}catch(IllegalArgumentException error){main.post(()->{if(destroyed)return;preparing=false;render();host.message("无法保存："+error.getMessage());});}});}
    private static void text(TextView view,String value){if(!value.contentEquals(view.getText()))view.setText(value);}
    private void render(){boolean supported=connected&&latest!=null&&latest.capability==1,busy=preparing||latest!=null&&latest.busy!=0,readReady=supported&&latest.state==1,writeReady=readReady&&(latest.flags&16)==0;SdLibraryFlow.Entry entry=latest==null?null:latest.entries[selected];
        save.setEnabled(writeReady&&!busy);load.setEnabled(readReady&&!busy&&entry!=null&&(entry.flags&1)!=0);delete.setEnabled(writeReady&&!busy&&entry!=null&&(entry.flags&1)!=0&&(entry.flags&2)==0);scan.setEnabled(supported&&!busy);refresh.setEnabled(connected&&latest!=null&&latest.capability>=0);for(Button slot:slots)slot.setEnabled(!busy);
        String message=!connected?"未连接":latest==null?"等待SD能力…":latest.message;if(preparing)message="正在适配所选曲目…";if(latest!=null&&latest.state==2&&latest.pendingToken!=0)message+="\n设备SD进度 "+latest.progress+"%";if(latest!=null&&latest.transferLba>=0)message+="\n当前"+(latest.transferWriting!=0?"写入准备":"读取扇区")+" · 地址 LBA "+latest.transferLba+"（不是累计数量）\n当前扇区分片 "+latest.transferChunk+" / 128";if(latest!=null&&latest.error!=0)message+="\n设备SD错误 "+latest.error;
        if(supported){message+="\n卡初始化 "+((latest.flags&1)!=0?"是":"否")+" · FAT32挂载 "+((latest.flags&2)!=0?"是":"否")+" · 写入保护 "+((latest.flags&16)!=0?"是":"否")+"\n设备状态 "+latest.state+" · flags "+String.format(java.util.Locale.ROOT,"0x%02X",latest.flags);if((latest.flags&16)!=0)message+="\n写入保护：可读取有效曲谱；保存/删除已禁用。";}
        if(latest!=null&&latest.reported!=0)message+="\n最近操作 token "+Long.toString(latest.token)+" · action "+latest.action+" · slot "+(latest.slot==255?"—":latest.slot);text(status,(simulated?"模拟SD文件存储（无真实卡/硬件） · ":"")+message);
        int count=0;if(latest!=null)for(SdLibraryFlow.Entry item:latest.entries)if((item.flags&1)!=0)count++;text(selection,"选中槽位 "+selected+" · "+(latest==null||latest.catalogLoaded==0?"尚未读取曲目清单":count+" / 32 首")+" · 设备选曲 "+(latest==null||latest.selected==255?"—":latest.selected));
        for(int i=0;i<32;i++){String label=latest==null||latest.catalogLoaded==0?String.format(java.util.Locale.ROOT,"%02d · 待扫描",i):latest.entries[i].label();text(slots[i],(i==selected?"▶ ":"")+label);}
    }
    public void close(){destroyed=true;worker.shutdownNow();}
}
