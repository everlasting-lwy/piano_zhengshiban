package org.pianolink;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Handler;
import android.os.Looper;
import android.widget.*;
import java.util.concurrent.*;

/** Dashboard controls for RAM download; this component never generates remote note packets. */
public final class OledGuideUi {
    public interface Host {SongData selected();String name();boolean download(int[] masks);boolean action(int action);void cancel();void refresh();void message(String text);}
    private final Activity activity;private final Host host;private final Handler main=new Handler(Looper.getMainLooper());private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final TextView status;private final ProgressBar progress;private final Button download,cancel,enter,restart,exit,delete,refresh;
    private boolean connected,simulated,preparing,destroyed;private Session.GuideState latest;
    public OledGuideUi(Activity activity,LinearLayout column,Host host){this.activity=activity;this.host=host;
        TextView title=new TextView(activity);title.setText("OLED · 实体18键整曲跟弹");title.setTextSize(17);title.setTextColor(0xff65ded6);column.addView(title);
        status=new TextView(activity);status.setTextColor(0xffe5edf6);status.setTextSize(13);column.addView(status);
        progress=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(2048);column.addView(progress);
        LinearLayout first=row(column);download=button(first,"下载所选曲目",()->preview());cancel=button(first,"取消下载",()->host.cancel());refresh=button(first,"查询状态",()->host.refresh());
        LinearLayout controls=row(column);enter=button(controls,"进入 / 重来",()->action(1));restart=button(controls,"重来",()->action(2));exit=button(controls,"退出GUIDE",()->action(0));
        LinearLayout last=row(column);delete=button(last,"删除FPGA曲谱",()->new AlertDialog.Builder(activity).setTitle("删除 FPGA RAM 曲谱？").setMessage("取消暂存并清空FPGA曲谱，手机曲库保留。GUIDE已打开时显示NO SONG。").setNegativeButton("保留",null).setPositiveButton("删除",(dialog,which)->action(3)).show());render();
    }
    private LinearLayout row(LinearLayout parent){LinearLayout view=new LinearLayout(activity);view.setOrientation(LinearLayout.HORIZONTAL);parent.addView(view);return view;}
    private Button button(LinearLayout row,String text,Runnable action){Button b=new Button(activity);b.setText(text);b.setTextSize(12);b.setAllCaps(false);b.setOnClickListener(v->action.run());row.addView(b,new LinearLayout.LayoutParams(0,-2,1));return b;}
    public void connection(boolean connected,boolean simulated){this.connected=connected;this.simulated=simulated;if(!connected)latest=null;render();}
    public void snapshot(Session.GuideState value){latest=value;render();}
    private void action(int value){if(!host.action(value))host.message("引导事务正在进行，请等待完成或先取消下载。");}
    private void preview(){final SongData source=host.selected();if(source==null){host.message("请先在曲库选择一首已载入曲目。");return;}final String name=host.name();preparing=true;render();worker.execute(()->{try{final OledGuideSong song=OledGuideSong.from(source);main.post(()->{if(destroyed)return;preparing=false;render();new AlertDialog.Builder(activity).setTitle("引导适配预览 · "+name).setMessage(song.preview()).setNegativeButton("返回",null).setPositiveButton("下载到FPGA",(dialog,which)->{if(!host.download(song.masks()))host.message("当前未就绪或事务忙，请查询状态后重试。");}).show();});}catch(IllegalArgumentException e){main.post(()->{if(destroyed)return;preparing=false;render();host.message("无法下载："+e.getMessage());});}});}
    private void render(){boolean busy=latest!=null&&latest.busy!=0,ready=connected&&latest!=null&&latest.capability==1;
        download.setEnabled(connected&&!busy&&!preparing&&(latest==null||latest.capability>=0));cancel.setEnabled(connected&&latest!=null&&latest.cancellable!=0);refresh.setEnabled(connected&&!busy);for(Button b:new Button[]{enter,restart,exit,delete})b.setEnabled(ready&&!busy);
        int done=latest==null?0:latest.uploaded,total=latest==null?0:latest.uploadTotal;progress.setMax(Math.max(1,total));progress.setProgress(done);
        String prefix=simulated?"模拟 FPGA（无硬件） · ":"";String text=!connected?"未连接；曲谱为易失RAM，复位/掉电清空":latest==null?"等待设备引导能力…":latest.message;
        if(preparing)text="正在生成18键适配预览…";if(busy&&total>0)text+="\n确认进度 "+done+" / "+total+" 步";
        if(connected&&latest!=null&&latest.reported!=0)text+="\n最近FPGA报告"+(busy&&total>0?"（下载时暂不刷新）":"")+"："+((latest.flags&1)==0?"NO SONG":(latest.flags&4)!=0?"DONE":"第 "+(latest.step+1)+" / "+latest.total+" 步")+((latest.flags&2)!=0?" · GUIDE":" · 已退出")+((latest.flags&8)!=0?" · 暂存中":"")+((latest.flags&16)!=0?" · 错键，请全松开":"")+String.format(java.util.Locale.ROOT,"\n目标 %05X · 实体键 %05X",latest.target,latest.physical);
        String rendered=prefix+text+"\n实体键C4—F5，使用原位八度；手机按键不会推进。后台下载与蓝牙连接保留。";
        if(!rendered.contentEquals(status.getText()))status.setText(rendered);
    }
    public void close(){destroyed=true;worker.shutdownNow();}
}
