package org.pianolink;

import android.Manifest;
import android.app.*;
import android.bluetooth.BluetoothDevice;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.*;

/** Real Bluetooth remains started/foreground while Activities come and go; mock stays bound. */
public final class LinkService extends Service {
    private static final String CONNECT="org.pianolink.CONNECT",DISCONNECT="org.pianolink.DISCONNECT",CHANNEL="pianolink_connection";
    private static final int NOTIFICATION=1;
    public final class LocalBinder extends Binder { public LinkService service(){return LinkService.this;} }
    private final LocalBinder binder=new LocalBinder();
    private final LinkSession session=new LinkSession();
    private boolean foreground,starting;

    public LinkSession session(){return session;}
    @Override public void onCreate(){
        super.onCreate();
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=new NotificationChannel(CHANNEL,"钢琴蓝牙连接",NotificationManager.IMPORTANCE_LOW);channel.setDescription("保持蓝牙连接；切到后台会释放按键并停止手机回放。");getSystemService(NotificationManager.class).createNotificationChannel(channel);}
        session.setStateListener((active,mock,text)->{
            if(!active){if(!starting)stopConnectionService();}
            else if(foreground)getSystemService(NotificationManager.class).notify(NOTIFICATION,notification(text));
        });
    }
    @Override public IBinder onBind(Intent intent){return binder;}
    public void connect(boolean simulation,BluetoothDevice device,boolean secure){
        if(simulation){session.connect(true,null,false);return;}
        if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){session.disconnect("蓝牙连接权限不可用，请允许附近设备。");return;}
        Intent start=new Intent(this,LinkService.class).setAction(CONNECT).putExtra("device",device).putExtra("secure",secure);
        try{if(Build.VERSION.SDK_INT>=26)startForegroundService(start);else startService(start);}
        catch(RuntimeException e){session.disconnect("无法启动蓝牙连接服务："+e.getMessage());}
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopConnectionService();return START_NOT_STICKY;}
        if(DISCONNECT.equals(intent.getAction())){session.disconnect("已从通知断开并释放手机按键");return START_NOT_STICKY;}
        if(!CONNECT.equals(intent.getAction()))return START_NOT_STICKY;
        starting=true;
        try{
            Notification notification=notification("正在连接蓝牙 SPP…");
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(NOTIFICATION,notification);
            foreground=true;
            BluetoothDevice device=intent.getParcelableExtra("device");
            if(device==null)throw new IllegalArgumentException("缺少蓝牙设备");
            session.connect(false,device,intent.getBooleanExtra("secure",false));
        }catch(RuntimeException e){session.disconnect("蓝牙前台服务启动失败："+e.getMessage());}
        finally{starting=false;if(!session.active())stopConnectionService();}
        return START_NOT_STICKY;
    }
    public void disconnect(String reason){session.disconnect(reason);}
    private Notification notification(String text){
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent disconnect=PendingIntent.getService(this,1,new Intent(this,LinkService.class).setAction(DISCONNECT),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("PianoLink · 蓝牙连接保留")
            .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text+"\n离开钢琴界面时释放按键并停止手机回放，连接与整曲下载保留。"))
            .setContentIntent(open).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE).setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_view,"打开钢琴",open).addAction(android.R.drawable.ic_menu_close_clear_cancel,"断开连接",disconnect).build();
    }
    private void stopConnectionService(){if(foreground){stopForeground(true);foreground=false;}stopSelf();}
    @Override public void onDestroy(){session.setStateListener(null);session.disconnect("蓝牙服务已停止");super.onDestroy();}
}
