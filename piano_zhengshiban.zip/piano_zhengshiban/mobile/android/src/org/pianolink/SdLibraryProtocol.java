package org.pianolink;

import java.nio.*;
import java.nio.charset.*;
import java.util.Arrays;

/** Frozen SD protocol 1, CMD16..1B. No command here implies completion. */
public final class SdLibraryProtocol {
    private SdLibraryProtocol(){}
    public static boolean status(Protocol.Frame f){return f.cmd==0x8b&&(f.d[0]==1||f.d[0]==2)&&f.d[1]<=4&&f.d[3]<=100&&(f.d[4]<32||f.d[4]==255)&&(f.d[5]&~31)==0&&(((f.d[5]&4)!=0)==(f.d[1]==2));}
    public static long token(int[] data,int offset){long value=0;for(int i=0;i<4;i++)value|=(data[offset+i]&255L)<<(i*8);return value;}
    public static boolean identity(Protocol.Frame f){return f.cmd==0x8e&&f.d[4]<=3&&(f.d[5]<32||f.d[5]==255)&&(token(f.d,0)==0||(f.d[4]==0?f.d[5]==255:f.d[5]<32));}
    public static boolean entry(Protocol.Frame f,int slot){int flags=f.d[1],steps=f.d[2]|f.d[3]<<8;return f.cmd==0x8c&&f.d[0]==slot&&(flags&~7)==0&&steps<=2048&&f.d[4]<=32&&(((flags&1)!=0)==(steps>0))&&((flags&1)==0||((flags&4)==0));}
    public static byte[] title(String text){if(text==null||text.indexOf('\0')>=0)throw new IllegalArgumentException("标题不能包含空字符");byte[] out=new byte[32];int used=0;for(int i=0;i<text.length();){int code=text.codePointAt(i);if(code>=0xd800&&code<=0xdfff)throw new IllegalArgumentException("标题含无效Unicode字符");byte[] part=new String(Character.toChars(code)).getBytes(StandardCharsets.UTF_8);if(used+part.length>32)break;System.arraycopy(part,0,out,used,part.length);used+=part.length;i+=Character.charCount(code);}return out;}
    public static String decodeTitle(byte[] bytes,int length){try{for(int i=0;i<length;i++)if(bytes[i]==0)throw new IllegalArgumentException("标题含空字符");return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes,0,length)).toString();}catch(CharacterCodingException e){throw new IllegalArgumentException("设备标题UTF8无效",e);}}
    public static String error(int code){switch(code){case 0:return "无错误";default:return "SD错误 "+code;}}
}
