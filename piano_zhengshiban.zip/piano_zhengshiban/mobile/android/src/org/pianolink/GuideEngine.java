package org.pianolink;

import java.util.Arrays;
import java.util.TreeSet;

/** Android-free, fixed song clock and tolerant onset judge for one selected input stream. */
public final class GuideEngine {
    public static final int PENDING = 0, HIT = 1, MISS = 2;
    public enum State { READY, RUNNING, PAUSED, FINISHED }
    private static final long MASK36 = 68719476735L;
    private static final long WINDOW_MS = 300;
    public final GuideSong song;

    private final boolean[] hit;
    private final int[] hitPrefix;
    private final TreeSet<Integer>[] pending;
    private State state = State.READY;
    private double speed = 1;
    private double position = -3000;
    private double anchorPosition = -3000;
    private long anchorRealtime, lastRealtime;
    private long heldMask;
    private int hits, wrong, overdue;

    @SuppressWarnings("unchecked")
    public GuideEngine(GuideSong song) {
        if (song == null) throw new IllegalArgumentException("谱面为空");
        this.song = song;
        hit = new boolean[song.notes.size()];
        hitPrefix = new int[hit.length + 1];
        pending = (TreeSet<Integer>[]) new TreeSet<?>[36];
        for (int key = 0; key < 36; key++) pending[key] = new TreeSet<Integer>();
        resetResults();
    }

    /** Start only a ready score. Current input is a baseline, never a fresh press. */
    public void start(long now) {
        if (state != State.READY) return;
        anchorRealtime = lastRealtime = Math.max(0, now);
        anchorPosition = position;
        state = State.RUNNING;
    }

    public void pause(long now) {
        advance(now);
        if (state != State.RUNNING) return;
        anchorPosition = position;
        state = State.PAUSED;
    }

    public void resume(long now) {
        if (state != State.PAUSED) return;
        anchorRealtime = lastRealtime = Math.max(lastRealtime, now);
        anchorPosition = position;
        state = State.RUNNING;
    }

    /** Reset and run a new attempt while preserving speed and currently held input. */
    public void restart(long now) {
        resetResults();
        position = anchorPosition = -3000;
        anchorRealtime = lastRealtime = Math.max(0, now);
        state = State.RUNNING;
    }

    public void setSpeed(double selectedSpeed, long now) {
        if (selectedSpeed != 0.5 && selectedSpeed != 0.75 && selectedSpeed != 1
                && selectedSpeed != 1.25 && selectedSpeed != 1.5)
            throw new IllegalArgumentException("速度应为0.5、0.75、1、1.25或1.5倍");
        advance(now);
        anchorPosition = position;
        anchorRealtime = lastRealtime = Math.max(lastRealtime, now);
        speed = selectedSpeed;
    }

    /** Call for full input snapshots, including releases and repeated polling/ACK states. */
    public void input(long mask, long now) {
        advance(now);
        mask &= MASK36;
        long pressed = mask & ~heldMask;
        heldMask = mask;
        if (state != State.RUNNING) return;
        long current = (long) Math.floor(position);
        int split = firstOnsetAtOrAfter(current);
        while (pressed != 0) {
            int key = Long.numberOfTrailingZeros(pressed);
            TreeSet<Integer> choices = pending[key];
            Integer earlier = choices.lower(split);
            Integer later = choices.ceiling(split);
            int selected = -1;
            long distance = WINDOW_MS + 1;
            if (earlier != null) {
                long delta = current - song.notes.get(earlier).startMs;
                if (delta <= WINDOW_MS) { selected = earlier; distance = delta; }
            }
            if (later != null) {
                long delta = song.notes.get(later).startMs - current;
                if (delta <= WINDOW_MS && delta < distance) selected = later;
            }
            if (selected < 0) wrong++;
            else {
                hit[selected] = true;
                hits++;
                choices.remove(selected);
                for (int i = selected + 1; i < hitPrefix.length; i += i & -i) hitPrefix[i]++;
            }
            pressed &= pressed - 1;
        }
    }

    /** Rebase after source/lifecycle changes without judging or synthesizing any edges. */
    public void rebaseInput(long mask) { heldMask = mask & MASK36; }
    public void tick(long now) { advance(now); }
    public long positionMs(long now) { advance(now); return (long) Math.floor(position); }
    public State state() { return state; }
    public double speed() { return speed; }
    public int hitCount() { return hits; }
    public int wrongCount() { return wrong; }

    public int result(int id) {
        if (id < 0 || id >= hit.length) throw new IllegalArgumentException("音符编号超出范围");
        return hit[id] ? HIT : id < overdue ? MISS : PENDING;
    }

    public int missCount() {
        int expiredHits = 0;
        for (int i = overdue; i > 0; i -= i & -i) expiredHits += hitPrefix[i];
        return overdue - expiredHits;
    }

    private void resetResults() {
        Arrays.fill(hit, false);
        Arrays.fill(hitPrefix, 0);
        for (TreeSet<Integer> keys : pending) keys.clear();
        for (GuideSong.Note note : song.notes) pending[note.key].add(note.id);
        hits = wrong = overdue = 0;
    }

    private void advance(long now) {
        if (state != State.RUNNING) return;
        lastRealtime = Math.max(lastRealtime, now);
        position = anchorPosition + ((double) lastRealtime - anchorRealtime) * speed;
        // Include explicit final silence/release plus a complete inclusive late-onset window.
        long end = song.durationMs + WINDOW_MS;
        if (position >= end) { position = end; state = State.FINISHED; }
        long current = (long) Math.floor(position);
        int low = 0, high = hit.length;
        while (low < high) {
            int mid = low + (high - low) / 2;
            if (song.notes.get(mid).startMs + WINDOW_MS < current) low = mid + 1;
            else high = mid;
        }
        overdue = low;
    }

    private int firstOnsetAtOrAfter(long current) {
        int low = 0, high = hit.length;
        while (low < high) {
            int mid = low + (high - low) / 2;
            if (song.notes.get(mid).startMs < current) low = mid + 1;
            else high = mid;
        }
        return low;
    }
}
