package org.pianolink;
import android.media.*;

/** Local phone sound only: this is explicitly not an FPGA audio test. */
public final class DemoAudio {
    private volatile boolean running=true,enabled,extended;
    private volatile long extendedMask;
    private volatile int mask,timbre,volume=8,octave;
    private final Thread thread;
    public DemoAudio(){thread=new Thread(this::render,"PianoLink-local-audio");thread.start();}
    public void enabled(boolean value){enabled=value;}
    public void notes(int value){mask=value&4095;extended=false;}
    public void extendedNotes(long value){extendedMask=value&0xfffffffffL;extended=true;}
    public void parameters(int t,int v,int o){timbre=t;volume=v;octave=o;}
    public void close(){mask=0;running=false;}
    private void render(){
        AudioTrack track=null;
        try{
            int rate=22050;int min=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
            track=new AudioTrack(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
                new AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),Math.max(2048,min),AudioTrack.MODE_STREAM,AudioManager.AUDIO_SESSION_ID_GENERATE);
            track.play();double[] phases=new double[48];int[] semitones={0,2,4,5,7,9,11,1,3,6,8,10};short[] pcm=new short[256];double gain=0;
            while(running){
                int t=timbre,v=volume,o=octave;long bits=0;if(enabled){if(extended)bits=extendedMask;else for(int n=0;n<12;n++)if((mask&(1<<n))!=0)bits|=1L<<(12+semitones[n]+(o==1?12:o==2?-12:0));}double[] step=new double[48];boolean[] active=new boolean[48];int voices=0;
                for(int n=0;n<48;n++)if((bits&(1L<<n))!=0&&voices++<4){active[n]=true;step[n]=2*Math.PI*130.812783*Math.pow(2,n/12.0)/rate;}
                for(int i=0;i<pcm.length;i++){
                    double sum=0;for(int n=0;n<48;n++)if(active[n]){phases[n]=(phases[n]+step[n])%(2*Math.PI);double p=phases[n];sum+=t==1?(Math.sin(p)+0.3*Math.sin(2*p)):t==2?(Math.sin(p)+0.2*Math.sin(3*p)):t==3?Math.sin(p)*Math.sin(p/2):Math.sin(p);}
                    double target=bits==0?0:v/15.0;gain+=(target-gain)*0.02;pcm[i]=(short)Math.max(-32767,Math.min(32767,sum*gain*4500));
                }
                track.write(pcm,0,pcm.length);
            }
        }catch(Exception ignored){/* Sound is optional; Bluetooth and simulation remain usable. */}
        finally{if(track!=null){try{track.stop();}catch(Exception ignored){}track.release();}}
    }
}
