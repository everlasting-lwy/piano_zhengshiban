package org.pianolink;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.concurrent.*;

/** Blocking sector facade for the dedicated FAT worker, never the I/O scheduler or UI. */
public final class SectorRpcClient {
    public interface Progress {void update(boolean writing,long lba,int chunks);}
    private final Session session;private final long token;private final Progress progress;private long sectors;private int requestId;private boolean active;
    public SectorRpcClient(Session session){this(session,null);}
    public SectorRpcClient(Session session,Progress progress){this.session=session;this.progress=progress;SecureRandom random=new SecureRandom();long candidate=random.nextInt()&0xffffffffL;token=candidate==0?1:candidate;requestId=random.nextInt(65535)+1;}
    private void progress(boolean writing,long lba,int chunks){if(progress!=null&&(chunks==0||chunks%32==0))progress.update(writing,lba,chunks);}
    private Protocol.Frame call(int cmd,int... data)throws IOException{int[] payload=new int[6];System.arraycopy(data,0,payload,0,data.length);Future<Protocol.Frame> future=session.blockRpc(cmd,payload);try{Protocol.Frame reply=future.get(5,TimeUnit.SECONDS);if(reply.cmd==0x80&&reply.d[1]!=0)throw new IOException("SD扇区RPC "+Integer.toHexString(cmd)+" 被拒绝，错误 "+reply.d[1]);return reply;}catch(InterruptedException e){future.cancel(false);Thread.currentThread().interrupt();throw new IOException("SD事务被中断；结果未确认",e);}catch(ExecutionException|TimeoutException e){future.cancel(false);throw new IOException("SD扇区通信失败；请重新查询设备状态，不自动重试事务",e);}}
    private void ownership(int action)throws IOException{call(0x20,action,(int)token&255,(int)(token>>>8)&255,(int)(token>>>16)&255,(int)(token>>>24)&255,0);}
    public void open()throws IOException{Protocol.Frame status=call(0x26);if(status.cmd!=0x92||(status.d[2]&16)!=0)throw new IOException("SD上次写入结果不确定，请在电脑检查卡后重启");if((status.d[2]&1)!=0)throw new IOException("SD仍有未结束会话；等待空闲租约结束后再查询");requestId=status.d[3]|status.d[4]<<8;Protocol.Frame capacity=call(0x28);if(capacity.cmd!=0x93||capacity.d[4]!=1||capacity.d[5]!=2)throw new IOException("SD介质未就绪或不支持扇区协议2");sectors=SdLibraryProtocol.token(capacity.d,0);if(sectors==0)throw new IOException("SD容量无效");ownership(0);active=true;}
    public long sectorCount(){return sectors;}
    private int nextId(){requestId=(requestId+1)&65535;if(requestId==0)requestId=1;return requestId;}
    private void range(long lba)throws IOException{if(!active||lba<0||lba>=sectors)throw new IOException("SD会话未开始或扇区超出容量");}
    private void await(int id)throws IOException{long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(20);while(System.nanoTime()<deadline){Protocol.Frame f=call(0x26);if(f.cmd!=0x92)throw new IOException("SD扇区状态类型无效");if((f.d[2]&16)!=0||f.d[0]==3||f.d[1]!=0)throw new IOException("SD扇区失败，错误 "+f.d[1]+"；写入结果可能不确定");if((f.d[2]&1)==0)throw new IOException("SD会话已过期；停止事务");if((f.d[3]|f.d[4]<<8)==id&&f.d[0]==0&&(f.d[2]&2)!=0)return;try{Thread.sleep(80);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException("SD等待被中断",e);}}throw new IOException("SD扇区超时；结果未确认");}
    public byte[] read(long lba)throws IOException{range(lba);progress(false,lba,0);int id=nextId();call(0x21,(int)lba&255,(int)(lba>>>8)&255,(int)(lba>>>16)&255,(int)(lba>>>24)&255,id&255,id>>>8);await(id);byte[] sector=new byte[512];for(int offset=0;offset<512;offset+=4){Protocol.Frame f=call(0x25,offset&255,offset>>>8);if(f.cmd!=0x91)throw new IOException("SD缓存回复无效");for(int i=0;i<4;i++)sector[offset+i]=(byte)f.d[i+2];progress(false,lba,offset/4+1);}return sector;}
    public void write(long lba,byte[] sector)throws IOException{range(lba);if(sector==null||sector.length!=512)throw new IOException("扇区写入必须为512字节");progress(true,lba,0);int id=nextId();call(0x24,id&255,id>>>8);for(int offset=0;offset<512;offset+=4){call(0x22,offset&255,offset>>>8,sector[offset]&255,sector[offset+1]&255,sector[offset+2]&255,sector[offset+3]&255);progress(true,lba,offset/4+1);}int crc=OledGuideProtocol.crc16(sector);call(0x23,(int)lba&255,(int)(lba>>>8)&255,(int)(lba>>>16)&255,(int)(lba>>>24)&255,crc&255,crc>>>8);await(id);}
    public void close()throws IOException{if(active){ownership(1);active=false;}}
}
