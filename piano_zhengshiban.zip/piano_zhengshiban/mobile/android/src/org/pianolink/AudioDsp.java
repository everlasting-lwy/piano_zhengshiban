package org.pianolink;

import java.io.IOException;

/** Streaming PCM conversion; independent of Android so decoder boundaries are testable. */
public final class AudioDsp {
    private AudioDsp() {}
    public interface Cancellation { boolean cancelled(); }
    public interface SampleSink { void sample(float value) throws IOException; }
    public static final class CancelledException extends IOException {
        public CancelledException() { super("音频转换已取消"); }
    }
    public static void checkCancelled(Cancellation cancellation) throws CancelledException {
        if (cancellation != null && cancellation.cancelled()) throw new CancelledException();
    }
    /** Owns a cancellation watcher; close joins it before the interpreter may be released. */
    public static final class CancellationMonitor implements java.io.Closeable {
        private volatile boolean closed;
        private final Thread watcher;
        public CancellationMonitor(Cancellation cancellation,Runnable cancelNative) {
            watcher=new Thread(()->{
                while(!closed) {
                    if(cancellation!=null&&cancellation.cancelled()) {
                        if(!closed)cancelNative.run();
                        return;
                    }
                    try{Thread.sleep(20);}catch(InterruptedException stopped){return;}
                }
            },"PianoLink-inference-cancel");
            watcher.setDaemon(true);watcher.start();
        }
        public void close() {
            closed=true;watcher.interrupt();boolean interrupted=false;
            while(watcher.isAlive())try{watcher.join();}catch(InterruptedException stopped){interrupted=true;}
            if(interrupted)Thread.currentThread().interrupt();
        }
    }
    public static final class Resampler {
        private static final int RADIUS=24, PHASES=1024;
        private final int inputRate,outputRate;
        private final float[] ring=new float[256];
        private final float[][] weights=new float[PHASES][RADIUS*2];
        private long received,produced;
        private boolean finished;
        public Resampler(int inputRate, int outputRate) {
            if(inputRate<8000||inputRate>384000||outputRate<8000||outputRate>384000)
                throw new IllegalArgumentException("不支持的采样率");
            this.inputRate=inputRate; this.outputRate=outputRate;
            double cutoff=Math.min(1.0,outputRate/(double)inputRate)*0.92;
            for(int phase=0;phase<PHASES;phase++) {
                double fraction=phase/(double)PHASES,total=0;
                for(int tap=0;tap<RADIUS*2;tap++) {
                    double distance=tap-RADIUS+1-fraction;
                    double x=Math.PI*distance*cutoff;
                    double window=0.42+0.5*Math.cos(Math.PI*distance/RADIUS)
                            +0.08*Math.cos(2*Math.PI*distance/RADIUS);
                    double weight=(Math.abs(x)<1e-12?cutoff:Math.sin(x)/(Math.PI*distance))*window;
                    weights[phase][tap]=(float)weight; total+=weight;
                }
                for(int tap=0;tap<RADIUS*2;tap++) weights[phase][tap]/=total;
            }
        }
        public void accept(float[] samples, int offset, int length, SampleSink sink) throws IOException {
            if(finished) throw new IllegalStateException("resampler already finished");
            if(offset<0||length<0||offset>samples.length-length) throw new IndexOutOfBoundsException();
            for(int i=offset;i<offset+length;i++) {
                ring[(int)(received%ring.length)]=Float.isNaN(samples[i])?0:Math.max(-1,Math.min(1,samples[i]));
                received++;
                while((produced*(long)inputRate)/outputRate+RADIUS<received) emit(sink);
            }
        }
        public void finish(SampleSink sink) throws IOException {
            if(finished) return;
            while(produced*(long)inputRate<received*(long)outputRate) emit(sink);
            finished=true;
        }
        private void emit(SampleSink sink) throws IOException {
            long numerator=produced*(long)inputRate, center=numerator/outputRate;
            int phase=(int)((numerator%outputRate)*PHASES/outputRate);
            double sum=0;
            for(int tap=0;tap<RADIUS*2;tap++) {
                long index=center+tap-RADIUS+1;
                if(index>=0&&index<received) sum+=ring[(int)(index%ring.length)]*weights[phase][tap];
            }
            sink.sample((float)sum); produced++;
        }
    }
}
