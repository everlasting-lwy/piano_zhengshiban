package org.pianolink;

import android.bluetooth.BluetoothDevice;

/** Service-owned transport and live snapshot. All UI ownership is explicitly attached/detached. */
public final class LinkSession {
    public interface StateListener { void changed(boolean active,boolean simulated,String message); }
    private LinkController transport;
    private LinkController.Listener ui;
    private StateListener owner;
    private long generation;
    private boolean ready,simulated,secure,inputEnabled;
    private Protocol.Frame status,capability,extended,effects;
    private Session.GuideState guide;
    private SdLibraryFlow.State sd;
    private final MockFpga.SdCard simulatedCard=new MockFpga.SdCard();
    private String message="未连接";

    public synchronized void setStateListener(StateListener listener){owner=listener;}
    public synchronized void attach(LinkController.Listener listener){
        if(ui!=listener&&transport!=null)transport.visual(0,false);
        ui=listener;inputEnabled=true;
        if(ready)listener.connected(simulated);
        if(status!=null)listener.frame(status);
        if(capability!=null)listener.frame(capability);
        if(extended!=null&&extended!=capability)listener.frame(extended);
        if(effects!=null)listener.frame(effects);
        if(guide!=null)listener.guide(guide);
        if(sd!=null)listener.sd(sd);
        if(transport==null)listener.ended(message);
        else if(!ready)listener.message(message);
    }
    public synchronized void detach(LinkController.Listener listener){
        if(ui!=listener)return;
        pause();ui=null;
    }
    /** Pause stops all further UI key writes, including an already queued playback callback. */
    public synchronized void pause(){inputEnabled=false;if(transport!=null){transport.visual(0,false);transport.release();}}
    public synchronized void pause(LinkController.Listener source){if(ui==source)pause();}
    public synchronized void resume(LinkController.Listener source){if(ui==source)inputEnabled=true;}
    public synchronized void connect(boolean simulation,BluetoothDevice device,boolean useSecure){
        disconnect("正在连接…");simulated=simulation;secure=useSecure;
        final long current=++generation;
        transport=new LinkController(simulation,new LinkController.Listener(){
            public void connected(boolean mock){synchronized(LinkSession.this){if(current!=generation)return;ready=true;message=mock?"已连接 · 模拟 FPGA（无硬件）":"FPGA 已应答 · "+(secure?"安全":"兼容")+" SPP";if(owner!=null)owner.changed(true,simulated,message);if(ui!=null)ui.connected(mock);}}
            public void frame(Protocol.Frame frame){synchronized(LinkSession.this){if(current!=generation)return;cache(frame);if(ui!=null)ui.frame(frame);}}
            public void visual(VisualFrames.Snapshot snapshot){synchronized(LinkSession.this){if(current==generation&&ui!=null&&inputEnabled)ui.visual(snapshot);}}
            public void guide(Session.GuideState snapshot){synchronized(LinkSession.this){if(current!=generation)return;guide=snapshot;if(ui!=null)ui.guide(snapshot);}}
            public void sd(SdLibraryFlow.State snapshot){synchronized(LinkSession.this){if(current!=generation)return;sd=snapshot;if(ui!=null)ui.sd(snapshot);}}
            public void message(String text){synchronized(LinkSession.this){if(current!=generation)return;message=text;if(owner!=null)owner.changed(true,simulated,text);if(ui!=null)ui.message(text);}}
            public void ended(String reason){synchronized(LinkSession.this){if(current==generation)disconnect(reason);}}
        },simulatedCard);
        transport.connect(device,useSecure);
    }
    private void cache(Protocol.Frame f){
        if(f.cmd==0x81)status=f;
        // Cache a synthesized status, never replay an old recording event to a newly attached UI.
        if(f.cmd==0x82&&status!=null){int[] d=status.d.clone();d[4]=f.d[4];d[5]=f.d[5];status=new Protocol.Frame(status.seq,0x81,d);}
        if(f.cmd==0x83&&f.isExtendedState()){capability=f;extended=f;}
        if(f.cmd==0x84&&f.isExtendedState())extended=f;
        if(f.isEffectsState())effects=f;
    }
    public synchronized void disconnect(String reason){
        ++generation;LinkController old=transport;transport=null;ready=false;status=null;capability=null;extended=null;effects=null;guide=null;sd=null;message=reason;
        if(old!=null)old.close();
        if(owner!=null)owner.changed(false,simulated,reason);
        if(ui!=null)ui.ended(reason);
    }
    public synchronized boolean ready(){return ready&&transport!=null&&transport.ready();}
    public synchronized boolean secure(){return secure;}
    public synchronized boolean active(){return transport!=null;}
    public synchronized boolean simulated(){return simulated;}
    public synchronized void keys(int mask){if(inputEnabled&&transport!=null)transport.keys(mask);}
    public synchronized void extendedKeys(long mask){if(inputEnabled&&transport!=null)transport.extendedKeys(mask);}
    public synchronized boolean offerPlaybackMask(long mask,boolean absolute){return inputEnabled&&transport!=null&&transport.offerPlaybackMask(mask,absolute);}
    public synchronized boolean playbackPending(){return transport!=null&&transport.playbackPending();}
    public synchronized boolean guideDownload(LinkController.Listener source,int[] masks){return ui==source&&inputEnabled&&transport!=null&&transport.guideDownload(masks);}
    public synchronized boolean guideAction(LinkController.Listener source,int action){return ui==source&&inputEnabled&&transport!=null&&transport.guideAction(action);}
    public synchronized void guideCancel(LinkController.Listener source){if(ui==source&&transport!=null)transport.guideCancel();}
    public synchronized void guideRefresh(LinkController.Listener source){if(ui==source&&transport!=null)transport.guideRefresh();}
    public synchronized Session.GuideState guideState(){return transport==null?null:transport.guideState();}
    public synchronized boolean sdScan(LinkController.Listener source){return ui==source&&inputEnabled&&transport!=null&&transport.sdScan();}
    public synchronized boolean sdLoad(LinkController.Listener source,int slot){return ui==source&&inputEnabled&&transport!=null&&transport.sdLoad(slot);}
    public synchronized boolean sdDelete(LinkController.Listener source,int slot){return ui==source&&inputEnabled&&transport!=null&&transport.sdDelete(slot);}
    public synchronized boolean sdSave(LinkController.Listener source,int slot,String title,int[] masks){return ui==source&&inputEnabled&&transport!=null&&transport.sdSave(slot,title,masks);}
    public synchronized void sdRefresh(LinkController.Listener source){if(ui==source&&transport!=null)transport.sdRefresh();}
    public synchronized SdLibraryFlow.State sdState(){return transport==null?null:transport.sdState();}
    public synchronized void resetLegacy(LinkController.Listener listener){if(ui==listener&&inputEnabled&&transport!=null)transport.resetLegacy();}
    public synchronized void control(int command,int value){if(transport!=null)transport.control(command,value);}
    public synchronized void effect(LinkController.Listener source,int id,int value){if(ui==source&&inputEnabled&&transport!=null)transport.effect(id,value);}
    public synchronized void visual(LinkController.Listener source,int kind,boolean active){if(ui==source&&transport!=null)transport.visual(kind,active&&inputEnabled);}
    public synchronized void release(LinkController.Listener source){if(ui==source&&transport!=null)transport.release();}
}
