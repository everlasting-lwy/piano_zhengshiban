package org.pianolink;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final int PERMISSION=10,NOTIFICATIONS=13;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Recording recording=new Recording();
    private final KeyMap keyMap=new KeyMap();
    private SongLibraryUi libraryUi;
    private EffectsUi effectsUi;private boolean effectsMode;
    private SongGuideUi guideUi;private boolean guideMode;
    private OledGuideUi oledGuideUi;
    private SdLibraryUi sdLibraryUi;
    private SongData selectedSong,playbackSong;
    private SongReplay songReplay;
    private SharedPreferences preferences;
    private LinkSession link;
    private LinkService linkService;
    private boolean serviceBound,uiAttached;
    private final LinkController.Listener linkEvents=new LinkController.Listener(){
        public void connected(boolean simulated){
            if(link==null)return;
            connection.setText(simulated?"已连接 · 模拟 FPGA（无硬件）":"FPGA 已应答 · "+(link.secure()?"安全":"兼容")+" SPP");
            ensembleConnection.setText(connection.getText());piano.playable(!ensembleMode&&!effectsMode&&!guideMode);if(effectsUi!=null){effectsUi.connection(true,simulated,extendedSupported);effectsUi.active(effectsMode&&foreground);}
            if(guideUi!=null){guideUi.connection(true,simulated,extendedSupported);guideUi.active(guideMode&&foreground);if(guideMode&&foreground&&extendedSupported)link.extendedKeys(0);}
            if(oledGuideUi!=null)oledGuideUi.connection(true,simulated);
            if(sdLibraryUi!=null)sdLibraryUi.connection(true,simulated);
            info(simulated?"模拟设备使用同一 12 字节协议、四声部限制和 2 秒看门狗；可打开本地演示音。":"蓝牙与 FPGA 双向通信正常。导入 CSV 或切到后台会释放按键、停止回放，蓝牙连接保留。声音请在设备端聆听。");
            sendVolume(volumeState.ready());link.control(11,0);link.control(6,0);
        }
        public void frame(Protocol.Frame frame){onFrame(frame);}
        public void message(String message){info(message);if(link!=null&&!link.ready())connection.setText(message);}
        public void ended(String reason){resetDisconnectedUi(reason);}
        public void visual(VisualFrames.Snapshot snapshot){if(effectsUi!=null)effectsUi.snapshot(snapshot);}
        public void guide(Session.GuideState snapshot){if(oledGuideUi!=null)oledGuideUi.snapshot(snapshot);}
        public void sd(SdLibraryFlow.State snapshot){if(sdLibraryUi!=null)sdLibraryUi.snapshot(snapshot);}
    };
    private final ServiceConnection serviceConnection=new ServiceConnection(){
        public void onServiceConnected(ComponentName name,IBinder binder){linkService=((LinkService.LocalBinder)binder).service();link=linkService.session();if(foreground)attachUi();}
        public void onServiceDisconnected(ComponentName name){uiAttached=false;link=null;linkService=null;resetDisconnectedUi("蓝牙服务已停止，请重新连接");}
    };
    private DemoAudio audio;
    private PianoView piano;
    private EnsembleView ensemble;
    private ScrollView dashboard;
    private LinearLayout ensembleRoot;
    private TextView ensembleConnection,ensembleStatus,ensembleNotice,ensembleVolume;
    private SeekBar ensembleVolumeBar,effectVolumeBar;
    private VolumeState volumeState;
    private TextView connection,status,notice,recordState,volumeLabel;
    private Button recordButton,replayButton;
    private CheckBox localSound;
    private Spinner timbreSpinner,octaveSpinner;
    private SeekBar volumeBar;
    private LinearLayout column;
    private boolean updating,replaying,overflowSeen,foreground,ensembleMode,extendedSupported,releasing;
    private int timbre,volume=8,octave,lastEvent=-1,replayGeneration;
    private Runnable replayTask;
    private String lastInfo="真实连接支持已配对设备或输入蓝牙地址；先断开其他 SPP 调试器。无需扫描或定位权限。";

    @Override public void onCreate(Bundle state){
        super.onCreate(state);audio=new DemoAudio();preferences=getSharedPreferences("piano",MODE_PRIVATE);
        volumeState=new VolumeState(preferences.getInt("volume",8));volume=volumeState.selected();parameters();
        for(int i=0;i<12;i++)keyMap.set(i,Math.max(0,Math.min(11,preferences.getInt("map"+i,i))));
        ScrollView scroll=new ScrollView(this);dashboard=scroll;scroll.setFillViewport(true);
        column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);column.setPadding(dp(16),dp(12),dp(16),dp(18));column.setBackgroundColor(0xff111926);
        scroll.addView(column);scroll.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});setContentView(scroll);
        TextView title=text("PianoLink 2.3 · SD曲库与OLED跟弹",24);title.setTextColor(0xff65ded6);column.addView(title);
        column.addView(text("HC-05 串口蓝牙 / 无硬件模拟",14));
        connection=text("未连接 · 选择模拟设备即可在手机上体验",16);column.addView(connection);
        LinearLayout connectRow=row();button(connectRow,"模拟设备",v->connect(true,null));button(connectRow,"连接蓝牙",v->chooseBluetooth());button(connectRow,"断开",v->disconnect("已断开并释放手机按键"));column.addView(connectRow);
        LinearLayout parameterRow=row();
        timbreSpinner=spinner(new String[]{"设备音色：0","设备音色：1","设备音色：2","设备音色：3"},position->{timbre=position;parameters();if(link!=null)link.control(1,position);});parameterRow.addView(timbreSpinner,new LinearLayout.LayoutParams(0,dp(52),1));
        octaveSpinner=spinner(new String[]{"八度：原位","八度：升一组","八度：降一组"},position->{octave=position;parameters();if(link!=null)link.control(3,position);});parameterRow.addView(octaveSpinner,new LinearLayout.LayoutParams(0,dp(52),1));column.addView(parameterRow);
        volumeLabel=text("",14);column.addView(volumeLabel);volumeBar=volumeSlider();column.addView(volumeBar);
        localSound=new CheckBox(this);localSound.setText("本地演示音（最多四声部，非 FPGA 声音）");localSound.setTextSize(13);localSound.setOnCheckedChangeListener((b,checked)->setLocalAudio(checked));column.addView(localSound);
        status=text("声部 ○ ○ ○ ○   有效键 000   设备状态待连接",14);column.addView(status);
        piano=new PianoView(this,keyMap,mask->{if(link!=null&&!replaying&&!ensembleMode&&!effectsMode&&!guideMode&&!releasing)link.keys(mask);});column.addView(piano,new LinearLayout.LayoutParams(-1,dp(205)));piano.playable(false);
        LinearLayout ensembleRow=row();button(ensembleRow,"横屏 · 36 键合奏与实时卷帘",v->enterEnsemble());column.addView(ensembleRow);
        LinearLayout guideRow=row();button(guideRow,"横屏 · 乐曲引导（下落音符）",v->enterGuide());column.addView(guideRow);
        LinearLayout effectsRow=row();button(effectsRow,"效果与可视化",v->enterEffects());column.addView(effectsRow);
        LinearLayout keyActions=row();button(keyActions,"全部松开",v->{stopReplay();release();});button(keyActions,"按键映射",v->mapping());button(keyActions,"恢复映射",v->{stopReplay();release();for(int i=0;i<12;i++){keyMap.set(i,i);preferences.edit().putInt("map"+i,i).apply();}piano.invalidate();});column.addView(keyActions);
        column.addView(text("录制 / 曲库 / 离线音频转谱",17));
        recordState=text("尚无录制。首个设备事件记为 0ms，保留设备时间间隔。",13);column.addView(recordState);
        LinearLayout recordRow=row();recordButton=button(recordRow,"开始录制",v->toggleRecording());replayButton=button(recordRow,"播放所选",v->toggleReplay());column.addView(recordRow);
        LinearLayout fileRow=row();button(fileRow,"导出 CSV",v->exportCsv());button(fileRow,"导入 CSV",v->importCsv());button(fileRow,"清除溢出",v->{if(link!=null)link.control(8,0);overflowSeen=false;info("已请求清除设备溢出；已有录制的不完整标记保留。");});column.addView(fileRow);
        libraryUi=new SongLibraryUi(this,column,new SongLibraryUi.Host(){
            public void message(String value){info(value);}
            public void stopPlayback(){stopReplay();release();}
            public boolean recordingActive(){return recording.isActive();}
            public SongData recordingSnapshot(){return SongData.fromRecording(recording);}
            public void selected(SongLibrary.Entry entry,SongData song){stopReplay();if(guideUi!=null)guideUi.pauseForInterruption();release();selectedSong=song;}
            public void playSelected(){toggleReplay();}
        });
        oledGuideUi=new OledGuideUi(this,column,new OledGuideUi.Host(){
            public SongData selected(){return selectedSong;}
            public String name(){return libraryUi==null||libraryUi.selectedName()==null?"所选曲目":libraryUi.selectedName();}
            public boolean download(int[] masks){stopReplay();release();return link!=null&&link.guideDownload(linkEvents,masks);}
            public boolean action(int value){return link!=null&&link.guideAction(linkEvents,value);}
            public void cancel(){if(link!=null)link.guideCancel(linkEvents);}
            public void refresh(){if(link!=null)link.guideRefresh(linkEvents);}
            public void message(String text){info(text);}
        });
        sdLibraryUi=new SdLibraryUi(this,column,new SdLibraryUi.Host(){
            public SongData selected(){return selectedSong;}
            public String name(){return libraryUi==null||libraryUi.selectedName()==null?"所选曲目":libraryUi.selectedName();}
            public boolean save(int slot,String title,int[] masks){stopReplay();release();return link!=null&&link.sdSave(linkEvents,slot,title,masks);}
            public boolean load(int slot){return link!=null&&link.sdLoad(linkEvents,slot);}
            public boolean delete(int slot){return link!=null&&link.sdDelete(linkEvents,slot);}
            public boolean scan(){return link!=null&&link.sdScan(linkEvents);}
            public void refresh(){if(link!=null)link.sdRefresh(linkEvents);}
            public void message(String text){info(text);}
        });
        notice=text(lastInfo,13);notice.setTextColor(0xfff6cc7d);column.addView(notice);
        column.addView(text("曲库保存在手机，选择后播放；音频可离线转成36键CSV。回放保留松键边沿，链路繁忙时会变慢。切后台停止演奏并保留蓝牙连接。",12));
        LinearLayout systemRow=row();button(systemRow,"系统蓝牙设置",v->startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));column.addView(systemRow);
        createEnsemble();effectVolumeBar=volumeSlider();effectsUi=new EffectsUi(this,new EffectsUi.Host(){
            public void back(){leaveEffects();}public void release(){MainActivity.this.release();}
            public void effect(int id,int value){if(link!=null)link.effect(linkEvents,id,value);}
            public void visual(int kind,boolean active){if(link!=null)link.visual(linkEvents,kind,active&&effectsMode&&foreground);}
            public void keys(long mask){if(effectsMode&&foreground&&!releasing&&extendedSupported&&link!=null&&link.ready()){link.extendedKeys(mask);audio.extendedNotes(mask);}}
            public void localAudio(boolean enabled){setLocalAudio(enabled);}
        },effectVolumeBar);
        guideUi=new SongGuideUi(this,new SongGuideUi.Host(){
            public void back(){leaveGuide();}
            public void release(){MainActivity.this.release();}
            public void keys(long mask){
                if(!guideMode||!foreground||releasing)return;
                // Local touch stays responsive even without a Bluetooth device.
                audio.extendedNotes(mask);
                if(extendedSupported&&link!=null&&link.ready())link.extendedKeys(mask);
            }
            public void localAudio(boolean enabled){setLocalAudio(enabled);}
        });updateVolumeLabels();
        serviceBound=bindService(new Intent(this,LinkService.class),serviceConnection,Context.BIND_AUTO_CREATE);
        if(!serviceBound)info("连接服务无法启动，请重新打开应用。");
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int size){TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(0xffe5edf6);view.setPadding(0,dp(5),0,dp(5));return view;}
    private LinearLayout row(){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);return row;}
    private Button button(LinearLayout row,String label,View.OnClickListener click){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setAllCaps(false);b.setOnClickListener(click);row.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));return b;}
    private interface Selection{void select(int value);}
    private Spinner spinner(String[] labels,Selection selection){Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> parent){}public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){if(!updating)selection.select(position);}});return spinner;}
    private void info(String message){lastInfo=message;if(notice!=null)notice.setText(message);if(ensembleNotice!=null)ensembleNotice.setText(message);}
    private void parameters(){audio.parameters(timbre,volume,octave);}
    private void setLocalAudio(boolean enabled){audio.enabled(enabled);if(localSound!=null&&localSound.isChecked()!=enabled)localSound.setChecked(enabled);if(effectsUi!=null)effectsUi.localAudio(enabled);if(guideUi!=null)guideUi.localAudio(enabled);}
    private SeekBar volumeSlider(){
        SeekBar bar=new SeekBar(this);bar.setMax(15);bar.setProgress(volumeState.selected());
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar slider){volumeState.beginDrag();}
            public void onStopTrackingTouch(SeekBar slider){sendVolume(volumeState.endDrag());}
            public void onProgressChanged(SeekBar slider,int value,boolean user){
                int command=volumeState.change(value,user);if(!user)return;
                volume=volumeState.selected();preferences.edit().putInt("volume",volume).apply();parameters();
                if(volumeBar!=null&&volumeBar!=slider)volumeBar.setProgress(volume);
                if(ensembleVolumeBar!=null&&ensembleVolumeBar!=slider)ensembleVolumeBar.setProgress(volume);
                if(effectVolumeBar!=null&&effectVolumeBar!=slider)effectVolumeBar.setProgress(volume);
                updateVolumeLabels();sendVolume(command);
            }
        });return bar;
    }
    private void sendVolume(int value){if(value>=0&&link!=null&&link.ready())link.control(2,value);}
    private void updateVolumeLabels(){String actual=volumeState.reported()<0?"待设备报告":String.valueOf(volumeState.reported());String label="所选音量 "+volumeState.selected()+" / 15 · 设备 "+actual+(volumeState.reported()>=0&&volumeState.reported()!=volumeState.selected()?"（与所选不同）":"");if(volumeLabel!=null)volumeLabel.setText(label);if(ensembleVolume!=null)ensembleVolume.setText(label);if(effectsUi!=null)effectsUi.volume(label);}
    private void createEnsemble(){
        ensembleRoot=new LinearLayout(this);ensembleRoot.setOrientation(LinearLayout.VERTICAL);ensembleRoot.setBackgroundColor(0xff111926);ensembleRoot.setPadding(dp(10),dp(3),dp(10),dp(4));
        ensembleRoot.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft()+dp(10),insets.getSystemWindowInsetTop()+dp(3),insets.getSystemWindowInsetRight()+dp(10),insets.getSystemWindowInsetBottom()+dp(4));return insets;});
        LinearLayout top=row();Button back=new Button(this);back.setText("返回面板");back.setTextSize(12);back.setOnClickListener(v->leaveEnsemble());top.addView(back,new LinearLayout.LayoutParams(dp(104),dp(44)));
        ensembleConnection=text("未连接",12);top.addView(ensembleConnection,new LinearLayout.LayoutParams(0,dp(44),1));
        Button releaseButton=new Button(this);releaseButton.setText("全部松开");releaseButton.setTextSize(12);releaseButton.setOnClickListener(v->release());top.addView(releaseButton,new LinearLayout.LayoutParams(dp(104),dp(44)));ensembleRoot.addView(top);
        LinearLayout controls=row();ensembleVolume=text("",12);controls.addView(ensembleVolume,new LinearLayout.LayoutParams(0,dp(38),1.4f));ensembleVolumeBar=volumeSlider();controls.addView(ensembleVolumeBar,new LinearLayout.LayoutParams(0,dp(38),1));ensembleRoot.addView(controls);
        ensembleStatus=text("C3—B5 · 手机与实体琴共用 4 声部",12);ensembleRoot.addView(ensembleStatus);
        ensembleNotice=text("青色：手机触摸 · 金色：设备合并反馈 · 实时卷帘不写入 CSV",11);ensembleNotice.setMaxLines(2);ensembleNotice.setTextColor(0xfff6cc7d);ensembleRoot.addView(ensembleNotice);
        ensemble=new EnsembleView(this,mask->{if(ensembleMode&&!releasing&&extendedSupported&&link!=null&&link.ready()){link.extendedKeys(mask);audio.extendedNotes(foreground?mask:0);}});ensembleRoot.addView(ensemble,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void enterEnsemble(){
        if(libraryUi!=null&&libraryUi.isConverting()){info("请先完成或取消音频转换。");return;}
        stopReplay();release();if(recording.isActive()){recording.markIncomplete();recording.stop();updateRecording();}
        ensembleMode=true;ensembleConnection.setText(connection.getText());ensemble.playable(extendedSupported&&link!=null&&link.ready());
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);setContentView(ensembleRoot);
        if(extendedSupported&&link!=null&&link.ready())link.extendedKeys(0);
        info(extendedSupported?"C3—B5 固定音高 · 实体琴与手机合计最多 4 声部。青色触摸 / 金色设备合并反馈；卷帘仅即时显示，不录 CSV。40ms 内触摸变化可能合并。":"36 键需设备能力确认；可连接模拟设备体验，旧固件仍可返回十二键面板演奏。");
    }
    private void leaveEnsemble(){release();ensembleMode=false;if(link!=null&&link.ready())link.keys(0);setContentView(dashboard);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);piano.playable(link!=null&&link.ready());info("已返回十二键面板；蓝牙连接保留。");}
    private void enterEffects(){
        if(libraryUi!=null&&libraryUi.isConverting()){info("请先完成或取消音频转换。");return;}
        stopReplay();release();if(recording.isActive()){recording.markIncomplete();recording.stop();updateRecording();}
        effectsMode=true;piano.playable(false);effectsUi.connection(link!=null&&link.ready(),link!=null&&link.simulated(),extendedSupported);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);setContentView(effectsUi.view());effectsUi.active(foreground);if(link!=null&&link.ready())link.control(12,0);
    }
    private void leaveEffects(){effectsUi.active(false);release();effectsMode=false;if(link!=null&&link.ready())link.keys(0);setContentView(dashboard);piano.playable(link!=null&&link.ready());}
    private void enterGuide(){
        if(libraryUi!=null&&libraryUi.isConverting()){info("请先完成或取消音频转换。");return;}
        stopReplay();release();if(recording.isActive()){recording.markIncomplete();recording.stop();updateRecording();}
        String songName=libraryUi==null?null:libraryUi.selectedName();
        try{guideUi.load(selectedSong,songName==null?"自编入门练习":songName);}
        catch(IllegalArgumentException error){info("无法打开乐曲引导："+error.getMessage());return;}
        guideMode=true;piano.playable(false);
        guideUi.connection(link!=null&&link.ready(),link!=null&&link.simulated(),extendedSupported);
        guideUi.deviceStatus(octave,-1);guideUi.localAudio(localSound.isChecked());
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);setContentView(guideUi.view());guideUi.active(foreground);
        // Physical-only practice also needs the extended event stream (CMD0B only queries it).
        if(extendedSupported&&link!=null&&link.ready())link.extendedKeys(0);
        if(link!=null&&link.ready()){link.control(11,0);link.control(6,0);}
    }
    private void leaveGuide(){
        guideUi.active(false);release();guideMode=false;
        if(link!=null&&link.ready())link.resetLegacy(linkEvents);
        setContentView(dashboard);setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);piano.playable(link!=null&&link.ready());
        info("已返回面板；乐曲引导不会自动代奏，蓝牙连接保留。");
    }
    @Override public void onBackPressed(){if(guideMode)leaveGuide();else if(effectsMode)leaveEffects();else if(ensembleMode)leaveEnsemble();else super.onBackPressed();}
    @Override public void onConfigurationChanged(Configuration config){if(guideUi!=null)guideUi.pauseForInterruption();stopReplay();release();super.onConfigurationChanged(config);}
    private void chooseBluetooth(){
        if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},PERMISSION);return;}
        try{
            BluetoothManager manager=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);BluetoothAdapter adapter=manager==null?null:manager.getAdapter();
            if(adapter==null){info("此手机无蓝牙适配器，可使用模拟设备。");return;}
            if(!adapter.isEnabled()){info("请先在系统蓝牙设置中开启蓝牙；搜索或配对结束后退出搜索页面。");return;}
            ArrayList<BluetoothDevice> devices=new ArrayList<>(adapter.getBondedDevices());
            String[] labels=new String[devices.size()];for(int i=0;i<labels.length;i++){BluetoothDevice d=devices.get(i);labels[i]=(d.getName()==null?"未命名设备":d.getName())+"\n"+d.getAddress();}
            AlertDialog.Builder picker=new AlertDialog.Builder(this).setTitle("选择 HC-05 / SPP 设备");
            if(devices.isEmpty())picker.setMessage("没有已配对设备。可输入 SPP 调试器中显示的设备蓝牙地址；连接时仍可能需要确认系统配对。");
            else picker.setItems(labels,(dialog,index)->chooseConnectionMode(devices.get(index)));
            picker.setNeutralButton("输入地址",(dialog,which)->enterBluetoothAddress(adapter)).setNegativeButton("取消",null).show();
        }catch(SecurityException e){info("蓝牙权限不可用；模拟设备仍可使用。");}
    }
    private void enterBluetoothAddress(BluetoothAdapter adapter){
        EditText address=new EditText(this);address.setSingleLine(true);address.setHint("00:11:22:33:44:55");address.setText(preferences.getString("bluetoothAddress",""));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("输入模块蓝牙地址").setMessage("从能连接的 SPP 调试器复制地址，不是设备名称。先断开该调试器。")
            .setView(address).setPositiveButton("下一步",null).setNegativeButton("取消",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            String value=address.getText().toString().trim().toUpperCase(Locale.ROOT);
            if(!BluetoothAdapter.checkBluetoothAddress(value)){address.setError("格式应为六组十六进制数，例如 00:11:22:33:44:55");return;}
            try{BluetoothDevice device=adapter.getRemoteDevice(value);preferences.edit().putString("bluetoothAddress",value).apply();dialog.dismiss();chooseConnectionMode(device);}
            catch(SecurityException e){info("蓝牙连接权限不可用，请在系统应用权限中允许附近设备。");}
        }));dialog.show();
    }
    private void chooseConnectionMode(BluetoothDevice device){
        new AlertDialog.Builder(this).setTitle("选择 SPP 连接方式")
            .setItems(new String[]{"兼容 SPP（先尝试，无认证 RFCOMM）","安全 SPP（认证 RFCOMM，原版方式）"},(dialog,index)->connect(false,device,index==1))
            .setNegativeButton("取消",null).show();
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==PERMISSION){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)chooseBluetooth();else info("未授予蓝牙连接权限，可继续使用模拟设备。");}}
    private void connect(boolean simulation,BluetoothDevice device){
        connect(simulation,device,false);
    }
    private void connect(boolean simulation,BluetoothDevice device,boolean secure){
        if(linkService==null){info("连接服务正在准备，请稍后再试。");return;}
        stopReplay();release();lastEvent=-1;overflowSeen=false;
        if(!simulation&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATIONS);
        linkService.connect(simulation,device,secure);
    }
    private void onFrame(Protocol.Frame f){
        if(effectsUi!=null)effectsUi.frame(f);
        boolean extended=f.isExtendedState();
        if(extended){
            boolean newlySupported=f.cmd==0x83&&!extendedSupported;if(f.cmd==0x83)extendedSupported=true;
            if(newlySupported){if(ensembleMode&&link!=null){link.extendedKeys(0);ensemble.playable(true);}if(guideMode&&foreground&&link!=null)link.extendedKeys(0);if(effectsUi!=null)effectsUi.connection(link!=null&&link.ready(),link!=null&&link.simulated(),true);if(guideUi!=null)guideUi.connection(link!=null&&link.ready(),link!=null&&link.simulated(),true);info("已确认 36 键协议 · 手机与实体琴共用四个声部。金色反馈为设备合并音符；卷帘不写入 CSV。");}
            ensemble.confirmed(f.extendedMask());int voices=f.extendedVoices();StringBuilder label=new StringBuilder("C3—B5 · 合奏声部 ");for(int i=0;i<4;i++)label.append((voices&(1<<i))!=0?"● ":"○ ");label.append("（共用 4 声部）");if((f.d[5]&128)!=0)label.append(" · 设备事件曾溢出");ensembleStatus.setText(label);
            if(effectsUi!=null)effectsUi.confirmed(f.extendedMask());
            if(guideUi!=null)guideUi.confirmed(f.extendedMask());
            if(ensembleMode||effectsMode||isAbsolutePlayback())audio.extendedNotes(foreground?f.extendedMask():0);
            if(isAbsolutePlayback())status.setText(label.toString()+String.format(Locale.ROOT," · 键 %09X",f.extendedMask()));
        }
        if(f.cmd==0x80&&f.d[0]==11&&f.d[1]!=0&&!extendedSupported)info("当前固件未支持 36 键扩展；十二键面板可继续使用，升级固件后再进入横屏合奏。");
        boolean overflow=f.cmd==0x80?f.d[3]!=0:f.cmd==0x81&&(f.d[3]&128)!=0;
        if(overflow){overflowSeen=true;if(recording.isActive())recording.markIncomplete();info("设备事件队列溢出：本段录制可能不完整。可清除标志后重新录制。");}
        if(f.cmd==0x82){
            if(recording.isActive()&&lastEvent!=-1&&f.seq!=((lastEvent+1)&255)){recording.markIncomplete();info("事件序号中断：录制已标记不完整。");}
            lastEvent=f.seq;if(!ensembleMode&&!guideMode)recording.accept(f);updateKeys(f.mask(),f.voices(),"事件时间来自设备");updateRecording();
        }else if(f.cmd==0x81){
            if(f.d[0]>3||f.d[1]>15||f.d[2]>2){info("设备状态参数无效，请检查固件协议版本。");return;}
            updating=true;timbre=f.d[0];volumeState.report(f.d[1]);octave=f.d[2];timbreSpinner.setSelection(timbre);octaveSpinner.setSelection(octave);updating=false;parameters();updateVolumeLabels();
            if(guideUi!=null)guideUi.deviceStatus(octave,f.d[3]&3);
            updateKeys(f.d[4]|((f.d[5]&15)<<8),f.voices(),"模式 "+(f.d[3]&3)+(overflowSeen?" · 曾溢出":""));
        }
    }
    private void updateKeys(int mask,int voices,String suffix){StringBuilder label=new StringBuilder("声部 ");for(int i=0;i<4;i++)label.append((voices&(1<<i))!=0?"● ":"○ ");label.append(String.format(Locale.ROOT,"  键 %03X  ",mask)).append(suffix);status.setText(label);if(!ensembleMode&&!effectsMode&&!guideMode&&!isAbsolutePlayback())audio.notes(foreground?mask:0);}
    private void release(){releasing=true;try{if(piano!=null)piano.release();if(ensemble!=null)ensemble.release();if(effectsUi!=null)effectsUi.releaseKeys();if(guideUi!=null)guideUi.releaseKeys();}finally{releasing=false;}if(link!=null){link.release(linkEvents);if(guideMode&&foreground&&extendedSupported&&link.ready())link.control(11,0);}if(audio!=null)audio.notes(0);}
    private void disconnect(String reason){
        stopReplay();release();if(linkService!=null)linkService.disconnect(reason);else resetDisconnectedUi(reason);
    }
    private void resetDisconnectedUi(String reason){
        stopReplay();release();
        extendedSupported=false;if(volumeState!=null){volumeState.disconnected();updateVolumeLabels();}if(ensemble!=null){ensemble.playable(false);ensemble.confirmed(0);}if(ensembleConnection!=null)ensembleConnection.setText(reason);
        if(effectsUi!=null)effectsUi.connection(false,false,false);
        if(guideUi!=null)guideUi.connection(false,false,false);
        if(oledGuideUi!=null)oledGuideUi.connection(false,false);
        if(sdLibraryUi!=null)sdLibraryUi.connection(false,false);
        if(recording.isActive()){recording.markIncomplete();recording.stop();updateRecording();}
        if(piano!=null)piano.playable(false);if(connection!=null)connection.setText(reason);if(status!=null)status.setText("声部 ○ ○ ○ ○   手机键已释放");
    }
    private void mapping(){stopReplay();release();String[] labels=new String[12];for(int i=0;i<12;i++)labels[i]=PianoView.NAMES[i]+" → "+PianoView.NAMES[keyMap.get(i)];new AlertDialog.Builder(this).setTitle("选择屏幕按键（允许重复映射）").setItems(labels,(dialog,key)->new AlertDialog.Builder(this).setTitle(PianoView.NAMES[key]+" 映射到").setItems(PianoView.NAMES,(d,note)->{keyMap.set(key,note);preferences.edit().putInt("map"+key,note).apply();piano.invalidate();}).show()).setNegativeButton("关闭",null).show();}
    private boolean isAbsolutePlayback(){return replaying&&playbackSong!=null&&playbackSong.format==SongData.Format.ABSOLUTE36;}
    private void toggleRecording(){
        if(libraryUi!=null&&libraryUi.isConverting()){info("请先完成或取消音频转换。");return;}
        if(recording.isActive()){recording.stop();updateRecording();return;}
        if(link==null||!link.ready()){info("请先连接模拟设备或真实蓝牙设备。");return;}
        stopReplay();release();if(libraryUi!=null)libraryUi.recordingStarted();link.resetLegacy(linkEvents);lastEvent=-1;overflowSeen=false;recording.start();link.control(8,0);updateRecording();info("正在录制原12键设备事件。切到后台会释放按键、停止录制并标记不完整；蓝牙连接保留。");
    }
    private void updateRecording(){if(recordButton==null)return;recordButton.setText(recording.isActive()?"停止录制":"开始录制");recordState.setText((recording.isActive()?"录制中 · ":"已保存 · ")+recording.count()+" 事件 · "+recording.duration()+" ms"+(recording.isIncomplete()?" · 不完整":""));}
    private void toggleReplay(){
        if(replaying){stopReplay();return;}
        if(libraryUi!=null&&libraryUi.isConverting()){info("请先完成或取消音频转换。");return;}
        if(link==null||!link.ready()){info("请先连接设备，曲目回放需要保持连接。");return;}
        if(recording.isActive()){info("请先停止录制，再保存/回放。");return;}
        SongData chosen=selectedSong;
        if(chosen==null){try{chosen=SongData.fromRecording(recording);}catch(Exception e){info("请先从曲库选择曲目，或录制/导入CSV。");return;}}
        if(chosen.format==SongData.Format.ABSOLUTE36&&!extendedSupported){info("该曲目使用36键绝对音高，当前设备尚未确认36键能力；连接模拟设备或配套固件后再播放。");return;}
        release();replaying=true;playbackSong=chosen;piano.playable(false);replayButton.setText("停止回放");
        final int generation=++replayGeneration;final LinkSession current=link;
        final SongReplay timeline=new SongReplay(chosen,new SongReplay.Sink(){
            public boolean offer(long mask,boolean absolute){return current==link&&foreground&&current.offerPlaybackMask(mask,absolute);}
            public boolean pending(){return current.playbackPending();}
            public void release(){current.release(linkEvents);}
        });
        songReplay=timeline;timeline.start(SystemClock.elapsedRealtime());
        replayTask=new Runnable(){boolean warned;public void run(){
            if(generation!=replayGeneration||current!=link||!current.ready()){if(generation==replayGeneration)stopReplay();return;}
            if(!timeline.tick(SystemClock.elapsedRealtime())){stopReplay();info("曲目回放结束，已释放手机按键。");return;}
            if(timeline.isDelayed()&&!warned){warned=true;info("链路繁忙，保留音符与松键边沿，播放时间已适度延长。");}
            main.postDelayed(this,10);
        }};main.post(replayTask);
        info("曲目回放中 · "+(chosen.format==SongData.Format.ABSOLUTE36?"36键固定音高":"原12键")+(chosen.incomplete?" · 原记录不完整":""));
    }
    private void stopReplay(){
        replayGeneration++;if(replayTask!=null){main.removeCallbacks(replayTask);replayTask=null;}
        if(songReplay!=null){songReplay.stop();songReplay=null;}
        boolean was=replaying,absolute=isAbsolutePlayback();replaying=false;playbackSong=null;
        if(replayButton!=null)replayButton.setText("播放所选");
        if(piano!=null)piano.playable(!ensembleMode&&!effectsMode&&!guideMode&&link!=null&&link.ready());
        if(was&&link!=null){link.release(linkEvents);if(absolute&&!ensembleMode&&!guideMode)link.resetLegacy(linkEvents);}if(audio!=null&&was)audio.notes(0);
    }
    private void exportCsv(){if(libraryUi!=null)libraryUi.exportCsv();}
    private void importCsv(){if(libraryUi!=null)libraryUi.importCsv();}
    @Override public void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(libraryUi!=null)libraryUi.onActivityResult(request,result,data);
    }
    private void attachUi(){if(link==null)return;if(!uiAttached){uiAttached=true;link.attach(linkEvents);}link.resume(linkEvents);if(!ensembleMode&&!effectsMode&&!guideMode&&!replaying)link.resetLegacy(linkEvents);if(guideMode&&extendedSupported&&link.ready())link.control(11,0);}
    @Override protected void onResume(){super.onResume();foreground=true;attachUi();if(effectsUi!=null)effectsUi.active(effectsMode);if(guideUi!=null)guideUi.active(guideMode);}
    @Override protected void onPause(){
        foreground=false;if(effectsUi!=null)effectsUi.active(false);if(guideUi!=null)guideUi.active(false);sendVolume(volumeState.endDrag());stopReplay();release();if(link!=null)link.pause(linkEvents);
        if(recording.isActive()){recording.markIncomplete();recording.stop();updateRecording();}
        super.onPause();
    }
    @Override protected void onStop(){if(libraryUi!=null)libraryUi.onStop();if(link!=null&&uiAttached){link.detach(linkEvents);uiAttached=false;}super.onStop();}
    @Override protected void onDestroy(){
        stopReplay();release();if(link!=null)link.detach(linkEvents);uiAttached=false;
        if(serviceBound){unbindService(serviceConnection);serviceBound=false;}link=null;linkService=null;
        if(libraryUi!=null)libraryUi.close();if(effectsUi!=null)effectsUi.close();if(guideUi!=null)guideUi.close();if(oledGuideUi!=null)oledGuideUi.close();if(sdLibraryUi!=null)sdLibraryUi.close();audio.close();main.removeCallbacksAndMessages(null);super.onDestroy();
    }
}
