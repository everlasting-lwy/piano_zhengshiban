package org.pianolink;

import java.util.ArrayList;
import java.util.TreeSet;

/** Onset-only adaptation; durations never become remote key-playback commands. */
public final class OledGuideSong {
    private static final int[] PORT={0,7,1,8,2,3,9,4,10,5,11,6,12,13,14,15,16,17};
    private final int[] steps;
    public final int foldedNotes,mergedNotes,droppedNotes,simplifiedSteps;
    private OledGuideSong(int[] steps,int folded,int merged,int dropped,int simplified){this.steps=steps;foldedNotes=folded;mergedNotes=merged;droppedNotes=dropped;simplifiedSteps=simplified;}
    public int[] masks(){return steps.clone();}
    public int size(){return steps.length;}
    public static OledGuideSong from(SongData source){return from(GuideSong.from(source));}
    public static OledGuideSong from(GuideSong song){
        ArrayList<Integer> result=new ArrayList<>();int folded=0,merged=0,dropped=0,simplified=0;
        for(int i=0;i<song.notes.size();){long onset=song.notes.get(i).startMs;TreeSet<Integer> pitches=new TreeSet<>();
            while(i<song.notes.size()&&song.notes.get(i).startMs==onset){int key=song.notes.get(i++).key,adapted=key;while(adapted<12)adapted+=12;while(adapted>29)adapted-=12;if(adapted!=key)folded++;if(!pitches.add(adapted))merged++;}
            if(pitches.size()>4){simplified++;while(pitches.size()>4){pitches.pollFirst();dropped++;}}
            int mask=0;for(int key:pitches)mask|=1<<PORT[key-12];if(mask!=0)result.add(mask);
            if(result.size()>OledGuideProtocol.MAX_STEPS)throw new IllegalArgumentException("引导超过2048步，请先裁剪曲目后下载；不会自动截断");
        }
        if(result.isEmpty())throw new IllegalArgumentException("曲目没有可下载的引导音符");int[] masks=new int[result.size()];for(int i=0;i<masks.length;i++)masks[i]=result.get(i);return new OledGuideSong(masks,folded,merged,dropped,simplified);
    }
    public String preview(){return size()+" 步 / 2048\n折回八度 "+foldedNotes+" 音；合并重复 "+mergedNotes+" 音\n简化 "+simplifiedSteps+" 步，舍去 "+droppedNotes+" 个低音（每步保留最高4音）\n等待实体18键弹对，不考核节拍或时值。请使用原位八度。\n曲谱在FPGA RAM中，复位/掉电清空。";}
}
