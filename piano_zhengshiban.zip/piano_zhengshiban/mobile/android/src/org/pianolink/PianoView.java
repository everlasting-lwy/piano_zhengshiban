package org.pianolink;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

/** One multi-touch surface counts pointer IDs; duplicate mapped notes use OR, never toggles. */
public final class PianoView extends View {
    public interface Listener{void changed(int mask);}
    private final KeyMap map;private final Listener listener;private final Paint paint=new Paint(3);
    private final HashMap<Integer,Integer> fingers=new HashMap<>();private final RectF[] keys=new RectF[12];
    public static final String[] NAMES={"C","D","E","F","G","A","B","C♯","D♯","F♯","G♯","A♯"};
    private boolean playable=true;
    public PianoView(Context context,KeyMap map,Listener listener){super(context);this.map=map;this.listener=listener;setFocusable(true);setContentDescription("十二键多点触摸钢琴；自然音在下，升音在上");}
    public void playable(boolean enabled){playable=enabled;if(!enabled)release();}
    public void release(){fingers.clear();map.clear();listener.changed(0);invalidate();}
    private int keyAt(float x,float y){for(int n=7;n<12;n++)if(keys[n]!=null&&keys[n].contains(x,y))return n;for(int n=0;n<7;n++)if(keys[n]!=null&&keys[n].contains(x,y))return n;return -1;}
    private void update(){map.clear();for(int n:fingers.values())if(n>=0)map.down(n);listener.changed(map.mask());invalidate();}
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
        float unit=w/7f;for(int i=0;i<7;i++)keys[i]=new RectF(i*unit+2,h*.43f,(i+1)*unit-2,h-3);
        int[] positions={1,2,4,5,6};for(int i=0;i<5;i++)keys[7+i]=new RectF(positions[i]*unit-unit*.35f,3,positions[i]*unit+unit*.35f,h*.43f-3);
    }
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);canvas.drawColor(Color.rgb(17,25,38));
        for(int n=0;n<12;n++){boolean down=fingers.containsValue(n);paint.setColor(down?0xff38c7c3:n<7?0xffedf1f5:0xff33465f);canvas.drawRoundRect(keys[n],8,8,paint);
            paint.setColor(n<7?0xff112233:Color.WHITE);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(getResources().getDisplayMetrics().scaledDensity*15);String label=NAMES[n];if(map.get(n)!=n)label+="→"+NAMES[map.get(n)];canvas.drawText(label,keys[n].centerX(),keys[n].bottom-18,paint);}
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(!playable)return true;getParent().requestDisallowInterceptTouchEvent(true);
        int action=event.getActionMasked(),index=event.getActionIndex();
        if(action==MotionEvent.ACTION_CANCEL){release();return true;}
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN)fingers.put(event.getPointerId(index),keyAt(event.getX(index),event.getY(index)));
        else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP)fingers.remove(event.getPointerId(index));
        else if(action==MotionEvent.ACTION_MOVE)for(int i=0;i<event.getPointerCount();i++)fingers.put(event.getPointerId(i),keyAt(event.getX(i),event.getY(i)));
        update();if(action==MotionEvent.ACTION_UP)performClick();return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
