package org.pianolink;

import java.security.SecureRandom;

/** Read-only discovery and catalog snapshots plus a single identity-bound SD mutation. */
public final class SdLibraryFlow {
    public static final class Entry {
        public final int slot,flags,steps;public final String title;
        Entry(int slot,int flags,int steps,String title){this.slot=slot;this.flags=flags;this.steps=steps;this.title=title;}
        public String label(){return String.format(java.util.Locale.ROOT,"%02d · %s",slot,(flags&1)!=0?(title.isEmpty()?"未命名":title)+" · "+steps+"步":(flags&4)!=0?"损坏/冲突文件":"空槽")+((flags&2)!=0?" · 只读":"");}
    }
    public static final class State {
        public final int version,capability,reported,state,error,progress,selected,flags,busy,action,slot,catalogRevision,catalogLoaded,preparing;
        public final long token,pendingToken,revision,transferLba;public final int transferChunk,transferWriting;public final String message;public final Entry[] entries;
        State(SdLibraryFlow f){version=f.version;capability=f.capability;reported=f.reported;state=f.state;error=f.error;progress=f.progress;selected=f.selected;flags=f.flags;busy=f.mutating()||(f.flags&4)!=0?1:0;preparing=f.waitingUpload?1:0;token=f.token;action=f.action;slot=f.slot;pendingToken=f.expected;revision=f.revision;message=f.message;catalogRevision=f.catalogRevision;catalogLoaded=f.catalogLoaded?1:0;entries=f.entries.clone();transferLba=f.transferLba;transferChunk=f.transferChunk;transferWriting=f.transferWriting;}
    }
    int version,capability,reported,state,error,progress,selected=255,flags,action,slot=255,catalogRevision,phase;
    private int phonePhase,phoneAction,phoneSlot,phoneSteps,transferChunk,transferWriting;private long transferLba=-1;private String phoneTitle;private boolean phoneFailure;
    long token,expected,revision;String message="SD曲库：等待设备能力确认";
    boolean waitingUpload,queued,catalogLoaded,loadCompleted;int desiredAction,desiredSlot,titlePart,entrySlot,titleOffset,entryFlags,entrySteps,titleLength,snapshotRevision=-1;
    private int[] stagedStatus;private byte[] title=new byte[32],entryTitle;private Entry[] entries=emptyEntries(),stagedEntries;
    private static long nextToken=new SecureRandom().nextInt()&0xffffffffL;
    private static synchronized long newToken(){nextToken=(nextToken+1)&0xffffffffL;if(nextToken==0)nextToken=1;return nextToken;}
    static Entry[] emptyEntries(){Entry[] result=new Entry[32];for(int i=0;i<32;i++)result[i]=new Entry(i,0,0,"");return result;}
    public State snapshot(){return new State(this);}
    boolean mutating(){return waitingUpload||queued||expected!=0||phonePhase!=0;}
    boolean active(){return phase!=0;}
    void refresh(){if(phase==0&&capability>=0&&!waitingUpload&&!queued)phase=1;}
    boolean reserveSave(int target,String name){if(version==2||!canStart(target,1))return false;title=SdLibraryProtocol.title(name);waitingUpload=true;desiredSlot=target;desiredAction=1;message="正在上传所选曲目到RAM；尚未保存到SD…";revision++;return true;}
    boolean reservePhone(int op,int target,byte[] file){if(version!=2||!canStart(target,op))return false;if(op!=1&&op!=3)throw new IllegalArgumentException("手机只执行保存/删除");if(op==1){P18File score=P18File.decode(file);phoneTitle=score.title;phoneSteps=score.masks.length;}phonePhase=1;phoneFailure=false;transferLba=-1;transferChunk=0;phoneAction=op;phoneSlot=target;message="手机正在"+verb(op)+"FAT32普通P18文件；完成后由FPGA重新扫描确认…";revision++;return true;}
    void phoneProgress(boolean writing,long lba,int chunks){if(phonePhase!=1||lba<0||chunks<0||chunks>128)return;int mode=writing?1:0;if(transferLba!=lba||transferChunk!=chunks||transferWriting!=mode){transferLba=lba;transferChunk=chunks;transferWriting=mode;revision++;}}
    void phoneFinished(String failure){if(phonePhase!=1)return;transferLba=-1;if(failure!=null){phonePhase=0;phoneFailure=true;message=verb(phoneAction)+"未确认："+failure+"；请查询设备，不自动重试写事务";revision++;return;}phonePhase=2;desiredAction=0;desiredSlot=255;queued=true;message="手机写入与会话结束已完成，等待FPGA重新扫描确认"+verb(phoneAction)+"结果…";revision++;if(phase==0)beginQueued();}
    void uploadFinished(boolean success){if(!waitingUpload)return;waitingUpload=false;if(success){queued=true;message="本次RAM上传完成，准备SD保存…";revision++;beginQueued();}else{message="RAM上传未完成；未发送SD保存";revision++;}}
    boolean start(int op,int target){if(version==2&&(op==1||op==3)||!canStart(target,op))return false;phoneFailure=false;desiredAction=op;desiredSlot=target;queued=true;message="准备"+verb(op)+"…";revision++;if(phase==0)beginQueued();return true;}
    boolean canStart(int target,int op){if(op<0||op>3||(op==0?target!=255:target<0||target>=32))throw new IllegalArgumentException("SD操作/槽位无效");boolean writing=op==1||op==3;return capability==1&&!mutating()&&(flags&4)==0&&(op==0||state==1)&&(!writing||(flags&16)==0);}
    private void beginQueued(){if(!queued)return;queued=false;expected=newToken();titlePart=0;phase=desiredAction==1?3:4;}
    private static String verb(int op){return op==0?"重新扫描":op==1?"保存":op==2?"载入":"删除";}
    private String failureReason(){
        if(error!=0)return SdLibraryProtocol.error(error);
        if((flags&16)!=0)return "设备处于写入保护；请检查干净卸载、暂存文件及上次写入结果";
        if((flags&1)==0)return "SD卡尚未初始化";
        if((flags&2)==0)return "FAT32尚未挂载";
        if(state!=1)return "SD尚未就绪（状态"+state+"）";
        return "设备未确认本次操作完成";
    }
    Protocol.Frame request(){int[] d=new int[6];int command;switch(phase){case 1:command=0x16;break;case 2:command=0x1b;break;case 3:command=0x18;d[0]=titlePart*5;for(int i=0;i<5;i++)d[i+1]=d[0]+i<32?title[d[0]+i]&255:0;break;case 4:command=0x17;d[0]=desiredAction;d[1]=desiredSlot;for(int i=0;i<4;i++)d[i+2]=(int)(expected>>>(i*8))&255;break;case 5:command=0x19;d[0]=entrySlot;break;case 6:command=0x1a;d[0]=entrySlot;d[1]=titleOffset;break;default:throw new IllegalStateException("no SD request");}return new Protocol.Frame(0,command,d);}
    void interrupted(){phase=0;reported=0;waitingUpload=false;queued=false;expected=0;phonePhase=0;transferLba=-1;flags&=~4;message="SD连接中断；结果未知。重连先查询设备状态，请勿盲目重复保存/删除。";revision++;}
    private void invalid(String text){phase=0;expected=0;queued=false;waitingUpload=false;if(phonePhase==2){phonePhase=0;phoneFailure=true;}message=text;revision++;}
    void receive(Protocol.Frame request,Protocol.Frame reply){
        if(reply.cmd==0x80){if(reply.d[1]!=0){if(request.cmd==0x16||request.cmd==0x1b){capability=-1;invalid("设备不支持SD曲库；其他演奏功能可继续使用");}else invalid("SD命令被拒绝 "+Integer.toHexString(request.cmd)+"，错误 "+reply.d[1]+"；未确认成功");return;}if(phase==3){if(++titlePart==7)phase=4;}else if(phase==4){phase=0;message="设备已接受"+verb(desiredAction)+"，等待SD实际完成…";revision++;}else invalid("SD查询回复类型无效");return;}
        if(request.cmd==0x16){if(!SdLibraryProtocol.status(reply)){invalid("SD状态无效；未确认成功");return;}stagedStatus=reply.d.clone();phase=2;}
        else if(request.cmd==0x1b){if(!SdLibraryProtocol.identity(reply)||stagedStatus==null){invalid("SD操作身份无效；未确认成功");return;}publish(stagedStatus,reply);stagedStatus=null;if(queued)beginQueued();}
        else if(request.cmd==0x19){if(!SdLibraryProtocol.entry(reply,entrySlot)){invalid("SD槽位报告无效");return;}if(snapshotRevision<0)snapshotRevision=reply.d[5];if(snapshotRevision!=reply.d[5]){invalid("SD目录在读取中变化，请重新扫描");return;}entryFlags=reply.d[1];entrySteps=reply.d[2]|reply.d[3]<<8;titleLength=reply.d[4];entryTitle=new byte[32];titleOffset=0;if(titleLength>0)phase=6;else finishEntry("");}
        else if(request.cmd==0x1a){if(reply.cmd!=0x8d||reply.d[0]!=titleOffset){invalid("SD标题偏移不匹配");return;}for(int i=0;i<5&&titleOffset+i<32;i++)entryTitle[titleOffset+i]=(byte)reply.d[i+1];titleOffset+=5;if(titleOffset>=titleLength){try{finishEntry(SdLibraryProtocol.decodeTitle(entryTitle,titleLength));}catch(IllegalArgumentException e){invalid(e.getMessage());}}}
        // Retire the current catalog SEQ before yielding to the phone worker. Its
        // successful END/rescan will rebuild a complete snapshot after the write.
        if(phonePhase==1&&(request.cmd==0x19||request.cmd==0x1a)){stagedEntries=null;phase=0;}
        if(queued&&(request.cmd==0x19||request.cmd==0x1a)){stagedEntries=null;beginQueued();}
    }
    private void publish(int[] d,Protocol.Frame identity){
        long next=SdLibraryProtocol.token(identity.d,0);boolean changed=reported==0||capability!=1||version!=d[0]||state!=d[1]||error!=d[2]||progress!=d[3]||selected!=d[4]||flags!=d[5]||token!=next||action!=identity.d[4]||slot!=identity.d[5];
        version=d[0];capability=1;reported=1;state=d[1];error=d[2];progress=d[3];selected=d[4];flags=d[5];token=next;action=identity.d[4];slot=identity.d[5];phase=0;
        if(expected!=0){if(token==expected&&action==desiredAction&&slot==desiredSlot){if((flags&4)==0&&state!=2){
            // SCAN/LOAD are read-only. A protected volume can still be read,
            // but a phone write is never confirmed under a late write lock.
            boolean writing=desiredAction==1||desiredAction==3||phonePhase==2;
            boolean success=state==1&&error==0&&(flags&8)!=0&&(!writing||(flags&16)==0);
            expected=0;
            if(phonePhase==2){if(!success){phonePhase=0;phoneFailure=true;message=verb(phoneAction)+"未确认："+failureReason();}}
            else message=verb(desiredAction)+(success?"成功（设备SD已完成）"+((flags&16)!=0?"；写入保护，仅可读取":""):"未确认："+failureReason());
            if(success){if(desiredAction==2)loadCompleted=true;else startCatalog();}changed=true;
        }}else if((flags&4)==0){String text="设备操作身份与本次请求不符；结果未确认，请查询或重连";if(!text.equals(message)){message=text;changed=true;}}}
        else if(changed&&phonePhase==0&&!phoneFailure){message=state==2?"设备SD操作进行中 "+progress+"%":state==3?"不支持的SD卷，请使用FAT32":state==4?SdLibraryProtocol.error(error):"SD设备已就绪；重新扫描可读取32槽曲库";}
        if(phonePhase==0&&!mutating()&&!catalogLoaded&&state==1&&error==0&&(flags&4)==0)startCatalog();
        if(changed)revision++;
    }
    private void startCatalog(){entrySlot=0;snapshotRevision=-1;stagedEntries=emptyEntries();phase=5;}
    private void finishEntry(String name){stagedEntries[entrySlot]=new Entry(entrySlot,entryFlags,entrySteps,name);if(++entrySlot==32){entries=stagedEntries;stagedEntries=null;catalogRevision=snapshotRevision;catalogLoaded=true;phase=0;if(phonePhase==2){Entry target=entries[phoneSlot];boolean valid=phoneAction==3?(target.flags&5)==0:(target.flags&1)!=0&&target.steps==phoneSteps&&target.title.equals(phoneTitle);phoneFailure=!valid;message=verb(phoneAction)+(valid?"成功（手机写入并由FPGA重新扫描确认）":"未确认：重新扫描的目标槽位与请求不符");phonePhase=0;}revision++;}else phase=5;}
}
