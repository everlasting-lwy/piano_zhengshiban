package org.pianolink;
public final class KeyMap {
    private final int[] mapping={0,1,2,3,4,5,6,7,8,9,10,11};private final boolean[] held=new boolean[12];
    public synchronized void set(int key,int note){if(key<0||key>=12||note<0||note>=12)throw new IllegalArgumentException();mapping[key]=note;}
    public synchronized int get(int key){return mapping[key];}
    public synchronized void down(int key){held[key]=true;} public synchronized void up(int key){held[key]=false;}
    public synchronized void clear(){java.util.Arrays.fill(held,false);}
    public synchronized int mask(){int mask=0;for(int i=0;i<12;i++)if(held[i])mask|=1<<mapping[i];return mask;}
}
