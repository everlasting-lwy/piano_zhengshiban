package org.pianolink;

import java.util.Arrays;

/** Selection belongs to the player; asynchronous confirmations never move it. */
public final class EffectsState {
    public static final int[] NEUTRAL={0,0,0,15,8,0,0,0};
    private final int[] desired=NEUTRAL.clone(),confirmed=new int[8];
    private boolean initialized;
    public EffectsState(){Arrays.fill(confirmed,-1);}
    public static int maximum(int id){if(id<0||id>7)throw new IllegalArgumentException();return id==4?16:id>=6?2:15;}
    public void choose(int id,int value){if(value<0||value>maximum(id))throw new IllegalArgumentException();desired[id]=value;initialized=true;}
    public int desired(int id){return desired[id];}
    public int confirmed(int id){return confirmed[id];}
    public static int guideTarget(int mode,int step){if(mode==0||mode>2||step<0||step>(mode==1?7:17))return -1;if(mode==1)return step==7?12:step;int[] order={0,7,1,8,2,3,9,4,10,5,11,6,12,13,14,15,16,17};return order[step];}
    public boolean report(Protocol.Frame f){
        if(!f.isEffectsState())return false;
        int[] values={f.d[0]&15,f.d[0]>>>4,f.d[1]&15,f.d[1]>>>4,f.d[3]&31,f.d[2]&15,(f.d[2]>>>4)&3,f.d[2]>>>6};
        System.arraycopy(values,0,confirmed,0,8);if(!initialized){System.arraycopy(values,0,desired,0,8);initialized=true;}return true;
    }
    public void disconnected(){Arrays.fill(confirmed,-1);}
}
