package org.pianolink;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Looper;
import android.os.SystemClock;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.InterpreterApi;
import org.tensorflow.lite.Tensor;

/** Blocking, phone-local MP3/PCM-WAV -> Basic Pitch -> absolute36 conversion. Call on a worker. */
public final class AudioTranscriber {
    private static final long MAX_INPUT_BYTES=100L*1024*1024;
    private AudioTranscriber() {}
    public interface Callbacks extends AudioDsp.Cancellation {
        boolean cancelled();
        void progress(String stage,int percent);
    }
    public static final class Result {
        public final SongData song;
        public final String summary;
        Result(SongData song,String summary){this.song=song;this.summary=summary;}
    }
    /** Resources are job-owned; callers alone decide whether/where to commit a completed song. */
    public static Result convert(Context context,Uri uri,boolean polyphonic,Callbacks callbacks) throws Exception {
        if(Looper.myLooper()==Looper.getMainLooper())throw new IllegalStateException("音频转换需要在后台线程运行");
        if(context==null||uri==null||callbacks==null)throw new IllegalArgumentException("缺少音频文件或转换回调");
        Context application=context.getApplicationContext();if(application==null)application=context;
        long started=SystemClock.elapsedRealtime();File source=null,pcm=null;
        try {
            AudioDsp.checkCancelled(callbacks);progress(callbacks,"读取音频",0);
            source=File.createTempFile("pianolink-audio-", ".input",application.getCacheDir());
            copyInput(application,uri,source,callbacks);
            pcm=File.createTempFile("pianolink-audio-", ".pcm",application.getCacheDir());
            long samples;
            try(AudioPcmSink sink=new AudioPcmSink(pcm,callbacks)) {
                progress(callbacks,"解码",0);
                if(isWave(source)) {
                    try(PcmWavReader reader=new PcmWavReader(source)) {
                        sink.setSampleRate(reader.sampleRate);
                        final long[] frames={0};
                        reader.decode((values,length)->{
                            sink.samples(values,length);frames[0]+=length;
                            progress(callbacks,"解码",reader.frameCount==0?0:(int)(frames[0]*100/reader.frameCount));
                        },callbacks);
                    }
                } else decodeMp3(source,sink,callbacks);
                // close drains the resampler's short look-ahead; count is read after close below.
                sink.close();samples=sink.sampleCount();
            }
            AudioDsp.checkCancelled(callbacks);
            if(samples==0)throw new IOException("音频没有可识别的采样");
            PitchPostprocessor.Result decoded=infer(application,pcm,samples,polyphonic,callbacks);
            AudioDsp.checkCancelled(callbacks);
            if(decoded.song==null) {
                if(decoded.outOfRange>0)throw new IOException("未识别到 C3–B5 范围内可播放的音符；超音域 "+decoded.outOfRange+" 个");
                throw new IOException("未识别到可播放音符：音频可能是静音、过短或不适合钢琴/单旋律识别");
            }
            double seconds=samples/(double)BasicPitchWindowing.SAMPLE_RATE;
            String summary=String.format(Locale.CHINA,
                    "识别 %d 个音符，音频 %.1f 秒；超音域 %d，复音削减 %d，过快/过短省略 %d；用时 %.1f 秒。识别结果可试听校对。",
                    decoded.detectedNotes,seconds,decoded.outOfRange,decoded.polyphonyReduced,decoded.tooFast,
                    (SystemClock.elapsedRealtime()-started)/1000.0);
            progress(callbacks,"识别完成",100);AudioDsp.checkCancelled(callbacks);
            return new Result(decoded.song,summary);
        } catch(UnsatisfiedLinkError nativeFailure) {
            throw new IOException("本地识别运行库无法加载，请重新安装完整 PianoLink APK（不需要 Google 服务）",nativeFailure);
        } finally {
            if(source!=null)source.delete();if(pcm!=null)pcm.delete();
        }
    }
    private static void progress(Callbacks callbacks,String stage,int percent) throws AudioDsp.CancelledException {
        AudioDsp.checkCancelled(callbacks);callbacks.progress(stage,Math.max(0,Math.min(100,percent)));
    }
    private static void copyInput(Context context,Uri uri,File destination,Callbacks callbacks) throws IOException {
        try(InputStream raw=context.getContentResolver().openInputStream(uri)) {
            if(raw==null)throw new IOException("无法打开所选音频，请重新选择文件");
            try(OutputStream output=new BufferedOutputStream(new FileOutputStream(destination))) {
                byte[] block=new byte[32768];long bytes=0;
                for(int count;(count=raw.read(block))!=-1;) {
                    AudioDsp.checkCancelled(callbacks);bytes+=count;
                    if(bytes>MAX_INPUT_BYTES)throw new IOException("音频超过 100 MB 上限");
                    output.write(block,0,count);
                }
                if(bytes==0)throw new IOException("音频文件为空");
            }
        }
    }
    private static boolean isWave(File source) throws IOException {
        try(DataInputStream input=new DataInputStream(new FileInputStream(source))) {
            return source.length()>=4&&input.readInt()==0x52494646;
        }
    }
    private static final class CodecPcm {
        private final AudioPcmSink sink;
        private PcmByteDecoder decoder;
        private int rate,channels,encoding;
        CodecPcm(AudioPcmSink sink){this.sink=sink;}
        void format(MediaFormat format,MediaFormat original) throws IOException {
            int nextRate=integer(format,MediaFormat.KEY_SAMPLE_RATE,original.getInteger(MediaFormat.KEY_SAMPLE_RATE));
            int nextChannels=integer(format,MediaFormat.KEY_CHANNEL_COUNT,original.getInteger(MediaFormat.KEY_CHANNEL_COUNT));
            int nextEncoding=integer(format,"pcm-encoding",AudioFormat.ENCODING_PCM_16BIT);
            if(decoder!=null&&nextRate==rate&&nextChannels==channels&&nextEncoding==encoding)return;
            if(decoder!=null)decoder.finish();
            sink.setSampleRate(nextRate);decoder=new PcmByteDecoder(nextChannels,nextEncoding);
            rate=nextRate;channels=nextChannels;encoding=nextEncoding;
        }
        void bytes(byte[] data,int length) throws IOException {decoder.accept(data,0,length,sink);}
        void finish() throws IOException {if(decoder!=null)decoder.finish();}
    }
    private static int integer(MediaFormat format,String key,int fallback) {
        return format.containsKey(key)?format.getInteger(key):fallback;
    }
    private static void decodeMp3(File source,AudioPcmSink sink,Callbacks callbacks) throws IOException {
        MediaExtractor extractor=new MediaExtractor();MediaCodec codec=null;boolean codecStarted=false;
        try {
            extractor.setDataSource(source.getAbsolutePath());int track=-1;MediaFormat format=null;
            for(int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat candidate=extractor.getTrackFormat(i);String mime=candidate.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("audio/")){track=i;format=candidate;break;}
            }
            if(track<0)throw new IOException("文件没有可解码的音轨，请使用 MP3 或 PCM WAV");
            String mime=format.getString(MediaFormat.KEY_MIME);
            if(!"audio/mpeg".equals(mime)&&!"audio/mp3".equals(mime))throw new IOException("目前支持 MP3 和常用 PCM WAV；此文件编码为 "+mime);
            long duration=format.containsKey(MediaFormat.KEY_DURATION)?format.getLong(MediaFormat.KEY_DURATION):0;
            if(duration>600000000L)throw new IOException("音频超过 10 分钟上限");
            extractor.selectTrack(track);codec=MediaCodec.createDecoderByType(mime);
            codec.configure(format,null,null,0);codec.start();codecStarted=true;
            CodecPcm pcm=new CodecPcm(sink);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            boolean inputEnd=false,outputEnd=false,haveFormat=false;byte[] bytes=new byte[32768];
            long lastActivity=SystemClock.elapsedRealtime();
            while(!outputEnd) {
                AudioDsp.checkCancelled(callbacks);
                if(!inputEnd) {
                    int index=codec.dequeueInputBuffer(10000);
                    if(index>=0) {
                        ByteBuffer input=codec.getInputBuffer(index);
                        if(input==null)throw new IOException("系统 MP3 解码器没有输入缓冲区");
                        input.clear();int count=extractor.readSampleData(input,0);
                        if(count<0) {codec.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnd=true;}
                        else {
                            if((extractor.getSampleFlags()&MediaExtractor.SAMPLE_FLAG_ENCRYPTED)!=0)
                                throw new IOException("加密音频无法转换，请使用未加密的 MP3/WAV");
                            codec.queueInputBuffer(index,0,count,extractor.getSampleTime(),0);extractor.advance();
                        }
                        lastActivity=SystemClock.elapsedRealtime();
                    }
                }
                int index=codec.dequeueOutputBuffer(info,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {pcm.format(codec.getOutputFormat(),format);haveFormat=true;lastActivity=SystemClock.elapsedRealtime();}
                else if(index>=0) {
                    try {
                        if(info.size>0) {
                            if(!haveFormat){pcm.format(codec.getOutputFormat(),format);haveFormat=true;}
                            ByteBuffer output=codec.getOutputBuffer(index);
                            if(output==null||info.offset<0||info.size<0||info.offset>output.capacity()-info.size)
                                throw new IOException("系统解码器返回无效 PCM 缓冲区");
                            output.position(info.offset);output.limit(info.offset+info.size);
                            while(output.hasRemaining()) {
                                AudioDsp.checkCancelled(callbacks);int count=Math.min(output.remaining(),bytes.length);
                                output.get(bytes,0,count);pcm.bytes(bytes,count);
                            }
                            if(duration>0)progress(callbacks,"解码",(int)Math.min(100,Math.max(0,info.presentationTimeUs)*100/duration));
                        }
                        outputEnd=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    } finally {codec.releaseOutputBuffer(index,false);}
                    lastActivity=SystemClock.elapsedRealtime();
                }
                if(SystemClock.elapsedRealtime()-lastActivity>30000)throw new IOException("系统 MP3 解码器长时间没有返回音频，请换用 PCM WAV");
            }
            pcm.finish();progress(callbacks,"解码",100);
        } catch(MediaCodec.CodecException failure) {
            throw new IOException("系统 MP3 解码失败，请尝试导出为 PCM WAV："+failure.getDiagnosticInfo(),failure);
        } catch(IllegalArgumentException|IllegalStateException failure) {
            throw new IOException("音频已损坏或系统无法解码，请使用 MP3/PCM WAV",failure);
        } finally {
            if(codec!=null) {
                if(codecStarted)try{codec.stop();}catch(RuntimeException ignored){}
                try{codec.release();}catch(RuntimeException ignored){}
            }
            extractor.release();
        }
    }
    private static ByteBuffer model(Context context) throws IOException {
        try(InputStream input=context.getAssets().open("basic_pitch.tflite");ByteArrayOutputStream bytes=new ByteArrayOutputStream()) {
            byte[] block=new byte[16384];for(int count;(count=input.read(block))!=-1;) {
                if(bytes.size()+count>16*1024*1024)throw new IOException("随包识别模型大小无效");bytes.write(block,0,count);
            }
            ByteBuffer buffer=ByteBuffer.allocateDirect(bytes.size()).order(ByteOrder.nativeOrder());buffer.put(bytes.toByteArray());buffer.rewind();return buffer;
        }
    }
    private static void shape(Tensor tensor,int... expected) throws IOException {
        if(tensor.dataType()!=DataType.FLOAT32||!Arrays.equals(tensor.shape(),expected))
            throw new IOException("随包 Basic Pitch 模型形状不匹配："+tensor.name()+" "+Arrays.toString(tensor.shape()));
    }
    private static PitchPostprocessor.Result infer(Context context,File pcm,long samples,boolean polyphonic,Callbacks callbacks) throws Exception {
        AudioDsp.checkCancelled(callbacks);progress(callbacks,"加载本地模型",0);
        Interpreter.Options options=new Interpreter.Options().setNumThreads(Math.min(4,Math.max(1,Runtime.getRuntime().availableProcessors())))
                .setUseXNNPACK(true).setCancellable(true).setRuntime(InterpreterApi.Options.TfLiteRuntime.FROM_APPLICATION_ONLY);
        try(Interpreter interpreter=new Interpreter(model(context),options)) {
            try(AudioDsp.CancellationMonitor monitor=new AudioDsp.CancellationMonitor(callbacks,()->interpreter.setCancelled(true));
                    RandomAccessFile audio=new RandomAccessFile(pcm,"r")) {
                AudioDsp.checkCancelled(callbacks);
                String[] signatures=interpreter.getSignatureKeys();String signature=null;
                for(String key:signatures)if(key.equals("serving_default"))signature=key;
                if(signature==null&&signatures.length==1)signature=signatures[0];
                if(signature==null||!Arrays.asList(interpreter.getSignatureInputs(signature)).contains("input_2")
                        ||!Arrays.asList(interpreter.getSignatureOutputs(signature)).containsAll(Arrays.asList("note","onset","contour")))
                    throw new IOException("随包 Basic Pitch 模型签名不匹配");
                interpreter.allocateTensors();
                shape(interpreter.getInputTensorFromSignature("input_2",signature),1,43844,1);
                shape(interpreter.getOutputTensorFromSignature("note",signature),1,172,88);
                shape(interpreter.getOutputTensorFromSignature("onset",signature),1,172,88);
                shape(interpreter.getOutputTensorFromSignature("contour",signature),1,172,264);
                ByteBuffer input=ByteBuffer.allocateDirect(43844*4).order(ByteOrder.nativeOrder());float[] window=new float[43844];
                float[][][] note=new float[1][172][88],onset=new float[1][172][88],contour=new float[1][172][264];
                Map<String,Object> inputs=new HashMap<>(),outputs=new HashMap<>();inputs.put("input_2",input);
                outputs.put("note",note);outputs.put("onset",onset);outputs.put("contour",contour);
                PitchPostprocessor processor=new PitchPostprocessor(polyphonic);int windows=BasicPitchWindowing.windowCount(samples);
                for(int w=0;w<windows;w++) {
                    AudioDsp.checkCancelled(callbacks);BasicPitchWindowing.readWindow(audio,window,w,samples);
                    input.clear();for(float value:window)input.putFloat(value);input.rewind();
                    progress(callbacks,"识别",w*100/windows);
                    try {interpreter.runSignature(inputs,outputs,signature);}
                    catch(RuntimeException failure) {
                        AudioDsp.checkCancelled(callbacks);
                        throw new IOException("本地模型推理失败，请检查完整安装包或缩短音频："+failure.getMessage(),failure);
                    }
                    AudioDsp.checkCancelled(callbacks);
                    BasicPitchWindowing.acceptWindow(processor,w,note[0],onset[0],samples,callbacks);
                }
                progress(callbacks,"整理音符",100);AudioDsp.checkCancelled(callbacks);
                return processor.finish(samples*1000.0/22050);
            }
        }
    }
}
