package org.pianolink;

/** One bounded snapshot. No partial data escapes this assembler. */
public final class VisualFrames {
    public static final long TIMEOUT_MS=2500;
    public static final class Snapshot {
        public final int kind,sequence;public final long captureMillis,receivedAt;public final int[] data;
        private Snapshot(int kind,int seq,long capture,long received,int[] values){this.kind=kind;sequence=seq;captureMillis=capture;receivedAt=received;data=values.clone();}
    }
    private int sequence=-1,kind,chunks,next;private int[] buffer;private long started,capture,lastCapture=-1;
    public void clear(){sequence=-1;buffer=null;next=0;lastCapture=-1;}
    public void begin(int seq,int requested,long now){if(requested<1||requested>4)throw new IllegalArgumentException();sequence=seq&255;kind=requested;started=now;buffer=null;next=0;}
    private void discard(){sequence=-1;buffer=null;next=0;}
    public boolean busy(long now){if(sequence>=0&&now-started>=TIMEOUT_MS)discard();return sequence>=0;}
    public boolean matches(int seq,int requested,long now){return busy(now)&&sequence==seq&&kind==requested;}
    public Snapshot receive(Protocol.Frame f,long now){
        if(f.cmd!=0x86&&f.cmd!=0x87)return null;if(!busy(now))return null;
        if(f.seq!=sequence||f.d[0]!=kind){discard();return null;}
        for(int value:f.d)if(value<0||value>255){discard();return null;}
        if(f.cmd==0x86){
            int count=kind==1?16:kind==2?8:kind==3?32:1;
            long time=(long)f.d[2]|((long)f.d[3]<<8)|((long)f.d[4]<<16)|((long)f.d[5]<<24);
            long delta=(time-lastCapture)&0xffffffffL;
            if(buffer!=null||f.d[1]!=count){discard();return null;}
            // A separate FPGA reset can restart millis while HC05 keeps SPP open.
            // Withhold this backward frame, then rebase only on the next requested snapshot.
            if(lastCapture>=0&&(delta==0||delta>=0x80000000L)){if(delta>=0x80000000L)lastCapture=-1;discard();return null;}
            chunks=count;capture=time;buffer=new int[count*4];return null;
        }
        if(buffer==null)return null;
        if(f.d[1]!=next||next>=chunks||(kind==4&&((f.d[4]&0xe0)!=0||((f.d[4]>>>2)&3)>2||f.d[5]>17))){discard();return null;}
        System.arraycopy(f.d,2,buffer,next*4,4);next++;
        if(next!=chunks)return null;Snapshot complete=new Snapshot(kind,sequence,capture,now,buffer);lastCapture=capture;discard();return complete;
    }
}
