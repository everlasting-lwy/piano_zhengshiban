package org.pianolink;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Bounded FAT32 root P18 writer. The caller owns an exclusive sector-RPC session.
 * Writes are verified, but FAT32 and SD flash do not provide power-loss atomicity.
 * An uncertain transaction is never retried or cleaned up automatically. */
public final class Fat32Store {
    public interface BlockDevice {
        long sectorCount();
        byte[] read(long lba) throws IOException;
        void write(long lba, byte[] sector) throws IOException;
    }
    public enum Reason { PARAMETER, MEDIA, UNSUPPORTED, GEOMETRY, CHAIN, NOT_FOUND,
        INVALID_FILE, PROTECTED, FULL, SEARCH_LIMIT, DIRECTORY_FULL, VERIFY, WRITE_LOCKED, IO }
    public static final class StoreException extends IOException {
        public final Reason reason;
        StoreException(Reason reason,String message){super("FAT32 "+reason+": "+message);this.reason=reason;}
        StoreException(Reason reason,String message,Throwable cause){this(reason,message);initCause(cause);}
    }
    private static final int SECTOR=512, ROOT_SECTORS=4096, FAT_SEARCH_SECTORS=8192;
    private static final long MASK=0x0fffffffL, EOC=0x0ffffff8L, CLEAN=0x08000000L, NO_HARD_ERROR=0x04000000L;
    private static final int MAX_FILE=6208, MAX_FILE_CLUSTERS=13, OTHER_CHAIN_STEPS=FAT_SEARCH_SECTORS*128;
    private final BlockDevice device;
    private boolean uncertain;

    public Fat32Store(BlockDevice device){if(device==null)throw new NullPointerException("device");this.device=device;}
    public synchronized void save(int slot,byte[] p18)throws IOException{
        checkSlot(slot);
        if(p18==null)throw problem(Reason.INVALID_FILE,"missing P18");
        byte[] frozen=p18.clone();validateP18(frozen);
        execute(slot,frozen,false);
    }
    public synchronized void delete(int slot)throws IOException{checkSlot(slot);execute(slot,null,true);}

    private void execute(int slot,byte[] source,boolean deleting)throws IOException{
        if(uncertain)throw problem(Reason.WRITE_LOCKED,"previous metadata result is uncertain; inspect card before a new writer session");
        Context c=new Context();
        try{
            c.mount();
            Directory root=c.directory(c.g.root,true,0,null);
            Entry target=null;
            String wanted=name('P',slot);
            for(Entry e:root.entries){
                if(managedSlot(e.name,'T')>=0){uncertain=true;throw problem(Reason.WRITE_LOCKED,"temporary P18 remnant requires inspection");}
                if(e.name.equals(wanted)){if(target!=null)throw problem(Reason.INVALID_FILE,"duplicate target name");target=e;}
            }
            Managed old=null;
            if(target!=null){
                if((target.attributes&0x19)!=0)throw problem(Reason.PROTECTED,"target is read-only, directory, or volume label");
                old=c.managed(target,root.clusters);
            }else if(deleting)throw problem(Reason.NOT_FOUND,"managed file absent");
            if(!deleting&&root.free==null)throw problem(Reason.DIRECTORY_FULL,"root directory has no temporary entry; extension is unsupported");
            List<Long> fresh=deleting?new ArrayList<Long>():c.allocate((source.length+SECTOR*c.g.spc-1)/(SECTOR*c.g.spc));
            Set<Long> protectedClusters=new HashSet<Long>(root.clusters);
            if(old!=null)protectedClusters.addAll(old.clusters);
            protectedClusters.addAll(fresh);
            c.checkOtherReferences(root,target,protectedClusters);
            List<Patch> fsinfo=c.fsinfoPatches();
            // Everything above is read-only. In particular all root links, even
            // beyond an end marker, are checked before changing a marker sector.
            c.started=true;
            c.setFat(1,c.fat1&~CLEAN,c.fat1);c.fat1&=~CLEAN;
            for(Patch patch:fsinfo)c.writeVerified(patch.lba,patch.bytes);
            if(deleting){
                c.replace(target.location,new byte[]{(byte)0xe5},false);
                c.release(old);
                byte[] removed=c.disk(target.location.lba);
                if((removed[target.location.offset]&255)!=0xe5)throw problem(Reason.VERIFY,"deleted entry reappeared");
            }else{
                for(int i=0;i<fresh.size();i++)c.setFat(fresh.get(i),i+1<fresh.size()?fresh.get(i+1):MASK,0);
                Location temp=root.free;
                if(temp.end&&temp.offset==480&&temp.following>=0)c.replace(new Location(temp.following,0,false,-1),new byte[]{0},false);
                c.replace(temp,entry(name('T',slot),fresh.get(0),source.length),temp.end&&temp.offset<480);
                int at=0;
                for(long cluster:fresh)for(int s=0;s<c.g.spc&&at<source.length;s++){
                    byte[] sector=new byte[SECTOR];int n=Math.min(SECTOR,source.length-at);
                    System.arraycopy(source,at,sector,0,n);c.writeVerified(c.clusterLba(cluster)+s,sector);at+=n;
                }
                // Verify the complete temporary file before exposing the target.
                c.cache.clear();
                Entry temporary=c.entryAt(temp);
                Managed staged=c.managed(temporary,root.clusters);
                if(!Arrays.equals(staged.bytes,source))throw problem(Reason.VERIFY,"temporary P18 differs from frozen source");
                Location published;
                if(target==null){c.replace(temp,new byte[]{'P'},false);published=temp;}
                else{
                    byte[] replacement=target.bytes.clone();putCluster(replacement,fresh.get(0));put32(replacement,28,source.length);replacement[11]|=0x20;
                    c.replace(target.location,replacement,false);published=target.location;
                    c.replace(temp,new byte[]{(byte)0xe5},false);
                    c.release(old);
                }
                // Success requires a fresh read of the ordinary published file,
                // not an ACK or a result reconstructed from cached sectors.
                c.cache.clear();Entry actual=c.entryAt(published);
                if(!actual.name.equals(wanted))throw problem(Reason.VERIFY,"published name differs");
                Managed verified=c.managed(actual,root.clusters);
                if(!Arrays.equals(verified.bytes,source))throw problem(Reason.VERIFY,"published P18 differs");
            }
            c.setFat(1,c.fat1|CLEAN,c.fat1);
            c.completed=true;
        }finally{if(c.started&&!c.completed)uncertain=true;}
    }

    private final class Context {
        final Map<Long,byte[]> cache=new HashMap<Long,byte[]>();
        final Set<Long> fatReadSectors=new HashSet<Long>();
        Geometry g;long capacity,fat1;boolean started,completed;int directorySectors;
        byte[] disk(long lba)throws IOException{
            if(lba<0||lba>=capacity)throw problem(Reason.GEOMETRY,"sector outside card: "+lba);
            try{byte[] b=device.read(lba);if(b==null||b.length!=SECTOR)throw problem(Reason.IO,"read must return exactly512 bytes");return b.clone();}
            catch(StoreException e){throw e;}catch(IOException e){throw new StoreException(Reason.IO,"read sector "+lba,e);}catch(RuntimeException e){throw new StoreException(Reason.IO,"read sector "+lba,e);}
        }
        byte[] read(long lba)throws IOException{byte[] b=cache.get(lba);if(b==null){b=disk(lba);cache.put(lba,b);}return b;}
        void writeVerified(long lba,byte[] bytes)throws IOException{
            if(!started||bytes.length!=SECTOR||lba<0||lba>=capacity)throw problem(Reason.GEOMETRY,"invalid write extent");
            byte[] expected=bytes.clone();
            try{device.write(lba,expected.clone());}catch(IOException e){throw new StoreException(Reason.IO,"write sector "+lba,e);}catch(RuntimeException e){throw new StoreException(Reason.IO,"write sector "+lba,e);}
            byte[] actual=disk(lba);if(!Arrays.equals(expected,actual))throw problem(Reason.VERIFY,"sector readback mismatch at "+lba);
            cache.put(lba,actual);
        }
        void mount()throws IOException{
            capacity=device.sectorCount();if(capacity<=0||capacity>0xffffffffL)throw problem(Reason.MEDIA,"card capacity unavailable or unsupported");
            long base=0,extent=capacity;byte[] b=read(0);
            if(!signature(b))throw problem(Reason.UNSUPPORTED,"boot signature absent");
            if(!looksLikeBoot(b)){
                boolean found=false;
                for(int i=0;i<4;i++){int at=446+16*i,type=b[at+4]&255;if(type==0x0b||type==0x0c){base=u32(b,at+8);extent=u32(b,at+12);found=true;break;}}
                if(!found)throw problem(Reason.UNSUPPORTED,"only FAT32 superfloppy or MBR0B/0C supported");
                if(base==0||extent==0||base+extent>capacity)throw problem(Reason.GEOMETRY,"partition outside card");
                b=read(base);if(!signature(b)||!looksLikeBoot(b))throw problem(Reason.UNSUPPORTED,"partition has no supported FAT32 BPB");
            }
            int spc=b[13]&255,reserved=u16(b,14),fats=b[16]&255,flags=u16(b,40);
            long total=u32(b,32),fatSize=u32(b,36),root=u32(b,44),overhead=reserved+fats*fatSize;
            if(spc==0||spc>128||(spc&(spc-1))!=0||reserved==0||(fats!=1&&fats!=2)||u16(b,17)!=0||u16(b,19)!=0||u16(b,22)!=0||u16(b,42)!=0||fatSize==0||total==0||total>extent||overhead>=total)throw problem(Reason.GEOMETRY,"invalid FAT32 BPB");
            long clusters=(total-overhead)/spc;
            if(clusters<65525||clusters>0x0ffffff3L||fatSize*128<clusters+2||root<2||root>clusters+1)throw problem(Reason.GEOMETRY,"FAT32 cluster geometry invalid");
            boolean mirrored=(flags&0x80)==0;int active=mirrored?0:flags&15;
            if(active>=fats)throw problem(Reason.GEOMETRY,"active FAT outside copy count");
            g=new Geometry(base,total,reserved,fats,fatSize,spc,clusters+1,root,mirrored,active,u16(b,48),u16(b,50),b.clone());
            long fat0=fat(0);fat1=fat(1);
            if((fat0&255)!=(b[21]&255)||(fat0&0x0fffff00L)!=0x0fffff00L||(fat1&0x03ffffffL)<0x03fffff8L)throw problem(Reason.CHAIN,"reserved FAT entries invalid");
            if((fat1&(CLEAN|NO_HARD_ERROR))!=(CLEAN|NO_HARD_ERROR)){uncertain=true;throw problem(Reason.WRITE_LOCKED,"volume is dirty or records a hardware error");}
        }
        long clusterLba(long cluster)throws IOException{if(cluster<2||cluster>g.maxCluster)throw problem(Reason.CHAIN,"cluster outside volume");return g.data+(cluster-2)*g.spc;}
        int[] copies(){return g.mirrored&&g.fats==2?new int[]{0,1}:new int[]{g.active};}
        long fat(long cluster)throws IOException{
            long sector=cluster/128;if(cluster<0||sector>=g.fatSize)throw problem(Reason.CHAIN,"FAT entry outside table");
            if(!fatReadSectors.contains(sector)){if(fatReadSectors.size()>=FAT_SEARCH_SECTORS)throw problem(Reason.SEARCH_LIMIT,"FAT preflight search bound exceeded");fatReadSectors.add(sector);}
            long value=-1;
            for(int copy:copies()){long v=u32(read(g.fatBase+copy*g.fatSize+sector),(int)(cluster%128)*4)&MASK;if(value>=0&&value!=v)throw problem(Reason.CHAIN,"mirrored FATs disagree");value=v;}
            return value;
        }
        List<Long> chain(long first,int max)throws IOException{
            List<Long> ids=new ArrayList<Long>();Set<Long> seen=new HashSet<Long>();long cl=first;
            while(true){
                if(cl<2||cl>g.maxCluster||!seen.add(cl))throw problem(Reason.CHAIN,"cyclic or invalid cluster chain");
                if(ids.size()>=max)throw problem(Reason.SEARCH_LIMIT,"cluster chain preflight bound exceeded");
                ids.add(cl);long next=fat(cl);if(next>=EOC)return ids;cl=next;
            }
        }
        Directory directory(long first,boolean root,long parent,Set<Long> forbidden)throws IOException{
            int remaining=ROOT_SECTORS-directorySectors;
            List<Long> ids=chain(first,remaining/g.spc);
            if(forbidden!=null)for(long cl:ids)if(forbidden.contains(cl))throw problem(Reason.CHAIN,"directory crosslinks a touched chain");
            directorySectors+=ids.size()*g.spc;
            Directory d=new Directory(ids);List<Long> sectors=new ArrayList<Long>();
            for(long cl:ids)for(int s=0;s<g.spc;s++)sectors.add(clusterLba(cl)+s);
            boolean ended=false;
            for(int n=0;n<sectors.size()&&!ended;n++){
                long lba=sectors.get(n);byte[] b=read(lba);
                for(int off=0;off<SECTOR;off+=32){int firstByte=b[off]&255;
                    if(firstByte==0){if(root&&d.free==null)d.free=new Location(lba,off,true,n+1<sectors.size()?sectors.get(n+1):-1);ended=true;break;}
                    if(firstByte==0xe5){if(root&&d.free==null)d.free=new Location(lba,off,false,-1);continue;}
                    int attr=b[off+11]&255;if((attr&15)==15)continue;
                    Entry e=new Entry(new Location(lba,off,false,-1),Arrays.copyOfRange(b,off,off+32));
                    if(!root&&(e.name.equals(".          ")||e.name.equals("..         "))){long expected=e.name.charAt(1)=='.'?parent:first;if((e.attributes&16)==0||(e.start!=expected&&!(expected==g.root&&e.start==0)))throw problem(Reason.CHAIN,"invalid dot directory reference");continue;}
                    d.entries.add(e);
                }
            }
            return d;
        }
        Managed managed(Entry e,List<Long> rootIds)throws IOException{
            if(e.size<67||e.size>MAX_FILE||(e.attributes&0x18)!=0)throw problem(Reason.INVALID_FILE,"managed P18 length/attributes invalid");
            int expected=(int)((e.size+SECTOR*g.spc-1)/(SECTOR*g.spc));
            List<Long> ids=chain(e.start,MAX_FILE_CLUSTERS);
            if(ids.size()!=expected)throw problem(Reason.CHAIN,"managed allocation does not match its length");
            for(long cl:ids)if(rootIds.contains(cl))throw problem(Reason.CHAIN,"managed file crosslinks root directory");
            byte[] data=new byte[(int)e.size];int at=0;
            for(long cl:ids)for(int s=0;s<g.spc&&at<data.length;s++){byte[] b=read(clusterLba(cl)+s);int count=Math.min(SECTOR,data.length-at);System.arraycopy(b,0,data,at,count);at+=count;}
            validateP18(data);return new Managed(ids,data);
        }
        List<Long> allocate(int count)throws IOException{
            List<Long> ids=new ArrayList<Long>();
            long cl=2;
            if(g.fsinfo>0&&g.fsinfo!=0xffff&&g.fsinfo<g.reserved){
                byte[] info=read(g.base+g.fsinfo);
                if(u32(info,0)==0x41615252L&&u32(info,484)==0x61417272L&&u32(info,508)==0xaa550000L){
                    long hint=u32(info,492);if(hint>=2&&hint<=g.maxCluster)cl=hint;
                }
            }
            // FSInfo is only a starting hint. Verify every candidate and mirror,
            // wrap once, and retain fat()'s unique-sector preflight bound.
            for(long searched=0;searched<g.maxCluster-1;searched++){
                if(fat(cl)==0){ids.add(cl);if(ids.size()==count)return ids;}
                cl=cl==g.maxCluster?2:cl+1;
            }
            throw problem(Reason.FULL,"actual cluster range exhausted");
        }
        void checkOtherReferences(Directory root,Entry target,Set<Long> touched)throws IOException{
            List<Entry> files=new ArrayList<Entry>();ArrayDeque<DirectoryWork> pending=new ArrayDeque<DirectoryWork>();
            Set<Long> directories=new HashSet<Long>(root.clusters);
            for(Entry e:root.entries)if(e!=target&&(e.attributes&8)==0){if((e.attributes&16)!=0)pending.add(new DirectoryWork(e.start,g.root));else files.add(e);}
            while(!pending.isEmpty()){
                DirectoryWork work=pending.remove();Directory d=directory(work.first,false,work.parent,touched);
                for(long cl:d.clusters)if(!directories.add(cl))throw problem(Reason.CHAIN,"directory crosslink");
                for(Entry e:d.entries)if((e.attributes&8)==0){if((e.attributes&16)!=0)pending.add(new DirectoryWork(e.start,work.first));else files.add(e);}
            }
            Set<Long> forbidden=new HashSet<Long>(touched);forbidden.addAll(directories);
            for(Entry e:files){
                if(e.start==0&&e.size==0)continue;
                long cl=e.start,slow=cl,power=1,lam=0;int steps=0;
                while(true){
                    if(cl<2||cl>g.maxCluster||forbidden.contains(cl))throw problem(Reason.CHAIN,"another file crosslinks a touched chain");
                    if(++steps>OTHER_CHAIN_STEPS)throw problem(Reason.SEARCH_LIMIT,"other-file chain preflight bound exceeded");
                    long next=fat(cl);if(next>=EOC)break;
                    if(next<2||next>g.maxCluster||next==slow)throw problem(Reason.CHAIN,"other-file chain invalid or cyclic");
                    if(++lam==power){slow=next;power*=2;lam=0;}cl=next;
                }
            }
        }
        List<Patch> fsinfoPatches()throws IOException{
            List<Patch> out=new ArrayList<Patch>();
            if(g.fsinfo<=0||g.fsinfo==0xffff||g.fsinfo>=g.reserved)return out;
            addFsinfo(out,g.base+g.fsinfo);
            if(g.backup>0&&g.backup!=0xffff&&g.backup<g.reserved&&g.backup+g.fsinfo<g.reserved){
                byte[] backup=read(g.base+g.backup);boolean valid=signature(backup);
                for(int i=11;i<52&&valid;i++)valid=backup[i]==g.boot[i];
                if(valid)addFsinfo(out,g.base+g.backup+g.fsinfo);
            }
            return out;
        }
        void addFsinfo(List<Patch> out,long lba)throws IOException{byte[] b=read(lba);if(u32(b,0)==0x41615252L&&u32(b,484)==0x61417272L&&u32(b,508)==0xaa550000L){b=b.clone();put32(b,488,0xffffffffL);put32(b,492,0xffffffffL);out.add(new Patch(lba,b));}}
        void setFat(long cluster,long value,long expected)throws IOException{
            List<Patch> patches=new ArrayList<Patch>();
            for(int copy:copies()){
                long lba=g.fatBase+copy*g.fatSize+cluster/128;byte[] b=disk(lba);int off=(int)(cluster%128)*4;long raw=u32(b,off);
                if((raw&MASK)!=expected)throw problem(Reason.CHAIN,"FAT changed since preflight");
                put32(b,off,(raw&0xf0000000L)|(value&MASK));patches.add(new Patch(lba,b));
            }
            for(Patch patch:patches)writeVerified(patch.lba,patch.bytes);
        }
        void replace(Location location,byte[] bytes,boolean terminate)throws IOException{
            byte[] sector=disk(location.lba);if(bytes.length>32||location.offset+bytes.length>SECTOR)throw problem(Reason.GEOMETRY,"directory patch bounds");
            System.arraycopy(bytes,0,sector,location.offset,bytes.length);if(terminate)sector[location.offset+32]=0;writeVerified(location.lba,sector);
        }
        Entry entryAt(Location location)throws IOException{return new Entry(location,Arrays.copyOfRange(read(location.lba),location.offset,location.offset+32));}
        void release(Managed old)throws IOException{if(old!=null)for(long cluster:old.clusters){long expected=fat(cluster);setFat(cluster,0,expected);}}
    }
    private static final class Geometry {
        final long base,total,fatSize,fatBase,data,maxCluster,root;final int reserved,fats,spc,active,fsinfo,backup;final boolean mirrored;final byte[] boot;
        Geometry(long base,long total,int reserved,int fats,long fatSize,int spc,long maxCluster,long root,boolean mirrored,int active,int fsinfo,int backup,byte[] boot){this.base=base;this.total=total;this.reserved=reserved;this.fats=fats;this.fatSize=fatSize;this.spc=spc;this.maxCluster=maxCluster;this.root=root;this.mirrored=mirrored;this.active=active;this.fsinfo=fsinfo;this.backup=backup;this.boot=boot;fatBase=base+reserved;data=fatBase+fats*fatSize;}
    }
    private static final class Location {final long lba,following;final int offset;final boolean end;Location(long lba,int offset,boolean end,long following){this.lba=lba;this.offset=offset;this.end=end;this.following=following;}}
    private static final class Entry {final Location location;final byte[] bytes;final String name;final int attributes;final long start,size;Entry(Location location,byte[] bytes){this.location=location;this.bytes=bytes;name=new String(bytes,0,11,StandardCharsets.US_ASCII);attributes=bytes[11]&255;start=u16(bytes,26)|((long)u16(bytes,20)<<16);size=u32(bytes,28);}}
    private static final class Directory {final List<Long> clusters;final List<Entry> entries=new ArrayList<Entry>();Location free;Directory(List<Long> clusters){this.clusters=clusters;}}
    private static final class DirectoryWork {final long first,parent;DirectoryWork(long first,long parent){this.first=first;this.parent=parent;}}
    private static final class Managed {final List<Long> clusters;final byte[] bytes;Managed(List<Long> clusters,byte[] bytes){this.clusters=clusters;this.bytes=bytes;}}
    private static final class Patch {final long lba;final byte[] bytes;Patch(long lba,byte[] bytes){this.lba=lba;this.bytes=bytes;}}
    private static void checkSlot(int slot)throws IOException{if(slot<0||slot>31)throw problem(Reason.PARAMETER,"slot must be0..31");}
    private static void validateP18(byte[] bytes)throws IOException{try{P18File.decode(bytes);}catch(IllegalArgumentException e){throw new StoreException(Reason.INVALID_FILE,"P18 validation failed",e);}}
    private static StoreException problem(Reason reason,String text){return new StoreException(reason,text);}
    private static boolean signature(byte[] b){return(b[510]&255)==0x55&&(b[511]&255)==0xaa;}
    private static boolean looksLikeBoot(byte[] b){return u16(b,11)==512&&((b[0]&255)==0xeb||(b[0]&255)==0xe9);}
    private static int u16(byte[] b,int off){return(b[off]&255)|(b[off+1]&255)<<8;}
    private static long u32(byte[] b,int off){return(b[off]&255L)|(b[off+1]&255L)<<8|(b[off+2]&255L)<<16|(b[off+3]&255L)<<24;}
    private static void put16(byte[] b,int off,int value){b[off]=(byte)value;b[off+1]=(byte)(value>>>8);}
    private static void put32(byte[] b,int off,long value){for(int i=0;i<4;i++)b[off+i]=(byte)(value>>>(i*8));}
    private static void putCluster(byte[] b,long value){put16(b,20,(int)(value>>>16));put16(b,26,(int)value);}
    private static String name(char prefix,int slot){return String.format(Locale.ROOT,"%c%07dP18",prefix,slot);}
    private static int managedSlot(String name,char prefix){if(name.length()!=11||name.charAt(0)!=prefix||!name.substring(1,6).equals("00000")||!name.substring(8).equals("P18"))return-1;char a=name.charAt(6),b=name.charAt(7);int n=(a-'0')*10+b-'0';return a>='0'&&a<='3'&&b>='0'&&b<='9'&&n<32?n:-1;}
    private static byte[] entry(String name,long cluster,int length){byte[] b=new byte[32];System.arraycopy(name.getBytes(StandardCharsets.US_ASCII),0,b,0,11);b[11]=0x20;putCluster(b,cluster);put32(b,28,length);put16(b,16,0x21);put16(b,18,0x21);put16(b,24,0x21);return b;}
}
