package org.pianolink;

/** Frozen 0F..15 RAM score protocol; all masks use the physical port bit order. */
public final class OledGuideProtocol {
    public static final int MAX_STEPS=2048, MASK=0x3ffff;
    private OledGuideProtocol(){}
    public static boolean validMask(int mask){return mask>0&&(mask&~MASK)==0&&Integer.bitCount(mask)<=4;}
    public static int crc16(byte[] data){int crc=0xffff;for(byte value:data){crc^=(value&255)<<8;for(int bit=0;bit<8;bit++)crc=(crc&0x8000)!=0?((crc<<1)^0x1021)&65535:(crc<<1)&65535;}return crc;}
    public static int crcMasks(int[] masks){byte[] bytes=new byte[masks.length*3];for(int i=0;i<masks.length;i++){if(!validMask(masks[i]))throw new IllegalArgumentException("引导目标须为18键中的1至4音");for(int b=0;b<3;b++)bytes[i*3+b]=(byte)(masks[i]>>>(b*8));}return crc16(bytes);}
    public static boolean capability(Protocol.Frame f){return f.cmd==0x88&&f.d[0]==0x47&&f.d[1]==1&&(f.d[2]|f.d[3]<<8)>0&&(f.d[2]|f.d[3]<<8)<=MAX_STEPS&&f.d[4]==18&&f.d[5]==4;}
    public static boolean status(Protocol.Frame f,int capacity){if(f.cmd!=0x89||f.d[5]!=1||(f.d[4]&~31)!=0)return false;int step=f.d[0]|f.d[1]<<8,total=f.d[2]|f.d[3]<<8,flags=f.d[4];return total<=capacity&&step<=total&&(((flags&1)!=0)==(total>0))&&((flags&4)==0||((flags&1)!=0&&step==total));}
    public static boolean keys(Protocol.Frame f){int target=f.d[0]|f.d[1]<<8|f.d[2]<<16,physical=f.d[3]|f.d[4]<<8|f.d[5]<<16;return f.cmd==0x8a&&(target&~MASK)==0&&(physical&~MASK)==0&&Integer.bitCount(target)<=4;}
}
