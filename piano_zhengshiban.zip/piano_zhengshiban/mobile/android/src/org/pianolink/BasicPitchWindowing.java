package org.pianolink;

import java.io.*;

/** Basic Pitch input overlap and output crop expressed in original audio sample positions. */
public final class BasicPitchWindowing {
    public static final int SAMPLE_RATE=22050, WINDOW_SAMPLES=43844, OUTPUT_FRAMES=172;
    public static final int HOP_SAMPLES=36164, LEADING_SAMPLES=3840, CROP_FRAMES=15;
    private BasicPitchWindowing() {}
    public static double timeMs(int window,int frame) {
        if(window<0||frame<CROP_FRAMES||frame>=OUTPUT_FRAMES-CROP_FRAMES)throw new IllegalArgumentException("invalid retained model frame");
        return (window*(long)HOP_SAMPLES+(frame-CROP_FRAMES)*256L)*1000.0/SAMPLE_RATE;
    }
    public static int windowCount(long samples) {
        if(samples<=0||samples>600L*SAMPLE_RATE)throw new IllegalArgumentException("音频为空或超过 10 分钟");
        return (int)((samples+LEADING_SAMPLES+HOP_SAMPLES-1)/HOP_SAMPLES);
    }
    public static void readWindow(RandomAccessFile pcm,float[] destination,int window,long samples) throws IOException {
        if(destination.length!=WINDOW_SAMPLES||window<0)throw new IllegalArgumentException();
        java.util.Arrays.fill(destination,0);
        long sourceStart=window*(long)HOP_SAMPLES-LEADING_SAMPLES;
        long first=Math.max(0,sourceStart),end=Math.min(samples,sourceStart+WINDOW_SAMPLES);
        if(first>=end)return;
        pcm.seek(first*4);byte[] block=new byte[4096*4];
        for(long at=first;at<end;) {
            int count=(int)Math.min(4096,end-at);pcm.readFully(block,0,count*4);
            for(int i=0;i<count;i++) {
                int p=i*4,bits=(block[p]&255)|((block[p+1]&255)<<8)|((block[p+2]&255)<<16)|(block[p+3]<<24);
                destination[(int)(at-sourceStart)+i]=Float.intBitsToFloat(bits);
            }
            at+=count;
        }
    }
    public static void acceptWindow(PitchPostprocessor processor,int window,float[][] note,float[][] onset,
            long samples,AudioDsp.Cancellation cancellation) throws IOException {
        if(note.length!=OUTPUT_FRAMES||onset.length!=OUTPUT_FRAMES)throw new IOException("Basic Pitch 模型输出帧数不匹配");
        for(int frame=CROP_FRAMES;frame<OUTPUT_FRAMES-CROP_FRAMES;frame++) {
            AudioDsp.checkCancelled(cancellation);
            double time=timeMs(window,frame);
            if(time>=samples*1000.0/SAMPLE_RATE)break;
            processor.acceptFrame(time,note[frame],onset[frame]);
        }
    }
}
