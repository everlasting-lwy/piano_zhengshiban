package org.pianolink;

import android.app.Activity;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/** Native effects bench. Plots consume only validated, complete device snapshots. */
public final class EffectsUi {
    public interface Host {void back();void release();void effect(int id,int value);void visual(int kind,boolean active);void keys(long mask);void localAudio(boolean enabled);}
    private static final String[] NAMES={"混响 Reverb","回声 Echo","合唱 Chorus","表情 Expression","弯音 Bend","颤音 Vibrato","延迟长度 Delay","实体引导 Guide"};
    private final Activity activity;private final Host host;private final EffectsState state=new EffectsState();
    private final Handler main=new Handler(Looper.getMainLooper());private final ScrollView root;
    private final TextView connection,age,volume;private final TextView[] labels=new TextView[8];private final SeekBar[] sliders=new SeekBar[8];
    private final Graph graph;private final EnsembleView keyboard;private final Button neutral;
    private final CheckBox localAudio;private boolean updatingAudio;
    private boolean active,connected,simulated,supported,extended;private int kind=1;private VisualFrames.Snapshot latest;
    private final Runnable clock=new Runnable(){public void run(){updateAge();if(active)main.postDelayed(this,250);}};
    public EffectsUi(Activity activity,Host host,SeekBar volumeSlider){
        this.activity=activity;this.host=host;root=new ScrollView(activity);root.setFillViewport(true);
        LinearLayout content=new LinearLayout(activity);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(10),dp(14),dp(16));content.setBackgroundColor(0xff111926);root.addView(content);
        root.setOnApplyWindowInsetsListener((view,insets)->{view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        LinearLayout top=row();button(top,"返回曲库面板",v->host.back());button(top,"全部松开",v->host.release());content.addView(top);
        TextView title=text("效果与可视化测试",23);title.setTextColor(0xff65ded6);content.addView(title);
        connection=text("连接设备后查询效果能力",14);content.addView(connection);
        Spinner view=new Spinner(activity);ArrayAdapter<String> adapter=new ArrayAdapter<>(activity,android.R.layout.simple_spinner_item,new String[]{"暂停数据","波形 · 64 点 PCM","频谱 · 32 条 DFT","XY · 64 对采样","18 实体键引导"});adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);view.setAdapter(adapter);view.setSelection(1);
        view.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int position,long id){if(kind!=position){kind=position;clearPlot();request();}}});content.addView(view,new LinearLayout.LayoutParams(-1,dp(48)));
        graph=new Graph(activity);content.addView(graph,new LinearLayout.LayoutParams(-1,dp(225)));
        age=text("等待完整快照",12);content.addView(age);
        content.addView(text("波形/XY 为设备最终 PCM 的压缩快照；频谱为 256 点 DFT，Fs 48828.125 Hz，每格 190.735 Hz。9600 波特率下约 1–2.5 次/秒；丢弃残帧并显示数据年龄。",12));
        content.addView(text("手机 36 键 C3—B5 · 横放手机更易演奏",15));
        keyboard=new EnsembleView(activity,mask->host.keys(mask),false);keyboard.playable(false);content.addView(keyboard,new LinearLayout.LayoutParams(-1,dp(160)));
        localAudio=new CheckBox(activity);localAudio.setText("本地干声演示（不含 FPGA 效果）");localAudio.setTextSize(13);localAudio.setOnCheckedChangeListener((b,on)->{if(!updatingAudio)host.localAudio(on);});content.addView(localAudio);
        volume=text("",13);content.addView(volume);content.addView(volumeSlider);
        LinearLayout reset=row();neutral=button(reset,"恢复中性：表情 15 / 弯音 8 / 其余 0",v->{if(!supported||!connected)return;for(int id=0;id<8;id++){state.choose(id,EffectsState.NEUTRAL[id]);sliders[id].setProgress(state.desired(id));host.effect(id,state.desired(id));}updateLabels();});content.addView(reset);
        for(int id=0;id<8;id++){final int parameter=id;labels[id]=text("",14);content.addView(labels[id]);SeekBar bar=new SeekBar(activity);sliders[id]=bar;bar.setMax(EffectsState.maximum(id));bar.setProgress(state.desired(id));bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int value,boolean user){if(!user)return;state.choose(parameter,value);updateLabels();if(connected&&supported)host.effect(parameter,value);}});content.addView(bar,new LinearLayout.LayoutParams(-1,dp(38)));}
        content.addView(text("延迟：0 短 / 1 中 / 2 长；引导：0 关闭 / 1 C 大调 / 2 半音阶。引导只观察实体键，手机键不会推进步骤。所选值与设备实值分开显示，设备回报不会拖动滑块。",12));
        updateLabels();updateControls();
    }
    public View view(){return root;}
    private int dp(float n){return (int)(n*activity.getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String value,int size){TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);t.setTextColor(0xffe5edf6);t.setPadding(0,dp(4),0,dp(4));return t;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(activity);r.setOrientation(LinearLayout.HORIZONTAL);return r;}
    private Button button(LinearLayout r,String name,View.OnClickListener click){Button b=new Button(activity);b.setText(name);b.setTextSize(12);b.setAllCaps(false);b.setOnClickListener(click);r.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));return b;}
    public void volume(String label){volume.setText(label);}
    public void localAudio(boolean enabled){updatingAudio=true;localAudio.setChecked(enabled);updatingAudio=false;}
    public void connection(boolean ready,boolean mock,boolean keys36){connected=ready;simulated=mock;extended=keys36;if(!ready){supported=false;state.disconnected();clearPlot();}updateControls();updateLabels();}
    private void updateControls(){for(SeekBar slider:sliders)if(slider!=null)slider.setEnabled(connected&&supported);neutral.setEnabled(connected&&supported);keyboard.playable(active&&connected&&extended);connection.setText(!connected?"未连接 · 返回面板连接真实 HC-05 或模拟设备":!supported?"已连接 · 尚未确认效果能力（旧固件可继续使用原面板）":simulated?"模拟设备 · 图形为合成测试数据，无 FPGA 音频":"真实 FPGA · 效果能力已确认 · HC-05 9600 / 8N1");graph.simulated=simulated;graph.invalidate();}
    private void updateLabels(){for(int id=0;id<8;id++)if(labels[id]!=null){int actual=state.confirmed(id);labels[id].setText(NAMES[id]+"   所选 "+state.desired(id)+" / "+EffectsState.maximum(id)+"    设备 "+(actual<0?"待确认":String.valueOf(actual))+(actual>=0&&actual!=state.desired(id)?" · 待一致":""));}}
    public void frame(Protocol.Frame f){if(f.isEffectsState()){state.report(f);boolean first=!supported;supported=true;for(int id=0;id<8;id++)sliders[id].setProgress(state.desired(id));updateLabels();updateControls();if(first)request();}else if(f.cmd==0x80&&f.d[0]==12&&f.d[1]!=0){supported=false;state.disconnected();clearPlot();updateLabels();updateControls();connection.setText("当前 FPGA 未支持效果扩展；原十二键 / 曲库可继续使用。请使用配套固件。");}}
    public void confirmed(long keys){keyboard.confirmed(keys);}
    public void active(boolean value){if(active==value)return;active=value;main.removeCallbacks(clock);clearPlot();updateControls();request();if(active)main.post(clock);}
    private void request(){host.visual(kind,active&&connected&&supported);}
    public void snapshot(VisualFrames.Snapshot value){if(!active||!connected||!supported||value.kind!=kind)return;latest=value;graph.snapshot=value;graph.invalidate();updateAge();}
    private void clearPlot(){latest=null;if(graph!=null){graph.snapshot=null;graph.invalidate();}if(age!=null)updateAge();}
    private void updateAge(){if(latest==null){age.setTextColor(0xffb7c8dd);age.setText(kind==0?"数据已暂停":active?"等待完整快照；未完成的数据不会绘制":"页面暂停 · 已清除旧快照");return;}long elapsed=Math.max(0,SystemClock.elapsedRealtime()-latest.receivedAt);age.setText(String.format(Locale.ROOT,"%s · 接收年龄 %.1f 秒%s · 设备采样 %d ms",simulated?"模拟数据":"真实设备快照",elapsed/1000.0,elapsed>2500?" · 已陈旧":"",latest.captureMillis));age.setTextColor(elapsed>2500?0xffffb966:0xffb7c8dd);}
    public void releaseKeys(){keyboard.release();}
    public void close(){active=false;main.removeCallbacks(clock);keyboard.release();}

    private static final class Graph extends View {
        private static final String[] PHYSICAL={"C4","D4","E4","F4","G4","A4","B4","C♯4","D♯4","F♯4","G♯4","A♯4","C5","C♯5","D5","D♯5","E5","F5"};
        final Paint paint=new Paint(3);VisualFrames.Snapshot snapshot;boolean simulated;
        Graph(Activity activity){super(activity);setContentDescription("设备波形、频谱、XY 或18实体键引导；仅显示完整快照，模拟模式有水印。");}
        private void color(int c){paint.setColor(c);paint.setStyle(Paint.Style.FILL);}
        private void text(Canvas c,String label,float x,float y,float size,int tint){color(tint);paint.setTextSize(size);paint.setTextAlign(Paint.Align.LEFT);c.drawText(label,x,y,paint);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),s=getResources().getDisplayMetrics().scaledDensity;c.drawColor(0xff0a1220);color(0xff24364a);for(int i=1;i<4;i++){c.drawLine(0,h*i/4,w,h*i/4,paint);c.drawLine(w*i/4,0,w*i/4,h,paint);}VisualFrames.Snapshot f=snapshot;
            if(f==null){text(c,"等待完整设备数据",14,32*s,14*s,0xff8ea4bc);}else if(f.kind==4){int bits=f.data[0]|(f.data[1]<<8)|((f.data[2]&3)<<16),mode=(f.data[2]>>>2)&3,step=f.data[3],target=EffectsState.guideTarget(mode,step);boolean wrong=(f.data[2]&16)!=0;
                text(c,"实体引导 · 模式 "+mode+" · 步骤 "+(step+1)+(wrong?" · 错键，请全部松开":""),12,25*s,13*s,wrong?0xffff8a83:0xffd7e6f5);
                float cell=w/9,top=42*s,rh=(h-top-25*s)/2;for(int i=0;i<18;i++){float x=(i%9)*cell,y=top+(i/9)*rh;color((bits&(1<<i))!=0?(wrong?0xffbd5454:0xff228f8b):0xff233348);c.drawRect(x+3,y+3,x+cell-3,y+rh-3,paint);if(i==target){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3*s);paint.setColor(0xffffc566);c.drawRect(x+5,y+5,x+cell-5,y+rh-5,paint);}text(c,PHYSICAL[i],x+cell*.12f,y+rh*.58f,Math.min(12*s,cell*.24f),0xffeaf2fb);}text(c,"金框 = 当前目标 · 色块 = 实体键 · 手机不推进",12,h-8*s,11*s,0xffb7c8dd);
            }else if(f.kind==2){float width=w/32;for(int i=0;i<32;i++){color(0xff4fd6cd);c.drawRect(i*width+1,h-24*s-(h-45*s)*f.data[i]/255f,(i+1)*width-1,h-24*s,paint);}text(c,"0 Hz",8,h-7*s,11*s,0xffb7c8dd);text(c,"相对幅度 · 最高格约 5.91 kHz",w*.34f,h-7*s,11*s,0xffb7c8dd);
            }else {Path path=new Path();int points=f.kind==1?64:64;for(int i=0;i<points;i++){float x=f.kind==1?w*i/63f:w*f.data[i*2]/255f,y=h*(1-(f.kind==1?f.data[i]:f.data[i*2+1])/255f);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}paint.setColor(0xff65ded6);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2*s);c.drawPath(path,paint);paint.setStyle(Paint.Style.FILL);text(c,f.kind==1?"最终 PCM · 8 位显示值":"x[n] / x[n−64]",10,h-9*s,11*s,0xffb7c8dd);}
            if(simulated)text(c,"SIMULATED · 模拟数据",12,h*.5f,17*s,0xffffc566);
        }
    }
}
