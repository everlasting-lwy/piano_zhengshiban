param([string]$Jdk='C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$out=Join-Path $PSScriptRoot 'build/sector-rpc-test';New-Item -ItemType Directory -Force -Path $out|Out-Null
$sources=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','Session')|ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$client=Join-Path $PSScriptRoot 'src/org/pianolink/SectorRpcClient.java';if(Test-Path -LiteralPath $client){$sources+=$client}
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/SectorRpcTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/V2PhoneFlowTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/SectorRpcProgressTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/PhoneCatalogRpcFairnessTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $out @sources;if($LASTEXITCODE -ne 0){throw 'Sector RPC compile failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.SectorRpcTest;if($LASTEXITCODE -ne 0){throw 'Sector RPC tests failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.PhoneCatalogRpcFairnessTest;if($LASTEXITCODE -ne 0){throw 'Phone catalog/RPC fairness tests failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.SectorRpcProgressTest;if($LASTEXITCODE -ne 0){throw 'Sector progress tests failed'}
& "$Jdk/bin/java.exe" -cp $out org.pianolink.V2PhoneFlowTest;if($LASTEXITCODE -ne 0){throw 'V2 phone flow tests failed'}
