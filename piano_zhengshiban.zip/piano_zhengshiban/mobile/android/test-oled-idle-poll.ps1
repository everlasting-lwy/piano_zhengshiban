param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/oled-idle-poll-test'
$stubRoot=Join-Path $testOut 'stubs'
$stubs=@{
'android/content/Context.java'='package android.content;public class Context {}'
'android/app/Activity.java'='package android.app;public class Activity extends android.content.Context {}'
'android/content/DialogInterface.java'='package android.content;public interface DialogInterface {interface OnClickListener {void onClick(DialogInterface d,int which);}}'
'android/app/AlertDialog.java'='package android.app;public class AlertDialog {public static class Builder {public Builder(Activity a){}public Builder setTitle(String s){return this;}public Builder setMessage(String s){return this;}public Builder setNegativeButton(String s,android.content.DialogInterface.OnClickListener l){return this;}public Builder setPositiveButton(String s,android.content.DialogInterface.OnClickListener l){return this;}public AlertDialog show(){return new AlertDialog();}}}'
'android/view/View.java'='package android.view;public class View {private boolean enabled=true;private OnClickListener listener;public View(android.content.Context c){}public interface OnClickListener {void onClick(View v);}public void setOnClickListener(OnClickListener l){listener=l;}public void setEnabled(boolean b){enabled=b;}public boolean isEnabled(){return enabled;}public boolean performClick(){if(!enabled||listener==null)return false;listener.onClick(this);return true;}}'
'android/widget/LinearLayout.java'='package android.widget;public class LinearLayout extends android.view.View {public static final int HORIZONTAL=0;public LinearLayout(android.content.Context c){super(c);}public void setOrientation(int o){}public void addView(android.view.View v){}public void addView(android.view.View v,LayoutParams p){}public static class LayoutParams {public LayoutParams(int w,int h,int weight){}}}'
'android/widget/TextView.java'='package android.widget;public class TextView extends android.view.View {private CharSequence text="";public int textWrites;public TextView(android.content.Context c){super(c);}public void setText(CharSequence s){text=s;textWrites++;}public CharSequence getText(){return text;}public void setTextSize(int n){}public void setTextColor(int n){}}'
'android/widget/Button.java'='package android.widget;public class Button extends TextView {public Button(android.content.Context c){super(c);}public void setAllCaps(boolean b){}}'
'android/widget/ProgressBar.java'='package android.widget;public class ProgressBar extends android.view.View {public ProgressBar(android.content.Context c,Object a,int style){super(c);}public void setMax(int n){}public void setProgress(int n){}}'
'android/R.java'='package android;public final class R {public static final class attr {public static final int progressBarStyleHorizontal=0;}}'
}
foreach($entry in $stubs.GetEnumerator()){$path=Join-Path $stubRoot $entry.Key;New-Item -ItemType Directory -Force -Path (Split-Path $path)|Out-Null;[IO.File]::WriteAllText($path,$entry.Value,[Text.UTF8Encoding]::new($false))}
$sources=@(Get-ChildItem -LiteralPath $stubRoot -Recurse -Filter '*.java'|ForEach-Object FullName)
$sources+=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java'|ForEach-Object FullName)
$sources+=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session','Recording','SongData','GuideSong','OledGuideSong','OledGuideUi','VisualFrames','VisualPoller','LinkController','LinkSession')|ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/OledGuideIdlePollTest.java'
$sources+=Join-Path $PSScriptRoot 'test/org/pianolink/OledGuideIdlePollTransportTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 --release 8 -d $testOut @sources
if($LASTEXITCODE -ne 0){throw 'OLED idle-poll tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.OledGuideIdlePollTest
if($LASTEXITCODE -ne 0){throw 'OLED idle-poll regression tests failed'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.OledGuideIdlePollTransportTest
if($LASTEXITCODE -ne 0){throw 'OLED timed idle-poll transport regression tests failed'}
