param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/transport-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$testSources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'test/host') -Recurse -Filter '*.java' | ForEach-Object {$_.FullName})
$testSources+=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session','VisualFrames','VisualPoller','LinkController') | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$testSources+=Join-Path $PSScriptRoot 'test/org/pianolink/TransportTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 -d $testOut @testSources
if($LASTEXITCODE -ne 0){throw 'Transport tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.TransportTest
if($LASTEXITCODE -ne 0){throw 'Transport behavior test failed'}
