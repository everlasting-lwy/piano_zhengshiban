param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot')
$ErrorActionPreference='Stop'
$testOut=Join-Path $PSScriptRoot 'build/ensemble-test'
New-Item -ItemType Directory -Force -Path $testOut | Out-Null
$testSources=@('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','SectorRpcClient','Fat32Store','Session') | ForEach-Object {Join-Path $PSScriptRoot "src/org/pianolink/$_.java"}
$testSources+=Join-Path $PSScriptRoot 'test/org/pianolink/EnsembleProtocolTest.java'
& "$Jdk/bin/javac.exe" -encoding UTF-8 -d $testOut @testSources
if($LASTEXITCODE -ne 0){throw 'Ensemble tests did not compile'}
& "$Jdk/bin/java.exe" -cp $testOut org.pianolink.EnsembleProtocolTest
if($LASTEXITCODE -ne 0){throw 'Ensemble protocol test failed'}
