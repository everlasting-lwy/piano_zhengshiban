package org.pianolink;

import java.io.*;
import java.nio.charset.Charset;
import java.util.Locale;

/** Host acceptance adapter: actual model predictions go through the phone's production decoder. */
public final class PitchFixtureCli {
    private static int i32(DataInputStream input) throws IOException {
        return input.readUnsignedByte()|(input.readUnsignedByte()<<8)|(input.readUnsignedByte()<<16)|(input.readUnsignedByte()<<24);
    }
    private static void matrix(DataInputStream input,float[][] values) throws IOException {
        for(int t=0;t<172;t++)for(int p=0;p<88;p++)values[t][p]=Float.intBitsToFloat(i32(input));
    }
    public static void main(String[] args) throws Exception {
        if(args.length<3||args.length>4||(!args[2].equals("mono")&&!args[2].equals("poly")))
            throw new IllegalArgumentException("PitchFixtureCli predictions.bpp output.csv mono|poly [notes.tsv]");
        long samples;PitchPostprocessor processor=new PitchPostprocessor(args[2].equals("poly"));
        try(DataInputStream input=new DataInputStream(new BufferedInputStream(new FileInputStream(args[0])))) {
            if(i32(input)!=0x31505042)throw new IOException("Expected BPP1 magic");
            int windows=i32(input);samples=(i32(input)&0xffffffffL)|((i32(input)&0xffffffffL)<<32);
            if(windows!=BasicPitchWindowing.windowCount(samples))throw new IOException("Window count disagrees with source audio length");
            float[][] note=new float[172][88],onset=new float[172][88];
            for(int w=0;w<windows;w++) {
                matrix(input,note);matrix(input,onset);
                BasicPitchWindowing.acceptWindow(processor,w,note,onset,samples,()->false);
            }
            if(input.read()!=-1)throw new IOException("Trailing prediction bytes");
        }
        PitchPostprocessor.Result result=processor.finish(samples*1000.0/22050);
        try(Writer csv=new OutputStreamWriter(new FileOutputStream(args[1]),Charset.forName("UTF-8"))) {
            csv.write(result.song==null?"time_ms,mask36,voices\n":result.song.toCsv());
        }
        if(args.length==4)try(PrintWriter notes=new PrintWriter(new OutputStreamWriter(new FileOutputStream(args[3]),Charset.forName("UTF-8")))) {
            notes.println("start_ms\tend_ms\tmidi\tconfidence");
            for(PitchPostprocessor.Note n:result.notes)notes.printf(Locale.US,"%.3f\t%.3f\t%d\t%.6f%n",n.startMs,n.endMs,n.midi,n.confidence);
        }
        System.out.println("detected="+result.detectedNotes+" outside="+result.outOfRange+" polyphony_reduced="+result.polyphonyReduced
                +" too_fast="+result.tooFast+" events="+(result.song==null?0:result.song.events.size()));
    }
}
