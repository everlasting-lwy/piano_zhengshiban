package org.pianolink;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/** Host checks use literal note fixtures and real disposable filesystem directories. */
public final class LibraryTest {
    private static int checks;
    private interface Action { void run() throws Exception; }
    private static void eq(long want, long got, String why) {
        checks++;
        if (want != got) throw new AssertionError(why + ": want " + want + ", got " + got);
    }
    private static void eq(Object want, Object got, String why) {
        checks++;
        if (want == null ? got != null : !want.equals(got))
            throw new AssertionError(why + ": want " + want + ", got " + got);
    }
    private static void bad(Action action, String why) throws Exception {
        checks++;
        try { action.run(); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError(why + ": accepted invalid data");
    }
    private static void ioBad(Action action, String why) throws Exception {
        checks++;
        try { action.run(); }
        catch (IOException expected) { return; }
        throw new AssertionError(why + ": operation unexpectedly succeeded");
    }
    private static SongData song() {
        return SongData.fromCsv("time_ms,mask,voices\n0,129,3\n250,0,0\n");
    }
    private static void songChecks() throws Exception {
        SongData legacy = song();
        eq(SongData.Format.LEGACY12, legacy.format, "old header keeps legacy ordering");
        eq(129, legacy.events.get(0).mask, "legacy natural/sharp bits do not move");
        eq(250, legacy.durationMs(), "duration uses original last timestamp");
        SongData absolute = SongData.fromCsv("# PianoLink v2; incomplete=true\r\ntime_ms,mask36,voices\r\n0,34359738369,15\r\n500,0,0\r\n");
        eq(SongData.Format.ABSOLUTE36, absolute.format, "new header selects absolute format");
        eq(34359738369L, absolute.events.get(0).mask, "C3 and B5 survive decimal parsing");
        eq(true, absolute.incomplete, "incomplete flag retained");
        SongData again = SongData.fromCsv(absolute.toCsv());
        eq(absolute.format, again.format, "CSV roundtrip format");
        eq(34359738369L, again.events.get(0).mask, "CSV roundtrip bit35");
        eq(true, again.incomplete, "CSV roundtrip incomplete flag");
        SongData lowAbsolute = SongData.fromCsv("time_ms,mask36,voices\n0,1,1\n");
        eq(SongData.Format.ABSOLUTE36, lowAbsolute.format, "small absolute mask is never guessed as legacy");
        ArrayList<SongData.Event> source = new ArrayList<SongData.Event>();
        source.add(new SongData.Event(0, 1, 1));
        SongData immutable = new SongData(SongData.Format.LEGACY12, source, false);
        source.clear();
        eq(1, immutable.events.size(), "input list cannot mutate a playback snapshot");
        checks++;
        try { immutable.events.clear(); throw new AssertionError("events must be immutable"); }
        catch (UnsupportedOperationException expected) { }
        Recording recording = new Recording();
        recording.fromCsv("# PianoLink v1; incomplete=true\ntime_ms,mask,voices\n0,2048,1\n100,0,0\n");
        SongData snapshot = SongData.fromRecording(recording);
        recording.start();
        eq(2, snapshot.events.size(), "recording replacement cannot change saved snapshot");
        eq(2048, snapshot.events.get(0).mask, "recording old key semantics retained");
        eq(true, snapshot.incomplete, "recording incompleteness copied");

        final String[] malformed = {
            "time_ms,mask32,voices\n0,1,1\n", "0,1,1\n", "time_ms,mask,voices\n",
            "time_ms,mask,voices\n0,4096,1\n", "time_ms,mask36,voices\n0,68719476736,1\n",
            "time_ms,mask36,voices\n0,-1,1\n", "time_ms,mask,voices\n0,1,16\n",
            "time_ms,mask,voices\n0,1,-1\n", "time_ms,mask,voices\n-1,1,1\n",
            "time_ms,mask,voices\n86400001,1,1\n", "time_ms,mask,voices\n10,1,1\n9,0,0\n",
            "time_ms,mask,voices\n0,1\n", "time_ms,mask,voices\n0,1,1,0\n",
            "time_ms,mask,voices\n0,1.5,1\n", "time_ms,mask,voices\n0,999999999999999999999,1\n"
        };
        for (final String csv : malformed) bad(new Action() { public void run() { SongData.fromCsv(csv); } }, "malformed/range CSV");
        bad(new Action() { public void run() { new SongData(SongData.Format.LEGACY12, Collections.<SongData.Event>emptyList(), false); } }, "empty event set");
        bad(new Action() { public void run() { new SongData(null, Arrays.asList(new SongData.Event(0,1,1)), false); } }, "missing format");
        bad(new Action() { public void run() { new SongData(SongData.Format.LEGACY12, Arrays.asList((SongData.Event)null), false); } }, "null event");
        bad(new Action() { public void run() { new SongData(SongData.Format.LEGACY12, Arrays.asList(new SongData.Event(0,4096,1)), false); } }, "constructor range guard");
        List<SongData.Event> limit = new ArrayList<SongData.Event>();
        for (int i = 0; i < 100000; i++) limit.add(new SongData.Event(i, 1, 1));
        eq(100000, new SongData(SongData.Format.LEGACY12, limit, false).events.size(), "100000-event boundary accepted");
        limit.add(new SongData.Event(100000, 0, 0));
        final List<SongData.Event> tooMany = limit;
        bad(new Action() { public void run() { new SongData(SongData.Format.LEGACY12, tooMany, false); } }, "100001 events rejected");
        eq(86400000, SongData.fromCsv("time_ms,mask,voices\n86400000,0,0\n").durationMs(), "24h boundary accepted");
        eq(68719476735L, SongData.fromCsv("time_ms,mask36,voices\n0,68719476735,15\n").events.get(0).mask, "all36 bits boundary accepted");
        eq(4095, SongData.fromCsv("\ufefftime_ms,mask,voices\n0,4095,15\n0,0,0\n").events.get(0).mask, "BOM and coincident old timestamps supported");
        StringBuilder excessiveRows = new StringBuilder("time_ms,mask,voices\n");
        for (int i = 0; i < 100001; i++) excessiveRows.append("0,1,1\n");
        final String oversizedRows = excessiveRows.toString();
        bad(new Action() { public void run() { SongData.fromCsv(oversizedRows); } }, "CSV event limit is enforced during parsing");
        char[] huge = new char[8 * 1024 * 1024];
        Arrays.fill(huge, 'x');
        final String oversized = "#" + new String(huge) + "\ntime_ms,mask,voices\n0,1,1\n";
        bad(new Action() { public void run() { SongData.fromCsv(oversized); } }, "8MiB input limit applies to comments too");
        char[] multibyte = new char[3 * 1024 * 1024];
        Arrays.fill(multibyte, '\u4e2d');
        final String multibyteOversized = "#" + new String(multibyte) + "\ntime_ms,mask,voices\n0,1,1\n";
        bad(new Action() { public void run() { SongData.fromCsv(multibyteOversized); } }, "8MiB limit counts UTF8 bytes rather than characters");
    }
    private static void write(File file, String text) throws Exception {
        FileOutputStream out = new FileOutputStream(file);
        try { out.write(text.getBytes("UTF-8")); } finally { out.close(); }
    }
    private static void eraseOwned(File file, File root) throws Exception {
        String owner = root.getCanonicalPath();
        String candidate = file.getCanonicalPath();
        if (!candidate.equals(owner) && !candidate.startsWith(owner + File.separator))
            throw new AssertionError("Test cleanup escaped its disposable directory");
        File[] children = file.listFiles();
        if (children != null) for (File child : children) eraseOwned(child, root);
        if (!file.delete() && file.exists()) throw new IOException("Cannot remove test file " + file);
    }
    private static boolean directoryLink(File link, File target) throws Exception {
        try {
            java.nio.file.Files.createSymbolicLink(link.toPath(), target.getAbsoluteFile().toPath());
            return true;
        } catch (IOException unavailable) {
            if (!System.getProperty("os.name").startsWith("Windows")) return false;
        } catch (UnsupportedOperationException unavailable) { return false; }
        String script = "New-Item -ItemType Junction -Path '" + link.getAbsolutePath().replace("'", "''")
                + "' -Target '" + target.getAbsolutePath().replace("'", "''") + "' | Out-Null";
        Process process = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script)
                .redirectErrorStream(true).start();
        BufferedReader output = new BufferedReader(new InputStreamReader(process.getInputStream(), "UTF-8"));
        try { while (output.readLine() != null) { } } finally { output.close(); }
        return process.waitFor() == 0;
    }
    private static void storageChecks() throws Exception {
        final File directory = new File("build/library-fixture-" + UUID.randomUUID().toString());
        if (!directory.mkdirs()) throw new IOException("Cannot create owned test directory");
        try {
            final SongLibrary library = new SongLibrary(directory);
            eq(0, library.list().size(), "fresh persistent library is empty");
            SongLibrary.Entry first = library.add("钢琴练习", song());
            SongLibrary.Entry second = library.add("钢琴练习", SongData.fromCsv("time_ms,mask36,voices\n0,34359738368,1\n700,0,0\n"));
            eq("钢琴练习", first.name, "Unicode display name retained");
            eq("钢琴练习 (2)", second.name, "same-name imports get a suffix");
            eq(250, first.durationMs, "metadata original duration");
            eq(2, second.eventCount, "metadata event count");
            eq(SongData.Format.ABSOLUTE36, second.format, "metadata format");
            eq(false, first.id.equals(second.id), "independent generated IDs");
            eq(true, first.id.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"), "path-safe UUID IDs");
            SongLibrary reopened = new SongLibrary(directory);
            eq(2, reopened.list().size(), "two songs persist across instances");
            eq(129, reopened.load(first.id).events.get(0).mask, "first song keeps independent playback data");
            eq(34359738368L, reopened.load(second.id).events.get(0).mask, "second song keeps independent playback data");
            eq(first.id, reopened.list().get(0).id, "deterministic name order");
            SongLibrary.Entry renamed = reopened.rename(first.id, "练习新版");
            eq(first.id, renamed.id, "rename keeps stable ID");
            eq("练习新版", new SongLibrary(directory).list().get(0).name, "rename survives restart");
            eq("钢琴练习 (2) (2)", reopened.rename(first.id, second.name).name, "duplicate rename uses same suffix policy");
            eq("钢琴练习 (2)", reopened.rename(second.id, second.name).name, "renaming to self never adds suffix");
            final String secondId = second.id;
            File blockedTemporary = new File(directory, second.id + ".meta.tmp");
            eq(true, blockedTemporary.mkdir(), "prepare actual filesystem write failure");
            ioBad(new Action() { public void run() throws Exception { library.rename(secondId, "failed rename"); } }, "failed metadata write reports I/O failure");
            eq("钢琴练习 (2)", new SongLibrary(directory).list().get(0).name, "failed rename preserves committed name");
            eq(34359738368L, reopened.load(second.id).events.get(0).mask, "failed rename preserves committed notes");
            eq(true, blockedTemporary.delete(), "remove owned failure fixture");
            bad(new Action() { public void run() throws Exception { library.add("bad", SongData.fromCsv("time_ms,mask,voices\n0,4096,1\n")); } }, "bad CSV import rejected before persistence");
            eq(2, new SongLibrary(directory).list().size(), "invalid import preserves all old entries");
            eq(129, reopened.load(first.id).events.get(0).mask, "invalid import preserves old contents");
            SongLibrary.Entry traversalName = reopened.add("../outside.csv", song());
            eq("../outside.csv", traversalName.name, "display names are never paths");
            eq(true, new File(directory, traversalName.id + ".csv").isFile(), "only generated ID forms storage paths");
            final String[] attacks = { "../outside", "..\\outside", "/tmp/outside", "C:\\outside", first.id + "/..", "" };
            for (final String attack : attacks) {
                bad(new Action() { public void run() throws Exception { library.load(attack); } }, "load rejects path traversal");
                bad(new Action() { public void run() throws Exception { library.rename(attack, "name"); } }, "rename rejects path traversal");
                bad(new Action() { public void run() throws Exception { library.delete(attack); } }, "delete rejects path traversal");
            }
            bad(new Action() { public void run() throws Exception { library.add("bad\nname", song()); } }, "control characters rejected in names");
            List<SongLibrary.Entry> listing = reopened.list();
            listing.clear();
            eq(3, reopened.list().size(), "caller mutation cannot remove persistent entries");
            reopened.delete(first.id);
            eq(2, new SongLibrary(directory).list().size(), "delete survives restart");
            final String deletedId = first.id;
            ioBad(new Action() { public void run() throws Exception { library.load(deletedId); } }, "deleted current ID cannot be loaded");

            // Simulate a power loss after the previous metadata was backed up but before rename commit.
            File metadata = new File(directory, second.id + ".meta");
            File backup = new File(directory, second.id + ".meta.bak");
            eq(true, metadata.renameTo(backup), "prepare interrupted metadata rename");
            write(new File(directory, second.id + ".meta.tmp"), "partial metadata");
            SongLibrary recovered = new SongLibrary(directory);
            eq(2, recovered.list().size(), "interrupted rename recovers committed entries");
            eq("钢琴练习 (2)", recovered.list().get(1).name, "recovery retains last committed name");
            eq(34359738368L, recovered.load(second.id).events.get(0).mask, "recovery retains saved notes");
            // A fully committed metadata file takes precedence over any stale prior backup.
            eq(true, metadata.renameTo(backup), "prepare old metadata backup");
            java.nio.file.Files.copy(backup.toPath(), metadata.toPath());
            recovered.rename(second.id, "最终曲名");
            java.nio.file.Files.copy(metadata.toPath(), backup.toPath());
            write(metadata, "damaged final metadata");
            recovered = new SongLibrary(directory);
            eq("最终曲名", recovered.list().get(1).name, "valid backup restores a damaged final metadata file");
            eq(34359738368L, recovered.load(second.id).events.get(0).mask, "backup recovery verifies independent CSV");
            write(new File(directory, "abandoned.csv.tmp"), "partial CSV");
            write(new File(directory, "abandoned.meta.tmp"), "partial metadata");
            eq(2, new SongLibrary(directory).list().size(), "orphan temporaries never masquerade as songs");

            SongLibrary.Entry corrupt = recovered.add("Corrupt metadata", song());
            write(new File(directory, corrupt.id + ".meta"), "not metadata");
            eq(2, new SongLibrary(directory).list().size(), "corrupt metadata cannot hide healthy songs");
            final String corruptId = corrupt.id;
            ioBad(new Action() { public void run() throws Exception { library.load(corruptId); } }, "corrupt entry load gives I/O failure");
            SongLibrary.Entry corruptCsv = recovered.add("Corrupt CSV", song());
            write(new File(directory, corruptCsv.id + ".csv"), "time_ms,mask,voices\n0,4096,1\n");
            eq(2, new SongLibrary(directory).list().size(), "corrupt CSV cannot hide healthy songs");
            SongLibrary.Entry forged = recovered.add("Forged metadata", song());
            File forgedFile = new File(directory, forged.id + ".meta");
            Properties properties = new Properties();
            FileInputStream input = new FileInputStream(forgedFile);
            try { properties.load(input); } finally { input.close(); }
            properties.setProperty("id", "../outside");
            FileOutputStream output = new FileOutputStream(forgedFile);
            try { properties.store(output, "tampered ID"); } finally { output.close(); }
            eq(2, new SongLibrary(directory).list().size(), "metadata cannot redirect entry path");

            // Delete's tombstone wins even when a crash left CSV and backup metadata behind.
            File deletedMeta = new File(directory, traversalName.id + ".meta");
            eq(true, deletedMeta.renameTo(new File(directory, traversalName.id + ".deleted")), "prepare interrupted deletion");
            eq(1, new SongLibrary(directory).list().size(), "interrupted deletion cannot resurrect a selected song");
            eq(34359738368L, new SongLibrary(directory).load(second.id).events.get(0).mask, "healthy song survives unrelated corruption and cleanup");
            File corruptMarker = new File(directory, second.id + ".deleted");
            write(corruptMarker, "corrupt deletion marker");
            eq(1, new SongLibrary(directory).list().size(), "corrupt deletion artifact cannot erase a healthy committed song");
            eq(34359738368L, new SongLibrary(directory).load(second.id).events.get(0).mask, "invalid tombstone preserves independent CSV");
            eq(true, corruptMarker.delete(), "remove corrupt owned marker");
            Properties wrongHashMarker = new Properties();
            File healthyMetadata = new File(directory, second.id + ".meta");
            FileInputStream healthyInput = new FileInputStream(healthyMetadata);
            try { wrongHashMarker.load(healthyInput); } finally { healthyInput.close(); }
            wrongHashMarker.setProperty("sha256", "0000000000000000000000000000000000000000000000000000000000000000");
            FileOutputStream markerOutput = new FileOutputStream(corruptMarker);
            try { wrongHashMarker.store(markerOutput, "well-formed but incorrect hash"); } finally { markerOutput.close(); }
            eq(1, new SongLibrary(directory).list().size(), "wrong-hash deletion marker cannot erase healthy metadata and CSV");
            eq(34359738368L, new SongLibrary(directory).load(second.id).events.get(0).mask, "wrong-hash marker preserves healthy playback data");
            eq(true, corruptMarker.delete(), "remove wrong-hash marker with committed metadata");

            // With metadata absent, the surviving CSV must still match the marker before cleanup.
            File savedMetadata = new File(directory, second.id + ".saved-test-metadata");
            eq(true, healthyMetadata.renameTo(savedMetadata), "prepare metadata-absent recovery checkpoint");
            markerOutput = new FileOutputStream(corruptMarker);
            try { wrongHashMarker.store(markerOutput, "wrong hash with surviving CSV"); } finally { markerOutput.close(); }
            new SongLibrary(directory);
            eq(true, new File(directory, second.id + ".csv").isFile(), "wrong-hash marker cannot erase surviving CSV without metadata");
            eq(true, savedMetadata.renameTo(healthyMetadata), "restore owned healthy metadata");
            eq(true, corruptMarker.delete(), "remove metadata-absent wrong-hash marker");

            // Genuine deletion can crash after CSV removal but before backup/marker cleanup.
            SongLibrary.Entry cleanupCheckpoint = recovered.add("Deletion cleanup checkpoint", song());
            File cleanupMarker = new File(directory, cleanupCheckpoint.id + ".deleted");
            eq(true, new File(directory, cleanupCheckpoint.id + ".meta").renameTo(cleanupMarker), "prepare committed deletion before CSV cleanup");
            java.nio.file.Files.copy(cleanupMarker.toPath(), new File(directory, cleanupCheckpoint.id + ".meta.bak").toPath());
            eq(true, new File(directory, cleanupCheckpoint.id + ".csv").delete(), "prepare deletion after CSV cleanup");
            eq(1, new SongLibrary(directory).list().size(), "crash after CSV deletion never resurrects deleted song");
            eq(false, cleanupMarker.exists(), "completed deletion recovery removes valid marker");
            eq(false, new File(directory, cleanupCheckpoint.id + ".meta.bak").exists(), "completed deletion recovery removes stale backup");
            File linkTarget = new File(directory, "owned-link-target");
            eq(true, linkTarget.mkdir(), "prepare owned link target");
            File preserved = new File(linkTarget, "preserved.txt");
            write(preserved, "must survive recovery");
            File poisonedTombstone = new File(directory, UUID.randomUUID().toString() + ".deleted");
            if (directoryLink(poisonedTombstone, linkTarget)) {
                try {
                    eq(1, new SongLibrary(directory).list().size(), "symlinked recovery artifact cannot hide healthy songs");
                    eq(true, preserved.isFile(), "recovery never follows a linked deletion marker");
                } finally { java.nio.file.Files.deleteIfExists(poisonedTombstone.toPath()); }
            } else System.out.println("SKIP symlink/junction isolation: filesystem does not permit links");
        } finally { eraseOwned(directory, directory); }
    }
    public static void main(String[] args) throws Exception {
        songChecks();
        storageChecks();
        System.out.println("PASS " + checks + " library/CSV behavioral checks");
    }
}
