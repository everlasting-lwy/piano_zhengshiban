package org.pianolink;

import java.lang.reflect.*;
import java.util.*;

/** Frozen-wire fixtures and complete-frame safety through the production classes. */
public final class EffectsTest {
    private static int checks;
    private static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    private static void eq(long want,long got,String why){ok(want==got,why+": want "+want+", got "+got);}
    private static Protocol.Frame frame(int seq,int cmd,int...d){return new Protocol.Frame(seq,cmd,d);}
    private static void ack(Session s,Session.Send send){s.receive(frame(send.frame.seq,0x80,send.frame.cmd,0,1,0,0,0));}
    private static Object create(String name)throws Exception{try{return Class.forName("org.pianolink."+name).getConstructor().newInstance();}catch(ClassNotFoundException e){throw new AssertionError("missing production "+name,e);}}
    private static Object call(Object target,String name,Class<?>[] types,Object...args)throws Exception{try{return target.getClass().getMethod(name,types).invoke(target,args);}catch(InvocationTargetException e){throw (Exception)e.getCause();}}
    private static Object receive(Object a,Protocol.Frame f,long now)throws Exception{return call(a,"receive",new Class<?>[]{Protocol.Frame.class,long.class},f,now);}
    private static void begin(Object a,int seq,int kind,long now)throws Exception{call(a,"begin",new Class<?>[]{int.class,int.class,long.class},seq,kind,now);}
    private static int[] data(Object snapshot)throws Exception{return (int[])snapshot.getClass().getField("data").get(snapshot);}
    public static void main(String[] args)throws Exception{
        Session s=new Session();
        try{s.control(13,3);s.control(13,(1<<8)|9);s.control(13,7);}catch(IllegalArgumentException e){throw new AssertionError("effect commands must queue independently per parameter",e);}
        Session.Send send=s.tick(0);ack(s,send);
        send=s.tick(40);eq(13,send.frame.cmd,"effect command");eq(0,send.frame.d[0],"first parameter retained");eq(7,send.frame.d[1],"same parameter coalesces latest value");ack(s,send);
        send=s.tick(80);eq(1,send.frame.d[0],"second simultaneous slider not overwritten");eq(9,send.frame.d[1],"second value");ack(s,send);
        s.control(14,3);s.control(13,(4<<8)|16);send=s.tick(120);eq(13,send.frame.cmd,"effect control precedes bulk request");ack(s,send);
        send=s.tick(160);eq(14,send.frame.cmd,"visual request eventually served");eq(3,send.frame.d[0],"requested XY kind");ack(s,send);
        s.control(12,0);send=s.tick(200);eq(12,send.frame.cmd,"effects query accepted");ok(s.receive(frame(send.frame.seq,0x85,0,0xf0,0,0x88,0,0x31)),"85 retires matching query without ACK");
        s.control(14,1);s.release();send=s.tick(201);eq(5,send.frame.cmd,"release preempts visual query");
        boolean invalid=false;try{s.control(13,(4<<8)|17);}catch(IllegalArgumentException e){invalid=true;}ok(invalid,"out-of-range bend cannot enter queue");
        Session query=new Session();query.control(12,0);send=query.tick(0);ack(query,send);send=query.tick(40);
        ok(!query.receive(frame(send.frame.seq,0x85,0,0xf0,0,0x88,0,0x30)),"wrong capability marker cannot retire query");ok(!query.receive(frame(send.frame.seq+1,0x85,0,0xf0,0,0x88,0,0x31)),"wrong query sequence cannot confirm support");ok(query.receive(frame(send.frame.seq,0x80,12,2,1,0,0,0)),"old firmware unsupported ACK retires query");

        MockFpga mock=new MockFpga();Protocol.Frame f=Protocol.decode(mock.accept(Protocol.encode(10,12,0,0,0,0,0,0),100));
        eq(0x85,f.cmd,"mock capability uses new protocol");eq(0xf0,f.d[1],"neutral expression");eq(0x88,f.d[3],"centered bend");eq(0x31,f.d[5],"exact capability marker");
        f=Protocol.decode(mock.accept(Protocol.encode(11,13,4,16,0,0,0,0),101));eq(0,f.d[1],"mock accepts maximum bend");
        f=Protocol.decode(mock.accept(Protocol.encode(12,13,7,3,0,0,0,0),102));eq(1,f.d[1],"mock validates guide range");
        f=Protocol.decode(mock.accept(Protocol.encode(13,13,0,3,1,0,0,0),103));eq(1,f.d[1],"mock validates setter reserved bytes");
        int[] chosen={15,14,13,12,16,11,2,2};for(int id=0;id<8;id++){f=Protocol.decode(mock.accept(Protocol.encode(20+id,13,id,chosen[id],0,0,0,0),200+id));eq(0,f.d[1],"mock setter accepts parameter "+id);int bad=id==4?17:id>=6?3:16;f=Protocol.decode(mock.accept(Protocol.encode(30+id,13,id,bad,0,0,0,0),300+id));eq(1,f.d[1],"mock setter rejects range for parameter "+id);}
        f=Protocol.decode(mock.accept(Protocol.encode(40,12,0,0,0,0,0,0),400));eq(0xef,f.d[0],"echo/reverb packed wire fixture");eq(0xcd,f.d[1],"expression/chorus packed wire fixture");eq(0xab,f.d[2],"guide/delay/vibrato packed wire fixture");eq(0x90,f.d[3],"maximum bend marker wire fixture");
        for(int kind=1;kind<=4;kind++){int count=kind==1?16:kind==2?8:kind==3?32:1;mock.accept(Protocol.encode(50+kind,14,kind,0,0,0,0,0),500+kind);f=Protocol.decode(mock.pollEvent());eq(0x86,f.cmd,"metadata before synthetic chunks");eq(count,f.d[1],"kind-specific chunk count");for(int i=0;i<count;i++){f=Protocol.decode(mock.pollEvent());eq(0x87,f.cmd,"synthetic chunk command");eq(50+kind,f.seq,"chunk request sequence");eq(i,f.d[1],"chunk index");}ok(mock.pollEvent()==null,"bounded one-shot synthetic snapshot");}
        mock.accept(Protocol.encode(60,13,7,1,0,0,0,0),600);mock.accept(Protocol.encode(61,14,4,0,0,0,0,0),601);while(mock.pollEvent()!=null){}
        mock.accept(Protocol.encode(62,9,0,0x10,0,0,0,0),602);mock.accept(Protocol.encode(63,9,0,0,0,0,0,0),603);f=Protocol.decode(mock.accept(Protocol.encode(64,12,0,0,0,0,0,0),604));eq(0,f.d[4]&31,"phone keys cannot advance synthetic physical guide");mock.physicalKeys(1L<<12,605);mock.physicalKeys(0,606);f=Protocol.decode(mock.accept(Protocol.encode(65,12,0,0,0,0,0,0),607));eq(1,f.d[4]&31,"physical-only press/release advances guide");

        Object state=create("EffectsState");
        ok((Boolean)call(state,"report",new Class<?>[]{Protocol.Frame.class},frame(1,0x85,0x43,0xa2,0x65,0x90,0x71,0x31)),"valid packed status accepted");
        eq(3,(Integer)call(state,"desired",new Class<?>[]{int.class},0),"initial status initializes desired once");
        call(state,"choose",new Class<?>[]{int.class,int.class},0,12);
        call(state,"report",new Class<?>[]{Protocol.Frame.class},frame(2,0x85,0x41,0xa2,0x65,0x90,0x71,0x31));
        eq(12,(Integer)call(state,"desired",new Class<?>[]{int.class},0),"async report cannot jump selected slider");eq(1,(Integer)call(state,"confirmed",new Class<?>[]{int.class},0),"actual device value updates separately");
        ok(!(Boolean)call(state,"report",new Class<?>[]{Protocol.Frame.class},frame(2,0x85,0,0,0,0xa8,0,0x31)),"reserved status bits rejected");
        ok(!(Boolean)call(state,"report",new Class<?>[]{Protocol.Frame.class},frame(2,0x85,0,0,0,0x88,0,0x30)),"36-key/other capability cannot imply effects support");
        try{eq(12,(Integer)EffectsState.class.getMethod("guideTarget",int.class,int.class).invoke(null,1,7),"major scale ends on physicalC5");eq(7,(Integer)EffectsState.class.getMethod("guideTarget",int.class,int.class).invoke(null,2,1),"chromatic second note maps natural-first Csharp");eq(17,(Integer)EffectsState.class.getMethod("guideTarget",int.class,int.class).invoke(null,2,17),"chromatic last target isF5");eq(-1,(Integer)EffectsState.class.getMethod("guideTarget",int.class,int.class).invoke(null,0,0),"disabled guide has no target");}catch(NoSuchMethodException e){throw new AssertionError("guide drawing must match physical natural-first target mapping",e);}

        Object a=create("VisualFrames");begin(a,7,1,100);
        ok(receive(a,frame(7,0x87,1,0,1,2,3,4),101)==null,"chunk before metadata rejected");
        receive(a,frame(7,0x86,1,16,0xe8,3,0,0),102);Object complete=null;
        for(int i=0;i<16;i++)complete=receive(a,frame(7,0x87,1,i,i*4,i*4+1,i*4+2,i*4+3),110+i);
        ok(complete!=null,"only full 64-point frame published");eq(63,data(complete)[63],"complete frame content");
        begin(a,8,1,200);receive(a,frame(8,0x86,1,16,0xe9,3,0,0),201);
        receive(a,frame(8,0x87,1,0,1,2,3,4),202);ok(receive(a,frame(7,0x87,1,1,5,6,7,8),203)==null,"old seq cannot be merged into active frame");
        for(int i=1;i<16;i++)ok(receive(a,frame(8,0x87,1,i,1,2,3,4),204+i)==null,"mixed-sequence frame discarded entirely");
        begin(a,9,2,300);receive(a,frame(9,0x86,2,8,0xea,3,0,0),301);
        receive(a,frame(9,0x87,2,0,1,2,3,4),302);receive(a,frame(9,0x87,2,0,1,2,3,4),303);
        for(int i=1;i<8;i++)ok(receive(a,frame(9,0x87,2,i,1,2,3,4),304+i)==null,"duplicate index invalidates entire frame");
        begin(a,10,4,400);receive(a,frame(10,0x86,4,1,0xeb,3,0,0),401);
        ok(receive(a,frame(10,0x87,4,0,0,0,0x20,0),402)==null,"reserved guide bits rejected");
        begin(a,11,4,500);receive(a,frame(11,0x86,4,1,0xeb,3,0,0),501);
        complete=receive(a,frame(11,0x87,4,0,0x81,0x80,0x1a,17),502);ok(complete!=null,"valid physical guide complete");eq(0x1a,data(complete)[2],"guide mode/wrong/physical high bits retained");
        begin(a,12,4,600);receive(a,frame(12,0x86,4,1,0xea,3,0,0),601);ok(receive(a,frame(12,0x87,4,0,0,0,0,0),602)==null,"older device capture rejected");
        begin(a,13,4,700);receive(a,frame(13,0x86,4,1,0xec,3,0,0),701);ok(receive(a,frame(13,0x87,4,0,0,0,0,0),3300)==null,"timed-out partial cannot publish");
        begin(a,14,3,3400);receive(a,frame(14,0x86,3,16,0xed,3,0,0),3401);ok(!(Boolean)call(a,"busy",new Class<?>[]{long.class},3402L),"wrong kind length invalidates acquisition");
        Object reset=create("VisualFrames");begin(reset,1,4,0);receive(reset,frame(1,0x86,4,1,0x88,0x13,0,0),1);ok(receive(reset,frame(1,0x87,4,0,0,0,0,0),2)!=null,"pre-reset capture accepted");
        begin(reset,2,4,500);receive(reset,frame(2,0x86,4,1,0,0,0,0),501);ok(receive(reset,frame(2,0x87,4,0,0,0,0,0),502)==null,"first backward capture withheld");
        begin(reset,3,4,1000);receive(reset,frame(3,0x86,4,1,0xf4,1,0,0),1001);ok(receive(reset,frame(3,0x87,4,0,0,0,0,0),1002)!=null,"FPGA reboot recovers on next request without SPP reconnect");

        Object p=create("VisualPoller");call(p,"select",new Class<?>[]{int.class,boolean.class},1,true);
        eq(-1,(Integer)call(p,"next",new Class<?>[]{long.class},0L),"no request before capability");call(p,"supported",new Class<?>[]{boolean.class},true);
        eq(1,(Integer)call(p,"next",new Class<?>[]{long.class},0L),"visible foreground view requests snapshot");eq(-1,(Integer)call(p,"next",new Class<?>[]{long.class},100L),"queued request cannot repeat");
        call(p,"sent",new Class<?>[]{int.class,int.class,long.class},1,1,100L);eq(-1,(Integer)call(p,"next",new Class<?>[]{long.class},900L),"partial frame blocks next request");
        eq(1,(Integer)call(p,"next",new Class<?>[]{long.class},2700L),"timeout allows bounded recovery");
        call(p,"select",new Class<?>[]{int.class,boolean.class},1,false);eq(-1,(Integer)call(p,"next",new Class<?>[]{long.class},5000L),"background stops all visual requests");
        System.out.println("PASS "+checks+" effects/coalescing/frame/polling checks");
    }
}
