package org.pianolink;

import android.bluetooth.*;
import java.io.*;
import java.util.concurrent.*;

/** Exercises the production LinkController with host sockets, not a separate connection model. */
public final class TransportTest {
    private static int checks;
    private static void ok(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static final class Events implements LinkController.Listener {
        final CountDownLatch connected=new CountDownLatch(1),ended=new CountDownLatch(1),statusReceived=new CountDownLatch(1),capability=new CountDownLatch(1),extendedChord=new CountDownLatch(1),unsupported=new CountDownLatch(1),legacyKey=new CountDownLatch(1);
        volatile String reason="",message="";volatile int status;
        volatile long expectedExtended,lastExtended;
        public void connected(boolean simulated){connected.countDown();}
        public void frame(Protocol.Frame frame){
            if(frame.cmd==0x81){status++;statusReceived.countDown();if((frame.d[4]|((frame.d[5]&15)<<8))==1)legacyKey.countDown();}
            if(frame.cmd==0x83){capability.countDown();lastExtended=frame.extendedMask();if(lastExtended==expectedExtended)extendedChord.countDown();}
            if(frame.cmd==0x80&&frame.d[0]==11&&frame.d[1]==2)unsupported.countDown();
        }
        public void message(String text){message=text;}
        public void ended(String text){reason=text;ended.countDown();}
    }
    private static final class Socket extends BluetoothSocket {
        final PipedInputStream input=new PipedInputStream(4096);
        final PipedOutputStream incoming=new PipedOutputStream(input);
        final CountDownLatch entered=new CountDownLatch(1),closedSignal=new CountDownLatch(1);
        final MockFpga fpga=new MockFpga();final Protocol.Decoder decoder=new Protocol.Decoder();
        final boolean fail,blocked,respond;
        volatile boolean closed;int statusFault;boolean unsupported36;
        Socket(boolean fail,boolean blocked,boolean respond)throws IOException{this.fail=fail;this.blocked=blocked;this.respond=respond;}
        public void connect()throws IOException{
            entered.countDown();
            if(blocked){try{closedSignal.await();}catch(InterruptedException e){Thread.currentThread().interrupt();}throw new IOException("cancelled socket");}
            if(fail)throw new IOException("authentication refused");
        }
        public InputStream getInputStream(){return input;}
        public OutputStream getOutputStream(){return new OutputStream(){public void write(int value)throws IOException{
            if(closed)throw new IOException("closed");
            Protocol.Frame request=decoder.feed((byte)value);
            if(request!=null&&respond){byte[] reply=unsupported36&&request.cmd==11?Protocol.encode(request.seq,0x80,11,2,1,0,0,0):fpga.accept(request.bytes(),System.nanoTime()/1000000);if(reply!=null){
                Protocol.Frame response=Protocol.decode(reply);
                if(response.cmd==0x81&&statusFault!=0){
                    if(statusFault==2)response.d[1]=16;
                    reply=Protocol.encode(response.seq+(statusFault==1?1:0),response.cmd,response.d);
                }
                incoming.write(reply);incoming.flush();
            }}
        }};}
        public void close()throws IOException{closed=true;closedSignal.countDown();incoming.close();input.close();}
    }
    private static void mode(LinkController link,BluetoothDevice device,boolean secure)throws Exception{
        LinkController.class.getMethod("connect",BluetoothDevice.class,boolean.class).invoke(link,device,secure);
    }
    public static void main(String[] args)throws Exception{
        Socket secure=new Socket(true,false,false),compatible=new Socket(false,false,true);
        BluetoothDevice device=new BluetoothDevice(secure,compatible);Events events=new Events();LinkController link=new LinkController(false,events);
        try{
            link.connect(device);events.connected.await(2,TimeUnit.SECONDS);
            ok(device.insecureCalls==1&&device.secureCalls==0,"default compatible SPP must use the insecure socket API");
            ok(events.connected.getCount()==0&&events.statusReceived.await(1,TimeUnit.SECONDS),"ready only after a real protocol status round trip");
        }finally{link.close();}

        secure=new Socket(false,false,true);compatible=new Socket(true,false,false);device=new BluetoothDevice(secure,compatible);events=new Events();link=new LinkController(false,events);
        try{mode(link,device,true);ok(events.connected.await(2,TimeUnit.SECONDS),"explicit secure SPP connects");ok(device.secureCalls==1&&device.insecureCalls==0,"secure selection must not silently downgrade");}finally{link.close();}

        Socket silent=new Socket(false,false,false);events=new Events();link=new LinkController(false,events);
        try{link.connect(new BluetoothDevice(silent,silent));ok(events.ended.await(4,TimeUnit.SECONDS),"silent FPGA ends with a bounded protocol timeout");ok(events.connected.getCount()==1,"SPP alone must never report FPGA ready");ok(events.reason.contains("SPP")&&events.reason.contains("FPGA"),"timeout must identify the transport vs FPGA boundary");}finally{link.close();}

        Socket mismatch=new Socket(false,false,true);mismatch.statusFault=1;events=new Events();link=new LinkController(false,events);
        try{link.connect(new BluetoothDevice(mismatch,mismatch));ok(events.ended.await(4,TimeUnit.SECONDS),"mismatched status cannot complete initialization");ok(events.connected.getCount()==1,"unsolicited status must not report FPGA ready");}finally{link.close();}

        Socket invalid=new Socket(false,false,true);invalid.statusFault=2;events=new Events();link=new LinkController(false,events);
        try{link.connect(new BluetoothDevice(invalid,invalid));ok(events.ended.await(2,TimeUnit.SECONDS),"invalid matched status is rejected");ok(events.connected.getCount()==1&&events.reason.contains("状态参数无效"),"invalid status does not enable piano and identifies protocol error");}finally{link.close();}

        Socket refused=new Socket(true,false,false);events=new Events();link=new LinkController(false,events);
        try{mode(link,new BluetoothDevice(refused,refused),true);ok(events.ended.await(2,TimeUnit.SECONDS),"failed connect is reported");ok(refused.closedSignal.await(1,TimeUnit.SECONDS),"failed candidate is closed");ok(events.reason.contains("SPP"),"socket failure names the SPP connection stage");}finally{link.close();}

        Socket blocking=new Socket(false,true,false);events=new Events();link=new LinkController(false,events);
        link.connect(new BluetoothDevice(blocking,blocking));ok(blocking.entered.await(1,TimeUnit.SECONDS),"blocking connect entered");link.close();
        ok(blocking.closedSignal.await(1,TimeUnit.SECONDS),"cancel closes an in-flight connect");ok(events.connected.getCount()==1&&events.ended.getCount()==1,"cancel emits no stale success or failure callback");

        events=new Events();link=new LinkController(true,events);
        try{link.connect(null);ok(events.connected.await(2,TimeUnit.SECONDS),"simulation still completes protocol initialization");}finally{link.close();}

        Socket extended=new Socket(false,false,true);events=new Events();events.expectedExtended=(1L<<35)|1;link=new LinkController(false,events);
        try{
            link.connect(new BluetoothDevice(extended,extended));ok(events.connected.await(2,TimeUnit.SECONDS),"36-key connection initializes through legacy status");
            link.control(11,0);ok(events.capability.await(2,TimeUnit.SECONDS),"capability83 arrives through real production transport");
            link.extendedKeys(events.expectedExtended);ok(events.extendedChord.await(3,TimeUnit.SECONDS),"both ends of36-key chord survive byte stream and state polling");
            ok(link.ready()&&events.ended.getCount()==1,"36-key control preserves established link");
        }finally{link.close();}

        Socket oldDevice=new Socket(false,false,true);oldDevice.unsupported36=true;events=new Events();link=new LinkController(false,events);
        try{
            link.connect(new BluetoothDevice(oldDevice,oldDevice));ok(events.connected.await(2,TimeUnit.SECONDS),"legacy-only connection initializes");
            link.control(11,0);ok(events.unsupported.await(2,TimeUnit.SECONDS),"unsupported extension is exposed without disconnect");
            link.keys(1);link.control(6,0);ok(events.legacyKey.await(3,TimeUnit.SECONDS),"legacy keys remain functional after unsupported capability reply");
            ok(link.ready()&&events.ended.getCount()==1,"unsupported36 does not terminate legacy compatibility");
        }finally{link.close();}
        System.out.println("PASS "+checks+" transport behavioral checks (host stubs; not phone Bluetooth)");
    }
}
