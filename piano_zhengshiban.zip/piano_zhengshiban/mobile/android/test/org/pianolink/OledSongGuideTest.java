package org.pianolink;

import java.util.*;
import java.lang.reflect.*;

/** Frozen song-guide wire fixtures plus the production Session stop/wait queue. */
public final class OledSongGuideTest {
    private static int checks,seq;
    private static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    private static void eq(long want,long got,String why){ok(want==got,why+": expected "+want+", got "+got);}
    private static Protocol.Frame call(MockFpga m,int command,int... data){int[] d=new int[6];System.arraycopy(data,0,d,0,data.length);return Protocol.decode(m.accept(new Protocol.Frame(seq++&255,command,d).bytes(),0));}
    private static void ack(MockFpga m,int command,int status,int... data){Protocol.Frame f=call(m,command,data);eq(0x80,f.cmd,"ACK command");eq(command,f.d[0],"ACK request");eq(status,f.d[1],"ACK status");eq(1,f.d[2],"ACK version");}
    private static int crc(int... masks){int c=0xffff;for(int mask:masks)for(int b=0;b<3;b++){c^=((mask>>>(b*8))&255)<<8;for(int k=0;k<8;k++)c=(c&0x8000)!=0?((c<<1)^0x1021)&65535:(c<<1)&65535;}return c;}
    private static void load(MockFpga m,int... masks){int c=crc(masks);ack(m,0x10,0,masks.length&255,masks.length>>>8,c&255,c>>>8,1,0);for(int i=0;i<masks.length;i++)ack(m,0x11,0,i&255,i>>>8,masks[i]&255,(masks[i]>>>8)&255,masks[i]>>>16,0);ack(m,0x12,0);}
    private static Object invoke(Object o,String name,Class<?>[] types,Object... values)throws Exception{try{return o.getClass().getMethod(name,types).invoke(o,values);}catch(NoSuchMethodException e){throw new AssertionError("missing production API "+name,e);}catch(InvocationTargetException e){if(e.getCause() instanceof IllegalArgumentException)throw (IllegalArgumentException)e.getCause();throw e;}}
    private static Object converted(SongData song)throws Exception{try{return Class.forName("org.pianolink.OledGuideSong").getMethod("from",SongData.class).invoke(null,song);}catch(ClassNotFoundException e){throw new AssertionError("18-key adaptation is missing",e);}catch(InvocationTargetException e){if(e.getCause() instanceof IllegalArgumentException)throw (IllegalArgumentException)e.getCause();throw e;}}
    private static long field(Object value,String field)throws Exception{return value.getClass().getField(field).getLong(value);}
    private static int[] steps(Object value)throws Exception{return (int[])invoke(value,"masks",new Class<?>[0]);}
    private static Object state(Session s)throws Exception{return invoke(s,"guideState",new Class<?>[0]);}
    private static void download(Session s,int... masks)throws Exception{ok((Boolean)invoke(s,"guideDownload",new Class<?>[]{int[].class},(Object)masks),"download accepted");}
    private static SongData song(long... masks){ArrayList<SongData.Event> events=new ArrayList<>();for(int i=0;i<masks.length;i++)events.add(new SongData.Event(i*100,masks[i],4));return new SongData(SongData.Format.ABSOLUTE36,events,false);}
    private static void adaptation()throws Exception{
        Object legacy=converted(new SongData(SongData.Format.LEGACY12,Arrays.asList(new SongData.Event(0,1|128|256|512,4),new SongData.Event(100,0,0)),false));
        eq(1|128|256|512,steps(legacy)[0],"legacy natural-first physical mask preserved");
        int[] naturalFirst={0,7,1,8,2,3,9,4,10,5,11,6,12,13,14,15,16,17};
        for(int i=0;i<18;i++){Object a=converted(song(1L<<(12+i),0));eq(1<<naturalFirst[i],steps(a)[0],"physical mapping semitone "+i);}
        Object folded=converted(song((1L<<0)|(1L<<12)|(1L<<30)|(1L<<35),0));
        eq(1|(1<<6)|(1<<9),steps(folded)[0],"C3/C4 duplicate merged; F#5/B5 fold down");eq(3,field(folded,"foldedNotes"),"fold count");eq(1,field(folded,"mergedNotes"),"duplicate count");
        Object dense=converted(song((1L<<12)|(1L<<13)|(1L<<14)|(1L<<15)|(1L<<16)|(1L<<17),0));
        eq((1<<1)|(1<<8)|(1<<2)|(1<<3),steps(dense)[0],"highest four physical pitches retained");eq(2,field(dense,"droppedNotes"),"simplified note count");eq(1,field(dense,"simplifiedSteps"),"simplified step count");
        eq(2,steps(converted(song(1L<<12,(1L<<12)|(1L<<14),0))).length,"only onsets form steps, sustained note is not retriggered");
        ArrayList<SongData.Event> events=new ArrayList<>();for(int i=0;i<2049;i++){events.add(new SongData.Event(i*2,1L<<12,1));events.add(new SongData.Event(i*2+1,0,0));}
        boolean rejected=false;try{converted(new SongData(SongData.Format.ABSOLUTE36,events,false));}catch(IllegalArgumentException expected){rejected=expected.getMessage().contains("2048");}ok(rejected,"2049 steps rejected with crop guidance");events.remove(events.size()-1);events.remove(events.size()-1);eq(2048,steps(converted(new SongData(SongData.Format.ABSOLUTE36,events,false))).length,"2048 allowed");
        Class<?> wire=Class.forName("org.pianolink.OledGuideProtocol");eq(0x29b1,((Integer)wire.getMethod("crc16",byte[].class).invoke(null,(Object)"123456789".getBytes("US-ASCII"))).intValue(),"CRC16 literal CCITT-FALSE fixture");
    }
    private static void device()throws Exception{
        MockFpga m=new MockFpga();Protocol.Frame cap=call(m,0x0f);eq(0x88,cap.cmd,"frozen capability response");eq(0x47,cap.d[0],"capability magic");eq(2048,cap.d[2]|cap.d[3]<<8,"capacity");eq(18,cap.d[4],"physical keys");eq(4,cap.d[5],"chord limit");
        load(m,1,1<<17);ack(m,0x13,0,1);eq(3,call(m,0x14).d[4]&3,"loaded and active reported");
        call(m,4,1);eq(0,call(m,0x14).d[0],"phone keys never advance");m.physicalKeys(1L<<12,0);eq(1,call(m,0x14).d[0],"physical hit advances immediately");m.physicalKeys(1L<<29,1);eq(1,call(m,0x14).d[0],"held transition cannot advance next target");m.physicalKeys(0,2);m.physicalKeys(1L<<29,3);eq(2,call(m,0x14).d[0],"release arms next target");eq(4,call(m,0x14).d[4]&4,"completion flag");
        ack(m,0x13,0,2);m.physicalKeys(0,4);m.physicalKeys((1L<<12)|(1L<<14),5);eq(16,call(m,0x14).d[4]&16,"wrong chord visible");m.physicalKeys(1L<<12,6);eq(0,call(m,0x14).d[0],"wrong needs all released");m.physicalKeys(0,7);m.physicalKeys(1L<<12,8);eq(1,call(m,0x14).d[0],"retry after wrong release succeeds");
        int c=crc(2);ack(m,0x10,0,1,0,c&255,c>>>8,1,0);ack(m,0x11,1,0,0,0,0,0,0);ack(m,0x11,1,0,0,31,0,0,0);ack(m,0x11,1,0,0,1,0,4,0);ack(m,0x11,1,0,0,2,0,0,1);ack(m,0x11,3,1,0,2,0,0,0);ack(m,0x12,3);eq(2,call(m,0x14).d[2],"partial upload retains old song");
        ack(m,0x11,0,0,0,2,0,0,0);ack(m,0x11,0,0,0,2,0,0,0);ack(m,0x12,0);ack(m,0x12,0);eq(1,call(m,0x14).d[2],"duplicate STEP/COMMIT idempotent");
        ack(m,0x10,0,1,0,0,0,1,0);ack(m,0x11,0,0,0,4,0,0,0);ack(m,0x12,1);eq(1,call(m,0x14).d[2],"bad CRC preserves committed song");eq(0,call(m,0x14).d[4]&8,"bad CRC clears staging/loading like HDL");ack(m,0x13,0,4);eq(0,call(m,0x14).d[4]&8,"abort clears staging");
        ack(m,0x13,0,3);ack(m,0x13,0,3);Protocol.Frame empty=call(m,0x14);eq(0,empty.d[2],"delete clears score");eq(2,empty.d[4],"delete retains GUIDE for NO SONG");
        load(m,1|2);ack(m,0x13,0,1);m.physicalKeys(0,0);m.physicalKeys(1L<<12,1);eq(0,call(m,0x14).d[0],"partial correct chord waits");m.physicalKeys((1L<<12)|(1L<<14),2);eq(1,call(m,0x14).d[0],"staggered chord completes");ack(m,0x13,0,2);eq(0,call(m,0x14).d[0],"restart held chord is disarmed");m.physicalKeys((1L<<12)|(1L<<14),3);eq(0,call(m,0x14).d[0],"preheld keys ignored");
        m.physicalKeys(0,4);m.physicalKeys(1L<<13,5);eq(16,call(m,0x14).d[4]&16,"wrong flag before exit");ack(m,0x13,0,0);eq(0,call(m,0x14).d[4]&16,"exit clears wrong flag like HDL");
        MockFpga abortedCommit=new MockFpga();load(abortedCommit,1);ack(abortedCommit,0x13,0,4);ack(abortedCommit,0x12,3);eq(1,call(abortedCommit,0x14).d[2],"ABORT clears COMMIT retry eligibility without deleting active score");
    }
    private static void queue()throws Exception{
        Session interrupted=new Session();MockFpga interruptedDevice=new MockFpga();download(interrupted,1);long cut=0;
        for(long time=0;time<2000;time+=40){Session.Send send=interrupted.tick(time);if(send==null)continue;if(send.frame.cmd==0x11){cut=time;break;}interrupted.receive(Protocol.decode(interruptedDevice.accept(send.frame.bytes(),time)));}
        interrupted.guideInterrupted();interrupted.release();Session.Send safety=interrupted.tick(cut+1);ok(safety!=null&&safety.frame.cmd==5,"disconnect must release phone keys immediately even during unacknowledged guide STEP");eq(0,field(state(interrupted),"reported"),"interrupted link cannot claim current FPGA status");
        Session fair=new Session();MockFpga fairDevice=new MockFpga();download(fair,1,2,4,8,16,32,64,128,256,512,1024,2048);fair.control(2,12);boolean served=false;int stepsBeforeControl=0;
        for(long time=0;time<1500&&!served;time+=40){Session.Send send=fair.tick(time);if(send==null)continue;if(send.frame.cmd==0x11)stepsBeforeControl++;if(send.frame.cmd==2)served=true;fair.receive(Protocol.decode(fairDevice.accept(send.frame.bytes(),time)));}
        ok(served&&stepsBeforeControl<=3,"volume control is not starved by an entire long score transaction");
        Session s=new Session();MockFpga m=new MockFpga();download(s,1,2,4);List<Protocol.Frame> guide=new ArrayList<>();boolean lost=false,retried=false,released=false;int lostSeq=-1;
        for(long now=0;now<10000;now+=20){Session.Send send=s.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;
            if(f.cmd>=15){guide.add(f);if(f.cmd==0x11&&f.d[0]==1&&!lost){m.accept(f.bytes(),now);lost=true;lostSeq=f.seq;continue;}if(f.cmd==0x11&&f.seq==lostSeq)retried=true;}
            Protocol.Frame response=Protocol.decode(m.accept(f.bytes(),now));s.receive(response);
            if(f.cmd==0x11&&!released){s.release();released=true;}
            if(field(state(s),"busy")==0&&field(state(s),"reported")!=0)break;
        }
        ok(retried,"lost STEP ACK retries same index/sequence in actual Session");Object st=state(s);eq(3,field(st,"uploaded"),"acknowledged progress");eq(3,field(st,"total"),"device-reported total");eq(0,field(st,"busy"),"transaction completes");ok(guide.get(0).cmd==15,"capability gates begin");
        download(s,8,16);boolean cancelled=false,aborted=false;for(long now=11000;now<15000;now+=20){Session.Send send=s.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;Protocol.Frame response=Protocol.decode(m.accept(f.bytes(),now));s.receive(response);if(f.cmd==0x10&&!cancelled){invoke(s,"guideCancel",new Class<?>[0]);cancelled=true;}if(f.cmd==0x13&&f.d[0]==4)aborted=true;if(aborted&&field(state(s),"busy")==0)break;}ok(aborted,"cancel sends wire ABORT");eq(3,call(m,0x14).d[2],"cancel retains old committed song");
        Session bad=new Session();download(bad,1);boolean began=false;for(long now=0;now<2000;now+=40){Session.Send send=bad.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;if(f.cmd==0x10)began=true;bad.receive(f.cmd==15?new Protocol.Frame(f.seq,0x88,new int[]{0x47,1,0,8,17,4}):Protocol.decode(m.accept(f.bytes(),now)));}ok(!began,"malformed capability cannot start upload");eq(-1,field(state(bad),"capability"),"invalid capability shown unsupported");
        Session wrong=new Session();download(wrong,1);Session.Send q=wrong.tick(0);while(q.frame.cmd!=15){wrong.receive(Protocol.decode(m.accept(q.frame.bytes(),0)));q=wrong.tick(40);}ok(!wrong.receive(new Protocol.Frame(q.frame.seq,0x89,new int[]{0,0,1,0,1,1})),"wrong reply type cannot retire capability request");
    }
    private static void fullRam()throws Exception{
        Session session=new Session();MockFpga device=new MockFpga();int[] masks=new int[2048];for(int i=0;i<masks.length;i++)masks[i]=1<<(i%18);download(session,masks);
        Set<Integer> dropped=new HashSet<>(),retried=new HashSet<>();Map<Integer,Integer> sequences=new HashMap<>();boolean highIndex=false;
        for(long now=0;now<150000;now+=20){Session.Send send=session.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;Protocol.Frame response=Protocol.decode(device.accept(f.bytes(),now));
            if(f.cmd==0x11&&f.d[1]!=0)highIndex=true;
            if((f.cmd==0x10||f.cmd==0x12)&&!dropped.contains(f.cmd)){dropped.add(f.cmd);sequences.put(f.cmd,f.seq);continue;}
            if(sequences.containsKey(f.cmd)&&f.seq==sequences.get(f.cmd))retried.add(f.cmd);
            session.receive(response);Session.GuideState st=session.guideState();if(st.busy==0&&st.reported!=0)break;
        }
        Session.GuideState st=session.guideState();eq(2048,st.uploaded,"full capacity upload acknowledged without truncation");eq(2048,st.total,"full capacity confirmed by actual89 report");eq(0,st.busy,"full capacity transfer finishes");ok(highIndex,"STEP index uses both LE bytes across255");ok(retried.contains(0x10)&&retried.contains(0x12),"lost BEGIN and COMMIT ACK retry idempotently through real queue");
        Session malformed=new Session();download(malformed,1);boolean began=false;
        for(long now=0;now<2000;now+=40){Session.Send send=malformed.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;if(f.cmd==0x10)began=true;malformed.receive(f.cmd==0x14?new Protocol.Frame(f.seq,0x89,new int[]{0,0,1,0,0,1}):Protocol.decode(device.accept(f.bytes(),now)));}
        ok(!began&&malformed.guideState().reported==0,"incoherent loaded/total status preventsBEGIN and is never displayed as actual state");
    }
    private static void cancelAfterCommit()throws Exception{
        for(int position=0;position<3;position++){Session session=new Session();MockFpga device=new MockFpga();load(device,2,4);download(session,1);boolean cancelled=false,committed=false,aborted=false;
            for(long now=0;now<5000;now+=40){Session.Send send=session.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;Protocol.Frame response=Protocol.decode(device.accept(f.bytes(),now));if(f.cmd==0x12)committed=true;if(f.cmd==0x13&&f.d[0]==4)aborted=true;
                boolean boundary=position==0&&f.cmd==0x12||position==1&&f.cmd==0x12||position==2&&committed&&f.cmd==0x14;
                if(boundary&&!cancelled&&position==0){eq(0,session.guideState().cancellable,"Cancel unavailable while COMMIT is in flight");session.guideCancel();cancelled=true;ok(!session.guideState().message.contains("上一首保留"),"cancel after COMMIT send must not promise rollback");}
                session.receive(response);
                if(boundary&&!cancelled){eq(0,session.guideState().cancellable,"Cancel unavailable after COMMIT ACK/status");session.guideCancel();cancelled=true;ok(!session.guideState().message.contains("上一首保留"),"cancel after COMMIT ACK/status must not promise rollback");}
                if(cancelled&&session.guideState().busy==0)break;
            }
            Session.GuideState state=session.guideState();ok(cancelled&&!aborted,"late cancel does not send misleading ABORT afterCOMMIT");eq(1,state.total,"late cancel confirms newly committed score");eq(0,state.busy,"late cancel completes final89/8A query");eq(0,state.cancellable,"Cancel disabled once COMMIT enqueued");ok(!state.message.contains("取消")&&!state.message.contains("上一首保留"),"late cancel ends with accurate committed result");
        }
    }
    private static void reconnectStaging()throws Exception{
        MockFpga device=new MockFpga();load(device,8,16);int c=crc(1,2,4);ack(device,0x10,0,3,0,c&255,c>>>8,1,0);ack(device,0x11,0,0,0,1,0,0,0);ack(device,0x11,0,1,0,2,0,0,0);
        Session reconnected=new Session();download(reconnected,1,2,4);boolean aborted=false,abortedBeforeBegin=false;
        for(long now=0;now<5000;now+=40){Session.Send send=reconnected.tick(now);if(send==null)continue;Protocol.Frame f=send.frame;if(f.cmd==0x13&&f.d[0]==4)aborted=true;if(f.cmd==0x10)abortedBeforeBegin=aborted;reconnected.receive(Protocol.decode(device.accept(f.bytes(),now)));if(reconnected.guideState().busy==0)break;}
        Session.GuideState state=reconnected.guideState();eq(3,state.uploaded,"one download after reconnect replaces stale same-song staging from STEP0");eq(3,state.total,"reconnected upload confirms new total");ok(abortedBeforeBegin,"reported loading staging is ABORTed before freshBEGIN");ok(state.message.contains("下载完成"),"reconnect download succeeds on first attempt");
    }
    public static void main(String[] args)throws Exception{device();adaptation();queue();fullRam();cancelAfterCommit();reconnectStaging();System.out.println("PASS "+checks+" OLED song-guide checks (production Session, simulated device; no hardware claim)");}
}
