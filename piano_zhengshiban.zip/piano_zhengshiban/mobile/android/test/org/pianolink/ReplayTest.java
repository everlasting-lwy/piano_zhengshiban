package org.pianolink;
import java.util.*;
import java.lang.reflect.*;
public final class ReplayTest {
    static int checks;
    static void ok(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    static Object call(Object object,String name,Class<?>[] types,Object...args)throws Exception{
        try{return object.getClass().getMethod(name,types).invoke(object,args);}
        catch(NoSuchMethodException e){throw new AssertionError("Playback needs an ACK-aware bounded queue: missing "+name,e);}
    }
    static boolean offer(Session s,long mask,boolean absolute)throws Exception{return (Boolean)call(s,"offerPlaybackMask",new Class<?>[]{long.class,boolean.class},mask,absolute);}
    static boolean pending(Session s)throws Exception{return (Boolean)call(s,"playbackPending",new Class<?>[0]);}
    static void ack(Session s,Session.Send send){ok(s.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{send.frame.cmd,0,1,0,0,0})),"ACK matches playback frame");}
    public static void main(String[] args)throws Exception{
        Session s=new Session();ok(offer(s,1,false)&&offer(s,0,false)&&offer(s,1,false),"repeated pitch enqueues down/up/down");
        Session.Send first=s.tick(0);ok(first.frame.cmd==4&&first.frame.mask()==1,"legacy onset uses04");
        ok(s.tick(499)==null,"wait for in-flight ACK");Session.Send retry=s.tick(500);ok(retry.frame.seq==first.frame.seq&&retry.frame.mask()==1,"retry keeps original state");
        ack(s,retry);Session.Send off=s.tick(540);ok(off.frame.mask()==0,"release edge survives500ms ACK stall");ack(s,off);
        Session.Send again=s.tick(580);ok(again.frame.mask()==1,"repeated onset follows release");ok(pending(s),"last state remains pending untilACK");ack(s,again);ok(!pending(s),"queue drained afterlastACK");
        for(int i=0;i<8;i++)ok(offer(s,i,true),"bounded queue accepts slot"+i);ok(!offer(s,9,true),"ninth queue state rejected with backpressure");
        s.release();ok(!pending(s),"release cancels every queued state");Session.Send released=s.tick(581);ok(released.frame.cmd==5,"release bypasses rate limit andoldpending");ack(s,released);
        ok(offer(s,1L<<35,true),"absolute highest key enqueues");Session.Send ext=s.tick(621);ok(ext.frame.cmd==9&&ext.frame.extendedMask()==(1L<<35),"absolute36 uses09 withoutinttruncation");ack(s,ext);
        s.release();Session.Send release2=s.tick(622);ack(s,release2);s.setMask(1);s.setMask(2);Session.Send live=s.tick(662);ok(live.frame.cmd==4&&live.frame.mask()==2,"livekeys still coalesce latest state");
        boolean bad=false;try{offer(s,1L<<36,true);}catch(InvocationTargetException e){bad=e.getCause() instanceof IllegalArgumentException;}ok(bad,"out-of-range absolute snapshot refused");
        Session modes=new Session();MockFpga device=new MockFpga();offer(modes,1L<<35,true);Session.Send absolute=modes.tick(0);modes.receive(Protocol.decode(device.accept(absolute.frame.bytes(),0)));while(device.pollEvent()!=null){}
        modes.release();Session.Send onlyRelease=modes.tick(1);modes.receive(Protocol.decode(device.accept(onlyRelease.frame.bytes(),1)));while(device.pollEvent()!=null){}
        device.physicalKeys(1L<<12,20);ok(Protocol.decode(device.pollEvent()).cmd==0x84,"release alone preserves36mode on real protocol");
        call(modes,"resetLegacy",new Class<?>[0]);Session.Send legacyReset=modes.tick(41);ok(legacyReset.frame.cmd==4&&legacyReset.frame.mask()==0,"return to legacy recording sends explicit04 snapshot");device.accept(legacyReset.frame.bytes(),41);while(device.pollEvent()!=null){}
        device.physicalKeys(1L<<14,100);Protocol.Frame physical=Protocol.decode(device.pollEvent());Recording capture=new Recording();capture.start();capture.accept(physical);ok(physical.cmd==0x82&&capture.count()==1,"physical keys record after36song without touching phone keys");
        Class<?> replay;try{replay=Class.forName("org.pianolink.SongReplay");}catch(ClassNotFoundException e){throw new AssertionError("SongReplay timeline is missing",e);}
        Class<?> sinkType=Class.forName("org.pianolink.SongReplay$Sink");final ArrayList<Long> masks=new ArrayList<>();final boolean[] busy={false},allow={true};final int[] releases={0};
        Object sink=Proxy.newProxyInstance(sinkType.getClassLoader(),new Class<?>[]{sinkType},(p,m,a)->{if(m.getName().equals("offer")){if(!allow[0])return false;masks.add((Long)a[0]);busy[0]=true;return true;}if(m.getName().equals("pending"))return busy[0];if(m.getName().equals("release")){releases[0]++;busy[0]=false;return null;}return null;});
        SongData song=new SongData(SongData.Format.ABSOLUTE36,Arrays.asList(new SongData.Event(0,1L<<35,1),new SongData.Event(100,0,0)),false);
        Object timeline=replay.getConstructor(SongData.class,sinkType).newInstance(song,sink);call(timeline,"start",new Class<?>[]{long.class},1000L);
        ok((Boolean)call(timeline,"tick",new Class<?>[]{long.class},1000L),"timeline begins active");ok(masks.size()==1&&masks.get(0)==(1L<<35),"timeline retains36bitmask");
        call(timeline,"tick",new Class<?>[]{long.class},1099L);ok(masks.size()==1,"futureevent waits untiltime");
        allow[0]=false;call(timeline,"tick",new Class<?>[]{long.class},1100L);ok(masks.size()==1,"backpressure doesnotdropstate");
        allow[0]=true;call(timeline,"tick",new Class<?>[]{long.class},1200L);ok(masks.size()==2&&masks.get(1)==0,"late release is still enqueued");
        ok((Boolean)call(timeline,"tick",new Class<?>[]{long.class},2000L),"timeline waits forlastwireACK");busy[0]=false;ok(!(Boolean)call(timeline,"tick",new Class<?>[]{long.class},2001L),"timeline completes afterACK drain");
        ok(releases[0]>=2,"start andcompletion safelyrelease");call(timeline,"stop",new Class<?>[0]);int count=masks.size();call(timeline,"tick",new Class<?>[]{long.class},3000L);ok(masks.size()==count,"stoppedtimeline cannotresurrectnotes");
        System.out.println("PASS "+checks+" queued replay behavioral checks");
    }
}
