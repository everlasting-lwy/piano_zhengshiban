package org.pianolink;

import java.io.*;
import java.util.*;

public final class AudioTest {
    private static int checks;
    private static void check(boolean yes, String message) {
        checks++;
        if (!yes) throw new AssertionError(message);
    }
    private static float[] resample(float[] input, int rate, int chunk) throws Exception {
        final ArrayList<Float> result = new ArrayList<>();
        AudioDsp.Resampler resampler = new AudioDsp.Resampler(rate, 22050);
        AudioDsp.SampleSink sink = value -> result.add(value);
        for (int at=0; at<input.length; at+=chunk)
            resampler.accept(input, at, Math.min(chunk,input.length-at), sink);
        resampler.finish(sink);
        float[] values = new float[result.size()];
        for(int i=0;i<values.length;i++) values[i]=result.get(i);
        return values;
    }
    // An off-by-one output position or discarded chunk carry changes pitch/length here.
    private static void resamplingSurvivesOddChunks() throws Exception {
        float[] source = new float[4801];
        for(int i=0;i<source.length;i++) source[i]=(float)Math.sin(2*Math.PI*440*i/48000);
        float[] single=resample(source,48000,source.length), chunked=resample(source,48000,7);
        check(single.length==2206,"resampler must retain the fractional last output sample");
        check(Arrays.equals(single,chunked),"resampling must not depend on decoder chunk boundaries");
        double error=0;
        for(int i=32;i<single.length-32;i++) error+=Math.abs(single[i]-Math.sin(2*Math.PI*440*i/22050));
        check(error/(single.length-64)<0.002,"resampled 440 Hz should preserve frequency and amplitude");
        float[] high=new float[4800];
        for(int i=0;i<high.length;i++) high[i]=(float)Math.sin(2*Math.PI*18000*i/48000);
        float[] filtered=resample(high,48000,13); double energy=0;
        for(int i=32;i<filtered.length-32;i++) energy+=filtered[i]*filtered[i];
        check(Math.sqrt(energy/(filtered.length-64))<0.03,"downsampling must suppress above-Nyquist aliases");
        float[] up=resample(new float[]{0,0,0,0},8000,1);
        check(up.length==12,"upsampling must drain its final fractional frame");
    }
    private static void le16(DataOutputStream out,int value) throws IOException {
        out.writeByte(value);out.writeByte(value>>>8);
    }
    private static void le32(DataOutputStream out,long value) throws IOException {
        le16(out,(int)value);le16(out,(int)(value>>>16));
    }
    private static File wav(int encoding,int channels,int bits,int rate,byte[] pcm) throws Exception {
        File path=File.createTempFile("pianolink-audio-test-", ".wav");
        try(DataOutputStream out=new DataOutputStream(new FileOutputStream(path))) {
            out.writeBytes("RIFF");le32(out,48+pcm.length+(pcm.length&1));out.writeBytes("WAVE");
            out.writeBytes("JUNK");le32(out,3);out.write(new byte[]{5,6,7,0});
            out.writeBytes("fmt ");le32(out,16);le16(out,encoding);le16(out,channels);le32(out,rate);
            le32(out,(long)rate*channels*bits/8);le16(out,channels*bits/8);le16(out,bits);
            out.writeBytes("data");le32(out,pcm.length);out.write(pcm);if((pcm.length&1)!=0)out.writeByte(0);
        }
        return path;
    }
    // Incorrect stereo averaging, RIFF padding, signedness or cancellation leaks break these fixtures.
    private static void wavDecodesStereoAndRejectsDamage() throws Exception {
        byte[] pcm=new byte[17002*4];
        for(int i=0;i<17002;i++) { pcm[i*4]=0;pcm[i*4+1]=64;pcm[i*4+2]=0;pcm[i*4+3]=0; }
        File source=wav(1,2,16,44100,pcm);
        try {
            final ArrayList<Float> mono=new ArrayList<>();
            try(PcmWavReader reader=new PcmWavReader(source)) {
                check(reader.sampleRate==44100&&reader.channels==2&&reader.frameCount==17002,"WAV duration must count frames, not stereo samples");
                reader.decode((values,n)->{for(int i=0;i<n;i++)mono.add(values[i]);},()->false);
            }
            check(mono.size()==17002&&Math.abs(mono.get(17001)-0.25)<0.00001,"stereo PCM must downmix across chunk boundaries");
            final int[] blocks={0}; boolean cancelled=false;
            try(PcmWavReader reader=new PcmWavReader(source)) {
                reader.decode((values,n)->blocks[0]++,()->blocks[0]>0);
            } catch(AudioDsp.CancelledException expected) {cancelled=true;}
            check(cancelled&&blocks[0]==1,"cancel must stop WAV decoding before the next block");
            try(RandomAccessFile damaged=new RandomAccessFile(source,"rw")){damaged.setLength(source.length()-7);}
            boolean rejected=false;try(PcmWavReader ignored=new PcmWavReader(source)){}catch(IOException expected){rejected=true;}
            check(rejected,"truncated PCM must fail instead of returning a partial song");
        } finally { check(source.delete(),"test fixture must be closed after success/cancel/failure"); }
        File unsigned=wav(1,1,8,8000,new byte[]{0,(byte)128,(byte)255});
        try(PcmWavReader reader=new PcmWavReader(unsigned)) {
            final ArrayList<Float> values=new ArrayList<>();reader.decode((v,n)->{for(int i=0;i<n;i++)values.add(v[i]);},()->false);
            check(values.size()==3&&values.get(0)==-1&&values.get(1)==0&&values.get(2)>0.99,"8-bit WAV is unsigned and odd data chunks have a pad byte");
        } finally {unsigned.delete();}
        File compressed=wav(6,1,16,22050,new byte[100]);
        try {
            boolean rejected=false;try(PcmWavReader ignored=new PcmWavReader(compressed)){}catch(IOException expected){rejected=true;}
            check(rejected,"unsupported WAV encoding must produce an actionable failure");
        } finally {compressed.delete();}
    }
    private static PitchPostprocessor.Result predictions(boolean poly,int frames,int[][] pitches,int[][] onsets) {
        PitchPostprocessor processor=new PitchPostprocessor(poly);
        for(int t=0;t<frames;t++) {
            float[] note=new float[88],onset=new float[88];
            for(int p:pitches[t])note[p-21]=0.9f;
            for(int p:onsets[t])onset[p-21]=0.95f;
            processor.acceptFrame(t*256000.0/22050,note,onset);
        }
        return processor.finish(frames*256000.0/22050);
    }
    private static int[][] emptyFrames(int length) {int[][] rows=new int[length][];for(int i=0;i<length;i++)rows[i]=new int[0];return rows;}
    private static int attackCount(SongData song,int midi) {
        if(song==null)return 0;int attacks=0;long previous=0,bit=1L<<(midi-48);
        for(SongData.Event event:song.events){if((event.mask&bit)!=0&&(previous&bit)==0)attacks++;previous=event.mask;}
        return attacks;
    }
    // Starting again from the same mask must not swallow the second attack.
    private static void pitchOnsetsSustainAndRelease() {
        int[][] notes=emptyFrames(70),onsets=emptyFrames(70);
        for(int i=4;i<60;i++)notes[i]=new int[]{60};onsets[4]=new int[]{60};onsets[34]=new int[]{60};
        PitchPostprocessor.Result result=predictions(false,70,notes,onsets);
        check(result.detectedNotes==2,"separate onset peaks must split one sustained pitch");
        check(attackCount(result.song,60)==2,"same-pitch repeat must survive CSV adaptation");
        check(result.song.events.get(0).ms==0&&result.song.events.get(0).mask==0,"initial audio silence must survive replay's first-event time origin");
        check(result.song.events.get(result.song.events.size()-1).mask==0,"conversion must release the final note");
        long previous=-50;
        for(SongData.Event event:result.song.events){check(event.ms-previous>=50,"converted states must be at least 50 ms apart");previous=event.ms;}
        PitchPostprocessor.Result silence=predictions(true,30,emptyFrames(30),emptyFrames(30));
        check(silence.song==null&&silence.detectedNotes==0,"silence must not fabricate a song");
        notes=emptyFrames(30);onsets=emptyFrames(30);
        for(int i=3;i<24;i++)notes[i]=new int[]{47,48,83,84};onsets[3]=new int[]{47,48,83,84};
        result=predictions(true,30,notes,onsets);
        check(result.outOfRange==2&&result.detectedNotes==4,"out-of-range notes must be counted individually");
        check(attackCount(result.song,48)==1&&attackCount(result.song,83)==1,"C3 and B5 must map to absolute bits 0 and 35");
        notes=emptyFrames(30);onsets=emptyFrames(30);
        for(int i=3;i<25;i++)notes[i]=new int[]{60};onsets[3]=new int[]{60};onsets[8]=new int[]{60};
        result=predictions(false,30,notes,onsets);
        check(result.tooFast>0,"repeat without room for a 50 ms release must be reported");
    }
    private static void polyphonyKeepsStrongest() {
        PitchPostprocessor processor=new PitchPostprocessor(true);
        for(int t=0;t<30;t++) {
            float[] notes=new float[88],onsets=new float[88];
            if(t>=3&&t<24)for(int p=60;p<=64;p++){notes[p-21]=0.5f+0.1f*(p-60);if(t==3)onsets[p-21]=0.9f;}
            processor.acceptFrame(t*256000.0/22050,notes,onsets);
        }
        PitchPostprocessor.Result result=processor.finish(350);
        check(result.polyphonyReduced==1,"five-note chord must report one reduced note");
        check(attackCount(result.song,60)==0&&attackCount(result.song,64)==1,"chord adaptation must retain the strongest predictions");
        for(SongData.Event event:result.song.events)check(Long.bitCount(event.mask)<=4,"polyphony must never exceed four");
    }
    private static void csvVoicesPreservesBusyBitmap() {
        int[][] notes=emptyFrames(30),onsets=emptyFrames(30);
        for(int i=3;i<24;i++)notes[i]=new int[]{60,64,67,71};onsets[3]=new int[]{60,64,67,71};
        PitchPostprocessor.Result result=predictions(true,30,notes,onsets);
        boolean chord=false;
        for(SongData.Event event:result.song.events)if(Long.bitCount(event.mask)==4){check(event.voices==15,"four active voices must use busy bitmap 0b1111");chord=true;}
        check(chord,"four-note fixture must contain an audible chord");
        notes=emptyFrames(30);onsets=emptyFrames(30);
        for(int i=3;i<24;i++)notes[i]=new int[]{60,67};onsets[3]=new int[]{60,67};
        result=predictions(true,30,notes,onsets);chord=false;
        for(SongData.Event event:result.song.events) {
            if(Long.bitCount(event.mask)==2){check(event.voices==3,"two active voices must use busy bitmap 0b0011");chord=true;}
            if(event.mask==0)check(event.voices==0,"released keys must clear all voice busy bits");
        }
        check(chord,"two-note fixture must contain an audible chord");
    }
    private static void overlappingWindowsUseSourceClock() throws Exception {
        check(Math.abs(BasicPitchWindowing.timeMs(0,15))<0.001,"initial 3840-sample model padding must not delay the song");
        check(Math.abs(BasicPitchWindowing.timeMs(1,15)-1640.090702947846)<0.001,"second window must use its actual source sample position");
        check(Math.abs(BasicPitchWindowing.timeMs(300,15)-492027.2108843537)<0.001,"overlap seams must not accumulate timestamp drift");
        File file=File.createTempFile("pianolink-window-test-", ".pcm");
        try(RandomAccessFile pcm=new RandomAccessFile(file,"rw")) {
            for(int i=0;i<50000;i++){int bits=Float.floatToIntBits(i);pcm.writeByte(bits);pcm.writeByte(bits>>>8);pcm.writeByte(bits>>>16);pcm.writeByte(bits>>>24);}
            float[] window=new float[43844];BasicPitchWindowing.readWindow(pcm,window,0,50000);
            check(window[3839]==0&&window[3840]==0&&window[3841]==1,"first inference input needs leading zero padding");
            BasicPitchWindowing.readWindow(pcm,window,1,50000);
            check(window[0]==32324&&window[17675]==49999&&window[17676]==0,"overlapping input must use source samples and zero-pad only EOF");
        }finally{file.delete();}
        PitchPostprocessor processor=new PitchPostprocessor(false);
        float[][] note=new float[172][88],onset=new float[172][88];
        for(int i=0;i<172;i++){note[i][60-21]=0.9f;if(i==15)onset[i][60-21]=0.9f;}
        final int[] calls={0};boolean cancelled=false;
        try {BasicPitchWindowing.acceptWindow(processor,0,note,onset,50000,()->++calls[0]>5);}
        catch(AudioDsp.CancelledException expected){cancelled=true;}
        check(cancelled,"cancellation must interrupt output processing before saving");
    }
    private static void codecPcmCarriesPartialFrames() throws Exception {
        byte[] stereo={0,64,0,0,0,(byte)128,0,0,(byte)255,127,(byte)255,127};
        final ArrayList<Float> values=new ArrayList<>();PcmByteDecoder decoder=new PcmByteDecoder(2,2);
        for(int at=0;at<stereo.length;at+=3)decoder.accept(stereo,at,Math.min(3,stereo.length-at),(v,n)->{for(int i=0;i<n;i++)values.add(v[i]);});
        decoder.finish();
        check(values.size()==3&&values.get(0)==0.25f&&values.get(1)==-0.5f&&values.get(2)>0.999,"odd codec buffers must retain partial stereo frames");
        decoder=new PcmByteDecoder(2,2);decoder.accept(new byte[3],0,3,(v,n)->{});
        boolean rejected=false;try{decoder.finish();}catch(IOException expected){rejected=true;}
        check(rejected,"truncated final codec PCM must not silently lose a partial frame");
        byte[] floats={0,0,(byte)128,63,0,0,0,(byte)191};values.clear();
        decoder=new PcmByteDecoder(2,4);decoder.accept(floats,0,8,(v,n)->{for(int i=0;i<n;i++)values.add(v[i]);});decoder.finish();
        check(values.size()==1&&values.get(0)==0.25f,"float codec PCM must downmix independently of 16-bit PCM");
    }
    private static void nativeCancelWatcherStopsBeforeRelease() throws Exception {
        final java.util.concurrent.atomic.AtomicBoolean cancelled=new java.util.concurrent.atomic.AtomicBoolean();
        final java.util.concurrent.CountDownLatch notified=new java.util.concurrent.CountDownLatch(1);
        try(AudioDsp.CancellationMonitor monitor=new AudioDsp.CancellationMonitor(cancelled::get,notified::countDown)) {
            cancelled.set(true);
            check(notified.await(2,java.util.concurrent.TimeUnit.SECONDS),"native inference cancellation must be delivered while inference is busy");
        }
        final java.util.concurrent.atomic.AtomicInteger late=new java.util.concurrent.atomic.AtomicInteger();cancelled.set(false);
        AudioDsp.CancellationMonitor monitor=new AudioDsp.CancellationMonitor(cancelled::get,late::incrementAndGet);
        monitor.close();cancelled.set(true);Thread.sleep(40);
        check(late.get()==0,"joined watcher must never touch a released interpreter");
    }
    private static void pcmSpoolHandlesRateChangeAndCancel() throws Exception {
        File file=File.createTempFile("pianolink-pcm-spool-", ".pcm");
        try {
            AudioPcmSink sink=new AudioPcmSink(file,()->false);
            try {
                sink.setSampleRate(44100);sink.samples(new float[4410],4410);
                sink.setSampleRate(48000);sink.samples(new float[4800],4800);
            }finally{sink.close();}
            check(sink.sampleCount()==4410&&file.length()==17640,"sample-rate changes must drain each segment and preserve elapsed audio time");
            boolean cancelled=false;
            try(AudioPcmSink cancelledSink=new AudioPcmSink(file,()->true)) {
                cancelledSink.setSampleRate(44100);cancelledSink.samples(new float[50],50);
            }catch(AudioDsp.CancelledException expected){cancelled=true;}
            check(cancelled,"PCM conversion cancellation must propagate to job ownership");
        }finally{check(file.delete(),"PCM spool must close after cancellation");}
    }
    private static void overlappingWindowCropPreservesOneContinuousClock() throws Exception {
        PitchPostprocessor processor=new PitchPostprocessor(false);long samples=70000;
        for(int w=0;w<BasicPitchWindowing.windowCount(samples);w++) {
            float[][] note=new float[172][88],onset=new float[172][88];
            // Deliberately wrong predictions in the overlap margins must be discarded.
            for(int t=0;t<15;t++){note[t][80-21]=0.95f;onset[t][80-21]=0.95f;}
            for(int t=157;t<172;t++){note[t][80-21]=0.95f;onset[t][80-21]=0.95f;}
            if(w==0){for(int t=145;t<157;t++)note[t][60-21]=0.9f;onset[145][60-21]=0.95f;}
            if(w==1){for(int t=15;t<60;t++)note[t][60-21]=0.9f;onset[35][60-21]=0.95f;}
            BasicPitchWindowing.acceptWindow(processor,w,note,onset,samples,()->false);
        }
        PitchPostprocessor.Result result=processor.finish(samples*1000.0/22050);
        check(result.detectedNotes==2,"overlap margins must not create phantom notes or break a held pitch at a seam");
        check(Math.abs(result.notes.get(0).startMs-1509.297052154195)<0.001,"first onset uses the retained frame's source position");
        check(Math.abs(result.notes.get(1).startMs-1872.2902494331066)<0.001,"repeat after a seam must not inherit accumulated output-frame drift");
        check(attackCount(result.song,60)==2,"both seam-spanning repeated attacks must be playable");
    }
    private static void wavLimitsAndWidePcm() throws Exception {
        File longFile=wav(1,1,16,8000,new byte[0]);
        try {
            try(RandomAccessFile file=new RandomAccessFile(longFile,"rw")) {
                long bytes=9600002;file.setLength(56+bytes);file.seek(4);
                for(int i=0;i<4;i++)file.writeByte((int)((48+bytes)>>(8*i)));file.seek(52);
                for(int i=0;i<4;i++)file.writeByte((int)(bytes>>(8*i)));
            }
            boolean rejected=false;try(PcmWavReader ignored=new PcmWavReader(longFile)){}catch(IOException expected){rejected=true;}
            check(rejected,"601-second-equivalent WAV frames must be rejected before decoding");
            try(RandomAccessFile file=new RandomAccessFile(longFile,"rw")){file.setLength(100L*1024*1024+1);}
            rejected=false;try(PcmWavReader ignored=new PcmWavReader(longFile)){}catch(IOException expected){rejected=true;}
            check(rejected,"oversize audio must be rejected before allocating PCM");
        }finally{longFile.delete();}
        File pcm24=wav(1,1,24,22050,new byte[]{0,0,64,0,0,(byte)128});
        try(PcmWavReader reader=new PcmWavReader(pcm24)) {
            final ArrayList<Float> values=new ArrayList<>();reader.decode((v,n)->{for(int i=0;i<n;i++)values.add(v[i]);},()->false);
            check(values.size()==2&&values.get(0)==0.5f&&values.get(1)==-1,"24-bit PCM needs sign extension before normalization");
        }finally{pcm24.delete();}
        File floatWav=wav(3,1,32,22050,new byte[]{0,0,(byte)128,63,0,0,0,(byte)191});
        try(PcmWavReader reader=new PcmWavReader(floatWav)) {
            final ArrayList<Float> values=new ArrayList<>();reader.decode((v,n)->{for(int i=0;i<n;i++)values.add(v[i]);},()->false);
            check(values.size()==2&&values.get(0)==1&&values.get(1)==-0.5f,"IEEE-float WAV must not be interpreted as signed int PCM");
        }finally{floatWav.delete();}
    }
    public static void main(String[] args) throws Exception {
        resamplingSurvivesOddChunks();
        wavDecodesStereoAndRejectsDamage();
        pitchOnsetsSustainAndRelease();
        polyphonyKeepsStrongest();
        csvVoicesPreservesBusyBitmap();
        overlappingWindowsUseSourceClock();
        codecPcmCarriesPartialFrames();
        nativeCancelWatcherStopsBeforeRelease();
        pcmSpoolHandlesRateChangeAndCancel();
        overlappingWindowCropPreservesOneContinuousClock();
        wavLimitsAndWidePcm();
        System.out.println("Audio tests: "+checks+" passed");
    }
}
