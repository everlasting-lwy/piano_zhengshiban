package org.pianolink;

import android.app.Activity;
import android.view.View;
import android.widget.*;
import java.lang.reflect.Field;
import java.util.*;

/** Exercises the real guide queue and UI; only Android widgets/radio are host boundaries. */
public final class OledGuideIdlePollTest {
    static int checks, failures;
    interface Case {void run() throws Exception;}
    static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    static void run(String name,Case test){try{test.run();System.out.println("PASS "+name);}catch(Exception|AssertionError error){failures++;System.out.println("FAIL "+name+": "+error.getMessage());}}
    static final class Rig {
        final Session session=new Session();final MockFpga device=new MockFpga();long now;
        Protocol.Frame next(){for(int i=0;i<100;i++){now+=40;Session.Send send=session.tick(now);if(send==null)continue;if(send.frame.cmd>=15)return send.frame;reply(send.frame);}throw new AssertionError("guide request did not arrive");}
        void reply(Protocol.Frame request){ok(session.receive(Protocol.decode(device.accept(request.bytes(),now))),"matching device response accepted");}
        void finish(){for(int i=0;i<100;i++){Protocol.Frame f=next();reply(f);if(f.cmd==0x15)return;}throw new AssertionError("guide flow did not finish");}
        Rig(){session.guideRefresh();finish();}
    }
    static void silentPoll(){
        Rig r=new Rig();Session.GuideState before=r.session.guideState();r.session.guideRefresh();Session.GuideState during=r.session.guideState();
        ok(during.busy==0,"read-only refresh must not disable guide controls");ok(during.message.equals(before.message),"poll must preserve the stable message");ok(during.revision==before.revision,"starting an idle poll must not republish unchanged UI");
        Protocol.Frame status=r.next();ok(status.cmd==0x14,"known capability is reused for recurring status polls");r.reply(status);Protocol.Frame keys=r.next();ok(keys.cmd==0x15,"poll reads actual keys after status");r.reply(keys);
        Session.GuideState after=r.session.guideState();ok(after.revision==before.revision&&after.message.equals(before.message),"unchanged poll must not republish or replace stable text");
    }
    static void coherentReport(){
        Rig r=new Rig();r.session.guideRefresh();Protocol.Frame status=r.next();if(status.cmd==15){r.reply(status);status=r.next();}
        ok(r.session.receive(new Protocol.Frame(status.seq,0x89,new int[]{0,0,1,0,3,1})),"new valid status accepted");
        Session.GuideState halfway=r.session.guideState();ok(halfway.total==0&&halfway.target==0,"status must wait for its keys report before publication");
        Protocol.Frame keys=r.next();ok(r.session.receive(new Protocol.Frame(keys.seq,0x8a,new int[]{1,0,0,2,0,0})),"new valid keys accepted");
        Session.GuideState after=r.session.guideState();ok(after.total==1&&after.flags==3&&after.target==1&&after.physical==2,"status and keys publish together");ok(after.revision>halfway.revision,"changed actual state must still notify the UI");
    }
    static void queuedActionKeepsPending(){
        Rig r=new Rig();r.session.guideRefresh();Protocol.Frame pending=r.next();
        ok(r.session.guideAction(1),"tap during read-only poll must be accepted");ok(r.session.guideState().busy==1,"accepted action protects the queued mutation");
        ok(!r.session.receive(new Protocol.Frame((pending.seq+1)&255,0x89,new int[]{0,0,0,0,0,1})),"unmatched reply cannot retire the in-flight poll");
        Session.Send early=r.session.tick(r.now+100);ok(early==null,"queued action cannot replace unacknowledged poll");Session.Send retry=r.session.tick(r.now+500);r.now+=500;
        ok(retry!=null&&retry.frame.seq==pending.seq&&retry.frame.cmd==pending.cmd,"poll retry preserves its original sequence and command");r.reply(pending);
        Protocol.Frame keys=r.next();ok(keys.cmd==0x15,"old poll finishes before mutation begins");r.reply(keys);
        List<Integer> controls=new ArrayList<Integer>();for(int i=0;i<10;i++){Protocol.Frame f=r.next();if(f.cmd==0x13)controls.add(f.d[0]);r.reply(f);if(f.cmd==0x15)break;}
        ok(controls.equals(Arrays.asList(1)),"accepted enter tap executes once after polling");ok(r.session.guideState().busy==0,"queued action completes");
    }
    static void coalesceAndCancelQueuedDownload(){
        Rig r=new Rig();r.session.guideRefresh();Protocol.Frame pending=r.next();ok(r.session.guideAction(1),"first pending action accepted");ok(r.session.guideAction(0),"latest pending action coalesces safely");r.reply(pending);r.finish();
        List<Integer> controls=new ArrayList<Integer>();for(int i=0;i<10;i++){Protocol.Frame f=r.next();if(f.cmd==0x13)controls.add(f.d[0]);r.reply(f);if(f.cmd==0x15)break;}ok(controls.equals(Arrays.asList(0)),"latest intent executes without stale enter");
        r.session.guideRefresh();pending=r.next();ok(r.session.guideDownload(new int[]{1,2}),"download queues behind read-only poll");ok(r.session.guideState().cancellable==1,"queued download can be cancelled before BEGIN");r.session.guideCancel();ok(r.session.guideState().busy==0,"cancelling queued download leaves only read-only polling");r.reply(pending);r.finish();ok(r.session.guideState().total==0,"cancelled queued download never replaces RAM score");
    }
    static void queuedDownloadExecutesAndInterruptionDropsIntent(){
        Rig r=new Rig();r.session.guideRefresh();Protocol.Frame pending=r.next();int[] masks={1,2};ok(r.session.guideDownload(masks),"download intent accepted during poll");masks[0]=4;r.reply(pending);r.finish();
        ok(!r.session.guideAction(3),"real upload remains protected from other actions");r.finish();ok(r.session.guideState().total==2&&r.session.guideState().uploaded==2,"deferred download reaches COMMIT and confirmed status");
        ok(r.session.guideAction(1),"completed queued score can enter GUIDE");r.finish();ok(r.session.guideState().target==1,"queued payload is copied before caller mutation");
        r.session.guideRefresh();pending=r.next();ok(r.session.guideAction(3),"delete can queue for next poll");r.session.guideInterrupted();r.session.release();Session.Send release=r.session.tick(r.now+1);ok(release!=null&&release.frame.cmd==5,"disconnect drops queued intent and releases keys immediately");ok(r.session.guideState().reported==0&&r.session.guideState().busy==0,"interruption invalidates report and clears queued mutation");
    }
    static void malformedPollDropsQueuedIntent(){
        Rig r=new Rig();r.session.guideRefresh();Protocol.Frame pending=r.next();ok(r.session.guideDownload(new int[]{1,2}),"download queues pending validation");r.reply(pending);Protocol.Frame keys=r.next();
        ok(r.session.receive(new Protocol.Frame(keys.seq,0x8a,new int[]{0,0,4,0,0,0})),"malformed keys report consumes its matched response");ok(r.session.guideState().reported==0&&r.session.guideState().busy==0,"invalid poll clears queued mutation and invalidates the report");
        r.session.guideRefresh();r.finish();ok(r.session.guideState().total==0&&r.session.guideState().uploaded==0,"later successful polling cannot resurrect a discarded download");
    }
    static Object field(Object object,String name)throws Exception{Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
    static final class Host implements OledGuideUi.Host {
        final Session session;int accepted,rejected;Host(Session session){this.session=session;}
        public SongData selected(){return null;}public String name(){return "test";}public boolean download(int[] masks){return session.guideDownload(masks);}public boolean action(int value){boolean yes=session.guideAction(value);if(yes)accepted++;else rejected++;return yes;}public void cancel(){session.guideCancel();}public void refresh(){session.guideRefresh();}public void message(String text){}
    }
    static void uiRemainsClickable()throws Exception{
        Rig r=new Rig();Host host=new Host(r.session);OledGuideUi ui=new OledGuideUi(new Activity(),new LinearLayout(new Activity()),host);
        try{ui.connection(true,false);ui.snapshot(r.session.guideState());r.session.guideRefresh();ui.snapshot(r.session.guideState());
            for(String name:new String[]{"download","refresh","enter","restart","exit","delete"})ok(((View)field(ui,name)).isEnabled(),name+" remains enabled during automatic status query");
            ((View)field(ui,"enter")).performClick();ok(host.accepted==1&&host.rejected==0,"button tap during poll reaches the accepted Session action");ui.snapshot(r.session.guideState());ok(!((View)field(ui,"delete")).isEnabled(),"queued real action protects UI until completion");
        }finally{ui.close();}
    }
    static void unchangedUiDoesNotRewriteText()throws Exception{
        Rig r=new Rig();OledGuideUi ui=new OledGuideUi(new Activity(),new LinearLayout(new Activity()),new Host(r.session));
        try{ui.connection(true,false);ui.snapshot(r.session.guideState());TextView status=(TextView)field(ui,"status");int writes=status.textWrites;ui.snapshot(r.session.guideState());ok(status.textWrites==writes,"identical snapshot must not call TextView.setText again");}finally{ui.close();}
    }
    public static void main(String[] args){run("silent read-only polling",()->silentPoll());run("coherent status/keys publication",()->coherentReport());run("queued action preserves stop/wait sequence",()->queuedActionKeepsPending());run("coalescing and queued-download cancel",()->coalesceAndCancelQueuedDownload());run("queued upload and interruption",()->queuedDownloadExecutesAndInterruptionDropsIntent());run("invalid polling discards queued mutation",()->malformedPollDropsQueuedIntent());run("UI accepts taps throughout idle polling",()->uiRemainsClickable());run("UI skips identical text",()->unchangedUiDoesNotRewriteText());if(failures!=0)throw new AssertionError(failures+" failed regression scenarios");System.out.println("PASS "+checks+" idle-poll Session/UI checks");}
}
