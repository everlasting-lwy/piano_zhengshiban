package org.pianolink;

import android.bluetooth.*;
import android.os.Handler;
import java.io.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/** Real service-owned session + LinkController; only the external Bluetooth radio is replaced. */
public final class LifecycleTest {
    private static int checks;
    private static void ok(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void until(BooleanSupplier condition,String message)throws Exception{
        long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(4);
        while(!condition.getAsBoolean()&&System.nanoTime()<end)Thread.sleep(10);
        ok(condition.getAsBoolean(),message);
    }
    private static Object owner()throws Exception{
        try{return Class.forName("org.pianolink.LinkSession").getConstructor().newInstance();}
        catch(ClassNotFoundException e){throw new AssertionError("Activity-independent LinkSession ownership is missing: picker lifecycle cannot retain a transport",e);}
    }
    private static Object call(Object owner,String name,Class<?>[] types,Object... args)throws Exception{
        return owner.getClass().getMethod(name,types).invoke(owner,args);
    }
    private static void attach(Object s,Events e)throws Exception{call(s,"attach",new Class<?>[]{LinkController.Listener.class},e);}
    private static void detach(Object s,Events e)throws Exception{call(s,"detach",new Class<?>[]{LinkController.Listener.class},e);}
    private static void connect(Object s,boolean mock,BluetoothDevice d)throws Exception{call(s,"connect",new Class<?>[]{boolean.class,BluetoothDevice.class,boolean.class},mock,d,false);}
    private static void invoke(Object s,String method)throws Exception{call(s,method,new Class<?>[0]);}
    private static void keys(Object s,int mask)throws Exception{call(s,"keys",new Class<?>[]{int.class},mask);}
    private static void close(Object s)throws Exception{call(s,"disconnect",new Class<?>[]{String.class},"explicit disconnect");}
    private static final class Events implements LinkController.Listener{
        volatile int connected,status,frames,ended,eventFrames,capabilities;volatile long extended;volatile int mask,volume;volatile String message="";
        public void connected(boolean simulated){connected++;}
        public void frame(Protocol.Frame f){frames++;if(f.cmd==0x81){status++;mask=f.d[4]|((f.d[5]&15)<<8);volume=f.d[1];}if(f.cmd==0x82){eventFrames++;mask=f.mask();}if(f.cmd==0x83&&f.isExtendedState())capabilities++;if(f.isExtendedState())extended=f.extendedMask();}
        public void message(String text){message=text;}
        public void ended(String text){ended++;}
    }
    private static final class Socket extends BluetoothSocket{
        final PipedInputStream input=new PipedInputStream(4096);final PipedOutputStream incoming=new PipedOutputStream(input);
        final Protocol.Decoder decoder=new Protocol.Decoder();final MockFpga fpga=new MockFpga();
        volatile int connects,heartbeats,mask,releases;volatile boolean closed;
        Socket()throws IOException{}
        public void connect(){connects++;}
        public InputStream getInputStream(){return input;}
        public OutputStream getOutputStream(){return new OutputStream(){public void write(int value)throws IOException{
            if(closed)throw new IOException("closed");Protocol.Frame f=decoder.feed((byte)value);if(f==null)return;
            if(f.cmd==4||f.cmd==7){mask=f.d[0]|((f.d[1]&15)<<8);if(f.cmd==7)heartbeats++;}
            if(f.cmd==5){mask=0;releases++;}
            byte[] reply=fpga.accept(f.bytes(),System.nanoTime()/1000000);if(reply!=null){incoming.write(reply);incoming.flush();}
        }};}
        public void close()throws IOException{closed=true;incoming.close();input.close();}
    }
    public static void main(String[] args)throws Exception{
        Object s=owner();Socket socket=new Socket();BluetoothDevice device=new BluetoothDevice(socket,socket);Events first=new Events();
        try{
            attach(s,first);connect(s,false,device);until(()->first.connected==1&&first.status>0,"ready follows protocol handshake");
            call(s,"control",new Class<?>[]{int.class,int.class},2,12);
            call(s,"control",new Class<?>[]{int.class,int.class},6,0);
            until(()->first.volume==12,"device parameter updates are received before UI recreation");
            keys(s,3);until(()->socket.mask==3,"foreground keys reach real transport");
            int releases=socket.releases;invoke(s,"pause");until(()->socket.mask==0&&socket.releases>releases,"picker pause releases held keys");
            // A replay runnable already queued before onPause must not resurrect keys.
            keys(s,7);Thread.sleep(120);ok(socket.mask==0,"paused playback/key callbacks cannot resurrect held keys");
            detach(s,first);int oldFrames=first.frames,beats=socket.heartbeats;
            until(()->socket.heartbeats>beats,"transport heartbeat continues while UI is detached");
            ok(!socket.closed&&socket.connects==1,"file picker stop retains exact Bluetooth socket");
            ok(first.frames==oldFrames,"detached Activity receives no live frames");
            Events second=new Events();attach(s,second);ok(second.connected==1&&second.status>0,"recreated UI receives cached ready and live status immediately");
            ok(second.volume==12,"recreated UI immediately restores last device volume");
            keys(s,4);until(()->socket.mask==4,"reattached UI can play without reconnect");
            Events third=new Events();attach(s,third);detach(s,second);keys(s,8);until(()->socket.mask==8,"stale Activity detach cannot detach or pause replacement UI");
            int beforeStaleRelease=socket.releases;
            try{call(s,"release",new Class<?>[]{LinkController.Listener.class},second);call(s,"pause",new Class<?>[]{LinkController.Listener.class},second);}
            catch(NoSuchMethodException e){throw new AssertionError("UI lifecycle release must identify its Activity owner so stale onDestroy cannot release the new UI",e);}
            Thread.sleep(100);ok(socket.releases==beforeStaleRelease&&socket.mask==8,"old Activity destroy cannot release replacement Activity keys");
            keys(s,16);until(()->socket.mask==16,"old Activity pause cannot disable replacement input");
            ok(socket.connects==1,"repeated attachment never reconnects transport");
            close(s);until(()->socket.closed,"explicit disconnect closes owned socket");ok(third.ended==1,"explicit disconnect reports once to attached UI");
            Socket delayed=new Socket();invoke(s,"pause");connect(s,false,new BluetoothDevice(delayed,delayed));
            until(()->delayed.heartbeats>0,"connection initiated before pause may finish in background");
            keys(s,3);Thread.sleep(120);ok(delayed.mask==0,"late connection completion cannot enable paused UI input");
            Handler.hold();delayed.incoming.close();until(()->delayed.closed,"remote socket failure closes owned transport while its callback is queued");
            close(s);
            Events mock=new Events();attach(s,mock);connect(s,true,null);Handler.flush();until(()->mock.connected==1,"mock connects with no Bluetooth device or permission dependency");
            // Late callbacks from the old socket cannot end the replacement simulation.
            Thread.sleep(250);ok((Boolean)call(s,"ready",new Class<?>[0]),"queued stale socket failure cannot terminate new session");
            keys(s,512);until(()->mock.eventFrames>0&&mock.mask==512,"simulation emits a live device event through owned transport");
            Events snapshot=new Events();attach(s,snapshot);ok(snapshot.mask==512,"UI recreation restores live keys newer than last periodic status");
            ok(snapshot.eventFrames==0,"cached device events are not replayed into a new recording");
            attach(s,mock);call(s,"control",new Class<?>[]{int.class,int.class},11,0);until(()->mock.capabilities>0,"extended capability received before picker");
            call(s,"extendedKeys",new Class<?>[]{long.class},1L<<35);until(()->mock.extended==(1L<<35),"36-key input reaches highest absolute pitch");
            invoke(s,"pause");until(()->mock.extended==0,"pause releases 36-key input as well as legacy notes");
            detach(s,mock);Events returned=new Events();attach(s,returned);ok(returned.connected==1&&returned.status>0,"bound mock survives picker and restores state");
            ok(returned.capabilities>0&&returned.extended==0,"cached capability plus latest released state restore ensemble UI");
            detach(s,returned);close(s);Events offline=new Events();attach(s,offline);
            ok(offline.ended==1&&offline.connected==0,"return after background disconnect resets stale playable UI");
        }finally{close(s);}
        System.out.println("PASS "+checks+" ownership/lifecycle checks (production transport; host radio boundary)");
    }
}
