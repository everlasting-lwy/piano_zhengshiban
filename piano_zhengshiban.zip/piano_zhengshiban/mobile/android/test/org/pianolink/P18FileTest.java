package org.pianolink;
import java.lang.reflect.*;
import java.util.*;
public final class P18FileTest {
    static int checks;static void ok(boolean yes,String text){checks++;if(!yes)throw new AssertionError(text);}
    static byte[] encode(String title,int... masks)throws Exception{try{return (byte[])Class.forName("org.pianolink.P18File").getMethod("encode",String.class,int[].class).invoke(null,title,masks);}catch(ClassNotFoundException e){throw new AssertionError("P18 codec missing",e);}}
    static Object decode(byte[] data)throws Exception{return Class.forName("org.pianolink.P18File").getMethod("decode",byte[].class).invoke(null,(Object)data);}
    public static void main(String[] args)throws Exception{
        byte[] data=encode("你好😀",385,2048);ok(Arrays.equals(Arrays.copyOf(data,9),new byte[]{80,49,56,71,85,73,68,69,1}),"literal magic/version");ok(data.length==70&&data[9]==10&&data[10]==2,"exact bytes and UTF8 count");ok(Arrays.equals(Arrays.copyOfRange(data,64,70),new byte[]{(byte)129,1,0,0,8,0}),"physical LE body agrees with Python fixture");Object score=decode(data);ok("你好😀".equals(score.getClass().getField("title").get(score)),"title decoded");ok(Arrays.equals((int[])score.getClass().getField("masks").get(score),new int[]{385,2048}),"masks decoded");
        for(int offset:new int[]{0,8,9,10,12,14,16,48,62,64}){byte[] bad=data.clone();bad[offset]^=(byte)128;boolean rejected=false;try{decode(bad);}catch(InvocationTargetException e){rejected=e.getCause() instanceof IllegalArgumentException;}ok(rejected,"reject corrupt byte "+offset);}
        byte[] full=encode("😀😀😀😀😀😀😀😀😀",1);ok(full[9]==32,"never split UTF8 at32");ok(!decode(full).getClass().getField("title").get(decode(full)).toString().contains("�"),"strict unicode");
        for(int mask:new int[]{0,31,0x40000}){boolean rejected=false;try{encode("x",mask);}catch(InvocationTargetException e){rejected=e.getCause() instanceof IllegalArgumentException;}ok(rejected,"reject invalid physical mask "+mask);}
        System.out.println("PASS "+checks+" P18 Java cross-language binary fixture checks");
    }
}
