package org.pianolink;
import java.lang.reflect.*;

/** Wire compatibility and shared-source semantics, independent of Android UI. */
public final class EnsembleProtocolTest {
    private static int checks;
    private static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    private static void eq(long want,long got,String why){ok(want==got,why+" want="+want+" got="+got);}
    private static void set36(Session session,long mask)throws Exception{
        try{Session.class.getMethod("setExtendedMask",long.class).invoke(session,mask);}
        catch(NoSuchMethodException e){throw new AssertionError("Session must expose a non-truncating 36-key snapshot API");}
    }
    private static long mask36(Protocol.Frame f)throws Exception{return ((Long)Protocol.Frame.class.getMethod("extendedMask").invoke(f)).longValue();}
    private static Protocol.Frame accept(MockFpga fpga,int seq,int cmd,long mask,long now){
        return Protocol.decode(fpga.accept(Protocol.encode(seq,cmd,(int)mask&255,(int)(mask>>>8)&255,(int)(mask>>>16)&255,(int)(mask>>>24)&255,(int)(mask>>>32)&15,0),now));
    }
    public static void main(String[] args)throws Exception{
        Session session=new Session();long chord=1L|(1L<<12)|(1L<<35);
        set36(session,chord);Session.Send send=session.tick(0);
        eq(9,send.frame.cmd,"extended snapshots use command09");eq(chord,mask36(send.frame),"36-bit chord includes both endpoints without int truncation");
        eq(8,send.frame.d[4],"highest note lives in D4 low nibble");eq(0,send.frame.d[5],"reserved byte stays zero");
        session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{9,0,1,0,0,0}));
        send=session.tick(250);eq(10,send.frame.cmd,"extended heartbeat retains complete snapshot");eq(chord,mask36(send.frame),"heartbeat not truncated");
        session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{10,0,1,0,0,0}));
        session.release();send=session.tick(251);eq(5,send.frame.cmd,"release36 is still backward compatible command05");
        session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{5,0,1,0,0,0}));
        session.setMask(1);send=session.tick(291);eq(4,send.frame.cmd,"dashboard switches back to legacy12");eq(1,send.frame.mask(),"legacy snapshot remains unchanged");
        session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{4,0,1,0,0,0}));
        session.control(11,0);send=session.tick(331);eq(11,send.frame.cmd,"extended capabilities can be queried");
        ok(!session.receive(new Protocol.Frame((send.frame.seq+1)&255,0x83,new int[]{0,0,0,0,0,32})),"wrong sequence cannot retire capability query");
        ok(session.receive(new Protocol.Frame(send.frame.seq,0x83,new int[]{0,0,0,0,0,32})),"matched extended capability reply retires request");
        boolean bad=false;try{set36(new Session(),1L<<36);}catch(InvocationTargetException e){bad=e.getCause() instanceof IllegalArgumentException;}ok(bad,"out-of-range extended notes rejected");

        MockFpga fpga=new MockFpga();Protocol.Frame reply=accept(fpga,0,11,0,0);
        eq(0x83,reply.cmd,"extended capability reply83");eq(32,reply.d[5]&0x70,"protocol2 capability marker");
        reply=accept(fpga,1,9,chord,1);eq(0,reply.d[1],"valid36 accepted");
        Protocol.Frame event=Protocol.decode(fpga.pollEvent());eq(0x84,event.cmd,"36-key live event84");eq(chord,mask36(event),"event captures36 state");
        reply=accept(fpga,2,11,0,2);eq(chord,mask36(reply),"status contains36 state");eq(3,Long.bitCount(chord),"fixture uses three independent pitches");
        eq(7,((reply.d[4]>>>4)&15),"three voices reported");
        // A valid CRC does not authorize nonzero reserved bits.
        reply=Protocol.decode(fpga.accept(Protocol.encode(3,9,0,0,0,0,16,0),3));eq(1,reply.d[1],"reserved high nibble is rejected");
        reply=accept(fpga,4,11,0,4);eq(chord,mask36(reply),"invalid request cannot clear held chord");
        byte[] corrupt=Protocol.encode(5,9,0,0,0,0,0,0);corrupt[10]^=1;ok(fpga.accept(corrupt,5)==null,"badCRC cannot release a36 chord");
        accept(fpga,6,5,0,6);event=Protocol.decode(fpga.pollEvent());eq(0,mask36(event),"05 releases all remote36 notes");

        // C4 is played from both sources; releasing either source must preserve the other.
        Method physical=MockFpga.class.getMethod("physicalKeys",long.class,long.class);
        physical.invoke(fpga,1L<<12,10L);fpga.pollEvent();accept(fpga,7,9,1L<<12,11);
        accept(fpga,8,5,0,12);reply=accept(fpga,9,11,0,13);eq(1L<<12,mask36(reply),"phone release preserves physical same pitch");
        accept(fpga,10,9,1L<<12,14);physical.invoke(fpga,0L,15L);reply=accept(fpga,11,11,0,16);eq(1L<<12,mask36(reply),"physical release preserves phone same pitch");
        accept(fpga,12,10,1L<<35,100);fpga.tick(2099);reply=accept(fpga,13,11,0,2099);eq(1L<<35,mask36(reply),"watchdog waits full interval");
        fpga.tick(2100);reply=accept(fpga,14,11,0,2100);eq(0,mask36(reply),"watchdog clears remote high note");
        accept(fpga,15,9,0xfffffffffL,2200);reply=accept(fpga,16,11,0,2201);eq(15,(reply.d[4]>>>4)&15,"36 touches still at most four voices");
        accept(fpga,17,4,1,2300);reply=accept(fpga,18,6,0,2301);eq(1,reply.d[4],"legacy dashboard still controls C4");
        reply=accept(fpga,19,11,0,2302);eq(1L<<12,mask36(reply),"legacy command atomically replaces extended mask");
        System.out.println("PASS "+checks+" ensemble protocol behavior checks");
    }
}
