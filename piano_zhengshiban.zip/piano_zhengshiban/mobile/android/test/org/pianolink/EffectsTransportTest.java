package org.pianolink;

import android.bluetooth.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Real LinkSession/LinkController with paced bytes at the host radio boundary. */
public final class EffectsTransportTest {
    private static int checks;
    private interface Condition {boolean value();}
    private static void ok(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    private static void until(Condition c,String why)throws Exception{long end=System.nanoTime()/1000000+5000;while(!c.value()&&System.nanoTime()/1000000<end)Thread.sleep(10);ok(c.value(),why);}
    private static void visual(LinkSession link,LinkController.Listener owner,int kind,boolean active)throws Exception{try{LinkSession.class.getMethod("visual",LinkController.Listener.class,int.class,boolean.class).invoke(link,owner,kind,active);}catch(NoSuchMethodException e){throw new AssertionError("visual requests must be scoped to active Activity ownership",e);}}
    private static void effect(LinkSession link,LinkController.Listener owner,int id,int value)throws Exception{LinkSession.class.getMethod("effect",LinkController.Listener.class,int.class,int.class).invoke(link,owner,id,value);}
    private static final class Events implements LinkController.Listener {
        volatile int connected,capability,unsupported,snapshots;volatile VisualFrames.Snapshot latest;
        public void connected(boolean simulated){connected++;}
        public void frame(Protocol.Frame f){if(f.isEffectsState())capability++;if(f.cmd==0x80&&f.d[0]==12&&f.d[1]==2)unsupported++;}
        public void visual(VisualFrames.Snapshot value){latest=value;snapshots++;}
        public void message(String text){}public void ended(String reason){}
    }
    private static final class Socket extends BluetoothSocket {
        final PipedInputStream input=new PipedInputStream(8192);final PipedOutputStream incoming=new PipedOutputStream(input);
        final Protocol.Decoder decoder=new Protocol.Decoder();final MockFpga fpga=new MockFpga();
        final ScheduledExecutorService bytes=Executors.newSingleThreadScheduledExecutor();
        final List<Protocol.Frame> requests=Collections.synchronizedList(new ArrayList<Protocol.Frame>());
        volatile int visualRequests,beats;volatile boolean closed;boolean oldFirmware;
        Socket()throws IOException{}
        public void connect(){}
        private void reply(byte[] value)throws IOException{synchronized(incoming){if(!closed){incoming.write(value);incoming.flush();}}}
        public InputStream getInputStream(){return input;}
        public OutputStream getOutputStream(){return new OutputStream(){public void write(int value)throws IOException{Protocol.Frame f=decoder.feed((byte)value);if(f==null)return;requests.add(f);if(f.cmd==7||f.cmd==10)beats++;if(f.cmd==14&&f.d[0]!=0)visualRequests++;
            byte[] response=oldFirmware&&f.cmd>=12?Protocol.encode(f.seq,0x80,f.cmd,2,1,0,0,0):fpga.accept(f.bytes(),System.nanoTime()/1000000);
            if(response!=null)reply(response);int delay=0;byte[] event;while((event=fpga.pollEvent())!=null){final byte[] packet=event;delay+=15;bytes.schedule(()->{try{reply(packet);}catch(IOException ignored){}},delay,TimeUnit.MILLISECONDS);}
        }};}
        public void close()throws IOException{closed=true;bytes.shutdownNow();incoming.close();input.close();}
        boolean effect(int id,int value){synchronized(requests){for(Protocol.Frame f:requests)if(f.cmd==13&&f.d[0]==id&&f.d[1]==value)return true;}return false;}
    }
    public static void main(String[] args)throws Exception {
        LinkSession link=new LinkSession();Events first=new Events();Socket socket=new Socket();link.attach(first);
        try{
            link.connect(false,new BluetoothDevice(socket,socket),false);until(()->first.connected==1,"real legacy handshake completes");
            until(()->first.capability>0,"0C/85 capability queried automatically through byte transport");
            for(int id=0;id<8;id++)effect(link,first,id,id>=6?1:4);
            visual(link,first,3,true);for(int i=0;i<12;i++){Thread.sleep(15);visual(link,first,3,true);}
            until(()->first.snapshots>0,"repeated same-view activation cannot orphan queued XY request behind controls");ok(first.latest.kind==3&&first.latest.data.length==128,"complete XY contains64 pairs");
            ok(socket.visualRequests==1,"no second XY request before previous frame completes");
            effect(link,first,0,5);effect(link,first,1,8);until(()->socket.effect(0,5)&&socket.effect(1,8),"independent effects survive real serialized transport");
            link.pause(first);int requests=socket.visualRequests,beats=socket.beats;Thread.sleep(1000);ok(socket.visualRequests==requests,"background stops nonzero visual requests");ok(socket.beats>beats&&link.ready(),"background retains socket and heartbeat");
            link.resume(first);visual(link,first,4,true);until(()->first.latest.kind==4,"foreground resumes requested guide snapshot");
            Events replacement=new Events();link.attach(replacement);int snapshotCount=first.snapshots;visual(link,replacement,2,true);visual(link,first,0,false);until(()->replacement.latest!=null&&replacement.latest.kind==2,"stale Activity cannot cancel replacement visualization");ok(first.snapshots==snapshotCount,"detached owner receives no later complete frame");
            link.detach(replacement);int atDetach=socket.visualRequests;Thread.sleep(800);ok(socket.visualRequests==atDetach,"detach stops visualization even without explicit UI pause");
        }finally{link.disconnect("test complete");}
        LinkSession old=new LinkSession();Events events=new Events();Socket legacy=new Socket();legacy.oldFirmware=true;old.attach(events);
        try{old.connect(false,new BluetoothDevice(legacy,legacy),false);until(()->events.unsupported>0,"old firmware unsupported ACK releases0C wait");visual(old,events,1,true);effect(old,events,0,15);Thread.sleep(650);ok(legacy.visualRequests==0&&!legacy.effect(0,15),"unsupported firmware receives no effect/visual setters");old.keys(1);until(()->{synchronized(legacy.requests){for(Protocol.Frame f:legacy.requests)if(f.cmd==4&&f.d[0]==1)return true;}return false;},"legacy performance survives unsupported extension");ok(old.ready(),"old firmware remains connected");}finally{old.disconnect("test complete");}
        System.out.println("PASS "+checks+" effects transport/lifecycle checks (paced host radio; not physical HC05)");
    }
}
