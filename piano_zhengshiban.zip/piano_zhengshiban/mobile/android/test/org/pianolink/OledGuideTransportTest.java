package org.pianolink;

import android.bluetooth.*;
import java.io.*;
import java.util.*;

/** Real service/session/controller, replacing only the Android radio boundary. */
public final class OledGuideTransportTest {
    private static int checks;
    private interface Condition {boolean value();}
    private static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    private static void until(Condition condition,String why)throws Exception{long end=System.nanoTime()+6000000000L;while(!condition.value()&&System.nanoTime()<end)Thread.sleep(10);ok(condition.value(),why);}
    private static final class Events implements LinkController.Listener {
        volatile int connected,reports;volatile Session.GuideState guide;
        public void connected(boolean simulation){connected++;}public void frame(Protocol.Frame f){}public void message(String text){}public void ended(String reason){}
        public void guide(Session.GuideState value){guide=value;reports++;}
    }
    private static final class Socket extends BluetoothSocket {
        final PipedInputStream input=new PipedInputStream(8192);final PipedOutputStream incoming=new PipedOutputStream(input);final Protocol.Decoder decoder=new Protocol.Decoder();final MockFpga fpga=new MockFpga();
        final List<Protocol.Frame> requests=Collections.synchronizedList(new ArrayList<Protocol.Frame>());volatile boolean closed,dropStep=true,old;volatile int dropped=-1,retried,begins,aborts,commits;
        Socket()throws IOException{}public void connect(){}public InputStream getInputStream(){return input;}
        public OutputStream getOutputStream(){return new OutputStream(){public void write(int b)throws IOException{Protocol.Frame f=decoder.feed((byte)b);if(f==null)return;requests.add(f);if(f.cmd==0x10)begins++;if(f.cmd==0x12)commits++;if(f.cmd==0x13&&f.d[0]==4)aborts++;
            byte[] reply=old&&f.cmd>=15?Protocol.encode(f.seq,0x80,f.cmd,2,1,0,0,0):fpga.accept(f.bytes(),System.nanoTime()/1000000);
            if(f.cmd==0x11&&f.seq==dropped)retried++;if(f.cmd==0x11&&dropStep){dropStep=false;dropped=f.seq;return;}if(reply!=null&&!closed){incoming.write(reply);incoming.flush();}
        }};}
        public void close()throws IOException{closed=true;incoming.close();input.close();}
        boolean nonzeroRemote(){synchronized(requests){for(Protocol.Frame f:requests)if((f.cmd==4||f.cmd==7||f.cmd==9||f.cmd==10)&&(f.d[0]|f.d[1]|f.d[2]|f.d[3]|f.d[4])!=0)return true;return false;}}
    }
    public static void main(String[] args)throws Exception{
        LinkSession link=new LinkSession();Events first=new Events(),second=new Events();Socket radio=new Socket();link.attach(first);
        try{
            link.connect(false,new BluetoothDevice(radio,radio),false);until(()->link.ready()&&first.guide!=null&&first.guide.capability==1&&first.guide.busy==0,"service discovers exact guide capability/status");
            ok(link.guideDownload(first,new int[]{1,2,4,8,16,32}),"UI initiates upload");until(()->radio.dropped>=0,"STEP executed but ACK deliberately lost at radio boundary");
            link.pause(first);link.detach(first);int before=first.reports;Thread.sleep(80);link.attach(second);
            ok(!link.guideAction(first,3),"detached Activity cannot delete FPGA score");
            until(()->second.guide!=null&&second.guide.busy==0&&second.guide.total==6,"background/recreated UI upload completes on same service/socket");
            ok(radio.retried==1,"in-flight STEP survives release and retries once");ok(first.reports==before,"detached UI receives no further reports");ok(!radio.nonzeroRemote(),"download never sends automatic note playback");
            ok(link.guideAction(second,1),"enter/restart accepted");until(()->second.guide.busy==0&&(second.guide.flags&2)!=0,"actual FPGA active state reported");
            int begins=radio.begins;ok(link.guideDownload(second,new int[]{64,128,256,512}),"second upload accepted");until(()->radio.begins>begins,"second staging begun");link.guideCancel(second);
            until(()->radio.aborts>0&&second.guide.busy==0,"cancel serialized as ABORT and checked status");ok(second.guide.total==6,"cancel retains prior committed score");
            ok(link.guideAction(second,3),"Bluetooth delete accepted");until(()->second.guide.busy==0&&second.guide.total==0,"delete confirmed by89 status");ok(second.guide.flags==2,"delete leaves active NO SONG view");
            ok(link.guideAction(second,0),"exit accepted");until(()->second.guide.busy==0&&(second.guide.flags&2)==0,"exit confirmed by device");
        }finally{link.disconnect("host test complete");}
        LinkSession old=new LinkSession();Events legacy=new Events();Socket oldRadio=new Socket();oldRadio.old=true;old.attach(legacy);
        try{old.connect(false,new BluetoothDevice(oldRadio,oldRadio),false);until(()->legacy.guide!=null&&legacy.guide.capability==-1,"unsupported firmware disables guide extension");ok(old.ready()&&oldRadio.begins==0,"unsupported guide preserves legacy link");}finally{old.disconnect("host test complete");}
        System.out.println("PASS "+checks+" OLED service transport/lifecycle checks (host radio boundary, no hardware)");
    }
}
