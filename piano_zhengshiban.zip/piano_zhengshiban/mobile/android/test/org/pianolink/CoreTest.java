package org.pianolink;

import java.util.*;

/** Plain Java behavioral tests: CRC, wire rejection, device safety, timing and mapping. */
public final class CoreTest {
    static int checks;
    static void eq(long want, long got, String why) {
        checks++; if (want != got) throw new AssertionError(why+": want "+want+", got "+got);
    }
    static void ok(boolean yes, String why) { eq(1, yes?1:0, why); }
    public static void main(String[] args) throws Exception {
        eq(0xf4, Protocol.crc("123456789".getBytes("US-ASCII"),0,9), "SMBUS reference vector");
        byte[] packet = Protocol.encode(7,4,0x81,0x08,0,0,0,0);
        eq(12,packet.length,"fixed frame length");
        // Independent polynomial long-division fixture: A5 5A 07 04 81 08 00 00 00 00 D0 0D.
        int[] wire={165,90,7,4,129,8,0,0,0,0,208,13};
        for(int i=0;i<12;i++)eq(wire[i],packet[i]&255,"frozen wire byte "+i);
        Protocol.Frame f=Protocol.decode(packet);
        eq(7,f.seq,"sequence"); eq(4,f.cmd,"command"); eq(0x881,f.mask(),"natural and sharp mask ordering");
        packet[5]^=1; ok(Protocol.decode(packet)==null,"bad CRC rejected");
        packet=Protocol.encode(7,4,1,0,0,0,0,0); packet[11]=0;
        ok(Protocol.decode(packet)==null,"bad terminator rejected");
        Protocol.Decoder decoder=new Protocol.Decoder();
        byte[] valid=Protocol.encode(0xa5,4,0x5a,1,0,0,0,0);
        byte[] stream=new byte[valid.length+4]; stream[0]=(byte)0xa5; stream[1]=0x5a;
        stream[2]=0; stream[3]=0; System.arraycopy(valid,0,stream,4,12);
        List<Protocol.Frame> decoded=new ArrayList<>();
        for(byte b:stream) { Protocol.Frame frame=decoder.feed(b); if(frame!=null)decoded.add(frame); }
        eq(1,decoded.size(),"parser recovers after damaged prefix"); eq(0xa5,decoded.get(0).seq,"sync bytes legal in body");
        decoder=new Protocol.Decoder();for(int i=0;i<6;i++)decoder.feed(valid[i],0);
        for(int i=6;i<12;i++)ok(decoder.feed(valid[i],400)==null,"timed-out prefix cannot execute");

        MockFpga mock=new MockFpga();
        byte[] damaged=Protocol.encode(1,4,1,0,0,0,0,0);damaged[10]^=1;
        ok(mock.accept(damaged,50)==null,"device does not ACK or execute a damaged request");
        Protocol.Frame ack=Protocol.decode(mock.accept(Protocol.encode(9,4,0xff,15,0,0,0,0),100));
        eq(0x80,ack.cmd,"key ACK"); eq(0,ack.d[1],"valid key status");
        Protocol.Frame ev=Protocol.decode(mock.pollEvent()); eq(0xfff,ev.mask(),"full key event"); eq(15,ev.voices(),"maximum four voices");
        Protocol.Frame state=Protocol.decode(mock.accept(Protocol.encode(10,6,0,0,0,0,0,0),101));
        eq(0x81,state.cmd,"status replaces ACK"); eq(0xfff,state.d[4]|((state.d[5]&15)<<8),"status keys");
        ack=Protocol.decode(mock.accept(Protocol.encode(11,1,4,0,0,0,0,0),102)); eq(1,ack.d[1],"timbre range rejected");
        ack=Protocol.decode(mock.accept(Protocol.encode(12,5,0,0,1,0,0,0),103)); eq(1,ack.d[1],"reserved bytes rejected");
        state=Protocol.decode(mock.accept(Protocol.encode(13,6,0,0,0,0,0,0),104)); eq(0xfff,state.d[4]|((state.d[5]&15)<<8),"invalid release preserves state");
        mock.tick(2099); ok(mock.pollEvent()==null,"watchdog waits 2000ms");
        mock.tick(2100); eq(0,Protocol.decode(mock.pollEvent()).mask(),"watchdog releases only remote keys");
        mock.accept(Protocol.encode(14,7,1,0,0,0,0,0),3000); mock.pollEvent();
        mock.accept(Protocol.encode(14,7,1,0,0,0,0,0),3400); mock.tick(5100);
        ok(mock.pollEvent()==null,"same-sequence retry refreshes watchdog without duplicate event");
        for(int i=0;i<20;i++) mock.accept(Protocol.encode(i,4,i&1,0,0,0,0,0),5200+i);
        state=Protocol.decode(mock.accept(Protocol.encode(22,6,0,0,0,0,0,0),5300)); ok((state.d[3]&128)!=0,"event FIFO overflow visible");
        ack=Protocol.decode(mock.accept(Protocol.encode(23,8,0,0,0,0,0,0),5301)); eq(0,ack.d[3],"overflow can be cleared");

        Recording recording=new Recording(); recording.start();
        recording.accept(new Protocol.Frame(0,0x82,new int[]{0xf0,0xff,0xff,0xff,1,0x10}));
        recording.accept(new Protocol.Frame(1,0x82,new int[]{0x10,0,0,0,0,0})); recording.stop();
        eq(32,recording.events().get(1).ms,"32bit timestamp wraps correctly");
        String csv=recording.toCsv(); Recording loaded=new Recording(); loaded.fromCsv(csv);
        eq(2,loaded.events().size(),"CSV roundtrip event count"); eq(1,loaded.events().get(0).mask,"CSV keeps key mask");
        boolean rejected=false; try { loaded.fromCsv("time_ms,mask,voices\n0,4096,1\n"); } catch(IllegalArgumentException e){rejected=true;}
        ok(rejected,"CSV out of range rejected"); eq(2,loaded.events().size(),"bad import preserves previous recording");
        rejected=false; try { loaded.fromCsv("time_ms,mask,voices\n10,1,1\n5,0,0\n"); } catch(IllegalArgumentException e){rejected=true;}
        ok(rejected,"CSV backward time rejected");
        KeyMap map=new KeyMap(); map.set(1,0); map.down(0); map.down(1); map.up(0);
        eq(1,map.mask(),"duplicate mapped note stays down until all fingers released"); map.clear(); eq(0,map.mask(),"cancel clears all touches");

        Session session=new Session(); session.setMask(1); Session.Send send=session.tick(0);
        eq(4,send.frame.cmd,"latest mask sent first"); eq(1,send.frame.mask(),"desired keys");
        ok(session.tick(499)==null,"one in flight"); Session.Send retry=session.tick(500);
        eq(send.frame.seq,retry.frame.seq,"retry keeps sequence");
        ok(!session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{2,0,1,0,0,0})),"unrelated ACK cannot clear pending");
        ok(session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{4,0,1,0,0,0})),"matching ACK clears pending");
        session.setMask(2); session.setMask(3); send=session.tick(540); eq(3,send.frame.mask(),"key traffic coalesces latest state");
        session.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{4,0,1,0,0,0}));
        send=session.tick(790); eq(7,send.frame.cmd,"heartbeat refreshes complete mask"); eq(3,send.frame.mask(),"heartbeat mask");
        session.release(); send=session.tick(800); eq(5,send.frame.cmd,"safety release preempts queued traffic");
        Session failed=new Session(); failed.setMask(1); failed.tick(0); failed.tick(500); failed.tick(1000);
        boolean timeout=false; try {failed.tick(1500);} catch(IllegalStateException e){timeout=true;} ok(timeout,"finite retry budget disconnects");
        Session controls=new Session();controls.control(2,2);controls.control(2,11);
        send=controls.tick(0);eq(7,send.frame.cmd,"initial full-state heartbeat");
        controls.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{7,0,1,0,0,0}));
        ok(controls.tick(39)==null,"ordinary traffic never exceeds 25Hz");
        send=controls.tick(40);eq(2,send.frame.cmd,"queued parameter sent");eq(11,send.frame.d[0],"parameter changes coalesce");
        int oldSeq=send.frame.seq;controls.release();send=controls.tick(41);
        eq(5,send.frame.cmd,"release bypasses rate limiter for safety");
        ok(!controls.receive(new Protocol.Frame(oldSeq,0x80,new int[]{2,0,1,0,0,0})),"late pre-release ACK cannot retire new release");
        Session held=new Session();held.setMask(1);send=held.tick(0);
        held.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{4,0,1,0,0,0}));
        held.control(2,11);held.setMask(1);send=held.tick(40);
        eq(2,send.frame.cmd,"unchanged finger movement must not starve parameter command");
        Session busyKeys=new Session();busyKeys.control(1,3);boolean controlServed=false;
        for(int time=0;time<=160;time+=40){
            busyKeys.setMask((time/40&1)+1);send=busyKeys.tick(time);
            if(send!=null){if(send.frame.cmd==1)controlServed=true;
                busyKeys.receive(new Protocol.Frame(send.frame.seq,0x80,new int[]{send.frame.cmd,0,1,0,0,0}));}
        }
        ok(controlServed,"continuous actual key changes must give controls a bounded service slot");
        // The abandoned private export commands remain unsupported after SD restoration.
        MockFpga bounded=new MockFpga();
        for(int command:new int[]{0x1c,0x1d}){
            Protocol.Frame retiredReply=Protocol.decode(bounded.accept(Protocol.encode(99,command,0,0,0,0,0,0),0));
            ok(retiredReply!=null&&retiredReply.cmd==0x80,"retired command returns ACK");
            ok(retiredReply.d[0]==command,"retired command ACK retains command identity");
            ok(retiredReply.d[1]==2,"retired command is unsupported");
        }
        System.out.println("PASS "+checks+" core behavioral checks");
    }
}
