package org.pianolink;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Literal score fixtures exercise conversion and the real, Android-free practice clock. */
public final class GuideTest {
    private static int checks;
    private interface Action { void run(); }
    private static void eq(long want, long got, String why) {
        checks++;
        if (want != got) throw new AssertionError(why + ": want " + want + ", got " + got);
    }
    private static void eq(Object want, Object got, String why) {
        checks++;
        if (want == null ? got != null : !want.equals(got))
            throw new AssertionError(why + ": want " + want + ", got " + got);
    }
    private static void bad(Action action, String why) {
        checks++;
        try { action.run(); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError(why + ": accepted invalid input");
    }
    private static GuideSong score(String rows) {
        return GuideSong.from(SongData.fromCsv("time_ms,mask36,voices\n" + rows));
    }
    private static void note(GuideSong song, int id, int key, long start, long end) {
        GuideSong.Note note = song.notes.get(id);
        eq(id, note.id, "stable chronological note id");
        eq(key, note.key, "absolute key");
        eq(start, note.startMs, "onset");
        eq(end, note.endMs, "release");
    }
    private static GuideSong single(long start, long end) {
        return score(start + ",4096,1\n" + end + ",0,0\n");
    }
    private static void conversionChecks() {
        GuideSong chord = score("0,34359742465,7\n100,34359742464,3\n250,4096,1\n400,0,0\n1000,0,0\n");
        eq(3, chord.notes.size(), "one span per key, not one span per polling row");
        note(chord, 0, 0, 0, 100);
        note(chord, 1, 12, 0, 400);
        note(chord, 2, 35, 0, 250);
        eq(3, chord.peakPolyphony, "chord size comes from snapshots, not voice field");
        eq(2, chord.outOfPhysicalRange, "C3 and B5 exceed original C4 through F5 physical range");
        eq(1000, chord.durationMs, "explicit trailing silence stays in timeline");
        eq(false, chord.tailPatched, "closed score does not claim a repaired tail");
        checks++;
        try { chord.notes.clear(); throw new AssertionError("score list must be immutable"); }
        catch (UnsupportedOperationException expected) { }

        GuideSong legacy = GuideSong.from(SongData.fromCsv("time_ms,mask,voices\n0,4095,0\n100,0,0\n"));
        eq(12, legacy.notes.size(), "all legacy natural-first bits survive mapping");
        for (int i = 0; i < 12; i++) note(legacy, i, 12 + i, 0, 100);
        GuideSong mapping = GuideSong.from(SongData.fromCsv("time_ms,mask,voices\n0,1,1\n10,2,1\n20,4,1\n30,8,1\n40,16,1\n50,32,1\n60,64,1\n70,128,1\n80,256,1\n90,512,1\n100,1024,1\n110,2048,1\n120,0,0\n"));
        int[] expectedKeys = {12,14,16,17,19,21,23,13,15,18,20,22};
        for (int i = 0; i < expectedKeys.length; i++) note(mapping, i, expectedKeys[i], i * 10, i * 10 + 10);

        GuideSong coincident = score("0,1,1\n0,4096,1\n0,0,0\n0,4096,1\n100,0,0\n100,4096,1\n200,0,0\n200,34359738368,1\n200,0,0\n");
        eq(1, coincident.notes.size(), "same-time final snapshot discards phantom retriggers and zero spans");
        note(coincident, 0, 12, 0, 200);
        eq(1, coincident.peakPolyphony, "superseded same-time rows cannot inflate peak");
        GuideSong tail = GuideSong.from(SongData.fromCsv("# incomplete=true\ntime_ms,mask36,voices\n50,4096,1\n100,4096,1\n"));
        note(tail, 0, 12, 50, 600);
        eq(600, tail.durationMs, "open tail ends 500ms after final snapshot");
        eq(true, tail.tailPatched, "tail repair is visible");
        eq(true, tail.incomplete, "recording incompleteness is retained independently");
        GuideSong physical = score("0,1610618880,0\n10,0,0\n"); // B3, C4, F5 and F#5
        eq(4, physical.notes.size(), "physical endpoints and their neighbors are represented");
        eq(2, physical.outOfPhysicalRange, "physical range endpoints are inclusive");
        bad(new Action() { public void run() { score("0,0,0\n10,0,0\n"); } }, "silent file has no fabricated notes");
        bad(new Action() { public void run() { score("0,4096,1\n0,0,0\n"); } }, "only zero-length onsets is empty");
        bad(new Action() { public void run() { GuideSong.from(null); } }, "null source");
        GuideSong demo = GuideSong.demo();
        checks++;
        if (demo.notes.size() < 3 || demo.durationMs <= 0) throw new AssertionError("demo must be an actual short score");
    }
    private static SongData dense(int lastChordSize) {
        List<SongData.Event> events = new ArrayList<SongData.Event>();
        for (int i = 0; i < 2777; i++) {
            events.add(new SongData.Event(i * 2, 68719476735L, 0));
            events.add(new SongData.Event(i * 2 + 1, 0, 0));
        }
        events.add(new SongData.Event(5554, (1L << lastChordSize) - 1, 0));
        events.add(new SongData.Event(5555, 0, 0));
        return new SongData(SongData.Format.ABSOLUTE36, events, true);
    }
    private static void sizeChecks() {
        GuideSong limit = GuideSong.from(dense(28));
        eq(100000, limit.notes.size(), "exactly 100000 note spans accepted");
        eq(true, limit.incomplete, "dense source keeps incomplete flag");
        note(limit, 99999, 27, 5554, 5555);
        bad(new Action() { public void run() { GuideSong.from(dense(29)); } }, "100001 note spans explicitly rejected");
        List<SongData.Event> coincident = new ArrayList<SongData.Event>();
        for (int i = 0; i < 99999; i++) coincident.add(new SongData.Event(0, i % 2 == 0 ? 4096 : 0, 0));
        coincident.add(new SongData.Event(1, 0, 0));
        GuideSong compact = GuideSong.from(new SongData(SongData.Format.ABSOLUTE36, coincident, false));
        eq(1, compact.notes.size(), "100000 coincident snapshots coalesce before emitting notes");
        note(compact, 0, 12, 0, 1);
        GuideEngine engine = new GuideEngine(limit);
        engine.start(0);
        engine.input(1L << 12, 8554);
        eq(1, engine.hitCount(), "dense closest pending onset hit");
        eq(GuideEngine.HIT, engine.result(99984), "dense match chooses last key12 onset");
        for (int i = 0; i < 2000; i++) engine.tick(8554);
        engine.tick(9000);
        eq(99999, engine.missCount(), "dense expiration accounts for every unhit span once");
        eq(GuideEngine.State.FINISHED, engine.state(), "dense score eventually finishes");
        eq(GuideEngine.MISS, engine.result(0), "lazy expiration reports an individual miss");
    }
    private static void clockChecks() {
        GuideEngine engine = new GuideEngine(single(0, 5000));
        eq(GuideEngine.State.READY, engine.state(), "fresh score is ready");
        eq(-3000, engine.positionMs(1000), "ready score keeps 3s preroll");
        engine.start(10000);
        eq(-3000, engine.positionMs(10000), "start anchors preroll");
        eq(-1500, engine.positionMs(11500), "elapsedRealtime drives score");
        engine.setSpeed(0.5, 11500);
        eq(-1500, engine.positionMs(11500), "speed change does not move position");
        eq(-1000, engine.positionMs(12500), "half speed advances song milliseconds");
        engine.pause(13000);
        eq(-750, engine.positionMs(23000), "pause freezes score");
        engine.setSpeed(1.5, 33000);
        eq(-750, engine.positionMs(33000), "paused speed change preserves score");
        engine.resume(40000);
        eq(0, engine.positionMs(40500), "resume uses new rate with no pause-time jump");
        engine.start(40500);
        eq(0, engine.positionMs(40500), "duplicate start cannot reset a running score");
        eq(1.5, engine.speed(), "selected speed is reported");
        engine.pause(40501);
        engine.resume(50000);
        engine.setSpeed(0.75, 50001);
        eq(3, engine.positionMs(50001), "fractional elapsed time survives pause and rate changes");
        bad(new Action() { public void run() { new GuideEngine(single(0,100)).setSpeed(0,0); } }, "zero speed rejected");
        bad(new Action() { public void run() { new GuideEngine(single(0,100)).setSpeed(Double.NaN,0); } }, "NaN speed rejected");
        bad(new Action() { public void run() { new GuideEngine(single(0,100)).setSpeed(Double.POSITIVE_INFINITY,0); } }, "infinite speed rejected");
        GuideEngine end = new GuideEngine(single(0,100));
        end.start(0);
        end.input(4096, 3300);
        eq(1, end.hitCount(), "last onset remains hittable at inclusive late boundary");
        end.tick(10000);
        eq(GuideEngine.State.FINISHED, end.state(), "finished after final release and judgment window");
        int wrong = end.wrongCount();
        end.input(8192, 20000);
        eq(wrong, end.wrongCount(), "finished score ignores input");
        end.restart(20000);
        eq(-3000, end.positionMs(20000), "restart restores preroll");
        eq(0, end.hitCount(), "restart clears hits");
        eq(0, end.missCount(), "restart clears misses");
        eq(GuideEngine.State.RUNNING, end.state(), "restart starts the score");
        GuideEngine trailing = new GuideEngine(score("0,4096,1\n100,0,0\n5000,0,0\n"));
        trailing.start(0);
        trailing.tick(7900);
        eq(GuideEngine.State.RUNNING, trailing.state(), "trailing source silence remains part of score");
    }
    private static void boundaryChecks() {
        long[] inputs = {3699, 3700, 4300, 4301};
        int[] hits = {0,1,1,0};
        int[] misses = {0,0,0,1};
        int[] wrong = {1,0,0,1};
        for (int i = 0; i < inputs.length; i++) {
            GuideEngine engine = new GuideEngine(single(1000,2000));
            engine.start(0);
            engine.input(4096, inputs[i]);
            eq(hits[i], engine.hitCount(), "300ms onset boundary hit");
            eq(misses[i], engine.missCount(), "300ms onset boundary expiration");
            eq(wrong[i], engine.wrongCount(), "unmatched edge is one wrong note");
        }
        GuideEngine engine = new GuideEngine(single(1000,2000));
        engine.start(0);
        engine.tick(4300);
        eq(GuideEngine.PENDING, engine.result(0), "note remains pending through +300ms");
        engine.tick(4301);
        engine.tick(4301);
        eq(1, engine.missCount(), "miss counts only once");
        eq(GuideEngine.MISS, engine.result(0), "pending result changes at +301ms");
    }
    private static void inputChecks() {
        GuideSong repeats = score("1000,4096,1\n1100,0,0\n1400,4096,1\n1500,0,0\n3000,0,0\n");
        GuideEngine closest = new GuideEngine(repeats);
        closest.start(0);
        closest.input(4096,4250);
        eq(GuideEngine.PENDING, closest.result(0), "early pending repeat is not preferred over closer onset");
        eq(GuideEngine.HIT, closest.result(1), "closest pending same key wins");
        closest.input(0,4251);
        closest.input(4096,4252);
        eq(2, closest.hitCount(), "another release-and-press can hit remaining pending onset");
        GuideEngine tie = new GuideEngine(repeats);
        tie.start(0);
        tie.input(4096,4200);
        eq(GuideEngine.HIT, tie.result(0), "equal-distance tie uses earlier onset");
        GuideEngine held = new GuideEngine(repeats);
        held.rebaseInput(4096);
        held.start(0);
        held.input(4096,4000);
        held.input(4096,4400);
        eq(0, held.hitCount(), "preheld key cannot earn onset hits from polling");
        eq(0, held.wrongCount(), "held polls are not wrong-note edges");
        held.input(0,4401);
        held.input(4096,4402);
        eq(1, held.hitCount(), "repeat needs physical release then a new edge");
        held.restart(5000);
        held.input(4096,9000);
        eq(0, held.hitCount(), "restart preserves held baseline");
        GuideEngine chord = new GuideEngine(score("1000,20480,2\n1100,0,0\n1400,20480,2\n1500,0,0\n3000,0,0\n"));
        chord.start(0);
        chord.input(20480,4000);
        chord.input(20480,4400);
        eq(2, chord.hitCount(), "held chord or merged ACK cannot retrigger either pitch");
        chord.input(16384,4401);
        chord.input(20480,4402);
        eq(3, chord.hitCount(), "only released chord pitch can retrigger");
        chord.input(0,4403);
        chord.input(16384,4404);
        eq(4, chord.hitCount(), "second chord pitch gets its own release edge");
        chord.input(49152,4500);
        chord.input(49152,4501);
        eq(1, chord.wrongCount(), "held unmatched pitch is counted once");
        GuideEngine rebase = new GuideEngine(single(1000,5000));
        rebase.start(0);
        rebase.rebaseInput(4096);
        rebase.input(4096,4000);
        eq(0, rebase.hitCount(), "changing input source does not fabricate an edge");
        rebase.pause(4000);
        rebase.input(0,5000);
        rebase.input(4096,5001);
        eq(0, rebase.hitCount(), "paused input never scores");
        rebase.resume(6000);
        rebase.input(4096,6000);
        eq(0, rebase.hitCount(), "paused presses remain baseline after resume");
        rebase.input(0,6001);
        rebase.input(4096,6002);
        eq(1, rebase.hitCount(), "new edge after resume can score");
        GuideEngine mask = new GuideEngine(single(1000,2000));
        mask.start(0);
        mask.input(1L << 48,4000);
        eq(0, mask.wrongCount(), "non-key bits never count as input");
    }
    public static void main(String[] args) {
        conversionChecks();
        clockChecks();
        boundaryChecks();
        inputChecks();
        sizeChecks();
        System.out.println("GuideTest: " + checks + " checks passed");
    }
}
