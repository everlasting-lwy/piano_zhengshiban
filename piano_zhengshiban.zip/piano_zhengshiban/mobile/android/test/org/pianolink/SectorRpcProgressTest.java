package org.pianolink;
import java.lang.reflect.*;
import java.util.*;
public final class SectorRpcProgressTest {
    static int checks;static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    public static void main(String[] args)throws Exception{
        Class<?> type;try{type=Class.forName("org.pianolink.SectorRpcClient$Progress");}catch(ClassNotFoundException e){throw new AssertionError("low-frequency actual sector progress callback missing",e);}
        final List<Object[]> updates=Collections.synchronizedList(new ArrayList<Object[]>());Object observer=Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},(proxy,method,values)->{updates.add(values.clone());return null;});
        try(SectorRpcTest.Pump pump=new SectorRpcTest.Pump(SectorRpcTest.v2(new MockFpga.SdCard()))){Object client=Class.forName("org.pianolink.SectorRpcClient").getConstructor(Session.class,type).newInstance(pump.s,observer);SectorRpcTest.invoke(client,"open",new Class<?>[0]);long last=(Long)SectorRpcTest.invoke(client,"sectorCount",new Class<?>[0])-1;SectorRpcTest.invoke(client,"read",new Class<?>[]{long.class},0L);SectorRpcTest.invoke(client,"write",new Class<?>[]{long.class,byte[].class},last,new byte[512]);boolean readEnd=false,writeEnd=false;for(Object[] update:updates){boolean writing=(Boolean)update[0];long lba=(Long)update[1];int chunk=(Integer)update[2];ok(chunk>=0&&chunk<=128,"actual4-byte chunk count stays within512-byte sector");ok(lba==(writing?last:0L),"reported LBA matches actual queued operation");if(chunk==128){if(writing)writeEnd=true;else readEnd=true;}}ok(readEnd&&writeEnd,"both real cache reads and write fills report128 acknowledged chunks");ok(updates.size()<=18,"progress updates are low-frequency rather than every4-byte frame");SectorRpcTest.invoke(client,"close",new Class<?>[0]);}
        System.out.println("PASS "+checks+" actual LBA/chunk progress checks (simulated wire)");
    }
}
