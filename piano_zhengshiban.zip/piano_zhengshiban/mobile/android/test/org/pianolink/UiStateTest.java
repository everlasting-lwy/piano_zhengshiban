package org.pianolink;

public final class UiStateTest {
    private static int checks;
    private static void eq(long want,long got,String what){checks++;if(want!=got)throw new AssertionError(what+": want "+want+", got "+got);}
    public static void main(String[] args){
        // A delayed status must never move the persisted selection or trigger writes.
        VolumeState volume=new VolumeState(11);volume.report(3);
        eq(11,volume.selected(),"stale device report preserves choice");eq(3,volume.reported(),"actual report visible");
        eq(11,volume.ready(),"one selected-volume send on ready");eq(-1,volume.ready(),"no repeated corrective writes");
        volume.beginDrag();eq(-1,volume.change(12,true),"drag suppresses intermediate command");
        volume.report(4);eq(12,volume.selected(),"report during drag preserves choice");
        eq(-1,volume.change(14,true),"second drag sample suppressed");eq(14,volume.endDrag(),"drag finish commits last choice");
        eq(-1,volume.endDrag(),"finish cannot resend");eq(-1,volume.change(2,false),"programmatic progress cannot change selection");eq(14,volume.selected(),"selection stable");
        eq(9,volume.change(9,true),"accessibility discrete selection commits");
        volume.disconnected();eq(-1,volume.reported(),"new connection unknown report");eq(9,volume.ready(),"reconnect sends saved choice once");
        eq(15,new VolumeState(100).selected(),"saved value clamped");
        PianoTouch p=new PianoTouch();
        int[] whites={0,2,4,5,7,9,11,12,14,16,17,19,21,23,24,26,28,29,31,33,35};
        int[] blacks={1,3,6,8,10,13,15,18,20,22,25,27,30,32,34};
        int[] boundaries={1,2,4,5,6,8,9,11,12,13,15,16,18,19,20};
        for(int i=0;i<whites.length;i++)eq(whites[i],p.keyAt(i*100+50,190,2100,200),"white pitch "+i);
        for(int i=0;i<blacks.length;i++)eq(blacks[i],p.keyAt(boundaries[i]*100,20,2100,200),"black overlap priority "+i);
        eq(0,p.keyAt(75,130,2100,200),"white beneath black overlap");
        eq(0,p.keyAt(67,20,2100,200),"outside black left edge");eq(1,p.keyAt(68,20,2100,200),"black left edge inclusive");
        eq(2,p.keyAt(132,20,2100,200),"black right edge exclusive");
        eq(0,p.keyAt(0,0,2100,200),"first left edge");eq(35,p.keyAt(2099,199,2100,200),"last right interior");
        eq(-1,p.keyAt(2100,10,2100,200),"right outside");eq(-1,p.keyAt(20,-1,2100,200),"above outside");
        p.down(7,0);p.down(20,0);p.up(7);eq(1,p.mask(),"same-note pointer reference count");
        p.move(20,35);eq(0x800000000L,p.mask(),"move replaces note with B5");
        p.down(99,1);eq(0x800000002L,p.mask(),"multiple pointer IDs chord");
        p.move(20,-1);eq(2,p.mask(),"move outside releases only pointer");p.up(99);eq(0,p.mask(),"last pointer up");
        p.move(99,12);eq(0,p.mask(),"moving lifted pointer cannot resurrect note");
        p.down(99,36);eq(0,p.mask(),"invalid key cannot wrap bit shift");p.cancel();
        for(int i=0;i<36;i++)p.down(i,i);eq(0xfffffffffL,p.mask(),"all 36 notes map distinctly");p.cancel();eq(0,p.mask(),"cancel releases every pointer");
        System.out.println("PASS "+checks+" UI state/volume/touch checks");
    }
}
