package org.pianolink;

import android.bluetooth.*;
import java.io.*;
import java.util.*;

/** Real 20ms controller and service, with a held radio response to exercise the tap race. */
public final class OledGuideIdlePollTransportTest {
    static int checks;
    interface Condition {boolean value();}
    static void ok(boolean yes,String why){checks++;if(!yes)throw new AssertionError(why);}
    static void until(Condition condition,String why)throws Exception{long end=System.nanoTime()+7000000000L;while(!condition.value()&&System.nanoTime()<end)Thread.sleep(10);ok(condition.value(),why);}
    static final class Events implements LinkController.Listener {
        volatile Session.GuideState latest;volatile int reports;
        public void connected(boolean simulated){}public void frame(Protocol.Frame frame){}public void message(String text){}public void ended(String reason){}
        public void guide(Session.GuideState state){latest=state;reports++;}
    }
    static final class Radio extends BluetoothSocket {
        final PipedInputStream input=new PipedInputStream(8192);final PipedOutputStream incoming=new PipedOutputStream(input);final MockFpga device=new MockFpga();final Protocol.Decoder decoder=new Protocol.Decoder();
        final List<Protocol.Frame> requests=Collections.synchronizedList(new ArrayList<Protocol.Frame>());volatile boolean closed,holdStatus;volatile byte[] held;
        Radio()throws IOException{}public void connect(){}public InputStream getInputStream(){return input;}
        public OutputStream getOutputStream(){return new OutputStream(){public void write(int value)throws IOException{Protocol.Frame f=decoder.feed((byte)value);if(f==null)return;requests.add(f);byte[] response=device.accept(f.bytes(),System.nanoTime()/1000000L);if(f.cmd==0x14&&holdStatus){held=response;return;}deliver(response);}};}
        synchronized void deliver(byte[] response)throws IOException{if(response!=null&&!closed){incoming.write(response);incoming.flush();}}
        void resumeStatus()throws IOException{holdStatus=false;byte[] response=held;held=null;deliver(response);}
        int count(int command){int count=0;synchronized(requests){for(Protocol.Frame f:requests)if(f.cmd==command)count++;}return count;}
        public synchronized void close()throws IOException{closed=true;incoming.close();input.close();}
    }
    public static void main(String[] args)throws Exception{
        LinkSession link=new LinkSession();Events events=new Events();Radio radio=new Radio();link.attach(events);
        try{
            link.connect(false,new BluetoothDevice(radio,radio),false);until(()->events.latest!=null&&events.latest.reported==1&&events.latest.busy==0,"initial guide discovery completes");
            int reports=events.reports;long revision=events.latest.revision;String message=events.latest.message;
            until(()->radio.count(0x15)>=3,"controller completes two periodic read-only polls");Thread.sleep(80);
            ok(events.reports==reports&&events.latest.revision==revision&&events.latest.message.equals(message),"idle timer polls do not flicker busy/message or emit unchanged reports");ok(radio.count(0x0f)==1,"controller does not requery fixed capability every second");
            radio.holdStatus=true;until(()->radio.held!=null,"periodic status reply held at radio boundary");
            ok(link.guideAction(events,1),"service accepts enter tap during its automatic poll");Thread.sleep(80);ok(radio.count(0x13)==0,"queued action cannot overtake unacknowledged polling request");
            radio.resumeStatus();until(()->events.latest.busy==0&&(events.latest.flags&2)!=0,"queued tap executes and returns actual FPGA active state");ok(radio.count(0x13)==1,"tap executes exactly once through real controller");
        }finally{link.disconnect("idle poll test complete");}
        System.out.println("PASS "+checks+" timed idle-poll controller/service checks (host radio, no hardware)");
    }
}
