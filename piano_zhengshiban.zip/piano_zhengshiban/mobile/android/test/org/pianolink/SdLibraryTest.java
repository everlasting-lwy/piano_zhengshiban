package org.pianolink;

import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Production stop/wait scheduler and protocol model; model persistence is not a card test. */
public final class SdLibraryTest {
    static int checks,seq;static long now;
    static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    static void eq(long want,long got,String why){ok(want==got,why+": want "+want+", got "+got);}
    static Object call(Object owner,String method,Class<?>[] types,Object... args)throws Exception{try{return owner.getClass().getMethod(method,types).invoke(owner,args);}catch(NoSuchMethodException e){throw new AssertionError("missing production SD API "+method,e);}catch(InvocationTargetException e){if(e.getCause() instanceof RuntimeException)throw (RuntimeException)e.getCause();throw e;}}
    static Object state(Session session)throws Exception{return call(session,"sdState",new Class<?>[0]);}
    static long field(Object s,String field)throws Exception{return s.getClass().getField(field).getLong(s);}
    static String message(Session s)throws Exception{return (String)state(s).getClass().getField("message").get(state(s));}
    static boolean action(Session s,String method,int slot)throws Exception{return (Boolean)call(s,method,new Class<?>[]{int.class},slot);}
    static boolean save(Session s,int slot,String title,int... masks)throws Exception{return (Boolean)call(s,"sdSave",new Class<?>[]{int.class,String.class,int[].class},slot,title,(Object)masks);}
    static Protocol.Frame request(MockFpga m,int command,int... data){int[] d=new int[6];System.arraycopy(data,0,d,0,data.length);return Protocol.decode(m.accept(new Protocol.Frame(seq++&255,command,d).bytes(),now));}
    static List<Protocol.Frame> run(Session s,MockFpga m,long duration)throws Exception{ArrayList<Protocol.Frame> frames=new ArrayList<>();long end=now+duration;for(;now<end;now+=40){m.tick(now);Session.Send send=s.tick(now);if(send!=null){frames.add(send.frame);ok(s.receive(Protocol.decode(m.accept(send.frame.bytes(),now))),"reply accepted cmd="+send.frame.cmd);}}return frames;}
    static void refresh(Session s)throws Exception{call(s,"sdRefresh",new Class<?>[0]);}
    static void scan(Session s)throws Exception{ok((Boolean)call(s,"sdScan",new Class<?>[0]),"scan accepted");}
    static void discover(Session s,MockFpga m)throws Exception{refresh(s);run(s,m,6000);eq(1,field(state(s),"capability"),"SD supported");}
    static void untilDone(Session s,MockFpga m)throws Exception{for(int i=0;i<50;i++){run(s,m,240);refresh(s);if(field(state(s),"busy")==0){run(s,m,2000);return;}}throw new AssertionError("operation never finishes");}
    static void protocol()throws Exception{
        MockFpga m=new MockFpga();Protocol.Frame status=request(m,0x16);eq(0x8b,status.cmd,"frozen status response");eq(1,status.d[0],"protocol version");eq(1,status.d[1],"simulated FAT32 mounted");eq(3,status.d[5]&3,"card and mount flags");
        Protocol.Frame invalid=request(m,0x17,0,255,0,0,0,0);eq(1,invalid.d[1],"zero token rejected");eq(1,request(m,0x17,0,0,1).d[1],"scan requires FF slot");
        Protocol.Frame accepted=request(m,0x17,0,255,0x78,0x56,0x34,0x12);eq(0,accepted.d[1],"accepted long operation");eq(2,request(m,0x16).d[1],"ACK does not finish operation");
        Protocol.Frame identity=request(m,0x1b);eq(0x8e,identity.cmd,"identity response");eq(0x78,identity.d[0],"token little endian");eq(0x12,identity.d[3],"full 32 bit identity");eq(0,request(m,0x17,0,255,0x78,0x56,0x34,0x12).d[1],"same identity retry accepted");eq(1,request(m,0x17,3,0,0x78,0x56,0x34,0x12).d[1],"token cannot change parameters");
        now+=1000;m.tick(now);eq(8,request(m,0x16).d[5]&8,"completion success is separate");eq(0,request(m,0x17,0,255,0x78,0x56,0x34,0x12).d[1],"completed retry remains idempotent");eq(1,request(m,0x16).d[1],"completed retry does not restart");
        eq(1,request(m,0x18,30,1,2,3,0,0).d[1],"title tail overflow rejected");eq(1,request(m,0x19,32).d[1],"slot out of range rejected");
    }
    static void transactions()throws Exception{
        Session s=new Session();MockFpga m=new MockFpga();discover(s,m);scan(s);untilDone(s,m);Object[] entries=(Object[])state(s).getClass().getField("entries").get(state(s));eq(32,entries.length,"all 32 slots listed");
        ok(save(s,7,"你好😀曲库名字会按UTF8截断",1,1<<17),"save selected score accepted");eq(1,field(state(s),"busy"),"preparation is real mutation busy");ok(!action(s,"sdDelete",1),"mutations mutually exclusive");ok(!s.guideDownload(new int[]{2}),"RAM replacement rejected throughout save");
        boolean sawUpload=false,sawSave=false;long token=0;
        for(int i=0;i<300&&!sawSave;i++){m.tick(now);Session.Send send=s.tick(now);now+=40;if(send==null)continue;if(send.frame.cmd==0x12)sawUpload=true;if(send.frame.cmd==0x17){sawSave=true;token=(send.frame.d[2]&255L)|(send.frame.d[3]&255L)<<8|(send.frame.d[4]&255L)<<16|(send.frame.d[5]&255L)<<24;ok(sawUpload,"SAVE occurs only after THIS RAM commit");}s.receive(Protocol.decode(m.accept(send.frame.bytes(),now)));}
        ok(sawSave&&token!=0,"save has nonzero 32-bit operation token");eq(1,field(state(s),"busy"),"short ACK cannot claim saved");ok(!message(s).contains("保存成功"),"no fake success before polling actual completion");untilDone(s,m);ok(message(s).contains("保存成功"),"matching final identity reports success");entries=(Object[])state(s).getClass().getField("entries").get(state(s));eq(2,field(entries[7],"steps"),"catalog refreshed from device");String title=(String)entries[7].getClass().getField("title").get(entries[7]);ok(title.getBytes(StandardCharsets.UTF_8).length<=32&&!title.contains("�"),"UTF8 title truncation preserves characters");
        ok(action(s,"sdLoad",7),"load accepted");untilDone(s,m);eq(2,s.guideState().total,"load re-queries actual RAM guide");ok(action(s,"sdDelete",7),"delete accepted");untilDone(s,m);entries=(Object[])state(s).getClass().getField("entries").get(state(s));eq(0,field(entries[7],"steps"),"delete refreshes actual catalog");
        long revision=field(state(s),"revision");String text=message(s);for(int i=0;i<4;i++){refresh(s);run(s,m,1200);}eq(revision,field(state(s),"revision"),"unchanged polling emits no idle UI revision");ok(text.equals(message(s)),"idle polling preserves message");
        Session recovered=new Session();discover(recovered,m);List<Protocol.Frame> reconnect=run(recovered,m,2000);for(Protocol.Frame f:reconnect)ok(f.cmd!=0x17,"reconnect never repeats old mutation");eq(0,field(state(recovered),"busy"),"reconnect queries real identity without mutation");
    }
    static void wrongIdentityAndUnsupported()throws Exception{
        Session s=new Session();MockFpga m=new MockFpga();discover(s,m);scan(s);boolean accepted=false;for(int i=0;i<100&&!accepted;i++){Session.Send out=s.tick(now);now+=40;if(out==null)continue;accepted=out.frame.cmd==0x17;s.receive(Protocol.decode(m.accept(out.frame.bytes(),now)));}
        now+=1000;m.tick(now);refresh(s);for(int i=0;i<80;i++){Session.Send out=s.tick(now);now+=40;if(out==null)continue;Protocol.Frame reply=Protocol.decode(m.accept(out.frame.bytes(),now));if(out.frame.cmd==0x1b)reply=new Protocol.Frame(reply.seq,0x8e,new int[]{0,0,0,0,0,255});s.receive(reply);}
        eq(1,field(state(s),"busy"),"different token success never completes our transaction");
        Session legacy=new Session();refresh(legacy);for(int i=0;i<80;i++){Session.Send out=legacy.tick(now);now+=40;if(out==null)continue;Protocol.Frame reply=out.frame.cmd>=0x16?new Protocol.Frame(out.frame.seq,0x80,new int[]{out.frame.cmd,2,1,0,0,0}):Protocol.decode(m.accept(out.frame.bytes(),now));legacy.receive(reply);}
        eq(-1,field(state(legacy),"capability"),"old FPGA disables only SD capability");ok(!action(legacy,"sdLoad",0),"unsupported cannot mutate");legacy.setMask(1);boolean keys=false;for(Protocol.Frame f:run(legacy,m,1000))if(f.cmd==4)keys=true;ok(keys,"old FPGA music commands remain functional");
    }
    static void cancelledQueuedSaveAndFailedSameCountUpload()throws Exception{
        Session queued=new Session();MockFpga device=new MockFpga();discover(queued,device);queued.guideRefresh();ok(save(queued,0,"cancelled",1),"save queues this upload behind read-only guide query");queued.guideCancel();run(queued,device,3000);eq(0,field(state(queued),"busy"),"cancelled queued upload releases SD reservation");eq(0,request(device,0x19,0).d[1],"cancelled queued upload never saves");
        Session failed=new Session();MockFpga old=new MockFpga();discover(failed,old);ok(failed.guideDownload(new int[]{1}),"old one-step RAM upload");run(failed,old,2000);ok(save(failed,0,"new one step",2),"same-count new upload accepted");boolean saveSent=false,commitRejected=false;for(int i=0;i<150;i++){Session.Send out=failed.tick(now);now+=40;if(out==null)continue;Protocol.Frame reply=Protocol.decode(old.accept(out.frame.bytes(),now));if(out.frame.cmd==0x12){commitRejected=true;reply=new Protocol.Frame(out.frame.seq,0x80,new int[]{0x12,3,1,0,0,0});}if(out.frame.cmd==0x17)saveSent=true;failed.receive(reply);}
        ok(commitRejected,"THIS commit failure exercised");ok(!saveSent,"matching old step count cannot fake this upload completion");eq(0,field(state(failed),"busy"),"failed upload releases reservation without SD write");
    }
    static void catalogFairToKeysAndQueuedIntent()throws Exception{
        Session s=new Session();MockFpga m=new MockFpga();discover(s,m);scan(s);boolean catalog=false;for(int i=0;i<100;i++){refresh(s);Session.Send out=s.tick(now);now+=40;m.tick(now);if(out==null)continue;s.receive(Protocol.decode(m.accept(out.frame.bytes(),now)));if(out.frame.cmd==0x19){catalog=true;break;}}
        ok(catalog,"catalog read in progress");s.setMask(3);int beforeKey=0;boolean keySent=false;for(int i=0;i<30;i++){Session.Send out=s.tick(now);now+=40;if(out==null)continue;if(out.frame.cmd==4){keySent=true;break;}if(out.frame.cmd>=0x16)beforeKey++;s.receive(Protocol.decode(m.accept(out.frame.bytes(),now)));}ok(keySent&&beforeKey<=3,"catalog cannot starve live key changes");
        // Finish the key ACK and queue a mutation while a read-only catalog is active.
        if(keySent){Session.Send retry=s.tick(now+500);now+=540;if(retry!=null)s.receive(Protocol.decode(m.accept(retry.frame.bytes(),now)));}
        ok(action(s,"sdLoad",0),"load tap accepted during catalog read");boolean operation=false;for(Protocol.Frame frame:run(s,m,2500))if(frame.cmd==0x17)operation=true;ok(operation,"queued mutation starts after current catalog packet");
    }
    static void initialCatalog()throws Exception{
        MockFpga device=new MockFpga();Session writer=new Session();discover(writer,device);
        ok(save(writer,0,"Existing score",1,1<<17),"seed an existing score");untilDone(writer,device);
        Session fresh=new Session();refresh(fresh);List<Protocol.Frame> frames=run(fresh,device,6000);
        eq(1,fresh.sdState().catalogLoaded,"first ready status automatically fetches existing catalog");
        eq(2,fresh.sdState().entries[0].steps,"existing slot0 visible without pressing rescan");
        for(Protocol.Frame f:frames)ok(f.cmd!=0x17,"startup catalog discovery is read-only");
        long revision=fresh.sdState().revision;refresh(fresh);run(fresh,device,1200);
        eq(revision,fresh.sdState().revision,"subsequent identical status is stable");
    }
    static SdLibraryFlow readyFlow(){SdLibraryFlow f=new SdLibraryFlow();f.version=2;f.capability=1;f.state=1;f.flags=3;f.catalogLoaded=true;return f;}
    static void completeScan(SdLibraryFlow f,int flags){
        long token=f.expected;Protocol.Frame op=f.request();f.receive(op,new Protocol.Frame(0,0x80,new int[]{0x17,0,2,0,0,0}));
        f.refresh();Protocol.Frame status=f.request();f.receive(status,new Protocol.Frame(0,0x8b,new int[]{2,1,0,100,255,flags}));
        Protocol.Frame identity=f.request();f.receive(identity,new Protocol.Frame(0,0x8e,new int[]{(int)token&255,(int)(token>>>8)&255,(int)(token>>>16)&255,(int)(token>>>24)&255,0,255}));
    }
    static void lockedVolumeReadOnly(){
        SdLibraryFlow f=readyFlow();ok(f.start(0,255),"scan begins before final lock report");completeScan(f,27);
        ok(f.message.contains("成功")&&f.message.contains("写入保护")&&!f.message.contains("失败"),"successful read-only scan reports write protection instead of failure with no error");
        ok(f.canStart(0,2),"write protection permits validated SD reads");
        ok(!f.canStart(0,1)&&!f.canStart(0,3),"write protection still forbids save/delete");
        SdLibraryFlow write=readyFlow();ok(write.reservePhone(1,0,P18File.encode("Test",new int[]{1})),"phone save reserves writable volume");write.phoneFinished(null);completeScan(write,27);
        ok(write.message.contains("未确认")&&write.message.contains("写入保护")&&!write.message.contains("无错误"),"late write lock cannot confirm a phone save");
        SdLibraryFlow unconfirmed=readyFlow();ok(unconfirmed.start(0,255),"scan with missing done flag starts");completeScan(unconfirmed,3);
        ok(unconfirmed.message.contains("未确认")&&!unconfirmed.message.contains("无错误"),"missing completion flag has actionable reason rather than no-error failure");
    }
    public static void main(String[] args)throws Exception{if(args.length>0&&args[0].equals("lock")){lockedVolumeReadOnly();return;}if(args.length>0&&args[0].equals("initial")){initialCatalog();return;}state(new Session());protocol();transactions();wrongIdentityAndUnsupported();cancelledQueuedSaveAndFailedSameCountUpload();catalogFairToKeysAndQueuedIntent();initialCatalog();lockedVolumeReadOnly();System.out.println("PASS "+checks+" SD protocol/session checks (simulator, no hardware)");}
}
