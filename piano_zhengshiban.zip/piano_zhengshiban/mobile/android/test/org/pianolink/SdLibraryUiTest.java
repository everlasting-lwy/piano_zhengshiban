package org.pianolink;
import android.app.Activity;
import android.view.View;
import android.widget.*;
import java.lang.reflect.*;
public final class SdLibraryUiTest {
    static int checks;static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    static Object field(Object owner,String name)throws Exception{Field f=owner.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(owner);}
    public static void main(String[] args)throws Exception{
        Class<?> type;try{type=Class.forName("org.pianolink.SdLibraryUi");}catch(ClassNotFoundException e){throw new AssertionError("SD panel missing",e);}Class<?> host=Class.forName("org.pianolink.SdLibraryUi$Host");final Session session=new Session();final int[] scans={0};Object proxy=Proxy.newProxyInstance(host.getClassLoader(),new Class<?>[]{host},(p,m,a)->{if(m.getName().equals("scan")){scans[0]++;return session.sdScan();}if(m.getReturnType()==boolean.class)return false;return null;});Activity activity=new Activity();Object ui=type.getConstructor(Activity.class,LinearLayout.class,host).newInstance(activity,new LinearLayout(activity),proxy);
        try{type.getMethod("connection",boolean.class,boolean.class).invoke(ui,true,true);
            type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,session.sdState());
            ok(((TextView)field(ui,"selection")).getText().toString().contains("尚未读取"),"unknown catalog is not reported as zero songs");
            ok(((Button[])field(ui,"slots"))[0].getText().toString().contains("待扫描"),"unread slot is not labeled empty");
            SdLibraryFlow transfer=new SdLibraryFlow();transfer.capability=1;transfer.version=2;transfer.state=1;
            ok(transfer.reservePhone(1,0,P18File.encode("Test",new int[]{1})),"prepare actual phone transfer state");
            transfer.phoneProgress(false,7660,64);type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,transfer.snapshot());
            String progress=((TextView)field(ui,"status")).getText().toString();
            ok(progress.contains("地址 LBA 7660")&&progress.contains("不是累计数量")&&progress.contains("64 / 128"),"sector address and per-sector chunks are labeled separately");
            SdLibraryFlow locked=new SdLibraryFlow();locked.capability=1;locked.version=2;locked.state=1;locked.flags=27;locked.catalogLoaded=true;
            SdLibraryFlow.State lockedSnapshot=locked.snapshot();lockedSnapshot.entries[0]=new SdLibraryFlow.Entry(0,1,18,"Existing score");type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,lockedSnapshot);
            ok(((View)field(ui,"load")).isEnabled(),"locked volume still permits read-only load");
            ok(!((View)field(ui,"save")).isEnabled()&&!((View)field(ui,"delete")).isEnabled(),"locked volume retains all write protection");
            String lockedStatus=((TextView)field(ui,"status")).getText().toString();
            ok(lockedStatus.contains("写入保护")&&lockedStatus.contains("0x1B"),"UI exposes exact protection condition and raw flags");
            session.sdRefresh();MockFpga device=new MockFpga();for(long now=0;now<1500;now+=40){Session.Send send=session.tick(now);if(send!=null)session.receive(Protocol.decode(device.accept(send.frame.bytes(),now)));}type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,session.sdState());
            Button[] slots=(Button[])field(ui,"slots");ok(slots.length==32,"panel has all32 selectable slots");slots[31].performClick();ok(((Integer)field(ui,"selected"))==31,"last slot selectable");ok(((View)field(ui,"scan")).isEnabled(),"scan enabled when supported");TextView status=(TextView)field(ui,"status");int writes=status.textWrites;session.sdRefresh();type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,session.sdState());ok(((View)field(ui,"scan")).isEnabled(),"read-only polling does not disable UI");ok(writes==status.textWrites,"unchanged polling does not rewrite status");((View)field(ui,"scan")).performClick();ok(scans[0]==1,"scan button dispatches actual host intent");type.getMethod("snapshot",SdLibraryFlow.State.class).invoke(ui,session.sdState());ok(!((View)field(ui,"save")).isEnabled(),"real transaction disables save");ok(!((View)field(ui,"delete")).isEnabled(),"real transaction disables delete");ok(status.getText().toString().contains("模拟"),"simulation labeled honestly");
        }finally{type.getMethod("close").invoke(ui);}
        System.out.println("PASS "+checks+" SD library panel/idle checks");
    }
}
