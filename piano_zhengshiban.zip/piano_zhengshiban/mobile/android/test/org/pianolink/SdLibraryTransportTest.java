package org.pianolink;
import android.bluetooth.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

/** Real controller/service lifecycle. External radio only; SD model is explicitly simulated. */
public final class SdLibraryTransportTest {
    static int checks;interface Condition{boolean value();}
    static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    static void until(Condition condition,String why)throws Exception{long end=System.nanoTime()+12000000000L;while(!condition.value()&&System.nanoTime()<end)Thread.sleep(15);ok(condition.value(),why);}
    static Object call(Object owner,String method,Class<?>[] types,Object... args)throws Exception{try{return owner.getClass().getMethod(method,types).invoke(owner,args);}catch(NoSuchMethodException e){throw new AssertionError("missing production SD bridge "+method,e);}}
    static Object snapshot(LinkSession link)throws Exception{return call(link,"sdState",new Class<?>[0]);}
    static long number(Object snapshot,String field){try{return snapshot.getClass().getField(field).getLong(snapshot);}catch(Exception e){throw new AssertionError(e);}}
    static Object[] entries(Object snapshot){try{return (Object[])snapshot.getClass().getField("entries").get(snapshot);}catch(Exception e){throw new AssertionError(e);}}
    static final class Events implements LinkController.Listener {volatile int connected,ended;public void connected(boolean simulated){connected++;}public void ended(String reason){ended++;}public void frame(Protocol.Frame f){}public void message(String value){}}
    static final class Radio extends BluetoothSocket {
        final PipedInputStream input=new PipedInputStream(8192);final PipedOutputStream incoming=new PipedOutputStream(input);final Protocol.Decoder decoder=new Protocol.Decoder();final MockFpga fpga=new MockFpga();final List<Protocol.Frame> requests=Collections.synchronizedList(new ArrayList<Protocol.Frame>());volatile boolean closed,dropOperationAck=true;
        Radio()throws IOException{}public void connect(){}public InputStream getInputStream(){return input;}public OutputStream getOutputStream(){return new OutputStream(){public void write(int value)throws IOException{Protocol.Frame f=decoder.feed((byte)value);if(f==null)return;requests.add(f);byte[] response=fpga.accept(f.bytes(),System.nanoTime()/1000000);if(f.cmd==0x17&&dropOperationAck){dropOperationAck=false;return;}if(response!=null&&!closed){incoming.write(response);incoming.flush();}}};}
        public void close()throws IOException{closed=true;incoming.close();input.close();}
        int count(int command){int result=0;synchronized(requests){for(Protocol.Frame f:requests)if(f.cmd==command)result++;}return result;}
    }
    public static void main(String[] args)throws Exception{
        LinkSession link=new LinkSession();snapshot(link);Radio radio=new Radio();Events first=new Events();link.attach(first);
        try{link.connect(false,new BluetoothDevice(radio,radio),false);until(()->first.connected==1,"controller ready");until(()->{try{return snapshot(link)!=null&&number(snapshot(link),"capability")==1;}catch(Exception e){return false;}},"service discovers SD by read-only pair");
            ok((Boolean)call(link,"sdScan",new Class<?>[]{LinkController.Listener.class},first),"service accepts explicit scan");link.detach(first);int beats=radio.count(7);until(()->radio.count(7)>beats,"heartbeats continue while UI detached");until(()->{try{return number(snapshot(link),"catalogLoaded")==1;}catch(Exception e){return false;}},"SD operation and catalog finish in background");
            Events second=new Events();link.attach(second);ok(second.connected==1,"reattach retains transport");ok((Boolean)call(link,"sdSave",new Class<?>[]{LinkController.Listener.class,int.class,String.class,int[].class},second,3,"背景保存",new int[]{1,2,4}),"new UI can save");ok(!(Boolean)call(link,"sdDelete",new Class<?>[]{LinkController.Listener.class,int.class},first,3),"stale UI cannot mutate replacement session");link.pause(second);until(()->{try{return number(entries(snapshot(link))[3],"steps")==3;}catch(Exception e){return false;}},"save survives onPause and refreshes actual catalog");
            List<Protocol.Frame> operations=new ArrayList<>();synchronized(radio.requests){for(Protocol.Frame f:radio.requests)if(f.cmd==0x17)operations.add(f);}ok(operations.size()>=3,"lost ACK retried plus save");ok(operations.get(0).seq==operations.get(1).seq&&Arrays.equals(operations.get(0).d,operations.get(1).d),"retry keeps same SEQ/token/action/slot");ok(!radio.closed,"service ownership keeps radio alive");
            int catalogRequests=radio.count(0x19),statuses=radio.count(0x16);until(()->radio.count(0x16)>=statuses+2,"periodic SD status runs");ok(radio.count(0x19)==catalogRequests,"idle poll does not flood catalog at9600baud");
        }finally{link.disconnect("test complete");}
        LinkSession simulated=new LinkSession();Events events=new Events();simulated.attach(events);
        try{simulated.connect(true,null,false);until(()->simulated.ready()&&simulated.sdState().capability==1,"simulation SD ready");ok(simulated.sdState().version==2,"default simulator advertises V2 sector RPC");ok(simulated.sdScan(events),"simulation scans ordinary sector FAT32");until(()->simulated.sdState().catalogLoaded==1,"simulation catalog read completes");simulated.disconnect("simulated power cycle");simulated.connect(true,null,false);until(()->simulated.ready()&&simulated.sdState().capability==1,"simulated device restarts");ok(simulated.sdScan(events),"restarted simulator scans same card");until(()->simulated.sdState().catalogLoaded==1,"restarted catalog finishes");ok(simulated.sdState().version==2,"recreated service transport retains V2 capability");}finally{simulated.disconnect("simulation test complete");}
        System.out.println("PASS "+checks+" SD controller/service checks (host radio, no hardware)");
    }
}
