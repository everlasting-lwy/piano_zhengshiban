package org.pianolink;
import java.lang.reflect.*;
public final class LibraryWorkTest {
    static int checks;
    static void ok(boolean v,String m){checks++;if(!v)throw new AssertionError(m);}
    static Object call(Object o,String n,Class<?>[] t,Object...a)throws Exception{return o.getClass().getMethod(n,t).invoke(o,a);}
    public static void main(String[]args)throws Exception{
        Class<?> type;try{type=Class.forName("org.pianolink.LibraryWork");}catch(ClassNotFoundException e){throw new AssertionError("Library work needs cancellation/commit ownership independent of Activity",e);}
        Object jobs=type.getConstructor().newInstance();Object first=call(jobs,"begin",new Class<?>[0]);Class<?> token=first.getClass();
        ok((Boolean)call(jobs,"owns",new Class<?>[]{token},first),"current task owns UI result");Object second=call(jobs,"begin",new Class<?>[0]);
        ok(!(Boolean)call(jobs,"owns",new Class<?>[]{token},first),"old load cannot replace newer selection");ok((Boolean)call(first,"cancelled",new Class<?>[0]),"superseded job canceled");
        boolean deliver;try{deliver=(Boolean)call(jobs,"mayDeliverMutation",new Class<?>[0]);}catch(NoSuchMethodException missing){throw new AssertionError("A newer read must not suppress reconciliation of a committed delete",missing);}
        ok(deliver,"committed delete/rename results still reconcile after a newer read");
        ok(!(Boolean)call(first,"claimCommit",new Class<?>[0]),"late old job cannot persist");
        call(jobs,"cancel",new Class<?>[0]);ok((Boolean)call(second,"cancelled",new Class<?>[0]),"onStop cancels current conversion");ok(!(Boolean)call(second,"claimCommit",new Class<?>[0]),"canceled inference cannot save a song");
        Object third=call(jobs,"begin",new Class<?>[0]);ok((Boolean)call(third,"claimCommit",new Class<?>[0]),"completed conversion atomically claims save");
        ok(!(Boolean)call(third,"cancel",new Class<?>[0]),"cancel is not falsely acknowledged after atomic commit began");ok(!(Boolean)call(third,"claimCommit",new Class<?>[0]),"commit can only be claimed once");
        call(third,"finish",new Class<?>[0]);ok((Boolean)call(jobs,"owns",new Class<?>[]{token},third),"completed job can render its one result");
        call(jobs,"close",new Class<?>[0]);ok(!(Boolean)call(jobs,"owns",new Class<?>[]{token},third),"destroyedActivity ignores late result");
        ok(!(Boolean)call(jobs,"mayDeliverMutation",new Class<?>[0]),"destroyed page ignores mutation UI callbacks too");
        Class<?> export;try{export=Class.forName("org.pianolink.PendingCsvExport");}catch(ClassNotFoundException missing){throw new AssertionError("Export needs a durable snapshot when the picker recreates Activity",missing);}
        java.io.File folder=java.io.File.createTempFile("piano-export-",".state");folder.delete();folder.mkdir();
        String csv="time_ms,mask36,voices\n0,34359738368,1\n100,0,0\n";
        Object before=export.getConstructor(java.io.File.class).newInstance(folder);call(before,"save",new Class<?>[]{String.class},csv);
        Object after=export.getConstructor(java.io.File.class).newInstance(folder);ok(csv.equals(call(after,"load",new Class<?>[0])),"replacement Activity can export original36-bit snapshot");
        call(after,"clear",new Class<?>[0]);boolean absent=false;try{call(after,"load",new Class<?>[0]);}catch(InvocationTargetException e){absent=e.getCause() instanceof java.io.IOException;}ok(absent,"completed export clears private pending data");folder.delete();
        System.out.println("PASS "+checks+" library work lifecycle checks");
    }
}
