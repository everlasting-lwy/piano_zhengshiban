package org.pianolink;

import java.io.*;
import java.util.*;

/** Real filesystem transactions against a sparse, fault-injectable block image. */
public final class Fat32StoreTest {
    static int checks;
    static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    static int u16(byte[] a,int p){return(a[p]&255)|(a[p+1]&255)<<8;}
    static long u32(byte[] a,int p){return(a[p]&255L)|(a[p+1]&255L)<<8|(a[p+2]&255L)<<16|(a[p+3]&255L)<<24;}
    static void p16(byte[] a,int p,int n){a[p]=(byte)n;a[p+1]=(byte)(n>>>8);}
    static void p32(byte[] a,int p,long n){for(int i=0;i<4;i++)a[p+i]=(byte)(n>>>(8*i));}
    static byte[] song(int count){int[] masks=new int[count];for(int i=0;i<count;i++)masks[i]=(1<<(i%18))|(1<<((i+5)%18));return P18File.encode("你好🎹",masks);}
    public static final class Card implements Fat32Store.BlockDevice {
        public long base=0,clusters=65530,fatsz=512,sectors,data=1056;public int spc=1,fats=2,active=0;
        public final Map<Long,byte[]> pages=new HashMap<Long,byte[]>();
        public boolean full;public int writes,reads,failWrite,failRead,corruptWrite;public String fault="before";
        public byte[] old=song(220);public final List<Long> written=new ArrayList<Long>();public final List<byte[]> writeData=new ArrayList<byte[]>();
        public Card(){this("super");}
        public Card(String kind){
            if(kind.equals("mbr")||kind.equals("active"))base=2048;
            if(kind.equals("spc8"))spc=8;if(kind.equals("single"))fats=1;
            if(kind.equals("16gb")){base=2048;spc=64;fatsz=3815;clusters=488129;}
            if(kind.equals("bound")){clusters=1048700;fatsz=(clusters+129)/128;}full=kind.equals("full")||kind.equals("bound");
            sectors=base+32+fats*fatsz+clusters*spc;data=base+32+fats*fatsz;
            if(kind.equals("16gb"))sectors=31250000; // 16,000,000,000-byte card; sparse memory only.
            byte[] boot=new byte[512];boot[0]=(byte)0xeb;boot[2]=(byte)0x90;p16(boot,11,512);boot[13]=(byte)spc;p16(boot,14,32);boot[16]=(byte)fats;boot[21]=(byte)0xf8;p32(boot,32,sectors-base);p32(boot,36,fatsz);p32(boot,44,2);p16(boot,48,1);p16(boot,50,6);boot[510]=0x55;boot[511]=(byte)0xaa;
            if(kind.equals("active")){active=1;p16(boot,40,0x81);}
            pages.put(base,boot);pages.put(base+6,boot.clone());
            if(base!=0){byte[] m=new byte[512];m[450]=0x0c;p32(m,454,base);p32(m,458,sectors-base);m[510]=0x55;m[511]=(byte)0xaa;pages.put(0L,m);}
            byte[] fsi=new byte[512];p32(fsi,0,0x41615252L);p32(fsi,484,0x61417272L);p32(fsi,488,1234);p32(fsi,492,20);p32(fsi,508,0xaa550000L);pages.put(base+1,fsi);pages.put(base+7,fsi.clone());
            for(long[] pair:new long[][]{{0,0xaffffff8L},{1,0xafffffffL},{2,0xa0000007L},{7,0xafffffffL},{4,0xafffffffL},{5,spc==1?0xa0000009L:0xafffffffL},{9,0xafffffffL}})fat(pair[0],pair[1]);
            if(active==1)fatCopy(0,2,0);
            byte[] first=new byte[512];for(int i=0;i<16;i++){byte[] e=entry(String.format(Locale.ROOT,"FILE%04dTXT",i),4,9,0x20);System.arraycopy(e,0,first,i*32,32);}for(int i=0;i<spc;i++)pages.put(data+i,first.clone());
            byte[] second=new byte[512];System.arraycopy(entry("P0000003P18",5,old.length,0x20),0,second,0,32);pages.put(lba(7),second);
            byte[] ordinary=new byte[512];System.arraycopy(new byte[]{111,114,100,105,110,97,114,121,33},0,ordinary,0,9);pages.put(lba(4),ordinary);
            for(int i=0;i<(old.length+511)/512;i++){byte[] b=new byte[512];System.arraycopy(old,i*512,b,0,Math.min(512,old.length-i*512));pages.put(spc==1?lba(i==0?5:9):lba(5)+i,b);}
        }
        public long lba(long c){return data+(c-2)*spc;}
        public long sectorCount(){return sectors;}
        public byte[] raw(long lba){byte[] b=pages.get(lba);if(b!=null)return b.clone();b=new byte[512];if(full&&lba>=base+32&&lba<base+32+fats*fatsz)Arrays.fill(b,(byte)255);return b;}
        public byte[] read(long lba)throws IOException{reads++;if(lba<0||lba>=sectors)throw new IOException("outside card");if(failRead==reads)throw new IOException("injected read");return raw(lba);}
        public void write(long lba,byte[] b)throws IOException{if(lba<0||lba>=sectors||b.length!=512)throw new IOException("outside card/write size");writes++;written.add(lba);writeData.add(b.clone());if(writes==failWrite&&fault.equals("before"))throw new IOException("injected before write");byte[] copy=b.clone();if(writes==corruptWrite)copy[100]^=1;pages.put(lba,copy);if(writes==failWrite&&fault.equals("after"))throw new IOException("injected after write");if(writes==failWrite&&fault.equals("verify"))failRead=reads+1;}
        public void fat(long c,long value){for(int f=0;f<fats;f++)fatCopy(f,c,value);}
        public void fatCopy(int copy,long c,long value){long l=base+32+copy*fatsz+c/128;byte[] b=raw(l);p32(b,(int)(c%128)*4,value);pages.put(l,b);}
        public long fatValue(int copy,long c){return u32(raw(base+32+copy*fatsz+c/128),(int)(c%128)*4);}
        public void resetFault(){failWrite=failRead=corruptWrite=0;}
        public void export(File path)throws IOException{RandomAccessFile f=new RandomAccessFile(path,"rw");try{f.setLength(sectors*512);if(full)for(long l=base+32;l<base+32+fats*fatsz;l++){f.seek(l*512);f.write(raw(l));}for(Map.Entry<Long,byte[]> e:pages.entrySet()){f.seek(e.getKey()*512);f.write(e.getValue());}}finally{f.close();}}
    }
    static byte[] entry(String name,long start,long size,int attr){byte[] e=new byte[32];try{byte[] n=name.getBytes("US-ASCII");System.arraycopy(n,0,e,0,11);}catch(Exception x){throw new AssertionError(x);}e[11]=(byte)attr;p16(e,20,(int)(start>>>16));p16(e,26,(int)start);p32(e,28,size);return e;}
    static byte[] find(Card c,int slot){String name=String.format(Locale.ROOT,"P%07dP18",slot);Set<Long> seen=new HashSet<Long>();long cl=2;while(cl<0xffffff8L){ok(seen.add(cl),"checker root cycle");for(int s=0;s<c.spc;s++){byte[] b=c.raw(c.lba(cl)+s);for(int o=0;o<512;o+=32){if(b[o]==0)return null;if((b[o]&255)==229)continue;try{if(new String(b,o,11,"US-ASCII").equals(name))return Arrays.copyOfRange(b,o,o+32);}catch(Exception x){throw new AssertionError(x);}}}cl=c.fatValue(c.active,cl)&0xfffffffL;}return null;}
    static byte[] content(Card c,int slot){byte[] e=find(c,slot);if(e==null)return null;int size=(int)u32(e,28),at=0;byte[] out=new byte[size];Set<Long> seen=new HashSet<Long>();long cl=u16(e,26)|((long)u16(e,20)<<16);while(at<size){ok(cl>=2&&cl<c.clusters+2&&seen.add(cl),"checker file chain");for(int s=0;s<c.spc&&at<size;s++){byte[] b=c.raw(c.lba(cl)+s);int n=Math.min(512,size-at);System.arraycopy(b,0,out,at,n);at+=n;}cl=c.fatValue(c.active,cl)&0xfffffffL;}ok(cl>=0xffffff8L,"checker unexpected extra cluster");return out;}
    interface Action{void run()throws Exception;}
    static Fat32Store.StoreException rejects(Card c,Action action,Fat32Store.Reason reason)throws Exception{int before=c.writes;try{action.run();throw new AssertionError("expected "+reason);}catch(Fat32Store.StoreException e){ok(reason==null||e.reason==reason,"reason "+e.reason+" expected "+reason);ok(c.writes==before,"preflight must not write");return e;}}
    static void ordinary(Card c){ok(Arrays.equals(Arrays.copyOf(c.raw(c.lba(4)),9),new byte[]{111,114,100,105,110,97,114,121,33}),"ordinary contents preserved");byte[] root=c.raw(c.data);try{ok(new String(root,0,11,"US-ASCII").equals("FILE0000TXT"),"ordinary directory not hidden");}catch(Exception x){throw new AssertionError(x);}}
    static void successful(String kind,File export)throws Exception{Card c=new Card(kind);byte[] next=song(350);Fat32Store fs=new Fat32Store(c);fs.save(3,next);ok(Arrays.equals(content(c,3),next),"published exact P18 "+kind);ok((c.fatValue(c.active,5)&0xfffffffL)==0,"old head freed");if(c.spc==1)ok((c.fatValue(c.active,9)&0xfffffffL)==0,"old tail freed");ok(c.fatValue(c.active,5)>>>28==10,"upper nibble retained");ordinary(c);for(long l:new long[]{c.base+1,c.base+7}){byte[] b=c.raw(l);ok(u32(b,488)==0xffffffffL&&u32(b,492)==0xffffffffL,"FSInfo invalidated");}ok((c.fatValue(c.active,1)&0x8000000L)!=0,"clean only after publication");if(export!=null)c.export(export);fs.delete(3);ok(find(c,3)==null,"delete published absence");ordinary(c);}
    static void preflightTests()throws Exception{
        for(final String kind:new String[]{"bad_header","readonly","directory","dirty","temp","cycle","range","root_cycle","end_self","end_back","crosslink","prefix_crosslink","free_crosslink","bad_geometry","fat16","bad_version","mirror"}){
            final Card c=new Card();byte[] root=c.raw(c.lba(7));
            if(kind.equals("bad_header")){byte[] b=c.raw(c.lba(5));b[62]^=1;c.pages.put(c.lba(5),b);}
            if(kind.equals("readonly"))root[11]=1;if(kind.equals("directory"))root[11]=16;
            if(kind.equals("dirty"))c.fat(1,0xa7ffffffL);
            if(kind.equals("temp"))System.arraycopy(entry("T0000009P18",12,67,32),0,root,32,32);
            if(kind.equals("cycle"))c.fat(9,5);if(kind.equals("range"))c.fat(5,c.clusters+7);
            if(kind.equals("root_cycle")) {c.fat(7,2);Arrays.fill(root,(byte)65);}
            if(kind.equals("end_self")){byte[] b=c.raw(c.data);Arrays.fill(b,480,512,(byte)0);c.pages.put(c.data,b);c.fat(2,2);}
            if(kind.equals("end_back")){for(int i=1;i<15;i++)System.arraycopy(entry(String.format(Locale.ROOT,"FULL%04dTXT",i),4,9,32),0,root,i*32,32);c.fat(7,2);}
            if(kind.equals("crosslink")||kind.equals("prefix_crosslink")||kind.equals("free_crosslink")){byte[] b=c.raw(c.data);p16(b,26,kind.equals("crosslink")?5:kind.equals("prefix_crosslink")?12:3);if(kind.equals("prefix_crosslink"))c.fat(12,5);c.pages.put(c.data,b);}
            if(kind.equals("bad_geometry"))p16(c.pages.get(0L),11,1024);if(kind.equals("fat16"))p32(c.pages.get(0L),32,10000);if(kind.equals("bad_version"))p16(c.pages.get(0L),42,1);if(kind.equals("mirror"))c.fatCopy(1,5,0xfffffffL);
            c.pages.put(c.lba(7),root);final Fat32Store fs=new Fat32Store(c);rejects(c,new Action(){public void run()throws Exception{fs.save(3,song(350));}},null);
        }
        for(final String kind:new String[]{"full","bound"}){final Card c=new Card(kind);final Fat32Store fs=new Fat32Store(c);rejects(c,new Action(){public void run()throws Exception{fs.save(3,song(350));}},kind.equals("full")?Fat32Store.Reason.FULL:Fat32Store.Reason.SEARCH_LIMIT);}
    }
    static void faults()throws Exception{
        Card baseline=new Card();new Fat32Store(baseline).save(3,song(350));int total=baseline.writes,publish=0;
        for(int i=0;i<total;i++)if(baseline.written.get(i)==baseline.lba(7)&&u16(baseline.writeData.get(i),26)!=5){publish=i+1;break;}
        ok(publish>0,"write trace includes publication");
        ok(baseline.written.get(0)==baseline.base+32&&(u32(baseline.writeData.get(0),4)&0x8000000L)==0,"dirty is first write");
        ok(baseline.written.get(total-1)==baseline.base+32+baseline.fatsz&&(u32(baseline.writeData.get(total-1),4)&0x8000000L)!=0,"clean is final write");
        for(String mode:new String[]{"before","after","verify","corrupt"})for(int index=1;index<=total;index++){
            final Card c=new Card();final Fat32Store fs=new Fat32Store(c);c.fault=mode;if(mode.equals("corrupt"))c.corruptWrite=index;else c.failWrite=index;
            try{fs.save(3,song(350));throw new AssertionError("fault hidden "+mode+"/"+index);}catch(IOException expected){}
            c.resetFault();byte[] actual=content(c,3);ok(Arrays.equals(actual,c.old)||Arrays.equals(actual,song(350)),"fault retains complete old/new publication "+mode+"/"+index);ordinary(c);
            if(index<publish||(index==publish&&mode.equals("before")))ok(Arrays.equals(actual,c.old),"every prepublication failure retains old target");
            ok(c.writes==index,"failed save performs no rollback/cleanup writes");
            final int after=c.writes;try{fs.save(3,song(350));throw new AssertionError("uncertain writer reused");}catch(Fat32Store.StoreException e){ok(e.reason==Fat32Store.Reason.WRITE_LOCKED,"uncertain reason");}ok(c.writes==after,"uncertain retry issued no writes");
        }
    }
    // Catches freeing before directory removal, a missing readback, and dirty
    // failures being silently retried after a delete has partly changed metadata.
    static void deleteFaults()throws Exception{
        Card baseline=new Card();new Fat32Store(baseline).delete(3);
        for(String mode:new String[]{"before","after","verify","corrupt"})for(int index=1;index<=baseline.writes;index++){
            final Card c=new Card();final Fat32Store fs=new Fat32Store(c);c.fault=mode;if(mode.equals("corrupt"))c.corruptWrite=index;else c.failWrite=index;
            try{fs.delete(3);throw new AssertionError("delete fault hidden "+mode+"/"+index);}catch(IOException expected){}
            c.resetFault();byte[] actual=content(c,3);ok(actual==null||Arrays.equals(actual,c.old),"delete leaves old complete or absent");ordinary(c);
            ok(c.writes==index,"failed delete performs no cleanup writes");
            int before=c.writes;try{fs.delete(3);throw new AssertionError("uncertain delete retried");}catch(Fat32Store.StoreException e){ok(e.reason==Fat32Store.Reason.WRITE_LOCKED,"delete uncertainty lock");}ok(c.writes==before,"locked delete emits no writes");
        }
    }
    static void geometryAndMetadata(File dir)throws Exception{
        for(final String kind:new String[]{"spc0","spc3","fats0","fats3","root1","smallfat","oversize","exfat","mbr_extent","mbr_zero","mbr_type","file_bound","root_bound","directory_full","duplicate","bad_body","hard_error","subdir_crosslink","subdir_cycle"}){
            final Card c=new Card(kind.startsWith("mbr_")?"mbr":"super");byte[] b=c.pages.get(c.base),r=c.raw(c.lba(7));
            if(kind.equals("spc0"))b[13]=0;if(kind.equals("spc3"))b[13]=3;if(kind.equals("fats0"))b[16]=0;if(kind.equals("fats3"))b[16]=3;
            if(kind.equals("root1"))p32(b,44,1);if(kind.equals("smallfat"))p32(b,36,1);if(kind.equals("oversize"))p32(b,32,c.sectors-c.base+1);
            if(kind.equals("exfat")){b[11]=0;b[12]=0;}
            if(kind.equals("mbr_extent"))p32(c.pages.get(0L),458,c.sectors);if(kind.equals("mbr_zero"))p32(c.pages.get(0L),454,0);if(kind.equals("mbr_type"))c.pages.get(0L)[450]=7;
            if(kind.equals("file_bound")){c.fat(9,20);for(int i=20;i<33;i++)c.fat(i,i==32?0xfffffffL:i+1);}
            if(kind.equals("root_bound")){c.fat(2,10000);for(int i=10000;i<14096;i++)c.fat(i,i==14095?0xfffffffL:i+1);}
            if(kind.equals("directory_full"))for(int i=1;i<16;i++)System.arraycopy(entry(String.format(Locale.ROOT,"FULL%04dTXT",i),4,9,32),0,r,i*32,32);
            if(kind.equals("duplicate"))System.arraycopy(entry("P0000003P18",5,c.old.length,32),0,r,32,32);
            if(kind.equals("bad_body")){byte[] data=c.raw(c.lba(5));data[100]^=1;c.pages.put(c.lba(5),data);}
            if(kind.equals("hard_error"))c.fat(1,0xabffffffL);
            if(kind.startsWith("subdir_")){
                System.arraycopy(entry("SUBDIR     ",12,0,16),0,r,32,32);c.fat(12,kind.equals("subdir_cycle")?12:0xfffffffL);
                byte[] sub=new byte[512];System.arraycopy(entry(".          ",12,0,16),0,sub,0,32);System.arraycopy(entry("..         ",0,0,16),0,sub,32,32);System.arraycopy(entry("OTHER   BIN",5,c.old.length,32),0,sub,64,32);c.pages.put(c.lba(12),sub);
            }
            c.pages.put(c.lba(7),r);final Fat32Store fs=new Fat32Store(c);rejects(c,new Action(){public void run()throws Exception{fs.save(3,song(350));}},null);
        }
        // Copy-specific reserved high nibbles must survive both allocation and free.
        Card high=new Card();for(int i=0;i<128;i++)high.fatCopy(1,i,(high.fatValue(1,i)&0xfffffffL)|0xb0000000L);
        new Fat32Store(high).save(3,song(350));for(int i=0;i<128;i++)ok((high.fatValue(1,i)>>>28)==11,"each mirror upper nibble preserved");ok(Arrays.equals(content(high,3),song(350)),"different high nibbles do not imply mirror disagreement");if(dir!=null)high.export(new File(dir,"highnibble.img"));
        for(String kind:new String[]{"primary_bad","backup_bad","backup_boot_bad","no_fsinfo"}){
            Card c=new Card();if(kind.equals("primary_bad"))c.pages.get(c.base+1)[0]=0;if(kind.equals("backup_bad"))c.pages.get(c.base+7)[0]=0;if(kind.equals("backup_boot_bad"))c.pages.get(c.base+6)[13]=2;if(kind.equals("no_fsinfo"))p16(c.pages.get(c.base),48,0xffff);
            byte[] primary=c.raw(c.base+1),backup=c.raw(c.base+7);new Fat32Store(c).save(3,song(350));
            boolean updatePrimary=!kind.equals("primary_bad")&&!kind.equals("no_fsinfo"),updateBackup=kind.equals("primary_bad");
            ok(updatePrimary?u32(c.raw(c.base+1),488)==0xffffffffL:Arrays.equals(primary,c.raw(c.base+1)),"valid primary only "+kind);
            ok(updateBackup?u32(c.raw(c.base+7),488)==0xffffffffL:Arrays.equals(backup,c.raw(c.base+7)),"validated backup only "+kind);
        }
        // A preflight read error made no metadata uncertain and permits a new try.
        final Card retry=new Card();final Fat32Store fs=new Fat32Store(retry);retry.failRead=3;rejects(retry,new Action(){public void run()throws Exception{fs.save(3,song(350));}},Fat32Store.Reason.IO);retry.resetFault();fs.save(3,song(350));ok(Arrays.equals(content(retry,3),song(350)),"preflight read retry recovers");
        // A caller mutating its upload array after the first write cannot alter the frozen song.
        final Card card=new Card();final byte[] upload=song(350),expected=upload.clone();Fat32Store.BlockDevice changing=new Fat32Store.BlockDevice(){public long sectorCount(){return card.sectorCount();}public byte[] read(long l)throws IOException{return card.read(l);}public void write(long l,byte[] b)throws IOException{Arrays.fill(upload,(byte)0);card.write(l,b);}};new Fat32Store(changing).save(3,upload);ok(Arrays.equals(content(card,3),expected),"source cloned before first write");
        Card reboot=new Card();new Fat32Store(reboot).save(3,song(350));new Fat32Store(reboot).delete(3);ok(find(reboot,3)==null,"fresh instance sees saved ordinary file");
    }
    static void allocationHint()throws Exception{
        final int[] fatReads={0};
        final Card c=new Card("16gb");long hint=32768;
        for(long cluster=3;cluster<hint;cluster++)if(cluster!=5&&cluster!=7)c.fat(cluster,0xafffffffL);
        p32(c.pages.get(c.base+1),492,hint);p32(c.pages.get(c.base+7),492,hint);
        Fat32Store.BlockDevice measured=new Fat32Store.BlockDevice(){public long sectorCount(){return c.sectorCount();}public byte[] read(long lba)throws IOException{if(lba>=c.base+32&&lba<c.data)fatReads[0]++;return c.read(lba);}public void write(long lba,byte[] data)throws IOException{c.write(lba,data);}};
        new Fat32Store(measured).save(0,song(1));
        System.out.println("16GB occupied-prefix save sector reads="+c.reads+", FAT reads="+fatReads[0]);
        ok(fatReads[0]<30,"valid FSInfo hint avoids hundreds of remote FAT sector reads");
        ok(Arrays.equals(content(c,0),song(1)),"hint allocation retains exact valid P18");ordinary(c);
        for(String mode:new String[]{"signature","outside","occupied","wrap"}){
            Card card=new Card();long next=mode.equals("outside")?0xffffffffL:mode.equals("occupied")?4:mode.equals("wrap")?card.clusters+1:32768;
            p32(card.pages.get(card.base+1),492,next);
            if(mode.equals("signature"))card.pages.get(card.base+1)[0]=0;
            if(mode.equals("wrap"))card.fat(next,0xafffffffL);
            new Fat32Store(card).save(0,song(1));byte[] e=find(card,0);long head=u16(e,26)|((long)u16(e,20)<<16);
            ok(head==(mode.equals("occupied")?6:3),"FSInfo is a bounded hint, actual FAT checked: "+mode);
            ok(Arrays.equals(content(card,0),song(1)),"fallback/wrap P18 valid: "+mode);ordinary(card);
        }
        final Card mismatch=new Card();p32(mismatch.pages.get(mismatch.base+1),492,20);mismatch.fatCopy(1,20,0xafffffffL);
        rejects(mismatch,new Action(){public void run()throws Exception{new Fat32Store(mismatch).save(0,song(1));}},Fat32Store.Reason.CHAIN);
    }
    public static void main(String[] args)throws Exception{
        if(args.length>0&&args[0].equals("hint")){allocationHint();return;}
        File dir=args.length==0?null:new File(args[0]);if(dir!=null)dir.mkdirs();
        for(String kind:new String[]{"super","mbr","active","single","spc8"})successful(kind,dir==null?null:new File(dir,kind+".img"));
        successful("16gb",null);
        Card large=new Card("16gb");ok(large.sectorCount()*512L==16000000000L,"16GB capacity uses long sector arithmetic");Fat32Store largeFs=new Fat32Store(large);largeFs.save(31,song(2048));ok(Arrays.equals(content(large,31),song(2048)),"16GB FAT32 maximum song in slot31");largeFs.delete(31);ok(find(large,31)==null,"16GB FAT32 slot31 deletion");ordinary(large);
        Card max=new Card();Fat32Store fs=new Fat32Store(max);byte[] original=max.old.clone();fs.save(0,song(1));fs.save(31,song(2048));ok(Arrays.equals(content(max,3),original),"other managed slot preserved");ok(Arrays.equals(content(max,31),song(2048)),"maximum2048 steps/13 clusters");fs.delete(0);fs.delete(31);ok(find(max,0)==null&&find(max,31)==null,"slot0 and31 deleted");ordinary(max);
        final Card invalid=new Card();final Fat32Store invalidFs=new Fat32Store(invalid);final byte[] bad=song(1);bad[0]^=1;rejects(invalid,new Action(){public void run()throws Exception{invalidFs.save(3,bad);}},Fat32Store.Reason.INVALID_FILE);rejects(invalid,new Action(){public void run()throws Exception{invalidFs.save(32,song(1));}},Fat32Store.Reason.PARAMETER);
        preflightTests();faults();deleteFaults();geometryAndMetadata(dir);allocationHint();System.out.println("PASS "+checks+" Java FAT32 transaction checks");
    }
}
