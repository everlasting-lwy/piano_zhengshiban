package org.pianolink;

import java.lang.reflect.*;
import java.io.*;
import java.util.concurrent.*;

/** Forces the documented UI/worker interleaving without changing production code. */
public final class VisualPauseRaceTest {
    private static Field field(String name)throws Exception{Field f=LinkController.class.getDeclaredField(name);f.setAccessible(true);return f;}
    public static void main(String[] args)throws Exception{
        LinkController controller=new LinkController(false,new LinkController.Listener(){public void connected(boolean x){}public void frame(Protocol.Frame x){}public void message(String x){}public void ended(String x){}});
        ScheduledExecutorService worker=(ScheduledExecutorService)field("worker").get(controller);
        Session session=(Session)field("session").get(controller);
        VisualPoller poller=(VisualPoller)field("visuals").get(controller);
        Method tick=LinkController.class.getDeclaredMethod("tick");tick.setAccessible(true);
        Field queued=VisualPoller.class.getDeclaredField("queued");queued.setAccessible(true);
        long now=android.os.SystemClock.elapsedRealtime();
        field("ready").set(controller,true);field("transportOpen").set(controller,true);
        field("lastStatus").set(controller,now);field("lastEffectsStatus").set(controller,now);
        field("output").set(controller,new ByteArrayOutputStream());
        poller.supported(true);controller.visual(4,true);
        Thread serial=new Thread(()->{try{tick.invoke(controller);}catch(Exception e){throw new RuntimeException(e);}},"forced-serial-worker");
        try{
            synchronized(session){
                serial.start();
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(2);
                boolean hasQueued=false;
                while(System.nanoTime()<deadline){synchronized(poller){hasQueued=queued.getBoolean(poller);}if(hasQueued)break;Thread.yield();}
                if(!hasQueued)throw new AssertionError("worker did not reach request/queue boundary");
                controller.visual(0,false);
                // Mirrors LinkSession.pause(): selection stops, then phone keys release.
                controller.release();
                System.out.println("UI visual(0,false) and release have returned");
            }
            serial.join(2000);if(serial.isAlive())throw new AssertionError("worker remained blocked");
            // Retire release emitted by the resumed tick, then inspect the next wire request.
            Field pending=Session.class.getDeclaredField("pending");pending.setAccessible(true);
            Protocol.Frame release=(Protocol.Frame)pending.get(session);
            if(release==null||release.cmd!=5)throw new AssertionError("expected release first");
            session.receive(new Protocol.Frame(release.seq,0x80,new int[]{5,0,1,0,0,0}));
            Session.Send next=session.tick(android.os.SystemClock.elapsedRealtime()+100);
            System.out.println("Next wire request after pause: cmd="+next.frame.cmd+" kind="+next.frame.d[0]);
            if(next.frame.cmd!=14||next.frame.d[0]!=0)throw new AssertionError("background stop was lost to an obsolete visual selection");
            System.out.println("PASS 4 deterministic visual pause race checks");
        }finally{worker.shutdownNow();}
    }
}
