package org.pianolink;
import java.lang.reflect.*;
import java.util.concurrent.*;

/** Production Session/flow with the FPGA's cached catalog full of32-byte titles. */
public final class PhoneCatalogRpcFairnessTest {
    static int checks;static long now;static void ok(boolean value,String why){checks++;if(!value)throw new AssertionError(why);}
    static void reply(Session session,MockFpga device,Protocol.Frame request){ok(session.receive(Protocol.decode(device.accept(request.bytes(),now))),"current reply retires matching pending sequence");}
    public static void main(String[] args)throws Exception{
        Session session=new Session();MockFpga.SdCard card=new MockFpga.SdCard();MockFpga device=new MockFpga(card,2);session.sdRefresh();for(;now<6000;now+=40){Session.Send out=session.tick(now);if(out!=null)reply(session,device,out.frame);}ok(session.sdState().version==2,"V2 discovery complete");ok(session.sdState().catalogLoaded==1,"initial read-only catalog complete before explicit scan");int previousRevision=session.sdState().catalogRevision;ok(session.sdScan(),"explicit scan begins");
        Protocol.Frame held=null;boolean seeded=false;for(int i=0;i<100;i++,now+=40){session.sdRefresh();Session.Send out=session.tick(now);if(out==null)continue;if(out.frame.cmd==0x19&&!seeded){Field field=MockFpga.SdCard.class.getDeclaredField("files");field.setAccessible(true);byte[][] files=(byte[][])field.get(card);for(int slot=0;slot<32;slot++)files[slot]=P18File.encode("ABCDEFGHIJKLMNOPQRSTUVWXYZ123456",new int[]{1});seeded=true;}if(out.frame.cmd==0x1a){held=out.frame;break;}reply(session,device,out.frame);}
        ok(held!=null,"long-title catalog reply is in flight");ok(session.sdPhoneBegin(1,0,P18File.encode("new",new int[]{1,2})),"phone writer reserves during read-only catalog");Future<Protocol.Frame> future=session.blockRpc(0x26,new int[6]);ok(session.tick(now+100)==null,"phone reservation cannot discard/replace in-flight catalog SEQ");now+=100;reply(session,device,held);
        int before=0;boolean sent=false;long begin=now;for(int i=0;i<140;i++,now+=40){Session.Send out=session.tick(now);if(out==null)continue;if(out.frame.cmd==0x26){sent=true;reply(session,device,out.frame);break;}before++;reply(session,device,out.frame);}
        ok(sent&&before<=3,"phone RPC starved behind long catalog: "+before+" other packets / "+(now-begin)+"ms paced clock; must get a bounded turn");ok(future.isDone()&&future.get().cmd==0x92,"FAT worker future receives actual status");ok(session.sdState().catalogLoaded==1&&session.sdState().catalogRevision==previousRevision&&session.sdState().entries[0].flags==0,"abandoned partial catalog retains previous complete snapshot");ok(session.sdState().busy==1,"real phone transaction stays reserved after read-only catalog ends");System.out.println("PASS "+checks+" phone-start during long-catalog fairness checks");
    }
}
