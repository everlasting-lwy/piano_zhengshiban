package android.bluetooth;
import java.io.*;
public abstract class BluetoothSocket implements Closeable {
    public abstract void connect() throws IOException;
    public abstract InputStream getInputStream() throws IOException;
    public abstract OutputStream getOutputStream() throws IOException;
}
