package android.bluetooth;
import java.io.*;
import java.util.UUID;
public final class BluetoothDevice {
    public final BluetoothSocket secure,insecure;
    public int secureCalls,insecureCalls;
    public BluetoothDevice(BluetoothSocket secure,BluetoothSocket insecure){this.secure=secure;this.insecure=insecure;}
    public BluetoothSocket createRfcommSocketToServiceRecord(UUID uuid)throws IOException{check(uuid);secureCalls++;return secure;}
    public BluetoothSocket createInsecureRfcommSocketToServiceRecord(UUID uuid)throws IOException{check(uuid);insecureCalls++;return insecure;}
    private void check(UUID uuid)throws IOException{if(!uuid.toString().equals("00001101-0000-1000-8000-00805f9b34fb"))throw new IOException("wrong SPP UUID");}
}
