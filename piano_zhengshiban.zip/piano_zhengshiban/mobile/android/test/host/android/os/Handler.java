package android.os;
/** Host-only dispatcher. APK compilation uses the Android platform classes. */
public final class Handler {
    private static final java.util.concurrent.ConcurrentLinkedQueue<Runnable> queued=new java.util.concurrent.ConcurrentLinkedQueue<>();
    private static volatile boolean held;
    public Handler(Looper looper){}
    public boolean post(Runnable runnable){synchronized(queued){if(held){queued.add(runnable);return true;}}runnable.run();return true;}
    public static void hold(){synchronized(queued){held=true;}}
    public static void flush(){synchronized(queued){held=false;}Runnable next;while((next=queued.poll())!=null)next.run();}
}
