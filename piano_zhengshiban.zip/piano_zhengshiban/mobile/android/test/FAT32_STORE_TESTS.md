# Fat32Store verification and handoff

Run `mobile/android/test-fat32-store.ps1` from the piano workspace. It compiles
the production writer and codec for Java 8, runs the sparse block-device tests,
then runs `check_fat32_images.py` with the bundled Python runtime. The JDK and
Python executable can be overridden with `-Jdk` and `-Python`.

Latest result: **1,831 Java checks** and **six independent image checks plus
18 deliberate image-corruption rejection checks**. Exported files are ordinary
simulation images under `mobile/android/build/fat32-store-test/images`; this
runner never opens a physical card or block device.

## Public interface

`Fat32Store.BlockDevice` provides `long sectorCount()`, `byte[] read(long lba)`
and `void write(long lba, byte[] sector)`. Reads return exactly 512 bytes;
read/write throw `IOException`. The caller owns an exclusive serialized device
session. `save(int slot, byte[] p18)` and `delete(int slot)` throw `IOException`.
The writer itself reads back every complete sector after writing, even if the
RPC layer also verifies it, and reopens the published P18 file before success.

`StoreException.reason` distinguishes `PARAMETER`, `MEDIA`, `UNSUPPORTED`,
`GEOMETRY`, `CHAIN`, `NOT_FOUND`, `INVALID_FILE`, `PROTECTED`, `FULL`,
`SEARCH_LIMIT`, `DIRECTORY_FULL`, `VERIFY`, `WRITE_LOCKED`, and `IO`. `FULL`
means the actual cluster range was exhausted; `SEARCH_LIMIT` means a bounded
search or chain check could not finish. Both refuse before the first write.

## Transaction and safety coverage

The initial test-first run failed because `Fat32Store` did not exist. The
implementation then passed the original 1,080 checks. Expanded coverage checks:

- FAT32 superfloppy, MBR, one FAT, mirrored FATs, active FAT 1, SPC 1 and 8,
  fragmented root and file chains, slots 0 and 31, and 2,048-step/13-cluster P18.
- Save, fresh-instance delete, exact source bytes, body/header CRC, UTF-8 title,
  ordinary file metadata/data preservation, and the selected source being
  frozen before writes.
- Zero-write refusal for unsupported/bad geometry, readonly/directory target,
  malformed existing P18, duplicate name, temporary remnant, dirty/error FAT,
  directory full, actual full card, exceeded search bounds, cycles and
  out-of-range links, root-tail loops beyond an end marker, and references from
  another root file or a child directory into a touched chain.
- Both valid FSInfo hint sectors become unknown. Invalid primary/backup FSInfo,
  invalid backup boot geometry and absent FSInfo are preserved. Each mirrored
  FAT retains its own reserved upper nibble; inactive FAT contents are preserved.
- Every one of the 22 save writes and 11 delete writes receives failures before
  application, after application, during readback, and from corrupt readback:
  132 injected write faults. Every prepublication failure retains the original
  target. The result after publication is a complete old or new file; deletion
  leaves the old file complete or absent. A failure stops writes immediately,
  never performs automatic cleanup, and locks that writer instance.
- Dirty is the first metadata write and clean is the final write. A preflight
  read error emits no writes and permits a fresh attempt on the same instance.

The independent Python parser imports no Java writer, codec or fixture helpers.
It checks BPB/partition geometry, complete FAT mirrors, ordinary directory
entries, fragmented chains, allocation lengths, old-chain release, active FAT
selection, reserved high bits, FSInfo signatures/hints and P18 contents/CRCs.
In-memory mutations prove it rejects body corruption, root FAT corruption and
stale free-space hints without changing the exported image files.

## Intentional limits

The piano1101 restoration also exercises a 16,000,000,000-byte FAT32 card
geometry in sparse memory: MBR at LBA 2048, two FATs and 32 KiB clusters. It
checks replacement, slot 31 with a maximum 2,048-step P18, deletion, ordinary
file preservation and long capacity arithmetic. It does not allocate or export
a 16 GB file and does not touch a physical card. The six exported smaller
images remain the separate independent Python cross-check fixtures.

Only root managed `P0000000.P18` through `P0000031.P18` are written. No format,
repair, root extension or song subfolder management exists. Child directories
are inspected read-only to reject crosslinks into touched allocations. The
complete allocated directory chains are checked even after a logical end
marker. The total directory traversal is limited to 4,096 sectors, FAT
preflight to 8,192 distinct sectors, and a managed file to 13 clusters. Huge or
inconsistent existing directory trees can therefore be refused conservatively.

An uncertain write leaves the volume dirty and the writer locked; a new writer
also refuses dirty/error flags or a visible managed temporary remnant. No temp
or lost allocation is automatically reclaimed. A successful final write can
be followed by a lost reply, so reconnect must query actual state. Verified
sector writes and ordered FAT32 metadata do not guarantee atomic recovery from
power loss, torn SD programming, or a card that acknowledges writes before
durable storage. These host tests establish simulation behavior, not physical
card durability or phone Bluetooth timing.
