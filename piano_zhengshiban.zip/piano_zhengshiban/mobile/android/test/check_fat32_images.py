"""Independent FAT32/P18 image checker: no Java helpers or writer code imported.

Images are sparse *regular test files*, never block devices. The reader also
checks its own rejection paths through in-memory sector mutations.
"""
import argparse
import binascii
import math
import pathlib
import struct


def u16(b, at):
    return struct.unpack_from('<H', b, at)[0]


def u32(b, at):
    return struct.unpack_from('<I', b, at)[0]


class Image:
    def __init__(self, path, patches=None):
        self.path = path
        self.file = path.open('rb')
        self.sectors = path.stat().st_size // 512
        self.patches = patches or {}

    def read(self, lba):
        assert 0 <= lba < self.sectors, 'LBA outside image'
        if lba in self.patches:
            return self.patches[lba]
        self.file.seek(lba * 512)
        b = self.file.read(512)
        assert len(b) == 512, 'short sector'
        return b

    def close(self):
        self.file.close()


def validate_p18(data):
    assert data[:9] == b'P18GUIDE\x01', 'P18 magic/version'
    count, title_length = u16(data, 10), data[9]
    assert 1 <= count <= 2048 and len(data) == 64 + 3 * count, 'P18 exact size'
    assert title_length <= 32, 'title length'
    assert data[14:16] == b'\0\0', 'reserved header'
    assert not any(data[16 + title_length:62]), 'title padding/reserved'
    assert u16(data, 62) == binascii.crc_hqx(data[:62], 0xffff), 'header CRC'
    assert u16(data, 12) == binascii.crc_hqx(data[64:], 0xffff), 'body CRC'
    title = data[16:16 + title_length].decode('utf-8', errors='strict')
    masks = [int.from_bytes(data[p:p + 3], 'little') for p in range(64, len(data), 3)]
    assert all(0 < mask <= 0x3ffff and 1 <= bin(mask).count('1') <= 4 for mask in masks), 'mask validity'
    return title, masks


def inspect(image, kind):
    b = image.read(0)
    assert b[510:512] == b'\x55\xaa', 'boot signature'
    base = 0
    if u16(b, 11) != 512:
        supported = [446 + 16 * n for n in range(4) if b[450 + 16 * n] in (11, 12)]
        assert supported, 'supported partition'
        part = supported[0]
        base, extent = u32(b, part + 8), u32(b, part + 12)
        assert base > 0 and base + extent <= image.sectors, 'partition bounds'
        b = image.read(base)
    else:
        extent = image.sectors
    assert b[510:512] == b'\x55\xaa' and u16(b, 11) == 512, 'FAT32 BPB'
    spc, reserved, copies = b[13], u16(b, 14), b[16]
    total, fatsz, root = u32(b, 32), u32(b, 36), u32(b, 44)
    flags = u16(b, 40)
    active = 0 if not flags & 0x80 else flags & 15
    assert spc and spc <= 128 and spc & (spc - 1) == 0, 'SPC'
    assert reserved and copies in (1, 2) and active < copies, 'FAT copies'
    assert not u16(b, 17) and not u16(b, 19) and not u16(b, 22) and not u16(b, 42), 'FAT32 fields'
    assert total <= extent and total == image.sectors - base, 'volume bounds'
    count = (total - reserved - copies * fatsz) // spc
    assert 65525 <= count <= 0x0ffffff3 and fatsz * 128 >= count + 2, 'cluster geometry'
    fatbase, database = base + reserved, base + reserved + copies * fatsz
    tables = [b''.join(image.read(fatbase + copy * fatsz + n) for n in range(fatsz)) for copy in range(copies)]
    if not flags & 0x80:
        for p in range(0, len(tables[0]), 4):
            assert all((u32(t, p) & 0x0fffffff) == (u32(tables[0], p) & 0x0fffffff) for t in tables), 'mirror contents'
    table = tables[active]

    def fat(cluster):
        assert 0 <= cluster <= count + 1, 'FAT cluster bounds'
        return u32(table, cluster * 4) & 0x0fffffff

    def lba(cluster):
        assert 2 <= cluster <= count + 1, 'data cluster bounds'
        return database + (cluster - 2) * spc

    def chain(start):
        ids = []
        while True:
            assert 2 <= start <= count + 1 and start not in ids, 'cluster range/cycle'
            assert len(ids) < 4096, 'chain checker bound'
            ids.append(start)
            start = fat(start)
            if start >= 0x0ffffff8:
                return ids

    assert fat(0) == 0x0ffffff8 and fat(1) == 0x0fffffff, 'reserved entries/clean status'
    root_ids = chain(root)
    assert root_ids == [2, 7], 'fragmented root preserved'
    entries, ended = [], False
    for cl in root_ids:
        for sector in range(spc):
            for offset in range(0, 512, 32):
                e = image.read(lba(cl) + sector)[offset:offset + 32]
                if e[0] == 0:
                    ended = True
                    break
                if e[0] != 0xe5 and e[11] & 15 != 15:
                    entries.append(e)
            if ended:
                break
        if ended:
            break
    assert not any(e[:1] == b'T' and e[8:11] == b'P18' for e in entries), 'temporary entry remains'
    targets = [e for e in entries if e[:11] == b'P0000003P18']
    assert len(targets) == 1, 'exactly one published target'
    target = targets[0]
    assert target[11] == 0x20, 'published attributes'
    size, first = u32(target, 28), u16(target, 26) | u16(target, 20) << 16
    ids = chain(first)
    assert len(ids) == math.ceil(size / (512 * spc)) <= 13, 'file allocation length'
    assert not set(ids) & {2, 7, 4, 5, 9}, 'new chain isolated'
    data = b''.join(image.read(lba(cl) + s) for cl in ids for s in range(spc))[:size]
    title, masks = validate_p18(data)
    assert title == '你好🎹' and len(masks) == 350, 'actual saved song'
    assert masks == [(1 << (i % 18)) | (1 << ((i + 5) % 18)) for i in range(350)], 'actual step masks'
    assert fat(5) == 0 and (spc != 1 or fat(9) == 0), 'validated old allocation freed'
    assert u32(table, 5 * 4) >> 28 == (11 if kind == 'highnibble' and active == 1 else 10), 'old reserved high bits'
    if kind == 'highnibble':
        assert all(u32(tables[1], c * 4) >> 28 == 11 for c in range(128)), 'per-copy high nibble retained'
    if active == 1:
        assert u32(tables[0], 2 * 4) == 0 and u32(tables[0], 5 * 4) == 0xa0000009, 'inactive FAT untouched'
    for sector in range(spc):
        root_sector = image.read(database + sector)
        for n in range(16):
            e = root_sector[n * 32:n * 32 + 32]
            assert e[:11] == ('FILE%04dTXT' % n).encode('ascii'), 'ordinary directory name preserved'
            assert e[11] == 0x20 and u16(e, 26) == 4 and u32(e, 28) == 9, 'ordinary metadata preserved'
    assert image.read(lba(4))[:9] == b'ordinary!' and fat(4) >= 0x0ffffff8, 'ordinary contents/allocation preserved'
    for fsinfo in (base + 1, base + 7):
        info = image.read(fsinfo)
        assert (u32(info, 0), u32(info, 484), u32(info, 508)) == (0x41615252, 0x61417272, 0xaa550000), 'FSInfo signature'
        assert info[488:496] == b'\xff' * 8, 'FSInfo hints invalidated'
    return {'base': base, 'data': database, 'fat': fatbase + active * fatsz, 'first': lba(first)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=pathlib.Path)
    args = parser.parse_args()
    names = ['super', 'mbr', 'active', 'single', 'spc8', 'highnibble']
    checked = 0
    for kind in names:
        path = args.directory / (kind + '.img')
        image = Image(path)
        try:
            info = inspect(image, kind)
            # Prove the independent checker catches corrupt data, a cyclic root,
            # and stale FSInfo without mutating the exported filesystem fixture.
            mutations = []
            body = bytearray(image.read(info['first']));body[100] ^= 1
            mutations.append({info['first']: bytes(body)})
            cyclic = bytearray(image.read(info['fat']));struct.pack_into('<I', cyclic, 8, 2)
            mutations.append({info['fat']: bytes(cyclic)})
            stale = bytearray(image.read(info['base'] + 1));struct.pack_into('<I', stale, 488, 1234)
            mutations.append({info['base'] + 1: bytes(stale)})
            for patch in mutations:
                bad = Image(path, patch)
                try:
                    try:
                        inspect(bad, kind)
                    except AssertionError:
                        checked += 1
                    else:
                        raise AssertionError('checker accepted injected image corruption')
                finally:
                    bad.close()
            checked += 1
        finally:
            image.close()
    print('PASS independent Python FAT32/P18 checker: %d images, %d checks (including rejection mutations)' % (len(names), checked))


if __name__ == '__main__':
    main()
