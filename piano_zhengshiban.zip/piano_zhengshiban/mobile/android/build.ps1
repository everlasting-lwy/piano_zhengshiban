param([string]$Jdk = 'C:/Program Files/Microsoft/jdk-17.0.13.11-hotspot', [string]$Sdk = '', [string]$AudioCache = '')
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (!$Sdk) { $Sdk = [IO.Path]::GetFullPath((Join-Path $root '../../tmp/android-sdk')) }
if (!(Test-Path -LiteralPath "$Sdk/android-35/android.jar")) {
    $sharedSdk = [IO.Path]::GetFullPath((Join-Path $root '../../../piano/tmp/android-sdk'))
    if (Test-Path -LiteralPath "$sharedSdk/android-35/android.jar") { $Sdk = $sharedSdk }
}
$tools = Join-Path $Sdk 'android-15'
$platform = Join-Path $Sdk 'android-35/android.jar'
if (!(Test-Path -LiteralPath $platform) -or !(Test-Path -LiteralPath "$tools/aapt2.exe")) { throw 'Run bootstrap-sdk.ps1 first or pass -Sdk containing android-35 and android-15 build tools.' }
$env:JAVA_HOME = $Jdk
$env:PATH = "$Jdk/bin;" + $env:PATH
function Run([string]$Command, [string[]]$Arguments) { & $Command @Arguments; if ($LASTEXITCODE -ne 0) { throw "$Command exited $LASTEXITCODE" } }
$build = Join-Path $root 'build'
$classes = Join-Path $build 'classes'
$tests = Join-Path $build 'test'
$dex = Join-Path $build 'dex'
$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $build,$classes,$tests,$dex,$dist | Out-Null
if (!$AudioCache) { $AudioCache=[IO.Path]::GetFullPath((Join-Path $root '../../tmp/audio_deps')) }
if (!(Test-Path -LiteralPath "$AudioCache/litert-1.4.2/classes.jar")) {
    $sharedAudio=[IO.Path]::GetFullPath((Join-Path $root '../../../piano/tmp/audio_deps'))
    if (Test-Path -LiteralPath "$sharedAudio/litert-1.4.2/classes.jar") { $AudioCache=$sharedAudio }
}
# A complete dependency cache is read-only, including the original piano cache.
$reuseAudio=Test-Path -LiteralPath "$AudioCache/litert-1.4.2/classes.jar"
& (Join-Path $root 'bootstrap-audio.ps1') -Cache $AudioCache -ReadOnly:$reuseAudio
$audioJars=@((Join-Path $audioCache 'litert-1.4.2/classes.jar'),(Join-Path $audioCache 'litert-api-1.4.2/classes.jar'))
$core = @('Protocol','MockFpga','OledGuideProtocol','SdLibraryProtocol','SdLibraryFlow','P18File','Recording','KeyMap','Session','VolumeState','PianoTouch') | ForEach-Object { Join-Path $root "src/org/pianolink/$_.java" }
$plainTests = @('CoreTest','UiStateTest','EnsembleProtocolTest') | ForEach-Object {Join-Path $root "test/org/pianolink/$_.java"}
Run "$Jdk/bin/javac.exe" (@('-encoding','UTF-8','-d',$tests) + $core + $plainTests)
Run "$Jdk/bin/java.exe" @('-cp',$tests,'org.pianolink.CoreTest')
Run "$Jdk/bin/java.exe" @('-cp',$tests,'org.pianolink.UiStateTest')
Run "$Jdk/bin/java.exe" @('-cp',$tests,'org.pianolink.EnsembleProtocolTest')
& (Join-Path $root 'test-transport.ps1') -Jdk $Jdk
& (Join-Path $root 'test-lifecycle.ps1') -Jdk $Jdk
& (Join-Path $root 'test-library.ps1') -Jdk $Jdk
& (Join-Path $root 'test-audio.ps1') -Jdk $Jdk
& (Join-Path $root 'test-replay.ps1') -Jdk $Jdk
& (Join-Path $root 'test-work.ps1') -Jdk $Jdk
& (Join-Path $root 'test-effects.ps1') -Jdk $Jdk
& (Join-Path $root 'test-effects-transport.ps1') -Jdk $Jdk
& (Join-Path $root 'test-guide.ps1') -Jdk $Jdk
& (Join-Path $root 'test-guide-ui.ps1') -Jdk $Jdk
& (Join-Path $root 'test-song-guide.ps1') -Jdk $Jdk
& (Join-Path $root 'test-fat32-store.ps1') -Jdk $Jdk
& (Join-Path $root 'test-sd-library.ps1') -Jdk $Jdk
& (Join-Path $root 'test-sector-rpc.ps1') -Jdk $Jdk
& (Join-Path $root 'test-phone-fat-worker.ps1') -Jdk $Jdk
& (Join-Path $root 'test-sd-ui.ps1') -Jdk $Jdk
$manifest = Join-Path $root 'AndroidManifest.xml'
$unsigned = Join-Path $build 'unsigned.apk'
Run "$tools/aapt2.exe" @('link','-I',$platform,'-A',(Join-Path $root 'assets'),'--manifest',$manifest,'--min-sdk-version','23','--target-sdk-version','35','--version-code','14','--version-name','2.3','-o',$unsigned)
$sources = @(Get-ChildItem -LiteralPath (Join-Path $root 'src/org/pianolink') -Filter '*.java' | ForEach-Object { $_.FullName })
Run "$Jdk/bin/javac.exe" (@('-encoding','UTF-8','--release','8','-classpath',(($platform)+ ';' + ($audioJars -join ';')),'-d',$classes) + $sources)
$classesJar = Join-Path $build 'classes.jar'
Run "$Jdk/bin/jar.exe" @('cf',$classesJar,'-C',$classes,'.')
Run "$Jdk/bin/java.exe" (@('-cp',"$tools/lib/d8.jar",'com.android.tools.r8.D8','--lib',$platform,'--min-api','23','--output',$dex,$classesJar)+$audioJars)
Run "$Jdk/bin/jar.exe" @('uf',$unsigned,'-C',$dex,'classes.dex')
$nativePackage=Join-Path $build 'native'
$nativeLib=Join-Path $nativePackage 'lib'
New-Item -ItemType Directory -Force -Path $nativeLib | Out-Null
Get-ChildItem -LiteralPath (Join-Path $audioCache 'litert-1.4.2/jni') -Directory | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $nativeLib -Recurse -Force}
Run "$Jdk/bin/jar.exe" @('uf',$unsigned,'-C',$nativePackage,'lib')
$aligned = Join-Path $build 'aligned.apk'
Run "$tools/zipalign.exe" @('-f','4',$unsigned,$aligned)
$keystore = Join-Path $root 'debug.keystore'
if (!(Test-Path -LiteralPath $keystore)) { Run "$Jdk/bin/keytool.exe" @('-genkeypair','-keystore',$keystore,'-storepass','android','-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=Android Debug,O=PianoLink,C=CN') }
$apk = Join-Path $dist 'PianoLink-piano1101-SD-v2.3.apk'
Run "$Jdk/bin/java.exe" @('-jar',"$tools/lib/apksigner.jar",'sign','--ks',$keystore,'--ks-pass','pass:android','--key-pass','pass:android','--out',$apk,$aligned)
Run "$Jdk/bin/java.exe" @('-jar',"$tools/lib/apksigner.jar",'verify','--verbose','--print-certs',$apk)
Run "$tools/zipalign.exe" @('-c','4',$apk)
Get-FileHash -LiteralPath $apk -Algorithm SHA256 | Format-List
Write-Output "APK: $apk"
