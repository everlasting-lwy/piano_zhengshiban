$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $PSScriptRoot '../tools/FpgaMidiSpeakers.cs')

function Assert-Message([uint32]$InputMessage, [uint32]$Expected, [string]$Label) {
    $actual = [FpgaMidiSpeakers.MidiDynamics]::ApplyVelocityGain($InputMessage, 1.25)
    if ($actual -ne $Expected) {
        throw ('{0}: expected {1:X6}, got {2:X6}' -f $Label, $Expected, $actual)
    }
}

# C4 on: 64 -> 80; default FPGA 120 -> saturated 127.
Assert-Message 0x403C90 0x503C90 'Ordinary Note On gain'
Assert-Message 0x784D90 0x7F4D90 'High key clipping preserves note'
Assert-Message 0x013C95 0x013C95 'Smallest positive note stays audible'
Assert-Message 0x003C90 0x003C90 'Zero velocity remains Note Off'
Assert-Message 0x403C80 0x403C80 'Release velocity is unchanged'
Assert-Message 0x6407B0 0x6407B0 'Controller is unchanged'
if ([FpgaMidiSpeakers.MidiDynamics]::ApplyVelocityGain(0x403C90, 1.0) -ne 0x403C90) {
    throw 'Gain 1 must preserve the original velocity'
}

# Exercise production parser with fragmented serial data before transforming.
$parser = New-Object FpgaMidiSpeakers.MidiParser
$head = [byte[]](0x90, 60)
$tail = [byte[]](64, 0x80, 60, 0)
if (@($parser.Feed($head, $head.Length)).Count -ne 0) { throw 'Premature parsed message' }
$messages = @($parser.Feed($tail, $tail.Length))
if ($messages.Count -ne 2) { throw 'Missing parsed on/off pair' }
Assert-Message $messages[0] 0x503C90 'Fragmented Note On'
Assert-Message $messages[1] 0x003C80 'Fragmented Note Off'
Write-Output 'PASS: MIDI velocity gain, saturation, channels, mute/release and fragmented serial parsing'
