`timescale 1ns/1ps
// Behavioral SD peer: samples MOSI only on wire rising edges and changes MISO
// only on falling edges. Command/address/CRC checking is independent of the DUT.
module sd_spi_image_model(input cs_n,sclk,mosi,input [1:0] kind,
    input [2:0] csd_variant,
    input absent,bad_crc,reject_write,stuck_busy,no_token,bad_r7,bad_ocr,bad_csd,init_stuck,status_error,
    output reg miso);
reg [7:0] memory[0:511];
integer image_fd,image_status,image_n;reg [1023:0] image_path;
initial begin
 if(!$value$plusargs("IMAGE=%s",image_path))$fatal(1,"missing IMAGE");
 image_fd=$fopen(image_path,"r+b");if(!image_fd)$fatal(1,"image open");
end
task image_read;input[31:0] sector;integer n;begin
 image_status=$fseek(image_fd,sector*512,0);if(image_status)$fatal(1,"image seek");
 for(n=0;n<512;n=n+1)begin image_n=$fgetc(image_fd);if(image_n<0)$fatal(1,"image EOF");memory[n]=image_n;end
end endtask
task image_write;input[31:0] sector;integer n;begin
 image_status=$fseek(image_fd,sector*512,0);if(image_status)$fatal(1,"image seek");
 for(n=0;n<512;n=n+1)$fwrite(image_fd,"%c",memory[n]);$fflush(image_fd);
end endtask
reg [7:0] queue[0:2047]; integer qh=0,qt=0,tbit=7;
reg [7:0] csd[0:15];
reg [7:0] rx=0; integer rbit=0,cmdn=0;
reg [7:0] cmd[0:5]; integer wstate=0,wi=0;
reg [15:0] wc=0,gotcrc=0; reg idle=1,app=0,crc_on=0,programming=0;
integer write_gaps=0;
integer high_clocks=0,commands=0,reads=0,writes=0,errors=0,i;
reg [31:0] last_address=0; reg [31:0] arg;
function [15:0] crc16;
 input [15:0] c; input [7:0] d; integer k; reg [15:0] x;
 begin x=c ^ (d<<8); for(k=0;k<8;k=k+1) x=x[15] ? (x<<1)^16'h1021 : x<<1; crc16=x; end
endfunction
function [7:0] command_crc;
 input [39:0] bits; integer k; reg [6:0] c; reg f;
 begin c=0; for(k=39;k>=0;k=k-1) begin f=bits[k]^c[6]; c=c<<1; if(f)c=c^7'h09; end command_crc={c,1'b1}; end
endfunction
task put; input [7:0] b; begin queue[qt]=b;qt=qt+1;end endtask
task problem; input [255:0] msg; begin errors=errors+1;$display("CARD ERROR: %0s",msg);end endtask
task block_data;
 input is_csd; reg [15:0] c; integer n;
 begin
  if(!crc_on)problem("data before CMD59 enables CRC");
  if(!no_token) begin
   put(8'hff);put(8'hfe);c=0;
   for(n=0;n<(is_csd?16:512);n=n+1) begin
    put(is_csd?csd[n]:memory[n]);c=crc16(c,is_csd?csd[n]:memory[n]);
   end
   put(c[15:8]);put(c[7:0]^(bad_crc?8'h01:8'h00));
  end
 end
endtask
task command;
 integer c;
 begin
  c=cmd[0]&63;arg={cmd[1],cmd[2],cmd[3],cmd[4]};commands=commands+1;
  if(cmd[5]!==command_crc({cmd[0],arg})) problem("command CRC7");
  if(c==0 && cmd[5]!==8'h95)problem("CMD0 golden CRC");
  if(c==8 && cmd[5]!==8'h87)problem("CMD8 golden CRC");
  if(c==0 && high_clocks<74) problem("fewer than 74 power clocks");
  if(c!=0 && high_clocks<8) problem("no CS-high release clocks");
  high_clocks=0;
  if(!absent) begin
   put(8'hff);
   case(c)
    0: begin if(programming)problem("CMD0 during programming");idle=1;app=0;crc_on=0;put(1);end
    8: if(kind==2)put(5);else begin
     if(arg!==32'h1aa)problem("CMD8 voltage/pattern");
     put(1);put(0);put(0);put(1);put(bad_r7?8'hab:8'haa);
    end
    55: begin app=1;put(idle?1:0);end
    41: begin
     if(!app)problem("ACMD41 without CMD55");app=0;
     if(arg!==(kind==2?32'h00000000:32'h40000000))problem("ACMD41 HCS");
     idle=init_stuck;put(init_stuck?1:0);
    end
    58: begin put(0);put(bad_ocr?0:(kind==0?8'hc0:8'h80));put(8'hff);put(8'h80);put(0);end
    59: begin if(arg!==1)problem("CMD59 CRC option");crc_on=1;put(0);end
    9: begin
     for(i=0;i<16;i=i+1)csd[i]=0;
     if(kind==0)begin csd[0]=8'h40;csd[8]=3;csd[9]=8'hff;end
     else begin csd[5]=9;csd[6]=3;csd[7]=8'hff;csd[8]=8'hc0;csd[9]=3;csd[10]=8'h80;end
     if(bad_csd)csd[0]=8'h80;
     if(csd_variant==1 || csd_variant==2)begin csd[7]=8'h3f;csd[8]=8'hff;csd[9]=(csd_variant==1?8'hff:8'hfe);end
     if(csd_variant==3)csd[5]=10;
     if(csd_variant==4)csd[5]=11;
     if(csd_variant==5)csd[5]=8;
     put(0);block_data(1);
    end
    16:begin if(arg!==512)problem("CMD16 block length");put(0);end
    13:begin put(0);put(status_error?8'h20:0);end
    17:begin last_address=arg;reads=reads+1;image_read(arg);put(0);block_data(0);end
    24:begin last_address=arg;put(0);wstate=1;wi=0;wc=0;write_gaps=-1;end
    default:begin problem("unexpected command");put(4);end
   endcase
  end
 end
endtask
task receive_byte;
 input [7:0] b;
 begin
  if(wstate==1) begin
   if(b==8'hfe)begin if(write_gaps<1)problem("missing NWR idle byte");wstate=2;end
   else if(qh==qt)write_gaps=write_gaps+1;
  end
  else if(wstate==2)begin memory[wi]=b;wc=crc16(wc,b);if(wi==511)wstate=3;else wi=wi+1;end
  else if(wstate==3)begin gotcrc={b,8'h00};wstate=4;end
  else if(wstate==4)begin
   gotcrc[7:0]=b;if(gotcrc!==wc)problem("write CRC16");
   writes=writes+1;wstate=0;if(!reject_write && gotcrc===wc)image_write(last_address);
   put(8'hff);put(reject_write?8'h0b:8'h05);
   programming=!reject_write;
   for(i=0;i<(stuck_busy?256:3);i=i+1)put(0);
   if(!stuck_busy)put(8'hff);
  end else if(cmdn!=0 || b[7:6]==2'b01)begin
   cmd[cmdn]=b;if(cmdn==5)begin cmdn=0;command;end else cmdn=cmdn+1;
  end
 end
endtask
initial begin miso=1;for(i=0;i<512;i=i+1)memory[i]=i^8'h5a;end
always @(posedge cs_n)begin qh=0;qt=0;tbit=7;rbit=0;rx=0;cmdn=0;wstate=0;miso=1;end
always @(posedge sclk)begin
 if(cs_n)high_clocks=high_clocks+1;
 else begin rx={rx[6:0],mosi};if(rbit==7)begin rbit=0;receive_byte(rx);end else rbit=rbit+1;end
end
always @(negedge sclk)begin
 if(cs_n || absent)miso=1;
 else if(qh<qt)begin miso=queue[qh][tbit];if(tbit==0)begin tbit=7;qh=qh+1;if(qh==qt && !stuck_busy)programming=0;end else tbit=tbit-1;end
 else if(stuck_busy && writes!=0)miso=0;
 else miso=1;
end
endmodule
