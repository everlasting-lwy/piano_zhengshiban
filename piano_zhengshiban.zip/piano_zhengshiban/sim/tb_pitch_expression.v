`timescale 1ns/1ps
module tb_pitch_expression;
reg clk=0;always #10 clk=~clk;
reg rst=0,clear=0,tick=0;reg[4:0] bend=8;reg[3:0] vibrato=0;
reg[127:0] base={32'd60000000,32'd50000000,32'd30000000,32'd20000000};
wire[127:0] adjusted;
pitch_expression_bank d(clk,rst,clear,tick,bend,vibrato,base,adjusted);
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
integer i,expected,change;reg[127:0] previous;
initial begin
clocks(3);rst=1;clocks(40);
if(adjusted!==base)$fatal(1,"Neutral expression changed note frequency");
bend=16;clocks(40);
for(i=0;i<4;i=i+1)begin expected=(base[i*32+:32]/16)*17;if(adjusted[i*32+:32]!=expected)$fatal(1,"Positive bend arithmetic");end
bend=0;clocks(40);
for(i=0;i<4;i=i+1)begin expected=(base[i*32+:32]/16)*15;if(adjusted[i*32+:32]!=expected)$fatal(1,"Negative bend arithmetic");end
bend=8;vibrato=15;change=0;previous=adjusted;
repeat(9000)begin tick=1;clocks(1);tick=0;clocks(20);if(adjusted!=previous)change=change+1;previous=adjusted;end
if(change<10)$fatal(1,"Vibrato is not continuous");
clear=1;clocks(1);if(adjusted!==0)$fatal(1,"Pitch clear failed");clear=0;
$display("PASS: shared four-voice pitch scaler unity/signed bend/continuous vibrato/clear");$finish;
end endmodule
