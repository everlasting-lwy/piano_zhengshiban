`timescale 1ns/1ps
module tb_song_guide_board;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,rx=1,sw=1;reg[17:0]keys=18'h3ffff;
tri1 scl,sda,vscl,vsda;
wire bclk,lrck,din;
localparam BIT=16;
top_piano_acg525 #(.BT_UART_CYCLES(BIT),.ENC_SAMPLE_CYCLES(1),
 .ENC_AB_FILTER_SAMPLES(2),.ENC_SW_FILTER_SAMPLES(3),.ENC_LONG_PRESS_SAMPLES(30),
 .OLED_I2C_DIV(2),.OLED_BOOT_CYCLES(1),.OLED_REFRESH_CYCLES(1000),.OLED_TIMEOUT_CYCLES(40),
 .VISUAL_I2C_DIV(2),.VISUAL_BOOT_CYCLES(1),.VISUAL_REFRESH_CYCLES(1000),.VISUAL_TIMEOUT_CYCLES(40)) dut(
 .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),
 .key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(rx),.hc_echo(1'b0),
 .encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),.oled_scl(scl),.oled_sda(sda),
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(sw),
 .visual_oled_scl(vscl),.visual_oled_sda(vsda),.i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task byte_in;input[7:0]v;integer n;begin
 rx=0;clocks(BIT);for(n=0;n<8;n=n+1)begin rx=v[n];clocks(BIT);end rx=1;clocks(BIT+4);
end endtask
function[7:0]crc8;input[63:0]v;reg[7:0]c;integer n,j;begin
 c=0;for(n=0;n<8;n=n+1)begin c=c^v[n*8+:8];for(j=0;j<8;j=j+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;
end endfunction
reg[7:0]seq=0;
task send;input[7:0]cmd;input[47:0]p;integer n;begin
 byte_in(8'ha5);byte_in(8'h5a);byte_in(seq);byte_in(cmd);
 for(n=0;n<6;n=n+1)byte_in(p[n*8+:8]);byte_in(crc8({p,cmd,seq}));byte_in(8'h0d);seq=seq+1;clocks(100);
end endtask
initial begin
 clocks(10);rst_n=1;clocks(100);
 // CRC16 independently calculated for bytes01 00 00 84 00 00 00 00 02.
 send(8'h10,{8'd0,8'd1,16'h0192,16'd3});
 send(8'h11,{8'd0,24'h000001,16'd0});
 send(8'h11,{8'd0,24'h000084,16'd1});
 send(8'h11,{8'd0,24'h020000,16'd2});send(8'h12,0);
 if(!dut.song_loaded || dut.song_total!=3)$fatal(1,"UART whole-song upload was not committed");
 sw=0;clocks(65);sw=1;clocks(20);
 if(!dut.song_active || dut.song_target!=1)$fatal(1,"long encoder did not enter first guide step");
 // Phone keyboard must never fulfill a physical target.
 send(8'h09,48'h000000001000);clocks(100);
 if(dut.song_step!=0)$fatal(1,"remote phone key advanced physical guide");
 keys[0]=0;clocks(52000);
 if(dut.song_step!=1 || dut.song_target!=18'h84)$fatal(1,"physical C4 did not advance to black/white chord");
 clocks(1000);if(dut.song_step!=1)$fatal(1,"holding previous key skipped a step");
 keys=18'h3ffff;clocks(102000);
 keys[7]=0;clocks(52000);if(dut.song_step!=1)$fatal(1,"partial chord advanced");
 keys[2]=0;clocks(52000);
 if(dut.song_step!=2 || dut.song_target!=18'h20000)$fatal(1,"four-voice-capable physical chord mapping incorrect");
 keys=18'h3ffff;clocks(102000);keys[0]=0;clocks(52000);
 if(!dut.song_wrong)$fatal(1,"wrong key missing diagnostic");
 keys[17]=0;clocks(52000);if(dut.song_complete)$fatal(1,"wrong chord accepted");
 keys=18'h3ffff;clocks(102000);keys[17]=0;clocks(52000);
 if(!dut.song_complete || dut.song_step!=3 || dut.song_target!=0)$fatal(1,"F5 did not finish guide");
 send(8'h13,3);if(dut.song_loaded || !dut.song_active)$fatal(1,"Bluetooth delete did not retain NO SONG guide page");
 if(dut.u_core.vol!=15)$fatal(1,"guide feature changed volume");
 $display("PASS: actualUART song download, encoder entry,18-key physical-only progress, staggered chord/held/wrong protection and Bluetooth delete; audio volume unchanged");$finish;
end
initial begin #22000000;$fatal(1,"board song guide timeout");end
endmodule
