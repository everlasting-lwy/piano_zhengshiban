`timescale 1ns/1ps
module tb_spectrum32;
reg clk=0;always #10 clk=~clk;
reg rst=0,clear=0,tick=0;reg signed[15:0] sample=0;
wire[255:0] bars;wire[511:0] magnitudes;wire valid;
spectrum32 d(clk,rst,clear,tick,sample,bars,magnitudes,valid);
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
integer f,n,k,value,expected,actual,fd,code,count=0;
always @(negedge clk)if(valid)count=count+1;
initial begin
fd=$fopen("tmp/spectrum/vectors.txt","r");if(!fd)$fatal(1,"Missing spectrum vectors");
clocks(3);rst=1;clocks(3);
for(f=0;f<7;f=f+1)begin
if(f==0 || f==4)begin clear=1;clocks(2);clear=0;end
for(n=0;n<256;n=n+1)begin
code=$fscanf(fd,"%d\n",value);sample=value;tick=1;clocks(1);tick=0;clocks(511);
end
if(count!=f+1)$fatal(1,"DFT frame lost/published early");
for(k=0;k<32;k=k+1)begin
code=$fscanf(fd,"%d\n",expected);actual=magnitudes[k*16+:16];
if(actual<expected-4 || actual>expected+4)$fatal(1,"DFT mismatch frame%0d bin%0d actual%0d expected%0d",f,k,actual,expected);
end
end
clear=1;clocks(2);clear=0;clocks(300);
if(bars!==0||magnitudes!==0||valid)$fatal(1,"Clear retained spectral snapshot");
$display("PASS:32 real DFT bins vs independent float reference,7frames silence/DC/negative/two tones/chord/offbin,clear/no dropped samples");$finish;
end
initial begin #20000000;$fatal(1,"spectrum timeout");end
endmodule
