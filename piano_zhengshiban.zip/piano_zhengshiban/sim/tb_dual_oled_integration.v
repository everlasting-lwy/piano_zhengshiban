`timescale 1ns/1ps
module tb_dual_oled_integration;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,rx=1,a=1,b=1,sw=1,va=1,vb=1,vsw=1;
reg old_stuck=0,new_stuck=0;
reg [17:0] keys=18'h3ffff;
tri1 scl,sda,vscl,vsda;
assign scl=old_stuck ? 1'b0:1'bz;
assign vsda=new_stuck ? 1'b0:1'bz;
wire [31:0] old_frames,new_frames;
wire bclk,lrck,din,reference_bclk,reference_lrck,reference_din;
dual_display_sink old_sink(.rst_n(rst_n),.scl(scl),.sda(sda),.frames(old_frames));
dual_display_sink new_sink(.rst_n(rst_n),.scl(vscl),.sda(vsda),.frames(new_frames));
localparam BIT=16;
top_piano_acg525 #(.BT_UART_CYCLES(BIT),.ENC_SAMPLE_CYCLES(1),
 .ENC_AB_FILTER_SAMPLES(2),.ENC_SW_FILTER_SAMPLES(3),.ENC_LONG_PRESS_SAMPLES(60),
 .OLED_I2C_DIV(2),.OLED_BOOT_CYCLES(1),.OLED_REFRESH_CYCLES(1000),
 .OLED_RETRY_CYCLES(100),.OLED_TIMEOUT_CYCLES(40),
 .VISUAL_I2C_DIV(2),.VISUAL_BOOT_CYCLES(1),.VISUAL_REFRESH_CYCLES(1000),
 .VISUAL_RETRY_CYCLES(100),.VISUAL_TIMEOUT_CYCLES(40)) dut(
 .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),
 .key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(rx),.hc_echo(1'b0),
 .encoder_a(a),.encoder_b(b),.encoder_sw_n(sw),.oled_scl(scl),.oled_sda(sda),
 .visual_encoder_a(va),.visual_encoder_b(vb),.visual_encoder_sw_n(vsw),
 .visual_oled_scl(vscl),.visual_oled_sda(vsda),
 .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
// Frozen pre-dual-OLED core: same synchronized physical/audio controls and
// UART stimulus, with no visual enable or other visual-control connection.
reference_single_oled_core #(.BT_UART_CYCLES(BIT)) reference_core(
 .sys_clk(clk),.sys_rst_n(dut.core_rst_n),.key_in(dut.keys_sync[17:0]),
 .key0(dut.keys_sync[21]),.key1(1'b1),.key2(1'b1),
 .key3(dut.keys_sync[20]),.key4(dut.keys_sync[22]),
 .local_command(dut.local_command),.local_command_valid(dut.local_command_valid),
 .uart_rxd(rx),.hc_echo(1'b0),
 .i2s_bclk(reference_bclk),.i2s_lrck(reference_lrck),.i2s_din(reference_din));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task turn;input integer visual,forward;integer i;reg [1:0] phase;begin
 for(i=0;i<4;i=i+1)begin
  if(forward)case(i)0:phase=2'b10;1:phase=0;2:phase=1;3:phase=3;endcase
  else case(i)0:phase=2'b01;1:phase=0;2:phase=2;3:phase=3;endcase
  if(visual)begin va=phase[1];vb=phase[0];end
  else begin a=phase[1];b=phase[0];end
  clocks(10);
 end
 clocks(10);
end endtask
task click;input integer long_press;begin
 vsw=0;clocks(long_press?80:10);vsw=1;clocks(10);
end endtask
task byte_in;input [7:0] v;integer i;begin
 rx=0;clocks(BIT);for(i=0;i<8;i=i+1)begin rx=v[i];clocks(BIT);end
 rx=1;clocks(BIT+4);
end endtask
function [7:0] crc8;input [63:0] v;reg [7:0] c;integer i,j;begin
 c=0;for(i=0;i<8;i=i+1)begin c=c^v[i*8+:8];
 for(j=0;j<8;j=j+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;
end endfunction
task volume8;integer i;begin
 byte_in(8'ha5);byte_in(8'h5a);byte_in(8'h41);byte_in(2);
 byte_in(8);for(i=1;i<6;i=i+1)byte_in(0);
 byte_in(crc8({48'd8,8'd2,8'h41}));byte_in(8'h0d);clocks(32);
end endtask
task await_frames;input integer target_old,target_new;integer n;begin
 n=0;
 // Two WAVE frames can each require 512 trigger-wait + 512 capture
 // samples at 1024 clocks/sample, plus electrical I2C transfer time.
 // 4M clocks (80ms at the real 50MHz clock) bounds that two-frame wait.
 while((old_frames<target_old || new_frames<target_new) && n<4000000)begin clocks(1);n=n+1;end
 if(old_frames<target_old || new_frames<target_new)$fatal(1,"Independent electrical OLED frame stalled");
end endtask
// Receive all 32 physical BCLK bits of both slots (I2S delay, 16 data bits,
// and padding), then compare only once a whole stereo frame has arrived.
// Clocks are checked separately, so a missing/shifted serial clock cannot
// hide behind this receiver's shared framing counter.
reg previous_lrck=1,serial_started=0,left_seen=0;
reg [31:0] slot=0,reference_slot=0,left_slot=0,reference_left_slot=0;
reg [63:0] stereo=0,reference_stereo=0;
integer serial_bits=0,complete_stereo=0,nonzero_stereo=0;
always @(negedge clk)if(dut.core_rst_n)begin
 if(bclk!==reference_bclk || lrck!==reference_lrck)
  $fatal(1,"Physical I2S clock differs from unaffected reference");
end
always @(posedge bclk)begin
 if(!dut.core_rst_n)begin
  previous_lrck=lrck;serial_started=0;left_seen=0;serial_bits=0;
 end else begin
  if(lrck!==previous_lrck)begin
   previous_lrck=lrck;serial_started=1;serial_bits=0;slot=0;reference_slot=0;
  end
  if(serial_started)begin
   slot={slot[30:0],din};reference_slot={reference_slot[30:0],reference_din};
   serial_bits=serial_bits+1;
   if(serial_bits==32)begin
    if(lrck)begin left_slot=slot;reference_left_slot=reference_slot;left_seen=1;end
    else if(left_seen)begin
     stereo={left_slot,slot};reference_stereo={reference_left_slot,reference_slot};
     if((^stereo===1'bx) || (^reference_stereo===1'bx) || stereo!==reference_stereo)
      $fatal(1,"Complete physical I2S stereo differs from unaffected reference: frame=%0d view=%0d actual=%016h reference=%016h",complete_stereo,dut.visual_view,stereo,reference_stereo);
     if(left_slot[30:15]!==slot[30:15])$fatal(1,"Complete I2S left/right samples disagree");
     complete_stereo=complete_stereo+1;
     if(left_slot[30:15]!=0 && slot[30:15]!=0)nonzero_stereo=nonzero_stereo+1;
    end
   end
  end
 end
end
integer phase_pairs=0,phase_nonzero=0;
task audio_phase_begin;begin
 phase_pairs=complete_stereo;phase_nonzero=nonzero_stereo;
end endtask
task audio_phase_end;input [8*48-1:0] label;integer n;begin
 n=0;
 while((complete_stereo-phase_pairs<32 || nonzero_stereo-phase_nonzero<16) && n<100000)begin
  clocks(1);n=n+1;
 end
 if(complete_stereo-phase_pairs<32 || nonzero_stereo-phase_nonzero<16)
  $fatal(1,"No complete nonzero I2S progress during %0s: pairs=%0d nonzero=%0d",label,complete_stereo-phase_pairs,nonzero_stereo-phase_nonzero);
 if(keys[0]!==0 || !dut.u_core.physical_keys[0] || !reference_core.physical_keys[0])
  $fatal(1,"Physical C4 was not held during %0s",label);
 $display("AUDIO: %0s complete stereo=%0d nonzero=%0d",label,complete_stereo-phase_pairs,nonzero_stereo-phase_nonzero);
end endtask
// Exercise current-cycle priority and the previous-remote-cycle guard in
// both cores with identical command stimulus while the visual encoder moves.
// Only control inputs are injected; physical keys and all audio remain real.
task remote_collision;begin
 clocks(8);
 force dut.local_command=8'h8e;force dut.local_command_valid=1'b1;
 force dut.u_core.bt_vol=4'd9;force dut.u_core.bt_vol_en=1'b1;
 force reference_core.bt_vol=4'd9;force reference_core.bt_vol_en=1'b1;
 clocks(1);
 if(dut.u_core.vol!==9 || reference_core.vol!==9)$fatal(1,"Current-cycle remote volume lost to local command");
 release dut.u_core.bt_vol_en;release dut.u_core.bt_vol;
 release reference_core.bt_vol_en;release reference_core.bt_vol;
 clocks(1);
 if(dut.u_core.vol!==9 || reference_core.vol!==9)$fatal(1,"Previous-cycle remote write failed to suppress stale local command");
 release dut.local_command_valid;release dut.local_command;
 clocks(4);
 if(dut.u_core.vol!==9 || reference_core.vol!==9)$fatal(1,"Visual/remote collision changed audio readback");
end endtask
integer taps=0,last_tap=0,cycles=0,nonzero=0;
always @(negedge clk)begin
 cycles=cycles+1;
 if(dut.core_rst_n && dut.pcm_frame_valid)begin
  if(last_tap && cycles-last_tap!=1024)$fatal(1,"Two displays disturbed audio cadence");
  taps=taps+1;last_tap=cycles;
  if(dut.pcm_frame!=0)nonzero=nonzero+1;
 end
end
reg [31:0] before_state;
integer old_before,new_before,taps_before,online_guard;
initial begin
 clocks(10);rst_n=1;clocks(40);keys[0]=0;
 if(dut.visual_view!==0 || dut.visual_gain_shift!==2 || dut.local_selected!==7)
  $fatal(1,"Dual OLED default selections/gain incorrect");
 await_frames(1,1);
 // The electrical receiver sees the last data byte before its ACK/STOP and
 // before the first AF display-on transaction. Wait for that bounded finish.
 online_guard=0;
 while((!dut.u_oled.online || !dut.u_visual_oled.online) && online_guard<10000)begin
  clocks(1);online_guard=online_guard+1;
 end
 if(dut.u_core.vol!==15 || !dut.u_oled.online || !dut.u_visual_oled.online || nonzero<32)
  $fatal(1,"Both 0x3C screens/local C4 did not start:vol%0d oldonline%0d newonline%0d nonzero%0d oldframes%0d newframes%0d",dut.u_core.vol,dut.u_oled.online,dut.u_visual_oled.online,nonzero,old_frames,new_frames);
 turn(0,0);
 if(dut.u_core.vol!==14)$fatal(1,"Original encoder no longer controls audio volume");
 before_state=dut.panel_state;
 audio_phase_begin();turn(1,1);audio_phase_end("WAVE gain 4x to 8x");
 audio_phase_begin();turn(1,1);audio_phase_end("WAVE gain 8x to 16x");
 audio_phase_begin();turn(1,1);audio_phase_end("WAVE gain clamp");
 if(dut.visual_gain_shift!==4 || dut.panel_state!==before_state || dut.local_selected!==7)
  $fatal(1,"Visual gain/clamp changed audio parameters");
 audio_phase_begin();click(0);audio_phase_end("SPECTRUM view entry");
 if(dut.visual_view!==1 || dut.visual_gain_shift!==0)$fatal(1,"Visual spectrum/defaultgain selection failed");
 audio_phase_begin();turn(1,1);audio_phase_end("SPECTRUM gain change");
 audio_phase_begin();click(1);audio_phase_end("SPECTRUM longpress GUIDE entry");
 if(dut.visual_view!==1 || dut.visual_gain_shift!==1 || !dut.song_active || dut.panel_state!==before_state)
  $fatal(1,"Visual guide entry switched graph or changed audio");
 audio_phase_begin();click(1);audio_phase_end("GUIDE longpress exit");
 if(dut.song_active)$fatal(1,"Guide exit failed");
 old_before=old_frames;new_before=new_frames;
 await_frames(old_before+1,new_before+1);
 audio_phase_begin();volume8();audio_phase_end("framed Bluetooth volume while SPECTRUM");
 if(dut.u_core.vol!==8 || dut.visual_view!==1 || dut.visual_gain_shift!==1)
  $fatal(1,"Framed Bluetooth volume/view isolation failed");
 old_before=old_frames;await_frames(old_before+2,new_frames);
 if(dut.u_oled.snapshot[3:0]!==8)$fatal(1,"Original OLED failed to show actual Bluetooth readback");
 turn(0,1);
 if(dut.u_core.vol!==9)$fatal(1,"Original encoder used stale value after Bluetooth update");
 before_state=dut.panel_state;
 audio_phase_begin();
 fork remote_collision();turn(1,1);join
 audio_phase_end("visual turn with current/previous remote writes");
 if(dut.panel_state!==before_state)$fatal(1,"Visual/remote collision changed panel_state");
 audio_phase_begin();click(0);audio_phase_end("XY view entry");
 if(dut.visual_view!==2 || dut.visual_gain_shift!==2)$fatal(1,"Visual XY/defaultgain selection failed");
 audio_phase_begin();turn(1,1);audio_phase_end("XY gain change");
 audio_phase_begin();click(1);audio_phase_end("XY longpress GUIDE entry");
 if(dut.visual_view!==2 || dut.visual_gain_shift!==3 || !dut.song_active || dut.panel_state!==before_state)
  $fatal(1,"Visual XY actions changed audio parameters");
 audio_phase_begin();click(1);audio_phase_end("GUIDE return to XY");
 if(dut.song_active)$fatal(1,"Second guide exit failed");
 audio_phase_begin();click(0);audio_phase_end("WAVE return with remembered gain");
 if(dut.visual_view!==0 || dut.visual_gain_shift!==4)$fatal(1,"WAVE remembered gain lost");
 audio_phase_begin();
 new_stuck=1;old_before=old_frames;taps_before=taps;
 await_frames(old_before+2,new_frames);
 audio_phase_end("visual OLED SDA stuck low");
 if(taps<=taps_before+16 || dut.u_core.vol!==9)$fatal(1,"Stuck visual OLED affected audio or parameters");
 new_stuck=0;old_before=old_frames;new_before=new_frames;
 await_frames(old_before+1,new_before+1);
 audio_phase_begin();
 old_stuck=1;new_before=new_frames;taps_before=taps;
 await_frames(old_frames,new_before+2);
 audio_phase_end("parameter OLED SCL stuck low");
 if(taps<=taps_before+16 || dut.u_core.vol!==9)$fatal(1,"Stuck parameter OLED affected visual/audio");
 old_stuck=0;old_before=old_frames;
 await_frames(old_before+1,new_frames);
 $display("PASS: two physical0x3C OLED buses, independent encoders/readback,4x default, framedBT, current/previous remote arbitration, all views and both stuckbus complete-I2S reference isolation (%0d stereo frames)",complete_stereo);
 $finish;
end
initial begin #180000000;$fatal(1,"Dual display integration timeout");end
endmodule

module dual_display_sink(input wire rst_n,input wire scl,inout wire sda,output reg[31:0]frames=0);
reg active=0,low=0,ack=0;reg [7:0] shift=0,control=0;
integer bits=0,bytes=0,page=0;
assign sda=low?1'b0:1'bz;
always @(negedge rst_n)begin active=0;low=0;bits=0;bytes=0;frames=0;page=0;end
always @(negedge sda)if(rst_n && scl===1'b1 && !low)begin active=1;bits=0;bytes=0;end
always @(posedge sda)if(rst_n && scl===1'b1)active=0;
always @(posedge scl)if(active)begin
 if(bits<8)begin
  shift={shift[6:0],sda};bits=bits+1;
  if(bits==8)begin
   if(bytes==0)ack=(shift==8'h78);
   if(bytes==1)control=shift;
   if(bytes==2 && ack && control==0 && shift>=8'hb0 && shift<=8'hb7)page=shift-8'hb0;
   if(bytes==129 && ack && control==8'h40 && page==7)frames=frames+1;
   bytes=bytes+1;
  end
 end else bits=9;
end
always @(negedge scl)if(active)begin
 if(bits==8)low=ack;
 else if(bits==9)begin low=0;bits=0;end
end
endmodule
