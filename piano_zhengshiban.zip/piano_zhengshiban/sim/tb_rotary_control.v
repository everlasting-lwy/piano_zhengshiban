`timescale 1ns/1ps
module tb_rotary_control;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=1,b=1,sw=1;
reg [31:0] values={1'b0,2'd0,4'd0,4'd0,4'd0,4'd0,5'd8,4'd15,4'd15};
wire [2:0] selected;wire [7:0] command;wire valid;
integer events=0;reg[7:0] last;
rotary_control #(.SAMPLE_CYCLES(2),.AB_FILTER_SAMPLES(1),.SW_FILTER_SAMPLES(3),.LONG_PRESS_SAMPLES(30)) dut(
 .clk(clk),.rst_n(rst_n),.a(a),.b(b),.sw_n(sw),.values(values),
 .selected(selected),.command(command),.command_valid(valid));
always @(posedge clk)if(valid)begin events=events+1;last=command;end
task phase;input[1:0] ab;begin {a,b}=ab;repeat(10)@(negedge clk);end endtask
task cw;begin phase(2'b10);phase(0);phase(1);phase(3);end endtask
task ccw;begin phase(1);phase(0);phase(2);phase(3);end endtask
task click;begin sw=0;repeat(20)@(negedge clk);sw=1;repeat(20)@(negedge clk);end endtask
integer n;
initial begin
 repeat(8)@(negedge clk);rst_n=1;repeat(12)@(negedge clk);
 ccw();if(events!=1 || last!=8'hae)$fatal(1,"one detent must decrement actual expression");
 values[7:4]=14;cw();if(events!=2 || last!=8'haf)$fatal(1,"positive detent/actual feedback");
 n=events;phase(2);phase(0);phase(2);phase(3);
 if(events!=n)$fatal(1,"partial reversal generated detent");
 phase(0);phase(3);if(events!=n)$fatal(1,"illegal diagonal generated detent");
 phase(2);phase(3);phase(2);phase(0);phase(1);phase(3);
 if(events!=n+1)$fatal(1,"bounce created duplicate/lost detent");
 click();if(selected!=1)$fatal(1,"short press selection");
 values[12:8]=0;ccw();if(last!=8'hb0)$fatal(1,"bend lower endpoint wraps");
 values[12:8]=16;cw();if(last!=8'hc0)$fatal(1,"bend upper endpoint wraps");
 values[12:8]=3;n=events;sw=0;repeat(110)@(negedge clk);
 if(events!=n+1 || last!=8'hb8)$fatal(1,"long reset not one-shot/default");
 sw=1;repeat(24)@(negedge clk);if(selected!=1)$fatal(1,"long release also short click");
 values[12:8]=12;ccw();if(last!=8'hbb)$fatal(1,"external change ignored by next detent");
 for(n=0;n<7;n=n+1)click();
 if(selected!=0)$fatal(1,"selection cycle must wrap eight items");
 $display("PASS: rotary detents/reverse/bounce/illegal transitions, endpoints, live feedback, short/long press");
 $finish;
end
initial begin #1000000;$fatal(1,"timeout");end
endmodule
