`timescale 1ns/1ps
// A known post-effect PCM sample exercises production master gain and I2S.
module tb_encoder_volume;
reg clk=0;always #10 clk=~clk;
reg rst=0,a=1,b=1,sw=1;wire bclk,lrck,din;
tri1 scl,sda;
top_piano_acg525 #(.ENC_SAMPLE_CYCLES(2),.ENC_AB_FILTER_SAMPLES(1),.ENC_SW_FILTER_SAMPLES(3),.ENC_LONG_PRESS_SAMPLES(30)) dut(
.visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst),.key_in(18'h3ffff),.key_timbre(1'b1),.key_mode(1'b1),
.key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0),
.encoder_a(a),.encoder_b(b),.encoder_sw_n(sw),.oled_scl(scl),.oled_sda(sda),
.i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
reg prev_lrck=0;integer bitcount=0;reg[15:0] shifted=0,last_word=16'hffff;
always @(posedge bclk)begin
 if(!dut.core_rst_n)begin prev_lrck=lrck;bitcount=0;shifted=0;last_word=16'hffff;end
 else if(prev_lrck!=lrck)begin prev_lrck=lrck;bitcount=0;shifted=0;end
 else begin
  bitcount=bitcount+1;
  if(bitcount<=16)shifted={shifted[14:0],din};
  if(bitcount==16)last_word=shifted;
 end
end
task phase;input[1:0] v;begin {a,b}=v;repeat(10)@(negedge clk);end endtask
task cw;begin phase(2);phase(0);phase(1);phase(3);end endtask
task ccw;begin phase(1);phase(0);phase(2);phase(3);end endtask
task expect_word;input[15:0] want;integer j;begin
 j=0;while(last_word!==want && j<4096)begin @(negedge clk);j=j+1;end
 if(last_word!==want)$fatal(1,"master gain/I2S want=%0d got=%0d",want,last_word);
end endtask
integer i;
initial begin
 repeat(8)@(negedge clk);rst=1;repeat(40)@(negedge clk);
 if(dut.local_selected!==7)$fatal(1,"board must start with VOLUME selected");
 force dut.u_core.audio_effected=16'sd12000;
 expect_word(16'd11250); // 12000 * 15 /16, independent literal reference
 ccw();if(dut.u_core.vol!=14)$fatal(1,"rotary did not lower master volume");
 expect_word(16'd10500);
 for(i=0;i<14;i=i+1)ccw();
 if(dut.u_core.vol!=0)$fatal(1,"master lower endpoint");
 expect_word(0);repeat(2048)@(negedge clk);
 if(last_word!=0)$fatal(1,"volume0 must silence even nonzero effected PCM");
 for(i=0;i<16;i=i+1)cw();
 if(dut.u_core.vol!=15)$fatal(1,"master upper saturation");
 expect_word(16'd11250);
 sw=0;repeat(20)@(negedge clk);sw=1;repeat(20)@(negedge clk);
 if(dut.local_selected!=0)$fatal(1,"short press Volume -> Expression");
 release dut.u_core.audio_effected;
 $display("PASS: default Volume, live rotary master gain, 0 mute, 15 saturation and actual I2S words");
 $finish;
end
initial begin #1000000;$fatal(1,"volume timeout");end
endmodule
