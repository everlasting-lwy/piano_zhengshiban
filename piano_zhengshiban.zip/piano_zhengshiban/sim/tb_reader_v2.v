`timescale 1ns/1ps
module tb_reader_v2 #(parameter ROOT_LIMIT=4096,IO_LIMIT=100000000);
reg clk=0;always #5 clk=~clk;
reg rst_n=0,media_ready=1,request=0;reg[31:0]media_sectors;reg[7:0]media_error=0;
reg[1:0]operation=0;reg[4:0]slot=3;reg[15:0]write_size=724;
wire mounted,busy,done;wire[7:0]error,file_attributes;wire[15:0]file_size;wire[31:0]present_slots;wire write_locked;
wire read_valid;wire[15:0]read_index;wire[7:0]read_data;reg read_ready=0;
wire source_request;wire[15:0]source_index;reg source_valid=0;reg[7:0]source_data=0;
wire block_start,block_write;wire[31:0]block_lba;reg block_busy=0,block_done=0;reg[7:0]block_error=0;
reg rd_valid=0;reg[8:0]rd_index=0;reg[7:0]rd_data=0;reg wr_request=0;reg[8:0]wr_index=0;wire wr_valid;wire[7:0]wr_data;
fat32_file_store #(.ROOT_SECTOR_LIMIT(ROOT_LIMIT),.IO_TIMEOUT_CYCLES(IO_LIMIT)) dut(.*);
reg[7:0]sector[0:511],old_song[0:723];integer fd,mode=0,pos=0,n,seek_result,cycles=0,read_count=0;
reg[4095:0]image_name,old_name;reg[255:0]case_name;reg[31:0]pending_lba;reg fail_once=0,check_bytes=0;
always @(posedge clk)begin
 cycles<=cycles+1;block_done<=0;rd_valid<=0;
 if(cycles>5000000)$fatal(1,"reader watchdog state%0d",dut.state);
 if(block_write||wr_valid||source_request)$fatal(1,"read-only layer exposed a write");
 if(block_start)begin
  if(block_busy||block_lba>=media_sectors)$fatal(1,"invalid/overlapping block request");
  block_busy<=1;block_error<=0;pending_lba<=block_lba;pos<=0;mode<=1;
 end else if(mode==1)begin seek_result=$fseek(fd,pending_lba*512,0);n=$fread(sector,fd);if(n!=512)$fatal(1,"short image");mode<=2;end
 else if(mode==2)begin rd_valid<=1;rd_index<=pos;rd_data<=sector[pos];if(pos==511)mode<=3;else pos<=pos+1;end
 else if(mode==3)begin
  block_busy<=0;block_done<=1;mode<=0;
  if(case_name=="read_io"&&operation==1&&!fail_once)begin block_error<=8'h42;fail_once<=1;end
 end
 read_ready<=(cycles%5)!=0;
 if(read_valid&&read_ready)begin
  if(read_index!=read_count)$fatal(1,"stream index %0d !=%0d",read_index,read_count);
  if(check_bytes&&read_data!==old_song[read_count])$fatal(1,"raw byte changed at %0d",read_count);
  read_count<=read_count+1;
 end
end
task cmd;input[1:0]op;integer t;begin
 @(negedge clk);operation=op;request=1;@(negedge clk);request=0;t=0;
 while(!done&&t<4900000)begin @(negedge clk);t=t+1;end
 if(!done)$fatal(1,"reader command timeout");@(negedge clk);
end endtask
task success;begin if(error!=0)$fatal(1,"unexpected error%0d op%0d",error,operation);end endtask
reg volume_bad,file_bad;
initial begin
 if(!$value$plusargs("IMAGE=%s",image_name)||!$value$plusargs("CASE=%s",case_name)||!$value$plusargs("SECTORS=%d",media_sectors)||!$value$plusargs("OLD=%s",old_name))$fatal;
 $readmemh(old_name,old_song);fd=$fopen(image_name,"rb");if(!fd)$fatal;
 volume_bad=case_name=="bad_geometry"||case_name=="fat16"||case_name=="bad_version"||case_name=="bad_root"||case_name=="bad_spc"||case_name=="bad_fats"||case_name=="bad_root_entries"||case_name=="bad_tot16"||case_name=="bad_fat16"||case_name=="card_bounds"||case_name=="partition_volume_bounds"||case_name=="partition_extent_bounds"||case_name=="cyclic_root"||case_name=="root_bound"||case_name=="busy_stuck"||case_name=="no_media"||case_name=="end_self"||case_name=="end_back"||case_name=="end_tail_loop"||case_name=="end_tail_back";
 file_bad=case_name=="directory"||case_name=="cyclic_file"||case_name=="range_file";
 repeat(5)@(negedge clk);rst_n=1;if(case_name=="busy_stuck")block_busy=1;if(case_name=="no_media")media_ready=0;
 cmd(0);
 if(volume_bad)begin if(error==0||mounted)$fatal(1,"unsafe volume accepted");end
 else begin
  success();if(!mounted)$fatal(1,"mount missing");
  if((case_name=="dirty"||case_name=="temp")&&!write_locked)$fatal(1,"maintenance flag missing");
  check_bytes=1;read_count=0;cmd(1);
  if(file_bad)begin if(error==0||read_count!=0)$fatal(1,"unsafe chain/entry streamed");end
  else if(case_name=="read_io")begin
   if(error==0)$fatal(1,"I/O failure hidden");media_error=8'h42;cmd(0);success();read_count=0;cmd(1);success();if(read_count!=724)$fatal(1,"stale-error recovery blocked");
  end else begin success();if(file_size!=724||read_count!=724)$fatal(1,"file length");end
 end
 cmd(2);if(error!=3)$fatal(1,"SAVE must be unsupported3, got%0d",error);
 cmd(3);if(error!=3)$fatal(1,"DELETE must be unsupported3, got%0d",error);
 $fclose(fd);$display("PASS read-only v2 %0s cycles%0d",case_name,cycles);$finish;
end
endmodule
