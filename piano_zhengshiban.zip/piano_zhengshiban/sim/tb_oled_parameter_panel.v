`timescale 1ns/1ps
// Regressions caught: stale/hard-coded values, wrong selection/label, torn frames,
// early AF, missing ACK/readback, absent/stuck-device deadlock. Only pins observed.
module tb_oled_parameter_panel;
parameter integer DIV=2;
parameter [7:0] SLAVE_ADDRESS=8'h7a;
reg clk=0;always #10 clk=~clk;
reg rst_n=0;
reg [2:0] selected=7,volume_source=0;
reg [31:0] values={1'b0,2'd0,4'd0,4'd0,4'd0,4'd0,5'd8,4'd15,4'd15};
localparam [31:0] REMOTE_VALUES={1'b0,2'd2,4'd4,4'd9,4'd12,4'd10,5'd16,4'd7,4'd3};
tri1 scl,sda;
reg slave_low=0,stuck=0,data_stuck=0,stretch=0,present=1;
assign sda=(slave_low || data_stuck) ? 1'b0:1'bz;
assign scl=(stuck || stretch) ? 1'b0:1'bz;
wire online,frame_done;
oled_parameter_panel #(.I2C_DIV(DIV),.BOOT_CYCLES(10),.REFRESH_CYCLES(100),
 .RETRY_CYCLES(30),.TIMEOUT_CYCLES(200)) dut(
 .clk(clk),.rst_n(rst_n),.selected(selected),.values(values),.volume_source(volume_source),
 .scl(scl),.sda(sda),.online(online),.frame_done(frame_done));
integer bits=0,bytes=0,transactions=0,data_pages=0,cmd_pages=0,data_bytes=0;
integer i,j,p,x,fd,current_page=0,af_count=0,init_count=0,init_in_session=0;
reg [7:0] init_bytes[0:24],pixels[0:1023];
reg active=0,ack=0,saw_3c=0,saw_3d=0;
reg [7:0] shift=0,control=0;
always @(negedge sda)if(scl===1'b1 && rst_n && !slave_low)begin
 active=1;bits=0;bytes=0;transactions=transactions+1;
end
always @(posedge sda)if(scl===1'b1 && rst_n)active=0;
always @(posedge scl)if(active)begin
 if(bits<8)begin
  shift={shift[6:0],sda};bits=bits+1;
  if(bits==8)begin
   if(bytes==0)begin
    ack=present && shift==SLAVE_ADDRESS;
    if(shift==8'h78)saw_3c=1;
    if(shift==8'h7a)saw_3d=1;
   end
   if(bytes==1)control=shift;
   if(bytes>=2 && ack && control==8'h40)begin
    if(bytes>129)$fatal(1,"overlong data page");
    pixels[current_page*128+bytes-2]=shift;data_bytes=data_bytes+1;
    if(bytes==129)data_pages=data_pages+1;
   end
   if(bytes>=2 && ack && control==0)begin
    if(bytes==2 && shift==8'hae)begin init_in_session=0;end
    if(init_in_session<25)begin
     init_bytes[init_in_session]=shift;init_in_session=init_in_session+1;
     if(init_in_session==25)init_count=init_count+1;
    end
    if(bytes==2 && shift>=8'hb0 && shift<=8'hb7)begin
     current_page=shift-8'hb0;
     if(current_page!=cmd_pages%8)$fatal(1,"unordered page command");
     cmd_pages=cmd_pages+1;
    end
    if(shift==8'haf)begin
     if(data_pages!=8 || data_bytes!=1024)$fatal(1,"AF before complete first frame");
     af_count=af_count+1;
    end
   end
   bytes=bytes+1;
  end
 end else bits=9;
end
always @(negedge scl)if(active)begin
 if(bits==8)slave_low=ack;
 else if(bits==9)begin slave_low=0;bits=0;end
end
// Independent literal 5x7 glyph fixtures; production font is never instantiated here.
function [39:0] glyph;
 input [7:0] c;
 begin case(c)
 " ":glyph=40'h0000000000;"/":glyph=40'h2010080402;
 "0":glyph=40'h3e5149453e;"1":glyph=40'h00427f4000;
 "2":glyph=40'h4261514946;"3":glyph=40'h2141454b31;
 "4":glyph=40'h1814127f10;"5":glyph=40'h2745454539;
 "6":glyph=40'h3c4a494930;"7":glyph=40'h0171090503;
 "8":glyph=40'h3649494936;"9":glyph=40'h064949291e;
 "A":glyph=40'h7e1111117e;"B":glyph=40'h7f49494936;
 "C":glyph=40'h3e41414122;"D":glyph=40'h7f4141221c;
 "E":glyph=40'h7f49494941;"H":glyph=40'h7f0808087f;
 "I":glyph=40'h00417f4100;"K":glyph=40'h7f08142241;
 "L":glyph=40'h7f40404040;"M":glyph=40'h7f020c027f;
 "N":glyph=40'h7f0408107f;"O":glyph=40'h3e4141413e;
 "P":glyph=40'h7f09090906;"R":glyph=40'h7f09192946;
 "S":glyph=40'h4649494931;"T":glyph=40'h01017f0101;
 "U":glyph=40'h3f4040403f;"V":glyph=40'h1f2040201f;
 "X":glyph=40'h6314081463;
 default:begin $fatal(1,"missing independent fixture glyph %c",c);glyph=0;end
 endcase end
endfunction
reg [167:0] lines[0:7];
reg [39:0] expected_glyph;
reg [7:0] expected;
integer bar_width;
task expect_frame;
 input integer scenario; // -1 default, otherwise selected parameter with remote values
 input [8*160-1:0] artifact;
 begin
  wait(!frame_done);wait(frame_done);@(negedge clk);
  if(!online || data_pages!=8 || cmd_pages!=8 || data_bytes!=1024)
   $fatal(1,"incomplete parameter frame online=%b pages=%0d cmds=%0d bytes=%0d",online,data_pages,cmd_pages,data_bytes);
  lines[0]="PIANOLINK LOCAL      ";lines[3]="                     ";
  if(scenario==-1)begin
   lines[1]="08 VOLUME            ";lines[2]="VALUE 15 / 15 SRC I  ";bar_width=128;
   lines[4]="REV 00  ECHO 00      ";lines[5]="CHR 00  TIME 084     ";
   lines[6]="EXP 15  BEND 08      ";lines[7]="VIB 00  VOL 15       ";
  end else begin
   lines[4]="REV 12  ECHO 09      ";lines[5]="CHR 04  TIME 168     ";
   lines[6]="EXP 07  BEND 16      ";lines[7]="VIB 10  VOL 03       ";
   case(scenario)
    0:begin lines[1]="01 EXPRESSION        ";lines[2]="VALUE 07 / 15 SRC B  ";bar_width=56;end
    1:begin lines[1]="02 BEND CENTER 08    ";lines[2]="VALUE 16 / 16 SRC B  ";bar_width=128;end
    2:begin lines[1]="03 VIBRATO           ";lines[2]="VALUE 10 / 15 SRC B  ";bar_width=80;end
    3:begin lines[1]="04 REVERB            ";lines[2]="VALUE 12 / 15 SRC B  ";bar_width=96;end
    4:begin lines[1]="05 ECHO              ";lines[2]="VALUE 09 / 15 SRC B  ";bar_width=72;end
    5:begin lines[1]="06 CHORUS            ";lines[2]="VALUE 04 / 15 SRC B  ";bar_width=32;end
    6:begin lines[1]="07 TIME              ";lines[2]="TIME 168 MS   SRC B  ";bar_width=128;end
    7:begin lines[1]="08 VOLUME            ";lines[2]="VALUE 03 / 15 SRC B  ";bar_width=24;end
   endcase
  end
  fd=$fopen(artifact,"w");if(!fd)$fatal(1,"cannot save parameter frame");
  for(i=0;i<1024;i=i+1)begin
   p=i/128;x=i%128;
   if(p==3)expected=(x==0 || x==127 || x<bar_width) ? 8'h7e : 8'h42;
   else begin
    expected=0;
    if(x/6<21 && x%6<5)begin expected_glyph=glyph(lines[p][167-(x/6)*8-:8]);expected=expected_glyph[39-(x%6)*8-:8];end
    if(p==1)expected=~expected;
   end
   if(pixels[i]!==expected)$fatal(1,"scenario %0d page %0d x%0d got %02x expected %02x",scenario,p,x,pixels[i],expected);
   $fdisplay(fd,"%02x",pixels[i]);
  end
  $fclose(fd);
  data_pages=0;cmd_pages=0;data_bytes=0;
 end
endtask
task reset_monitor;
 begin slave_low=0;active=0;data_pages=0;cmd_pages=0;data_bytes=0;end
endtask
initial begin
 repeat(8)@(negedge clk);rst_n=1;
 // Change every field and selection after page 0: complete old frame must survive.
 fork
  begin wait(data_pages==1);@(negedge clk);values=REMOTE_VALUES;selected=0;volume_source=3;end
  expect_frame(-1,"tmp/dual_oled_20261027/parameter_initial_frozen.hex");
 join
 if(!saw_3c || (SLAVE_ADDRESS==8'h7a && !saw_3d) || af_count!=1)$fatal(1,"address fallback/AF sequence");
 if(init_count!=1 ||
  {init_bytes[0],init_bytes[1],init_bytes[2],init_bytes[3],init_bytes[4]}!==40'hae00104081 ||
  {init_bytes[5],init_bytes[6],init_bytes[7],init_bytes[8],init_bytes[9]}!==40'hcfa1c8a6a8 ||
  {init_bytes[10],init_bytes[11],init_bytes[12],init_bytes[13],init_bytes[14]}!==40'h3fd300d580 ||
  {init_bytes[15],init_bytes[16],init_bytes[17],init_bytes[18],init_bytes[19]}!==40'hd9f1da12db ||
  {init_bytes[20],init_bytes[21],init_bytes[22],init_bytes[23],init_bytes[24]}!==40'h3020028d14)
  $fatal(1,"factory init sequence changed");
 for(j=0;j<8;j=j+1)begin
  selected=j;
  expect_frame(j,"tmp/dual_oled_20261027/parameter_selected.hex");
 end
 present=0;repeat(10000)@(negedge clk);
 if(online || frame_done)$fatal(1,"absent OLED must go offline");
 reset_monitor();present=1;expect_frame(7,"tmp/dual_oled_20261027/parameter_absent_recovered.hex");
 stuck=1;repeat(10000)@(negedge clk);if(online)$fatal(1,"stuck SCL not offline");
 reset_monitor();stuck=0;expect_frame(7,"tmp/dual_oled_20261027/parameter_scl_recovered.hex");
 data_stuck=1;repeat(10000)@(negedge clk);if(online)$fatal(1,"stuck SDA not offline");
 reset_monitor();data_stuck=0;expect_frame(7,"tmp/dual_oled_20261027/parameter_sda_recovered.hex");
 if(af_count!=4 || init_count<4)$fatal(1,"recovery must reinitialize and enable after frame");
 $display("PASS: parameter OLED actual 1024-byte frames, Volume15, all labels/remote values, atomic selection/value/source, full init before AF, address fallback, stretch/NACK/absent/stuck-SCL/stuck-SDA recovery (DIV=%0d address=%02x)",DIV,SLAVE_ADDRESS);
 $finish;
end
initial begin
 wait(rst_n);wait(transactions>=2);@(negedge scl);stretch=1;repeat(20)@(negedge clk);stretch=0;
end
initial begin #(50000000*DIV);$fatal(1,"parameter OLED timeout");end
endmodule

