`timescale 1ns/1ps
// Pins only: detects phantom startup/bounce, incorrect remembered gains and
// a long release accidentally advancing the view.
module tb_visual_rotary_control;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=0,b=0,sw=1;
wire [1:0] view;wire [2:0] gain;
visual_rotary_control #(.SAMPLE_CYCLES(2),.AB_FILTER_SAMPLES(3),
 .SW_FILTER_SAMPLES(3),.LONG_PRESS_SAMPLES(40)) dut(
 .clk(clk),.rst_n(rst_n),.a(a),.b(b),.sw_n(sw),.guide_active(1'b0),.view(view),.gain_shift(gain));
task phase;input[1:0] ab;begin {a,b}=ab;repeat(14)@(negedge clk);end endtask
task cw;begin phase(1);phase(3);phase(2);phase(0);end endtask
task ccw;begin phase(2);phase(3);phase(1);phase(0);end endtask
task click;begin sw=0;repeat(18)@(negedge clk);sw=1;repeat(18)@(negedge clk);end endtask
wire [1:0] reverse_view;wire [2:0] reverse_gain;
visual_rotary_control #(.SAMPLE_CYCLES(2),.AB_FILTER_SAMPLES(3),
 .SW_FILTER_SAMPLES(3),.LONG_PRESS_SAMPLES(40),.REVERSE(1)) reverse_dut(
 .clk(clk),.rst_n(rst_n),.a(a),.b(b),.sw_n(sw),.guide_active(1'b0),.view(reverse_view),.gain_shift(reverse_gain));
integer i;
initial begin
 repeat(8)@(negedge clk);rst_n=1;repeat(30)@(negedge clk);
 if(view!=0 || gain!=2)$fatal(1,"startup phase00/default WAVE4X");
 // Short phase spikes do not count as motion.
 {a,b}=1;repeat(2)@(negedge clk);{a,b}=0;repeat(20)@(negedge clk);
 if(gain!=2)$fatal(1,"AB contact spike changed gain");
 phase(1);phase(0);if(gain!=2)$fatal(1,"partial reversal changed gain");
 phase(3);phase(0);if(gain!=2)$fatal(1,"diagonal changed gain");
 cw();if(gain!=3 || reverse_gain!=1)$fatal(1,"CW/reverse must change gain in opposite directions");
 repeat(4)cw();if(gain!=4)$fatal(1,"upper clamp");
 click();if(view!=1 || gain!=0)$fatal(1,"spectrum default1X");
 ccw();if(gain!=0)$fatal(1,"lower clamp");cw();
 click();if(view!=2 || gain!=2)$fatal(1,"XY default4X");ccw();
 click();if(view!=0 || gain!=4)$fatal(1,"wrap/remember WAVE");
 click();if(view!=1 || gain!=1)$fatal(1,"remember spectrum");
 sw=0;repeat(130)@(negedge clk);
 if(view!=1 || gain!=1)$fatal(1,"long press must retain gain");
 cw();if(gain!=2)$fatal(1,"long hold blocks graph rotation with guide inactive");
 sw=1;repeat(20)@(negedge clk);
 if(view!=1 || gain!=2)$fatal(1,"long release advanced view");
 click();if(view!=2 || gain!=1)$fatal(1,"remember XY");
 sw=0;repeat(130)@(negedge clk);sw=1;repeat(20)@(negedge clk);
 if(view!=2 || gain!=1)$fatal(1,"XY long must retain gain/release");
 // Switch bounce shorter than debounce cannot become a click.
 sw=0;repeat(2)@(negedge clk);sw=1;repeat(20)@(negedge clk);
 if(view!=2)$fatal(1,"switch bounce changed view");
 // Every possible startup phase is learned before accumulating.
 for(i=0;i<4;i=i+1)begin
  rst_n=0;{a,b}=i;repeat(8)@(negedge clk);rst_n=1;repeat(30)@(negedge clk);
  if(view!=0 || gain!=2)$fatal(1,"phantom startup phase %0d",i);
 end
 $display("PASS: visual encoder defaults, three-view wrap, independent remembered gain, both clamps, stable startup phases, AB/switch bounce, partial/illegal reversal, long one-shot and release");$finish;
end
initial begin #3000000;$fatal(1,"visual encoder timeout");end
endmodule
