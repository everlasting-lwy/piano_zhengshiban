package org.pianolink;
import java.nio.file.*;import java.util.*;
public final class RtlWireTest {
 public static void main(String[] args)throws Exception{
  VisualFrames assembler=new VisualFrames();EffectsState effects=new EffectsState();
  Set<Integer> complete=new HashSet<>();Set<Integer> started=new HashSet<>();
  int packets=0,status=0;long now=0;
  for(String line:Files.readAllLines(Paths.get(args[0]))){
   line=line.trim();if(line.isEmpty())continue;byte[] b=new byte[12];
   if(line.length()!=24)throw new AssertionError("Not an actual12byte wire dump");
   for(int j=0;j<12;j++)b[j]=(byte)Integer.parseInt(line.substring(2*j,2*j+2),16);
   Protocol.Frame f=Protocol.decode(b);if(f==null)throw new AssertionError("Bad RTL CRC/frame");
   packets++;now+=13;
   if(f.cmd==0x85){if(!effects.report(f))throw new AssertionError("Real RTL85 rejected by APP");status++;}
   int kind=f.seq==10?1:f.seq==11?2:f.seq==12?3:(f.seq==13||f.seq==14)?4:0;
   if(kind==0||complete.contains(f.seq))continue;
   if(f.cmd==0x86&&!started.contains(f.seq)){assembler.begin(f.seq,kind,now);started.add(f.seq);}
   VisualFrames.Snapshot snapshot=assembler.receive(f,now);
   if(snapshot!=null){
    if(snapshot.kind!=kind)throw new AssertionError("Mixed kinds");
    int expected=kind==1?64:kind==2?32:kind==3?128:4;
    if(snapshot.data.length!=expected)throw new AssertionError("Data length");
    int energy=0;for(int v:snapshot.data)energy+=kind==2?v:Math.abs(v-128);
    if(kind==2&&energy==0)throw new AssertionError("No DFT energy");
    if(kind==1){boolean changed=false;for(int v:snapshot.data)changed|=v!=128;if(!changed)throw new AssertionError("Wave not real localPCM");}
    if(f.seq==13&&!Arrays.equals(snapshot.data,new int[]{1,0,4,0}))throw new AssertionError("Held physical C4 guide mapping");
    if(f.seq==14&&!Arrays.equals(snapshot.data,new int[]{0,0,4,1}))throw new AssertionError("Guide did not advance only on physical release");
    complete.add(f.seq);
   }
  }
  int[] actual={15,9,7,8,16,4,2,1};
  for(int id=0;id<8;id++)if(effects.confirmed(id)!=actual[id])throw new AssertionError("Effects status byte order");
  if(status!=1||complete.size()!=5)throw new AssertionError("Incomplete realRTL fixture: "+complete);
  System.out.println("PASS: "+packets+" actual Icarus UART frames decoded by production Java;85 eightparams and5 complete wave/DFT/XY/physical-guide snapshots");
 }
}

