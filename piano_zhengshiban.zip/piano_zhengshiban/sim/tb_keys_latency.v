`timescale 1ns/1ps
// Reproduces slow vector debounce, cross-key blocking, missed high-bit release.
// Production 50MHz defaults: no accelerated debounce in this bench.
module tb_keys_latency;
    reg clk=0;always #10 clk=~clk;
    reg rst=0;
    reg [17:0] pins=18'h3FFFF;
    wire [17:0] keys;
    key_direct7 #(.KEY_COUNT(18)) dut(.sys_clk(clk),.sys_rst_n(rst),.key_in(pins),.keys(keys));
    integer cycle=0,max_on=0,max_off=0,begin_cycle,n,k;
    always @(negedge clk)cycle=cycle+1;
    task clocks;input integer count;begin repeat(count)@(negedge clk);end endtask
    task await_mask;input [17:0] wanted;input integer limit;
        integer elapsed;begin
            elapsed=0;while(keys!==wanted && elapsed<limit)begin clocks(1);elapsed=elapsed+1;end
            if(keys!==wanted)$fatal(1,"Debounce deadline: want %h got %h after %0d cycles",wanted,keys,limit);
        end
    endtask
    initial begin
        clocks(8);rst=1;clocks(32);
        for(n=0;n<14;n=n+1)begin
            clocks(37);begin_cycle=cycle;pins[0]=0;
            clocks(49000);
            if(keys[0]!==0)$fatal(1,"Press accepted below stable sampling window");
            await_mask(18'h1,1500);
            if(cycle-begin_cycle>max_on)max_on=cycle-begin_cycle;
            begin_cycle=cycle;pins[0]=1;clocks(99000);
            if(keys[0]!==1)$fatal(1,"Release accepted below stable sampling window");
            await_mask(0,1500);
            if(cycle-begin_cycle>max_off)max_off=cycle-begin_cycle;
        end
        // Sub-threshold chatter alone must never generate a note.
        for(k=0;k<8;k=k+1)begin
            pins[17]=0;clocks(10000);pins[17]=1;clocks(10000);
            if(keys!==0)$fatal(1,"Chatter produced a ghost note");
        end
        // A permanently bouncing high key must not delay a stable low key.
        pins[0]=0;
        fork
            begin
                for(k=0;k<20;k=k+1)begin pins[17]=0;clocks(4000);pins[17]=1;clocks(4000);end
            end
            begin await_mask(18'h1,50500);end
        join
        if(keys!==18'h1)$fatal(1,"Independent key was blocked by neighbor chatter");
        pins=18'h3FFFF;await_mask(0,100500);
        // All 18 inputs, selective high-bit release and short release bounce.
        pins=0;await_mask(18'h3FFFF,50500);
        pins[0]=1;pins[17]=1;await_mask(18'h1FFFE,100500);
        pins[16]=1;clocks(20000);pins[16]=0;clocks(120000);
        if(keys!==18'h1FFFE)$fatal(1,"Short release bounce retriggered note");
        pins=18'h3FFFF;await_mask(0,100500);
        // Clear nearly-complete qualifications with a one-clock return that
        // lies wholly between shared ticks. Catches resetting only on tick.
        wait(dut.tick);clocks(1);pins[5]=0;clocks(47000);
        wait(dut.tick);clocks(20);pins[5]=1;clocks(1);pins[5]=0;
        clocks(49000);
        if(keys!==0)$fatal(1,"Between-tick press interruption retained partial count");
        await_mask(18'h20,1500);
        pins[5]=1;clocks(97000);
        wait(dut.tick);clocks(20);pins[5]=0;clocks(1);pins[5]=1;
        clocks(99000);
        if(keys!==18'h20)$fatal(1,"Between-tick release interruption retained partial count");
        await_mask(0,1500);
        pins[12]=0;clocks(10000);rst=0;clocks(8);pins=18'h3FFFF;rst=1;clocks(110000);
        if(keys!==0)$fatal(1,"Reset retained an in-flight press");
        $display("PASS: real50MHz per-key debounce, on<=%0d cycles off<=%0d cycles, short chatter, neighbor isolation,18-bit release and reset",max_on,max_off);
        $finish;
    end
    initial begin #100000000;$fatal(1,"Keys latency timeout");end
endmodule
