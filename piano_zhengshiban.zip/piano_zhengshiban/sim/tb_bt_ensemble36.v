`timescale 1ns/1ps
module tb_bt_ensemble36;
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0,rx_valid=0;
    reg [7:0] rx_data=0;
    reg [1:0] timbre=0,octave=0;
    reg [3:0] volume=15;
    reg [11:0] physical=0;
    wire [11:0] remote;
    wire [35:0] remote36;
    reg [35:0] physical36=0;
    wire [35:0] extended_keys=physical36|remote36|({24'd0,remote}<<12);
    wire extended_mode;
    wire [11:0] keys=physical|remote;
    wire [1:0] new_timbre,new_octave;
    wire [3:0] new_volume;
    wire te,oe,ve,tx,legacy_ready,overflow;
    localparam BIT=16;
    bt_link #(.UART_CYCLES(BIT),.MS_CYCLES(50),.RX_TIMEOUT_CYCLES(64)) dut(
        .clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
        .timbre(timbre),.octave(octave),.mode(2'd2),.volume(volume),.voices(4'h3),.keys(keys),
        .extended_keys(extended_keys),.remote_extended_keys(remote36),.extended_mode(extended_mode),
        .set_timbre(new_timbre),.set_octave(new_octave),.set_volume(new_volume),
        .timbre_en(te),.octave_en(oe),.volume_en(ve),.remote_keys(remote),
        .tx(tx),.legacy_ready(legacy_ready),.event_overflow(overflow));
    always @(posedge clk) begin
        if(te)timbre<=new_timbre;if(oe)octave<=new_octave;if(ve)volume<=new_volume;
    end
    function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
        c=0;
        for(i=0;i<8;i=i+1) begin c=c^b[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
        crc8=c;
    end endfunction
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task byte_in;input [7:0] value;begin rx_data=value;rx_valid=1;clocks(1);rx_valid=0;clocks(1);end endtask
    task request;input [7:0] seq,op;input [47:0] p;input bad;integer k;begin
        byte_in(8'hA5);byte_in(8'h5A);byte_in(seq);byte_in(op);
        for(k=0;k<6;k=k+1)byte_in(p[k*8 +:8]);
        byte_in(crc8({p,op,seq})^{7'd0,bad});byte_in(8'h0D);clocks(8);
    end endtask
    reg [95:0] packets[0:511];
    reg [95:0] partial=0;
    reg [7:0] wire_byte;
    integer count=0,index=0,j;
    initial forever begin
        @(negedge tx);clocks(BIT+BIT/2);
        for(j=0;j<8;j=j+1)begin wire_byte[j]=tx;clocks(BIT);end
        if(tx!==1) $fatal(1,"BT TX stop bit");
        partial[index*8 +:8]=wire_byte;
        if(index==11)begin
            if(partial[15:0]!==16'h5AA5 || partial[95:88]!==8'h0D || partial[87:80]!==crc8(partial[79:16]))
                $fatal(1,"Bad outgoing BT wire frame %h",partial);
            if(count>=512)$fatal(1,"Response overflow");
            packets[count]=partial;count=count+1;partial=0;index=0;
        end else index=index+1;
    end
    reg [47:0] response;
    task reply;input [7:0] seq,op;integer n,k;reg found;begin
        n=0;found=0;
        while(n<50000 && !found)begin
            for(k=0;k<count;k=k+1)if(packets[k][23:16]==seq && packets[k][31:24]==op)begin
                found=1;response=packets[k][79:32];
            end
            if(!found)begin clocks(50);n=n+50;end
        end
        if(!found)$fatal(1,"Missing reply seq=%h op=%h",seq,op);
    end endtask
    integer n,i;
    reg [31:0] last_time;
    initial begin
        clocks(8);rst_n=1;clocks(8);
        // Capability query is legal before any extended snapshot.
        request(1,11,0,0);reply(1,8'h83);
        if(response!==48'h223000000000 || extended_mode!==0)$fatal(1,"Capability marker/layout before entry %h",response);
        request(2,4,1,0);reply(2,8'h80);
        request(3,9,48'h000800000001,0);reply(3,8'h80);
        if(response[15:8]!==0 || remote!==0 || remote36!==36'h800000001 || extended_mode!==1)
            $fatal(1,"36-key snapshot must replace legacy keys");
        request(4,11,0,0);reply(4,8'h83);
        if(response!==48'h223800000001)$fatal(1,"Extended state truncates high/low keys %h",response);
        request(5,9,48'h001000000000,0);reply(5,8'h80);
        if(response[15:8]!==1 || remote36!==36'h800000001)$fatal(1,"D4 reserved nibble accepted");
        request(6,10,48'h010000000000,0);reply(6,8'h80);
        if(response[15:8]!==1 || remote36!==36'h800000001)$fatal(1,"D5 reserved bits accepted");
        request(7,9,2,1);clocks(3000);
        if(remote36!==36'h800000001)$fatal(1,"Bad CRC changed extended keys");
        request(8,11,1,0);reply(8,8'h80);
        if(response[15:8]!==1)$fatal(1,"Dirty capability query accepted");
        physical36=36'h1000;
        request(9,5,0,0);reply(9,8'h80);
        if(remote36!==0 || remote!==0 || extended_mode!==1 || extended_keys!==36'h1000)
            $fatal(1,"Release must preserve physical source and extended mode");
        request(10,10,48'h000fffffffff,0);reply(10,8'h80);
        if(remote36!==36'hfffffffff)$fatal(1,"Heartbeat36 high bits lost");
        request(11,7,12'h800,0);reply(11,8'h80);
        if(extended_mode!==0 || remote36!==0 || remote!==12'h800)$fatal(1,"Legacy heartbeat must leave extended mode");
        request(12,9,0,0);reply(12,8'h80);
        if(extended_mode!==1 || remote!==0 || remote36!==0)$fatal(1,"Zero36 snapshot must switch modes atomically");
        request(13,4,1,0);reply(13,8'h80);
        if(extended_mode!==0 || remote!==1 || remote36!==0)$fatal(1,"Legacy snapshot must leave extended mode");
        request(14,9,1,0);reply(14,8'h80);clocks(60000);
        request(15,10,1,0);reply(15,8'h80);clocks(60000);
        if(remote36!==1)$fatal(1,"Heartbeat36 did not refresh watchdog");
        clocks(42000);
        if(remote36!==0 || extended_keys!==36'h1000 || extended_mode!==1)$fatal(1,"Watchdog36 release touched physical input");
        request(16,11,0,0);reply(16,8'h83);
        if(response[35:0]!==36'h1000 || response[46:40]!==7'h22)$fatal(1,"Watchdog state projection %h",response);
        n=0;
        for(i=0;i<count;i=i+1)if(packets[i][31:24]==8'h84)begin
            if(packets[i][78:72]!==7'h22)$fatal(1,"Event84 missing marker/source mode");
            if(packets[i][67:32]==36'h800000001)n=n+1;
        end
        if(n==0)$fatal(1,"No live36 snapshot event");
        $display("PASS: BT36 capability/state/event wire CRC, dirty bits, 36mask/legacy exclusion, release isolation and heartbeat watchdog");$finish;
    end
    initial begin #20000000;$fatal(1,"BT link timeout");end
endmodule
