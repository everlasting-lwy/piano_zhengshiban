`timescale 1ns/1ps
// Real50MHz clock, production debounce/I2S; parse complete16-bit I2S words.
// UARTs alone are accelerated for control traffic; audio timing is unchanged.
module tb_audio_latency;
    reg clk=0;always #10 clk=~clk;
    reg rst=0,bt_rx=1;
    reg [17:0] pins=18'h3FFFF;
    wire bclk,lrck,din;
    tri1 oled_scl,oled_sda,parameter_scl,parameter_sda;
    wire [31:0] parameter_bytes;
    oled_latency_sink parameter_oled(.rst_n(rst),.scl(parameter_scl),.sda(parameter_sda),.bytes(parameter_bytes));
    wire [31:0] oled_bytes;
    oled_latency_sink oled(.rst_n(rst),.scl(oled_scl),.sda(oled_sda),.bytes(oled_bytes));
    localparam BIT=16;
    top_piano_acg525 #(.BT_UART_CYCLES(BIT),
        .OLED_BOOT_CYCLES(1),.OLED_REFRESH_CYCLES(1000),
        .VISUAL_BOOT_CYCLES(1),.VISUAL_REFRESH_CYCLES(1000)) dut(
        .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst),.key_in(pins),
        .encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),
        .oled_scl(parameter_scl),.oled_sda(parameter_sda),
        .visual_oled_scl(oled_scl),.visual_oled_sda(oled_sda),
        .key_timbre(1'b1),.key_mode(1'b1),.key_vol_up(1'b1),
        .key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(bt_rx),
        .hc_echo(1'b0),.i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
    integer cycle=0,start_cycle=0,key_cycle=0,gate_cycle=0,pcm_cycle=0,i2s_cycle=0;
    reg measuring=0;
    integer last_sample=0;
    integer capture_count=0,frame_count=0,measured_pcm_frames=0;
    always @(negedge clk)begin
        cycle=cycle+1;
        if(!dut.core_rst_n)last_sample=0;
        else if(dut.u_core.sample_tick)begin
            if(last_sample && cycle-last_sample!=1024)$fatal(1,"Control/keyboard changed sample cadence");
            last_sample=cycle;
        end
        if(measuring)begin
            if(!key_cycle && dut.u_core.physical_keys!=0)key_cycle=cycle;
            if(!gate_cycle && dut.u_core.v_gate!=0)gate_cycle=cycle;
            if(!pcm_cycle && dut.u_core.audio_scaled!=0)pcm_cycle=cycle;
            if(dut.pcm_frame_valid)measured_pcm_frames=measured_pcm_frames+1;
        end
        if(dut.core_rst_n && dut.u_visual_oled.capture_ready)capture_count=capture_count+1;
        if(dut.core_rst_n && dut.u_visual_oled.frame_done)frame_count=frame_count+1;
    end
    reg previous_lrck=0;
    reg [15:0] word_rx=0;
    integer bits_rx=0;
    always @(posedge bclk)begin
        if(!dut.core_rst_n)begin previous_lrck=lrck;bits_rx=0;word_rx=0;end
        else if(lrck!=previous_lrck)begin
            previous_lrck=lrck;bits_rx=0;word_rx=0; // I2S one-bit delay
        end else begin
            bits_rx=bits_rx+1;
            if(bits_rx<=16)word_rx={word_rx[14:0],din};
            if(bits_rx==16 && measuring && !i2s_cycle && word_rx!=0)i2s_cycle=cycle;
        end
    end
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    task uart_byte;input [7:0] value;integer j;begin
        bt_rx=0;clocks(BIT);
        for(j=0;j<8;j=j+1)begin
            bt_rx=value[j];clocks(BIT);
        end
        bt_rx=1;clocks(BIT+4);
    end endtask
    function [7:0] crc8;
      input [63:0] bytes;integer x,y;reg[7:0] c;begin
      c=0;for(x=0;x<8;x=x+1)begin c=c^bytes[x*8+:8];for(y=0;y<8;y=y+1)c=c[7]?(c<<1)^8'h07:c<<1;end
      crc8=c;end
    endfunction
    task request;input[7:0] seq,op;input[47:0] payload;integer n;begin
      uart_byte(8'ha5);uart_byte(8'h5a);uart_byte(seq);uart_byte(op);
      for(n=0;n<6;n=n+1)uart_byte(payload[n*8+:8]);
      uart_byte(crc8({payload,op,seq}));uart_byte(8'h0d);clocks(32);
    end endtask
    task set_fx;input[7:0] seq,id,value;begin
      request(seq,13,{32'd0,value,id});
    end endtask
    integer test_case,target_key,elapsed,k,logfile,captures_before,frames_before;
    integer worst_i2s=0,worst_gate=0;
    initial begin
        logfile=$fopen("sim/latency_samples.csv","w");
        $fdisplay(logfile,"case,timbre,key,pin_to_key_cycles,pin_to_gate_cycles,pin_to_pcm_cycles,pin_to_i2s_word_cycles");
        for(test_case=0;test_case<8;test_case=test_case+1)begin
            measuring=0;rst=0;pins=18'h3FFFF;clocks(32);rst=1;clocks(64);
            request(test_case*16,1,test_case%4);
            if(dut.u_core.timbre!==test_case%4)$fatal(1,"Latency timbre setup did not use framed BT command1");
            if(test_case>=4)begin
                set_fx(test_case*16+1,0,15);
                set_fx(test_case*16+2,1,15);
                set_fx(test_case*16+3,2,15);
                set_fx(test_case*16+4,6,test_case%3);
                if(dut.u_core.effect_reverb!==15 || dut.u_core.effect_echo!==15 ||
                   dut.u_core.effect_chorus!==15 || dut.u_core.effect_delay!==test_case%3)
                    $fatal(1,"Latency effects setup did not use framed BT command13");
                request(test_case*16+5,14,test_case-3);
                if(dut.u_core.bt_visual_kind!==test_case-3)$fatal(1,"Latency stress did not enter requested BT visualization");
                if(test_case<7)begin
                    elapsed=0;
                    while(!dut.u_core.u_bt_link.tx_active && elapsed<350000)begin clocks(1);elapsed=elapsed+1;end
                    clocks(263000);
                end
            end
            // Exercise live capture and full-rate electrical OLED drawing in
            // separate cases: neither display activity may delay physical keys.
            elapsed=0;
            if(test_case<4)begin
                while(dut.u_visual_oled.u_capture.state!==2 && elapsed<1500000)begin clocks(1);elapsed=elapsed+1;end
                if(dut.u_visual_oled.u_capture.state!==2)$fatal(1,"OLED did not begin an actual PCM capture");
            end else begin
                while(!(dut.u_visual_oled.busy && dut.u_visual_oled.kind==2) && elapsed<1500000)begin clocks(1);elapsed=elapsed+1;end
                if(!(dut.u_visual_oled.busy && dut.u_visual_oled.kind==2))$fatal(1,"OLED did not draw captured PCM on actual I2C");
            end
            clocks(23+test_case*113);
            target_key=(test_case%2)?17:0;
            key_cycle=0;gate_cycle=0;pcm_cycle=0;i2s_cycle=0;measured_pcm_frames=0;
            start_cycle=cycle;measuring=1;pins[target_key]=0;
            fork
                begin
                    elapsed=0;while(!i2s_cycle && elapsed<250000)begin clocks(1);elapsed=elapsed+1;end
                end
                begin
                    for(k=0;k<8;k=k+1)begin
                        set_fx(8'h80+k,0,15);
                        request(8'h90+k,2,15);
                    end
                end
            join
            if(!i2s_cycle || !key_cycle || !gate_cycle || !pcm_cycle)
                $fatal(1,"Physical-key to nonzero I2S exceeded5ms (case%0d)",test_case);
            if(i2s_cycle-start_cycle>=250000)$fatal(1,"I2S latency not below5ms");
            if(measured_pcm_frames<2)$fatal(1,"OLED PCM tap stalled during latency measurement");
            if(i2s_cycle-start_cycle>worst_i2s)worst_i2s=i2s_cycle-start_cycle;
            if(gate_cycle-start_cycle>worst_gate)worst_gate=gate_cycle-start_cycle;
            $fdisplay(logfile,"%0d,%0d,%0d,%0d,%0d,%0d,%0d",test_case,test_case%4,target_key,
                key_cycle-start_cycle,gate_cycle-start_cycle,pcm_cycle-start_cycle,i2s_cycle-start_cycle);
            $fflush(logfile);
            $display("Latency case%0d complete:cycle%0d pin-to-I2S%0d cycles",test_case,cycle,i2s_cycle-start_cycle);
            measuring=0;
            if(test_case==7)begin
                // A live display must request another snapshot after drawing,
                // then finish it and draw again without an external request.
                captures_before=capture_count;frames_before=frame_count;elapsed=0;
                while((capture_count<=captures_before || frame_count<frames_before+2) && elapsed<5000000)begin
                    clocks(1);elapsed=elapsed+1;
                end
                if(capture_count<=captures_before || frame_count<frames_before+2)
                    $fatal(1,"OLED waveform capture/draw did not continue automatically");
            end
            pins=18'h3FFFF;clocks(8);
        end
        if(oled_bytes<10 || parameter_bytes<10)$fatal(1,"OLED stress did not transmit live I2C bytes");
        $fclose(logfile);
        $display("PASS:8 production50MHz physical-to-I2S cases,4timbres,C4/F5,framed BT/effects/visuals plus active PCM capture and both independent OLED I2C buses; continuous captures=%0d frames=%0d; below5ms; worst gate=%0d cycles,I2S=%0d cycles (%0f ms)",capture_count,frame_count,worst_gate,worst_i2s,worst_i2s/50000.0);
        $finish;
    end
    initial begin #400000000;$fatal(1,"Audio latency bench timeout");end
endmodule

// Receiver only: acknowledge actual electrical bytes, no coupling into audio.
module oled_latency_sink(input wire rst_n,input wire scl,inout wire sda,output reg[31:0] bytes=0);
reg active=0,low=0;integer bits=0;
assign sda=low ? 1'b0:1'bz;
always @(negedge rst_n)begin active=0;low=0;bits=0;bytes=0;end
always @(negedge sda)if(rst_n && scl===1'b1 && !low)begin active=1;bits=0;end
always @(posedge sda)if(rst_n && scl===1'b1)active=0;
always @(posedge scl)if(active)begin bits=bits+1;if(bits==8)bytes=bytes+1'b1;end
always @(negedge scl)if(active)begin
 if(bits==8)low=1;
 else if(bits==9)begin low=0;bits=0;end
end
endmodule
