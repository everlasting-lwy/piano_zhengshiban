`timescale 1ns/1ps
module tb_encoder_integration;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=1,b=1,sw=1;
reg[17:0] keys=18'h3ffff;
tri1 scl,sda;
wire bclk,lrck,din;
top_piano_acg525 #(.ENC_INITIAL_SELECTION(0),.ENC_SAMPLE_CYCLES(2),.ENC_AB_FILTER_SAMPLES(1),.ENC_SW_FILTER_SAMPLES(3),
 .ENC_LONG_PRESS_SAMPLES(30),.OLED_BOOT_CYCLES(10),.OLED_I2C_DIV(2),
 .OLED_RETRY_CYCLES(30),.OLED_TIMEOUT_CYCLES(100)) dut(
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),
 .key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),
 .bt_rxd(1'b1),.hc_echo(1'b0),
 .encoder_a(a),.encoder_b(b),.encoder_sw_n(sw),.oled_scl(scl),.oled_sda(sda),
 .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
task phase;input[1:0] v;begin {a,b}=v;repeat(10)@(negedge clk);end endtask
task cw;begin phase(2);phase(0);phase(1);phase(3);repeat(5)@(negedge clk);end endtask
task ccw;begin phase(1);phase(0);phase(2);phase(3);repeat(5)@(negedge clk);end endtask
task click;begin sw=0;repeat(20)@(negedge clk);sw=1;repeat(20)@(negedge clk);end endtask
reg[7:0] remote_value;
task set_expression_max;
begin
 remote_value=8'haf;force dut.u_core.bt_effect_command=remote_value;force dut.u_core.bt_effect_en=1;
 repeat(2)@(negedge clk);release dut.u_core.bt_effect_command;release dut.u_core.bt_effect_en;
 repeat(3)@(negedge clk);
end endtask
task collision;
input[7:0] command;input[3:0] expected;
begin
 phase(1);phase(0);phase(2);{a,b}=3;
 wait(dut.u_rotary.tick && dut.u_rotary.previous!=dut.u_rotary.sync[2:1] && dut.u_rotary.next_sum<=-4);
 @(negedge clk);
 remote_value=command;
 force dut.u_core.bt_effect_command=remote_value;force dut.u_core.bt_effect_en=1;
 @(negedge clk);
 release dut.u_core.bt_effect_command;release dut.u_core.bt_effect_en;
 repeat(6)@(negedge clk);
 if(dut.u_core.effect_expression!=expected)$fatal(1,"BT/encoder generation collision command=%h expected=%0d actual=%0d",command,expected,dut.u_core.effect_expression);
end endtask
initial begin
 repeat(8)@(negedge clk);rst_n=1;repeat(40)@(negedge clk);
 ccw();if(dut.u_core.effect_expression!=14)$fatal(1,"local Expression not connected");
 click();cw();if(dut.u_core.effect_bend!=9)$fatal(1,"local Bend not connected");
 click();cw();if(dut.u_core.effect_vibrato!=1)$fatal(1,"local Vibrato not connected");
 click();cw();if(dut.u_core.effect_reverb!=1)$fatal(1,"local Reverb not connected");
 click();cw();if(dut.u_core.effect_echo!=1)$fatal(1,"local Echo not connected");
 click();cw();if(dut.u_core.effect_chorus!=1)$fatal(1,"local Chorus not connected");
 click();cw();cw();cw();if(dut.u_core.effect_delay!=2)$fatal(1,"local Time boundary");
 click();ccw();if(dut.u_core.vol!=14)$fatal(1,"local Volume not connected");
 click();set_expression_max();collision(8'ha7,7);
 // The no-op remote write must also suppress the rotary's stale decrement.
 set_expression_max();collision(8'haf,15);
 // Narrow command-level collision exercises the actual core arbiter.
 force dut.u_core.bt_effect_en=1;force dut.u_core.bt_effect_command=8'h13;
 force dut.local_command_valid=1;force dut.local_command=8'h1c;
 repeat(2)@(negedge clk);
 if(dut.u_core.effect_reverb!=3)$fatal(1,"BT must win local collision");
 release dut.u_core.bt_effect_en;release dut.u_core.bt_effect_command;
 repeat(2)@(negedge clk);
 if(dut.u_core.effect_reverb!=12)$fatal(1,"local command missing after remote release");
 release dut.local_command_valid;release dut.local_command;
 // OLED absent/NACK throughout; physical audio must still advance.
 keys[0]=0;repeat(100000)@(negedge clk);
 if(!dut.u_core.physical_keys[0] || !dut.u_core.v_gate[0])$fatal(1,"absent OLED stalled keys");
 if(dut.u_core.audio_scaled==0)$fatal(1,"absent OLED stalled synthesis");
 $display("PASS: local eight parameters, limits, BT/local generation and same-cycle precedence including same-value writes, absent OLED concurrent live audio");
 $finish;
end
initial begin #10000000;$fatal(1,"integration timeout");end
endmodule
