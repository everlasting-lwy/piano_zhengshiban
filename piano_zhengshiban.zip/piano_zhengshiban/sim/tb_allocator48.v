`timescale 1ns/1ps
module tb_allocator48;
 reg clk=0;always #10 clk=~clk;reg rst_n=0;
 reg [47:0] keys=0;wire [5:0] n0,n1,n2,n3;wire [3:0] gate;
 voice_allocator #(.KEY_COUNT(48),.NOTE_WIDTH(6)) dut(.sys_clk(clk),.sys_rst_n(rst_n),
 .keys(keys),.busy(4'hf),.n0(n0),.n1(n1),.n2(n2),.n3(n3),.gate(gate));
 reg [17:0] legacy_keys=0;wire [4:0] l0,l1,l2,l3;wire [3:0] legacy_gate;
 voice_allocator legacy(.sys_clk(clk),.sys_rst_n(rst_n),.keys(legacy_keys),.busy(4'hf),
 .n0(l0),.n1(l1),.n2(l2),.n3(l3),.gate(legacy_gate));
 reg [3:0] midi_gate=0;reg [19:0] notes=0;reg [1:0] octave=0;wire [7:0] data;wire start;
 message_encoder encoder(.clk(clk),.rst_n(rst_n),.gate(midi_gate),.note_all(notes),
 .pitch_all(28'hfffffff),.octave(octave),.midi_en(1'b1),.mready(1'b1),.data(data),.mstart(start));
 reg [7:0] messages[0:7];integer count=0,i;reg found;
 always @(negedge clk)if(start)begin messages[count]=data;count=count+1;end
 task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
 initial begin
 clocks(4);rst_n=1;clocks(4);
 for(i=0;i<48;i=i+1)begin
 keys=48'd1<<i;clocks(80);
 found=(gate[0] && n0==i+1)||(gate[1] && n1==i+1)||(gate[2] && n2==i+1)||(gate[3] && n3==i+1);
 if(!found || $countones(gate)!==1)$fatal(1,"Generic allocator lost key %0d",i);
 keys=0;clocks(80);if(gate!==0)$fatal(1,"Generic allocator key %0d stuck",i);
 end
 legacy_keys=18'h20000;clocks(80);
 if(legacy_gate!==1 || l0!==18)$fatal(1,"Default allocator18 compatibility");
 notes=18;midi_gate=1;clocks(20);
 octave=1;clocks(20);midi_gate=0;clocks(20);
 if(count!==4 || messages[0]!=={7'd77,1'b1} || messages[1]!=={7'd77,1'b0} ||
 messages[2]!=={7'd89,1'b1} || messages[3]!=={7'd89,1'b0})$fatal(1,"Default message encoder no longer uses legacy pitch mapping");
 $display("PASS: generic48 every bit including47, release, default18 allocator and default message encoder octave/pitch behavior");$finish;
 end
endmodule
