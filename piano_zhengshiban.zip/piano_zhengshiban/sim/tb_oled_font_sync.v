`timescale 1ns/1ps
// Detects glyph/column/address changes and accidental combinational or extra-cycle reads.
module tb_oled_font_sync;
    reg clk=0;
    always #5 clk=~clk;
    reg [7:0] character=8'hff;
    reg [2:0] column=3'd7;
    wire [7:0] original_pixels,pixels;
    oled_font reference_font(.character(character),.column(column),.pixels(original_pixels));
    oled_font_sync dut(.clk(clk),.character(character),.column(column),.pixels(pixels));
    integer address,pass,test_address,checks=0;
    reg [7:0] expected,previous_pixels;
    reg have_previous=0;
    initial begin
        // Sequential and permuted orders both cover every one of the 2048 addresses.
        for(pass=0;pass<2;pass=pass+1)begin
            for(address=0;address<2048;address=address+1)begin
                @(negedge clk);
                test_address=pass==0?address:((address*109+733)&2047);
                character=test_address>>3;
                column=test_address&7;
                #1;
                expected=original_pixels;
                if(have_previous && pixels!==previous_pixels)
                    $fatal(1,"font changed before rising edge: character=%0d column=%0d",character,column);
                @(posedge clk);
                #1;
                if(pixels!==expected)
                    $fatal(1,"font mismatch: pass=%0d character=%0d column=%0d expected=%02x actual=%02x",pass,character,column,expected,pixels);
                previous_pixels=pixels;
                have_previous=1;
                checks=checks+1;
            end
        end
        $display("PASS: oled_font_sync %0d registered reads; all 256 characters x 8 columns in two orders",checks);
        $finish;
    end
endmodule
