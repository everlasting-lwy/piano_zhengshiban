`timescale 1ns/1ps
module tb_sd_song_library;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_req_valid=0;reg[7:0]bt_req_command=0;reg[47:0]bt_req_payload=0;
wire bt_rsp_valid;wire[7:0]bt_rsp_command;wire[47:0]bt_rsp_payload;
wire g_req_valid,g_rsp_valid;wire[7:0]g_req_command,g_rsp_command;wire[47:0]g_req_payload,g_rsp_payload;
wire guide_loaded,guide_loading,guide_active;wire[11:0]guide_total_steps;
reg[17:0]physical_keys=0;reg local_next=0,local_prev=0,local_toggle=0;
wire sd_busy,selected_valid;wire[4:0]selected_slot;wire[7:0]sd_error;
wire sd_cs_n,sd_clk,sd_mosi,sd_miso;
wire[17:0]target;wire complete,wrong;wire[11:0]step;
sd_song_library #(.INIT_DIV(2),.DATA_DIV(1),.POWERUP_CYCLES(8),.INIT_TIMEOUT_CYCLES(1000000)) dut(.*);
song_guide guide(.clk(clk),.rst_n(rst_n),.request_valid(g_req_valid),.request_command(g_req_command),.request_payload(g_req_payload),
 .response_valid(g_rsp_valid),.response_command(g_rsp_command),.response_payload(g_rsp_payload),
 .local_toggle(local_toggle),.local_restart(1'b0),.physical_keys(physical_keys),.target(target),.active(guide_active),
 .loaded(guide_loaded),.loading(guide_loading),.complete(complete),.wrong(wrong),.step(step),.total_steps(guide_total_steps));
sd_spi_image_model card(.cs_n(sd_cs_n),.sclk(sd_clk),.mosi(sd_mosi),.miso(sd_miso),.kind(2'd0),.csd_variant(3'd0),
 .absent(1'b0),.bad_crc(1'b0),.reject_write(1'b0),.stuck_busy(1'b0),.no_token(1'b0),.bad_r7(1'b0),.bad_ocr(1'b0),.bad_csd(1'b0),.init_stuck(1'b0),.status_error(1'b0));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task req;input[7:0]c;input[47:0]p;input[7:0]r;integer n;begin
 bt_req_command=c;bt_req_payload=p;bt_req_valid=1;clocks(1);bt_req_valid=0;n=0;
 while(!bt_rsp_valid&&n<10)begin clocks(1);n=n+1;end
 if(!bt_rsp_valid||bt_rsp_command!==r)$fatal(1,"request %h failed latency=%d rsp=%h payload=%h",c,n,bt_rsp_command,bt_rsp_payload);
 clocks(2);
end endtask
task ack;input[7:0]c;input[47:0]p;begin req(c,p,8'h80);if(bt_rsp_payload[15:8]!=0)$fatal(1,"ack error %h",bt_rsp_payload);end endtask
task idle;integer n;begin n=0;while(sd_busy&&n<7000000)begin clocks(1000);n=n+1000;end
 if(sd_busy||sd_error!=0)$fatal(1,"SD operation failed timeout=%d error=%d state=%d fat=%d",n,sd_error,dut.u_bridge.state,dut.u_files.state);
 clocks(20);
end endtask
integer before_write,after_write,j;reg[15:0]crc;reg[47:0]info;
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer i;reg[15:0]c;begin c=old^{v,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
initial begin
 clocks(10);rst_n=1;clocks(100);
 j=0;while((!guide_loaded||sd_busy)&&j<7000000)begin clocks(1000);j=j+1000;end
 idle();
 if(!guide_loaded||guide_total_steps!=220||selected_slot!=3||!selected_valid)$fatal(1,"cold boot FAT32 load");
 $display("coldboot OK reads=%d cycles=%t",card.reads,$time);
 crc=16'hffff;crc=crcbyte(crcbyte(crcbyte(crc,1),0),0);crc=crcbyte(crcbyte(crcbyte(crc,0),0),2);
 ack(8'h10,{16'd1,crc,16'd2});ack(8'h11,{8'd0,24'h1,16'd0});ack(8'h11,{8'd0,24'h20000,16'd1});ack(8'h12,0);
 for(j=0;j<7;j=j+1)begin
  if(j==0)ack(8'h18,{8'd0,8'd0,"w","e","N",8'd0});else ack(8'h18,j*5);
 end
 before_write=card.writes;ack(8'h17,{32'h12345678,8'd4,8'd1});
 req(8'h16,0,8'h8b);if(!sd_busy)$fatal(1,"save did not start");
 // Read-only guide/status traffic continues while the same SD transaction runs.
 repeat(8)begin req(8'h14,0,8'h89);req(8'h16,0,8'h8b);clocks(1000);end
 idle();if(card.writes<=before_write)$fatal(1,"save no wire writes");after_write=card.writes;
 req(8'h1b,0,8'h8e);if(bt_rsp_payload!=={8'd4,8'd1,32'h12345678})$fatal(1,"identity result");
 ack(8'h17,{32'h12345678,8'd4,8'd1});clocks(1000);if(card.writes!=after_write)$fatal(1,"retry rewrote card");
 req(8'h19,4,8'h8c);if(bt_rsp_payload[39:8]!==32'h03000201)$fatal(1,"saved catalog %h",bt_rsp_payload);
 if($test$plusargs("SAVEONLY"))begin
  $display("PASS: integrated wire save completed for independent FAT/P18 file inspection");$finish;
 end
 // Core reset while keeping ordinary card files: the first slot is still3.
 rst_n=0;clocks(10);rst_n=1;clocks(100);
 j=0;while((!guide_loaded||sd_busy)&&j<7000000)begin clocks(1000);j=j+1000;end
 idle();
 if(!guide_loaded||guide_total_steps!=220)$fatal(1,"power cycle old first file");
 ack(8'h17,{32'h22222222,8'd4,8'd2});idle();
 if(guide_total_steps!=2||target!=1)$fatal(1,"saved file load steps=%d target=%h",guide_total_steps,target);
 local_toggle=1;clocks(1);local_toggle=0;clocks(5);if(target!=1)$fatal(1,"guide first mask");
 physical_keys=1;clocks(6);if(step!=1||target!=18'h20000)$fatal(1,"guide actual second mask");
 physical_keys=0;clocks(5);physical_keys=18'h20000;clocks(5);if(!complete)$fatal(1,"guide finish");physical_keys=0;
 ack(8'h17,{32'h33333333,8'd3,8'd3});idle();
 ack(8'h17,{32'h44444444,8'd4,8'd3});idle();
 req(8'h19,4,8'h8c);if(bt_rsp_payload[15:8]!=0)$fatal(1,"delete catalog");
 if(card.errors!=0)$fatal(1,"wire protocol faults=%d",card.errors);
 $display("PASS: complete SPI/FAT32/P18 cold boot, RAM-save/readback, token idempotency, catalog, reset reload, physical guidance and file deletion (%d reads/%d writes)",card.reads,card.writes);$finish;
end
initial begin#1200000000;$fatal(1,"integrated SD timeout state=%d file=%d err=%d",dut.u_bridge.state,dut.u_files.state,sd_error);end
endmodule
