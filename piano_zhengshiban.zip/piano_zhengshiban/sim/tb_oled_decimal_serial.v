`timescale 1ns/1ps
// Detects decimal errors, torn input snapshots, busy-start restarts and stale reset work.
module tb_oled_decimal_serial;
    reg clk=0;
    always #5 clk=~clk;
    reg rst_n=1,start=0;
    reg [11:0] value0=0,value1=0,value2=0;
    wire done;
    wire [15:0] bcd0,bcd1,bcd2;
    oled_decimal_serial dut(.clk(clk),.rst_n(rst_n),.start(start),
        .value0(value0),.value1(value1),.value2(value2),.done(done),
        .bcd0(bcd0),.bcd1(bcd1),.bcd2(bcd2));
    integer index,checks=0;
    // Arithmetic oracle is independent of the DUT's add-three/shift algorithm.
    function [15:0] decimal_expected;
        input integer value;
        begin decimal_expected=((value/1000)%10)*4096+((value/100)%10)*256+((value/10)%10)*16+value%10;end
    endfunction
    task assert_reset;
        begin
            #1 rst_n=0;
            #1;
            if(done!==0 || {bcd0,bcd1,bcd2}!==48'd0)$fatal(1,"reset did not clear outputs/done");
            @(negedge clk);start=0;rst_n=1;
        end
    endtask
    task convert;
        input [11:0] a,b,c;
        integer cycles,idle_cycle;
        reg [15:0] expected0,expected1,expected2;
        begin
            expected0=decimal_expected(a);expected1=decimal_expected(b);expected2=decimal_expected(c);
            @(negedge clk);value0=a;value1=b;value2=c;start=1;
            @(posedge clk);#1;
            if(done!==0)$fatal(1,"done asserted on acceptance");
            cycles=0;
            while(!done && cycles<40)begin
                @(negedge clk);
                // Every busy cycle changes all inputs; busy starts include the final cycle.
                value0=~a;value1=~b;value2=~c;
                start=(cycles==2 || cycles==17 || cycles==35);
                @(posedge clk);#1;cycles=cycles+1;
            end
            if(!done)$fatal(1,"conversion exceeded 40 clocks");
            if({bcd0,bcd1,bcd2}!=={expected0,expected1,expected2})
                $fatal(1,"decimal mismatch: %0d,%0d,%0d => %04x,%04x,%04x expected %04x,%04x,%04x",a,b,c,bcd0,bcd1,bcd2,expected0,expected1,expected2);
            @(negedge clk);start=0;
            for(idle_cycle=0;idle_cycle<3;idle_cycle=idle_cycle+1)begin
                @(posedge clk);#1;
                if(done!==0)$fatal(1,"done was not a one-clock pulse or busy start was queued");
                if({bcd0,bcd1,bcd2}!=={expected0,expected1,expected2})$fatal(1,"outputs changed while idle");
            end
            checks=checks+1;
        end
    endtask
    initial begin
        assert_reset();
        for(index=0;index<4096;index=index+1)
            convert(index,index^12'ha5b,4095-index);
        // Reset in each number's conversion; an abandoned job must never emit done.
        for(index=0;index<3;index=index+1)begin
            @(negedge clk);value0=4095;value1=2048;value2=1234;start=1;
            @(negedge clk);start=0;
            repeat(5+index*12)@(negedge clk);
            assert_reset();
            repeat(42)begin @(posedge clk);#1;if(done || {bcd0,bcd1,bcd2}!==48'd0)$fatal(1,"reset job resumed");end
            convert(0,999,4095);
        end
        $display("PASS: oled_decimal_serial %0d conversions; every 0..4095 value in all three positions; input capture, busy starts, done pulse, reset",checks);
        $finish;
    end
    initial begin #3000000;$fatal(1,"serial decimal timeout");end
endmodule
