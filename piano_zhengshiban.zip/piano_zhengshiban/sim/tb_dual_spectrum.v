`timescale 1ns/1ps
module tb_dual_spectrum;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,rx=1,oled_enable=1;
reg [17:0] keys=18'h3ffff;
wire [255:0] bars;
wire valid;
localparam BIT=16;
top_piano_test #(.BT_UART_CYCLES(BIT)) dut(
 .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),
 .key0(1'b1),.key1(1'b1),.key2(1'b1),.key3(1'b1),.key4(1'b1),
 .uart_rxd(rx),.hc_echo(1'b0),.local_command(8'd0),.local_command_valid(1'b0),
 .oled_spectrum_enable(oled_enable),.oled_spectrum_bars(bars),.oled_spectrum_valid(valid));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task byte_in;input [7:0] v;integer j;begin
 rx=0;clocks(BIT);for(j=0;j<8;j=j+1)begin rx=v[j];clocks(BIT);end
 rx=1;clocks(BIT+4);
end endtask
function [7:0] crc8;input [63:0] v;reg [7:0] c;integer j,k;begin
 c=0;for(j=0;j<8;j=j+1)begin c=c^v[8*j+:8];
 for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
 crc8=c;
end endfunction
task request;input [7:0] seq;input [47:0] data;integer j;begin
 byte_in(8'ha5);byte_in(8'h5a);byte_in(seq);byte_in(14);
 for(j=0;j<6;j=j+1)byte_in(data[8*j+:8]);
 byte_in(crc8({data,8'd14,seq}));byte_in(8'h0d);clocks(32);
end endtask
integer frames=0,pcm_checks=0,chunks=0;
reg signed [15:0] sampled;
always @(posedge clk)begin
 if(rst_n && dut.pcm_frame_valid && !dut.u_spectrum.running &&
    (oled_enable || dut.bt_visual_kind==2))begin
  sampled=dut.pcm_frame;
  #1;
  if(dut.u_spectrum.pcm!==sampled)$fatal(1,"Shared spectrum did not sample the final atomic PCM");
  pcm_checks=pcm_checks+1;
 end
end
always @(negedge clk)if(rst_n)begin
 if(valid)frames=frames+1;
 if(dut.bt_visual_take && dut.bt_visual_command==8'h87 && dut.bt_visual_tx_sequence==2)
  chunks=chunks+1;
end
task next_frames;input integer n;integer target,guard;begin
 target=frames+n;guard=0;
 while(frames<target && guard<700000)begin clocks(1);guard=guard+1;end
 if(frames<target)$fatal(1,"OLED/BT shared DFT consumer starved");
end endtask
integer before_frames,guard;
initial begin
 clocks(10);rst_n=1;keys[0]=0;
 next_frames(2);
 if(bars==0 || pcm_checks<256)$fatal(1,"OLED-only spectrum had no synthesized C4 data");
 request(1,1);
 if(dut.bt_visual_kind!==1)$fatal(1,"BT waveform request failed");
 next_frames(1);
 if(bars==0)$fatal(1,"BT waveform selection cleared active OLED spectrum");
 request(2,2);oled_enable=0;
 if(dut.bt_visual_kind!==2)$fatal(1,"BT spectrum request failed");
 next_frames(1);
 guard=0;
 while(chunks<8 && guard<200000)begin clocks(1);guard=guard+1;end
 if(chunks!=8)$fatal(1,"OLED leaving spectrum cancelled BT snapshot");
 request(3,0);clocks(8);
 if(bars!==0 || dut.u_spectrum.running!==0)$fatal(1,"Unused shared DFT did not clear/idle");
 oled_enable=1;next_frames(1);
 if(bars==0)$fatal(1,"OLED spectrum did not restart without BT request");
 $display("PASS: one DFT serves OLED/BT independently, final atomic PCM and framed BT mode arbitration");
 $finish;
end
initial begin #60000000;$fatal(1,"Dual spectrum test timeout");end
endmodule
