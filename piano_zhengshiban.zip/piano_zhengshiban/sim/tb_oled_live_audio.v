`timescale 1ns/1ps
// Real board synthesis -> atomic I2S sample -> waveform RAM -> electrical I2C.
module tb_oled_live_audio;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_rx=1;
reg [17:0] keys=18'h3ffff;
wire bclk,lrck,din;
tri1 scl,sda;
localparam BIT=16;
top_piano_acg525 #(.BT_UART_CYCLES(BIT),.VISUAL_BOOT_CYCLES(1),
 .VISUAL_I2C_DIV(2),.VISUAL_REFRESH_CYCLES(10000)) dut(
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),
 .key_timbre(1'b1),.key_mode(1'b1),.key_vol_up(1'b1),
 .key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(bt_rx),.hc_echo(1'b0),
 .encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),
 .visual_oled_scl(scl),.visual_oled_sda(sda),.i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));

// This receiver only samples and acknowledges the two physical open-drain pins.
reg slave_low=0,active=0,ack=0;
assign sda=slave_low ? 1'b0:1'bz;
integer bits=0,bytes=0,current_page=0,data_pages=0,cmd_pages=0,data_bytes=0;
reg [7:0] shift=0,control=0;
reg [7:0] pixels[0:1023];
always @(negedge sda)if(rst_n && scl===1'b1 && !slave_low)begin
 active=1;bits=0;bytes=0;
end
always @(posedge sda)if(rst_n && scl===1'b1)active=0;
always @(posedge scl)if(active)begin
 if(bits<8)begin
  shift={shift[6:0],sda};bits=bits+1;
  if(bits==8)begin
   if(bytes==0)ack=(shift==8'h78);
   if(bytes==1)control=shift;
   if(bytes>=2 && ack && control==0 && bytes==2 && shift>=8'hb0 && shift<=8'hb7)begin
    current_page=shift-8'hb0;
    if(current_page!=cmd_pages%8)$fatal(1,"Live OLED page order");
    cmd_pages=cmd_pages+1;
   end
   if(bytes>=2 && ack && control==8'h40)begin
    if(bytes>129)$fatal(1,"Live OLED page exceeded128 pixels");
    pixels[current_page*128+bytes-2]=shift;data_bytes=data_bytes+1;
    if(bytes==129)data_pages=data_pages+1;
   end
   bytes=bytes+1;
  end
 end else bits=9;
end
always @(negedge scl)if(active)begin
 if(bits==8)slave_low=ack;
 else if(bits==9)begin slave_low=0;bits=0;end
end

// Independently receive complete I2S words and compare both slots to the tap.
reg previous_lrck=1,left_seen=0;
reg [15:0] tap_word=0,word_rx=0,left_word=0;
integer received_bits=0,pairs=0,nonzero_taps=0,taps=0,cycles=0,last_tap=0;
reg previous_tap_valid=0;
always @(negedge clk)begin
 cycles=cycles+1;
 if(!dut.core_rst_n)begin
  previous_tap_valid=0;last_tap=0;
 end else begin
  if(previous_tap_valid && dut.pcm_frame_valid)$fatal(1,"Live PCM tap valid exceeded one clock");
  previous_tap_valid=dut.pcm_frame_valid;
  if(dut.pcm_frame_valid)begin
   if(last_tap && cycles-last_tap!=1024)$fatal(1,"Live PCM tap cadence");
   last_tap=cycles;tap_word=dut.pcm_frame;taps=taps+1;
   if(tap_word!=0)nonzero_taps=nonzero_taps+1;
  end
 end
end
always @(posedge bclk)begin
 if(!dut.core_rst_n)begin previous_lrck=lrck;received_bits=0;word_rx=0;left_seen=0;end
 else if(lrck!=previous_lrck)begin previous_lrck=lrck;received_bits=0;word_rx=0;end
 else begin
  received_bits=received_bits+1;
  if(received_bits<=16)word_rx={word_rx[14:0],din};
  if(received_bits==16)begin
   if(lrck)begin
    if(taps==0 || word_rx!==tap_word)$fatal(1,"Live OLED PCM differs from complete I2S left word");
    left_word=word_rx;left_seen=1;
   end else if(left_seen)begin
    if(word_rx!==left_word)$fatal(1,"Live OLED PCM differs from complete I2S right word");
    pairs=pairs+1;
   end
  end
 end
end

task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task uart_byte;input [7:0] value;integer n;begin
 bt_rx=0;clocks(BIT);
 for(n=0;n<8;n=n+1)begin bt_rx=value[n];clocks(BIT);end
 bt_rx=1;clocks(BIT+4);
end endtask
function [7:0] crc8;input [63:0] data;integer n,k;reg [7:0] c;begin
 c=0;
 for(n=0;n<8;n=n+1)begin
  c=c^data[n*8+:8];
  for(k=0;k<8;k=k+1)c=c[7] ? (c<<1)^8'h07:c<<1;
 end
 crc8=c;
end endfunction
task mute_via_bluetooth;integer n;begin
 uart_byte(8'ha5);uart_byte(8'h5a);uart_byte(8'h51);uart_byte(2);
 for(n=0;n<6;n=n+1)uart_byte(0);
 uart_byte(crc8({48'd0,8'd2,8'h51}));uart_byte(8'h0d);clocks(32);
 if(dut.u_core.vol!==0)$fatal(1,"Real framed Bluetooth command2 did not mute master volume");
end endtask

integer i,p,x,fd,different_columns=0,noncenter_pixels=0;
reg [63:0] first_column,column_pixels;
reg [7:0] expected;
task wait_frame;begin
 wait(!dut.u_visual_oled.frame_done);wait(dut.u_visual_oled.frame_done);@(negedge clk);
 if(!dut.u_visual_oled.online || data_pages!=8 || cmd_pages!=8 || data_bytes!=1024)
  $fatal(1,"Live OLED incomplete electrical frame:pages%0d cmds%0d bytes%0d",data_pages,cmd_pages,data_bytes);
end endtask
initial begin
 clocks(8);rst_n=1;keys[0]=0;
 wait_frame();
 if(!dut.u_core.physical_keys[0] || !dut.u_core.v_gate[0] || dut.u_core.timbre!==0)
  $fatal(1,"Default piano physical C4 did not reach synthesizer");
 if(nonzero_taps<32 || pairs<32)$fatal(1,"Insufficient actual synthesized PCM/I2S audio");
 fd=$fopen("sim/oled_live_audio.hex","w");
 if(!fd)$fatal(1,"Cannot open live waveform artifact");
 for(i=0;i<1024;i=i+1)begin
  p=i/128;expected=(p==4) ? 8'h10:0;
  if(p>=1 && pixels[i]!==expected)noncenter_pixels=noncenter_pixels+1;
  $fdisplay(fd,"%02x",pixels[i]);
 end
 $fclose(fd);
 for(x=0;x<128;x=x+1)begin
  column_pixels=0;
  for(p=1;p<8;p=p+1)column_pixels[p*8+:8]=pixels[p*128+x];
  if(x==0)first_column=column_pixels;
  else if(column_pixels!==first_column)different_columns=different_columns+1;
 end
 if(noncenter_pixels==0 || different_columns<8)$fatal(1,"Actual piano OLED waveform was flat");
 data_pages=0;cmd_pages=0;data_bytes=0;
 mute_via_bluetooth();
 // Refresh delay exceeds the complete real setter frame, so every sample in
 // this next capture is taken after the actual master-volume register is zero.
 wait(dut.u_visual_oled.capture_request);wait(!dut.u_visual_oled.capture_request);
 wait_frame();
 fd=$fopen("sim/oled_live_muted.hex","w");
 if(!fd)$fatal(1,"Cannot open muted waveform artifact");
 for(i=0;i<1024;i=i+1)begin
  p=i/128;expected=(p==4) ? 8'h10:0;
  if(p>=1 && pixels[i]!==expected)$fatal(1,"Bluetooth volume0 OLED must be y32 centerline page%0d x%0d got%h",p,i%128,pixels[i]);
  $fdisplay(fd,"%02x",pixels[i]);
 end
 $fclose(fd);
 if(tap_word!==0)$fatal(1,"Muted actual I2S frame is not zero");
 $display("PASS: actual physical C4 piano -> complete stereo I2S/tap -> nonflat1024byte OLED electrical frame; real framed BT volume0 -> centerline (%0d stereo pairs)",pairs);
 $finish;
end
initial begin #100000000;$fatal(1,"Live OLED audio timeout");end
endmodule
