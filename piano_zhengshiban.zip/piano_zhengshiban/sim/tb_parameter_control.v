`timescale 1ns/1ps
module tb_parameter_control;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,valid=0;reg[7:0] command=0;
 wire[3:0] rev,echo,chorus,expression,vibrato;wire[4:0] bend;wire[1:0] delay_select,guide;
 panel_parameter_control dut(.clk(clk),.rst_n(rst_n),.command(command),.command_valid(valid),
  .reverb(rev),.echo(echo),.chorus(chorus),.expression(expression),.vibrato(vibrato),
  .bend(bend),.delay_select(delay_select),.guide(guide));
 task put;input[7:0] c;begin @(negedge clk);command=c;valid=1;@(negedge clk);valid=0;end endtask
 integer i;reg[30:0] before_bad;
 initial begin
  repeat(3)@(negedge clk);rst_n=1;@(negedge clk);
  if({rev,echo,chorus,expression,vibrato,bend,delay_select,guide}!={4'd0,4'd0,4'd0,4'd15,4'd0,5'd8,2'd0,2'd0})$fatal(1,"sound defaults changed");
  for(i=0;i<16;i=i+1)begin
   put(8'h10+i);if(rev!=i)$fatal(1,"reverb range");
   put(8'h20+i);if(echo!=i)$fatal(1,"echo range");
   put(8'h30+i);if(chorus!=i)$fatal(1,"chorus range");
   put(8'ha0+i);if(expression!=i)$fatal(1,"expression range");
   put(8'hd0+i);if(vibrato!=i)$fatal(1,"vibrato range");
  end
  for(i=0;i<17;i=i+1)begin put(8'hb0+i);if(bend!=i)$fatal(1,"bend range");end
  for(i=0;i<3;i=i+1)begin
   put(8'h50+i);if(delay_select!=i)$fatal(1,"time range");
   put(8'h70+i);if(guide!=i)$fatal(1,"guide range");
  end
  before_bad={rev,echo,chorus,expression,vibrato,bend,delay_select,guide};
  for(i=0;i<256;i=i+1)begin
   if(!((i>=16&&i<=63)||(i>=80&&i<=82)||(i>=112&&i<=114)||(i>=160&&i<=192)||(i>=208&&i<=223)))begin
    put(i);if({rev,echo,chorus,expression,vibrato,bend,delay_select,guide}!==before_bad)$fatal(1,"nonparameter command changed state %h",i);
   end
  end
  command=8'h10;repeat(3)@(negedge clk);if(rev!=15)$fatal(1,"unqualified command applied");
  rst_n=0;@(negedge clk);rst_n=1;@(negedge clk);if(expression!=15||bend!=8||rev!=0)$fatal(1,"reset defaults");
  $display("PASS: BT/local parameter defaults, all ranges, invalid/removed-screen commands ignored, reset");$finish;
 end
 initial begin #100000;$fatal(1,"parameter control timeout");end
endmodule
