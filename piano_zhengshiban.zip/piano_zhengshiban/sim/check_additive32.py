"""Independent math oracle -> real four-voice HDL -> numeric and spectral checks."""
import cmath
import ctypes
import math
import os
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "tmp/additive32"
WORK.mkdir(parents=True, exist_ok=True)
sys.stdout.reconfigure(encoding="utf-8")

amplitudes = {}
for group in (range(1, 9), range(9, 33)):
    normalization = sum(h ** -1.5 for h in group)
    for h in group:
        amplitudes[h] = math.floor(32700 * h ** -1.5 / normalization)
assert all(amplitudes[h] > 0 for h in range(1, 33))
assert sum(amplitudes[h] for h in range(1, 9)) <= 32700
assert sum(amplitudes[h] for h in range(9, 33)) <= 32700

def reference(phase, increment):
    body = strike = 0
    for h in range(1, 33):
        if increment == 0 or h * increment >= (1 << 31):
            continue
        address = ((phase * h) & 0xffffffff) >> 22
        value = round(amplitudes[h] * math.sin(2 * math.pi * address / 1024))
        if h <= 8:
            body += value
        else:
            strike += value
    assert -32700 <= body <= 32700 and -32700 <= strike <= 32700
    return body & 0xffff, strike & 0xffff

def pack(values, width):
    return sum(value << (i * width) for i, value in enumerate(values))

cases = []
for n in range(1024):
    cases.append(([(n << 22) & 0xffffffff, (n * 997123) & 0xffffffff,
                   (n * 99817 + 0x12345678) & 0xffffffff, (n * 333331) & 0xffffffff],
                  [23012828] * 4))
rng = random.Random(20261024)
for h in range(1, 33):
    boundary = (1 << 31) // h
    for delta in (-1, 0, 1):
        inc = min(0xffffffff, boundary + delta)
        cases.append(([rng.getrandbits(32) for _ in range(4)],
                      [inc, 23012828, 0, 0xffffffff]))
for n in range(192):
    cases.append(([rng.getrandbits(32) for _ in range(4)],
                  [rng.randrange(1, 150000001) for _ in range(4)]))
with (WORK / "vectors.txt").open("w", encoding="ascii") as stream:
    for phases, increments in cases:
        expected = [reference(p, f) for p, f in zip(phases, increments)]
        body = pack([item[0] for item in expected], 16)
        strike = pack([item[1] for item in expected], 16)
        stream.write(f"{pack(phases,32):032x} {pack(increments,32):032x} "
                     f"{body:016x} {strike:016x}\n")

source = ROOT / "src/core/additive32_bank.v"
if not source.exists():
    raise AssertionError("Missing feature: the32-lane additive engine is not implemented")

binary = Path(os.environ.get("IVERILOG_BIN", str(ROOT / "tmp/iverilog/mingw64/bin")))
env = os.environ.copy()
env["PATH"] = str(binary) + os.pathsep + r"C:\mingw64\bin" + os.pathsep + env["PATH"]
env["TEMP"] = env["TMP"] = str(ROOT / "tmp")
if os.name == "nt":
    ctypes.windll.kernel32.SetErrorMode(0x8003)
commands = [
    [str(binary / "iverilog.exe"), "-g2012", "-s", "tb_additive32",
     "-o", str(WORK / "unit.vvp"), str(source), str(ROOT / "src/core/additive32_rom_pair.v"), str(ROOT / "sim/tb_additive32.v")],
    [str(binary / "vvp.exe"), str(WORK / "unit.vvp")],
]
for command in commands:
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=90)
    output = result.stdout.decode("utf-8", "replace") + result.stderr.decode("utf-8", "replace")
    print(output, end="", flush=True)
    if result.returncode:
        raise RuntimeError(f"HDL check failed ({result.returncode})")

samples = [tuple(map(int, line.split(","))) for line in
           (WORK / "samples.csv").read_text().splitlines()]
assert len(samples) == 1024, "Need one complete uniform phase cycle"
mixed = [.75 * body + .25 * strike for body, strike in samples]
spectral = []
for h in range(1, 33):
    magnitude = abs(sum(v * cmath.exp(-2j * math.pi * h * i / 1024)
                        for i, v in enumerate(mixed))) / 512
    expected = amplitudes[h] * (.75 if h <= 8 else .25)
    assert magnitude > 1, f"Harmonic{h} missing"
    assert abs(magnitude - expected) < 2, (h, magnitude, expected)
    spectral.append(f"{h},{magnitude:.6f},{expected:.6f}")
(WORK / "spectrum.csv").write_text("harmonic,measured,expected\n" +
                                 "\n".join(spectral) + "\n", encoding="ascii")
print(f"PASS: {len(cases)} four-voice math vectors, all32 harmonics, Nyquist edges, "
      "input snapshot/clear flushing/deadline; bounded signed output")
