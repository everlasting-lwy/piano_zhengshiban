`timescale 1ns/1ps
// Exercise the actual 50MHz / 115200 / 8N2 wire, not a ready mock.
module tb_midi_integrity;
    reg clk=0;always #10 clk=~clk;
    reg rst=0,start=0;
    reg [7:0] data=0,volume=240;
    wire ready,tx,start_tx,ready_tx;
    wire [7:0] bus;
    midi_encoder encoder(.clk(clk),.rst_n(rst),.data(data),.volume_in(volume),
        .mstart(start),.mready(ready),.tbus(bus),.tstart(start_tx),.tready(ready_tx));
    uart_tx uart(.clk(clk),.rst_n(rst),.tbus(bus),.start(start_tx),.ready(ready_tx),.tx(tx));
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    reg [7:0] received[0:255];
    integer count=0,b;
    reg [7:0] rx;
    initial forever begin
        @(negedge tx);clocks(651);
        for(b=0;b<8;b=b+1)begin rx[b]=tx;clocks(434);end
        if(tx!==1)$fatal(1,"MIDI first stop");
        clocks(434);if(tx!==1)$fatal(1,"MIDI second stop");
        received[count]=rx;count=count+1;
    end
    task send_message;input integer pitch,on;begin
        wait(ready);@(negedge clk);data={pitch[6:0],on[0]};start=1;
        clocks(1);start=0;
    end endtask
    integer i,first;
    initial begin
        clocks(4);rst=1;clocks(4);
        for(i=60;i<78;i=i+1)begin
            first=count;send_message(i,1);wait(count==first+3);
            if(received[first]!==8'h90 || received[first+1]!==i || received[first+2]!==120)
                $fatal(1,"Stable volume wire mismatch note=%0d velocity=%0d",i,received[first+2]);
            send_message(i,0);wait(count==first+6);
            if(received[first+3]!==8'h80 || received[first+4]!==i || received[first+5]!==0)
                $fatal(1,"Wire release mismatch");
        end
        $display("PASS: 18 notes have identical velocity120 and correct release at real baud");
        // A parameter change after acceptance must affect the NEXT note only.
        first=count;send_message(60,1);
        wait(count==first+1);volume=32;
        wait(count==first+3);
        if(received[first+2]!==120)
            $fatal(1,"Velocity changed mid-message: accepted120, emitted%0d",received[first+2]);
        send_message(62,1);wait(count==first+6);
        if(received[first+5]!==16)$fatal(1,"Next note must use new volume");
        $display("PASS: velocity is latched at message acceptance, subsequent note uses new volume");
        $finish;
    end
    initial begin #40000000;$fatal(1,"MIDI integrity timeout");end
endmodule
