`timescale 1ns/1ps
module tb_practice_guide;
reg clk=0;always #10 clk=~clk;
reg rst=0;reg[1:0] mode=0;reg[17:0] keys=0;
wire[17:0] target;wire[4:0] step;wire wrong,complete;
practice_guide d(clk,rst,mode,keys,target,step,wrong,complete);
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
integer i;reg[17:0] expected;
initial begin
clocks(3);rst=1;clocks(3);if(target!==0)$fatal(1,"Guide enabled unexpectedly");
mode=1;clocks(4);if(target!==1)$fatal(1,"Scale must start C4");
keys=2;clocks(4);if(!wrong||step!=0)$fatal(1,"Wrong key advanced guide");
keys=0;clocks(4);
keys=3;clocks(3);keys=1;clocks(3);keys=0;clocks(3);
if(step!=0)$fatal(1,"Wrong chord followed by partial release advanced without fresh correct press");
for(i=0;i<8;i=i+1)begin
expected=(i==7)?18'h1000:(18'h1<<i);
if(target!==expected)$fatal(1,"Wrong scale target %d",i);
keys=expected;clocks(6);if(step!=i)$fatal(1,"Held key advanced exercise");
keys=0;clocks(4);end
if(step!=0)$fatal(1,"Scale did not wrap");
mode=2;clocks(4);
for(i=0;i<18;i=i+1)begin
if(target==0 || (target & (target-1))!=0)$fatal(1,"Chromatic target not onehot");
keys=target;clocks(3);keys=0;clocks(3);end
if(step!=0)$fatal(1,"Chromatic wrap failed");
mode=0;clocks(3);if(target!==0)$fatal(1,"Guide off left target");
$display("PASS: scale/chromatic physical guide rejects wrong keys and requires release, no sound generation");$finish;
end endmodule
