`timescale 1ns/1ps
module tb_sd_sector_rpc;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_req_valid=0,file_idle=1,bad_crc=0;
reg[7:0]bt_req_command=0;reg[47:0]bt_req_payload=0;
wire bt_rsp_valid;wire[7:0]bt_rsp_command;wire[47:0]bt_rsp_payload;
wire session_active,write_uncertain,media_ready,media_busy,block_done,block_start,block_write;
wire[31:0]media_sectors,block_lba;wire[7:0]media_error,block_error;
assign block_error=media_error;
wire rd_valid,wr_request,wr_valid;wire[8:0]rd_index,wr_index;wire[7:0]rd_data,wr_data;
wire cs_n,sclk,mosi,miso;
sd_sector_rpc #(.LEASE_CYCLES(2000)) dut(.*);
sd_spi_block #(.INIT_DIV(2),.DATA_DIV(1),.POWERUP_CYCLES(8),.INIT_TIMEOUT_CYCLES(1000000)) spi(
 .clk(clk),.rst_n(rst_n),.reinit(1'b0),.start(block_start),.write(block_write),.lba(block_lba),
 .initialized(media_ready),.card_sectors(media_sectors),.busy(media_busy),.done(block_done),.error(media_error),
 .rd_valid(rd_valid),.rd_index(rd_index),.rd_data(rd_data),.wr_request(wr_request),.wr_index(wr_index),.wr_valid(wr_valid),.wr_data(wr_data),
 .cs_n(cs_n),.sclk(sclk),.mosi(mosi),.miso(miso));
sd_spi_card_model card(.cs_n(cs_n),.sclk(sclk),.mosi(mosi),.miso(miso),.kind(2'd0),.csd_variant(3'd0),
 .absent(1'b0),.bad_crc(bad_crc),.reject_write(1'b0),.stuck_busy(1'b0),.no_token(1'b0),.bad_r7(1'b0),.bad_ocr(1'b0),.bad_csd(1'b0),.init_stuck(1'b0),.status_error(1'b0));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task req;input[7:0]c;input[47:0]p;input[7:0]r;integer n;begin
 bt_req_command=c;bt_req_payload=p;bt_req_valid=1;clocks(1);bt_req_valid=0;n=0;
 while(!bt_rsp_valid&&n<10)begin clocks(1);n=n+1;end
 if(!bt_rsp_valid||bt_rsp_command!==r)$fatal(1,"request %h latency=%d response=%h payload=%h",c,n,bt_rsp_command,bt_rsp_payload);
 clocks(2);
end endtask
task ack;input[7:0]c;input[47:0]p;input[7:0]e;begin
 req(c,p,8'h80);if(bt_rsp_payload!=={24'd0,8'd2,e,c})$fatal(1,"bad ack for%h expected%h got%h",c,e,bt_rsp_payload);
end endtask
task done;integer n;begin n=0;while(dut.state!=0&&n<50000)begin clocks(1);n=n+1;end
 if(dut.state!=0)$fatal(1,"RPC block deadline state%d",dut.state);clocks(3);
end endtask
function[7:0]pattern;input integer n;begin pattern=(n*3)^8'ha5;end endfunction
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer i;reg[15:0]c;begin c=old^{v,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
task fill;input[15:0]id;integer n;begin
 ack(8'h24,id,0);
 for(n=0;n<512;n=n+4)begin
  ack(8'h22,{pattern(n+3),pattern(n+2),pattern(n+1),pattern(n),n[15:0]},0);
  if(n==0)begin ack(8'h24,id,0);if(dut.write_count!=4)$fatal(1,"prepare retry lost progress");end
 end
 ack(8'h22,{pattern(511),pattern(510),pattern(509),pattern(508),16'd508},0);
 if(dut.write_count!=512)$fatal(1,"chunk retry changed length");
end endtask
integer j,reads,writes;reg[15:0]crc;
initial begin
 clocks(8);rst_n=1;clocks(3);ack(8'h20,{8'd0,32'h12345678,8'd0},3);
 j=0;while(!media_ready&&j<20000)begin clocks(1);j=j+1;end
 if(!media_ready)$fatal(1,"SPI init");while(media_busy)clocks(1);clocks(3);
 req(8'h28,0,8'h93);if(bt_rsp_payload!=={8'd2,8'd1,32'd1048576})$fatal(1,"geometry");
 file_idle=0;ack(8'h20,{8'd0,32'h12345678,8'd0},3);file_idle=1;
 ack(8'h20,{8'd0,32'd0,8'd0},1);ack(8'h20,{8'd0,32'h12345678,8'd0},0);
 ack(8'h20,{8'd0,32'h87654321,8'd0},3);
 ack(8'h21,{16'd1,32'd17},0);ack(8'h20,{8'd0,32'h12345678,8'd1},3);done();
 if(dut.operation_error!=0||!dut.cache_valid)$fatal(1,"read completion");reads=card.reads;
 for(j=0;j<512;j=j+4)begin req(8'h25,j,8'h91);
  if(bt_rsp_payload!=={(8'(j+3)^8'h5a),(8'(j+2)^8'h5a),(8'(j+1)^8'h5a),(8'(j)^8'h5a),j[15:0]})$fatal(1,"read cache index%d data%h",j,bt_rsp_payload);
 end
 ack(8'h21,{16'd1,32'd17},0);clocks(20);if(card.reads!=reads)$fatal(1,"read replay restarted");
 ack(8'h21,{16'd1,32'd18},1);
 fill(2);crc=16'hffff;for(j=0;j<512;j=j+1)crc=crcbyte(crc,pattern(j));
 ack(8'h23,{crc^16'd1,32'd17},1);writes=card.writes;
 ack(8'h23,{crc,32'd17},0);done();
 if(dut.operation_error!=0||!dut.cache_valid||write_uncertain||card.writes!=writes+1)$fatal(1,"write/readback error=%d",dut.operation_error);
 for(j=0;j<512;j=j+1)if(card.memory[j]!==pattern(j))$fatal(1,"on-card byte%d",j);
 ack(8'h23,{crc,32'd17},0);clocks(20);if(card.writes!=writes+1)$fatal(1,"write replay rewrote card");
 // Card returns a mathematically valid CRC for corrupted stored data. The
 // write's byte comparison must catch this, independently of SPI CRC checks.
 fill(3);ack(8'h23,{crc,32'd17},0);
 while(dut.state!=5)clocks(1);card.memory[11]=card.memory[11]^8'h01;done();
 if(dut.operation_error!=13||!write_uncertain||dut.cache_valid)$fatal(1,"valid-CRC corrupt readback accepted");
 rst_n=0;clocks(8);rst_n=1;clocks(3);
 while(!media_ready||media_busy)clocks(1);clocks(3);
 ack(8'h20,{8'd0,32'h12345678,8'd0},0);
 bad_crc=1;ack(8'h21,{16'd3,32'd17},0);done();
 if(dut.operation_error!=7||dut.cache_valid)$fatal(1,"bad read CRC accepted");
 ack(8'h24,8,0);req(8'h26,0,8'h92);
 if(bt_rsp_payload[7:0]!=3||bt_rsp_payload[15:8]!=7||bt_rsp_payload[39:24]!=3)$fatal(1,"prepare rewrote prior operation result");
 bad_crc=0;ack(8'h21,{16'd4,32'd17},0);done();if(dut.operation_error!=0||!dut.cache_valid)$fatal(1,"read error recovery");
 fill(5);bad_crc=1;ack(8'h23,{crc,32'd17},0);done();
 if(!write_uncertain||dut.cache_valid||dut.operation_error!=7)$fatal(1,"write uncertainty not latched");
 bad_crc=0;fill(6);ack(8'h23,{crc,32'd17},2);
 ack(8'h20,{8'd0,32'h12345678,8'd1},0);ack(8'h20,{8'd0,32'h12345678,8'd1},0);
 ack(8'h20,{8'd0,32'h11111111,8'd0},0);clocks(2100);
 if(session_active||!write_uncertain)$fatal(1,"lease/uncertainty isolation");
 if(card.errors!=0)$fatal(1,"wire peer failures%d",card.errors);
 $display("PASS: sectorRPC real SPI read/write/byte-verified readback, bounded ACK/query, ordered chunks, identity retries, CRC/error recovery, write uncertainty and safe lease");$finish;
end
initial begin#10000000;$fatal(1,"RPC test timeout");end
endmodule
