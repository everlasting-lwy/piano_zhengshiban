"""File-backed SD peer + phone sectorRPC + autonomous FAT reader. No devices."""
from pathlib import Path
import ctypes,importlib.util,os,struct,subprocess,sys,binascii
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'tmp/sd_restore_20261101';HERE.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('fixture',ROOT/'sim/fat32_fixture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.HERE=HERE/'wire_fixtures';m.HERE.mkdir(exist_ok=True)
p18_body=b'\x01\x00\x00\x00\x00\x02';p18=bytearray(64)+p18_body
p18[:8]=b'P18GUIDE';p18[8]=1;p18[9]=3;p18[16:19]=b'New';struct.pack_into('<HH',p18,10,2,binascii.crc_hqx(p18_body,0xffff));struct.pack_into('<H',p18,62,binascii.crc_hqx(p18[:62],0xffff))
song_path=m.HERE/'phone_p18.hex';song_path.write_text('\n'.join(f'{v:02x}'for v in p18)+'\n')
binpath=Path(os.environ.get('IVERILOG_BIN',str(ROOT.parent/'piano/tmp/iverilog/mingw64/bin')));env=os.environ.copy();env['PATH']=str(binpath)+os.pathsep+r'C:\mingw64\bin'+os.pathsep+env['PATH']
env['TMP']=env['TEMP']=str(ROOT/'tmp')
if os.name=='nt':ctypes.windll.kernel32.SetErrorMode(0x8003)
def run(args):
 p=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,text=True,timeout=300)
 print(p.stdout+p.stderr,end='',flush=True);p.check_returncode();return p.stdout
vvp=HERE/'library.vvp'
run([str(binpath/'iverilog.exe'),'-g2012','-s','tb_sd_phone_library','-o',str(vvp),
 'src/sd_song_library.v','src/sd_sector_rpc.v','src/sd_spi_block.v','src/fat32_file_store.v','src/sd_song_bridge.v','src/song_guide.v','sim/sd_spi_image_model.v','sim/tb_sd_phone_library.v'])
for case in ('save','full'):
 image=HERE/f'wire_{case}.img';info=m.fixture(image,'super')
 # A normal one-cluster root makes the wire test short. Fragmented root,
 # maximum songs and hostile chains are exercised by the dedicated FAT suite.
 with image.open('r+b')as f:
  f.seek((info['data']+5)*512);root_entry=f.read(512)
  f.seek(info['data']*512);f.write(root_entry)
  for fat_copy in range(2):
   f.seek((32+fat_copy*info['fatsz'])*512+8);f.write(struct.pack('<I',0xafffffff))
 output=run([str(binpath/'vvp.exe'),str(vvp),f'+IMAGE={image.as_posix()}',f'+SONG={song_path.as_posix()}']+(['+SAVEONLY']if case=='save'else[]))
 assert 'PASS:' in output
 with image.open('rb')as f:
  def sector(lba):f.seek(lba*512);return f.read(512)
  fats=[b''.join(sector(32+k*info['fatsz']+i)for i in range(info['fatsz']))for k in range(2)]
  assert fats[0]==fats[1], 'FAT mirrors differ'
  def chain(c):
   seen=[]
   while c<0x0ffffff8:
    assert 2<=c<65532 and c not in seen;seen.append(c);c=struct.unpack_from('<I',fats[0],c*4)[0]&0xfffffff
   return seen
  entries=[]
  for c in chain(2):
   b=sector(info['data']+c-2)
   for off in range(0,512,32):
    e=b[off:off+32]
    if not e[0]:break
    if e[0]!=0xe5:entries.append(e)
  assert not any(e[:1]==b'T' for e in entries),'temporary file left behind'
  assert sector(info['data']+2)[:9]==b'ordinary!'
  target=[e for e in entries if e[:11]==b'P0000004P18']
  assert len(target)==(case=='save')
  if target:
   e=target[0];c=struct.unpack_from('<H',e,26)[0]|struct.unpack_from('<H',e,20)[0]<<16
   content=b''.join(sector(info['data']+x-2)for x in chain(c))[:struct.unpack_from('<I',e,28)[0]]
   assert len(content)==70 and content[:8]==b'P18GUIDE' and content[16:19]==b'New'
   assert content[64:]==b'\x01\x00\x00\x00\x00\x02'
   assert binascii.crc_hqx(content[:62],0xffff)==struct.unpack_from('<H',content,62)[0]
   assert binascii.crc_hqx(content[64:],0xffff)==struct.unpack_from('<H',content,12)[0]
   (HERE/'wire_saved_P0000004.P18').write_bytes(content)
  for lba in(1,7):assert sector(lba)[488:496]==b'\xff'*8
 image.unlink()
 print(f'PASS: independent ordinary FAT32 file/mirrors/CRC/FSInfo/preservation inspection ({case})',flush=True)
