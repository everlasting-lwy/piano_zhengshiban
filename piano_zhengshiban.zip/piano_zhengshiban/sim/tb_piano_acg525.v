`timescale 1ns/1ps
module tb_piano_acg525;
    reg clk=0;
    always #10 clk=~clk;
    reg reset_n=1;
    reg [17:0] keys=18'h3FFFF;
    reg timbre=1, mode_key=1, up=1, down=1, octave=1;
    reg bt=1, echo=0;
    wire bclk,lrck,din,trig,tx,ds,sh,st;
    wire [3:0] led;
    top_piano_acg525 #(.ENABLE_VOLUME_KEYS(1)) dut(
        .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(reset_n),.key_in(keys),
        .key_timbre(timbre),.key_mode(mode_key),.key_vol_up(up),
        .key_vol_down(down),.key_octave(octave),.bt_rxd(bt),.hc_echo(echo),
        
        .hc_trig(trig),.i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din),
        .led(led),.uart_txd(tx),.seg_ds(ds),.seg_sh_cp(sh),.seg_st_cp(st)
    );
    // Accelerate mechanical settling only; audio/UART retain real 50 MHz timing.
    defparam dut.u_core.u_key.DEBOUNCE_CYCLES=8;
    task settle; begin repeat(80) @(negedge clk); end endtask
    task mode_press;
        begin
            mode_key=0; repeat(8) @(negedge clk);
            force dut.u_core.key4_cnt=20'd500000;
            repeat(4) @(negedge clk);
            release dut.u_core.key4_cnt;
            settle;
            mode_key=1; repeat(8) @(negedge clk);
            force dut.u_core.key4_cnt=20'd500000;
            repeat(4) @(negedge clk);
            release dut.u_core.key4_cnt;
            settle;
        end
    endtask
    integer i,samples,last_sample_cycle,cycles=0,audio_nonzero=0;
    reg [3:0] expected_note;
    always @(posedge clk) cycles=cycles+1;
    always @(negedge clk) begin
        if(dut.core_rst_n && dut.u_core.audio_scaled != 0) audio_nonzero=audio_nonzero+1;
    end
    reg [7:0] midi [0:5];
    integer byte_count=0,j;
    reg [7:0] rx_byte;
    // Decode actual 115200-baud wire output, including Note Off on mode exit.
    initial begin
        forever begin
            @(negedge tx);
            repeat(651) @(negedge clk);
            for(j=0;j<8;j=j+1) begin
                rx_byte[j]=tx;
                repeat(434) @(negedge clk);
            end
            if(tx !== 1'b1) $fatal(1,"UART stop bit");
            if(byte_count<6) midi[byte_count]=rx_byte;
            byte_count=byte_count+1;
        end
    end
    initial begin
        // Must start correctly without manually pressing reset.
        settle;
        if(dut.core_rst_n !== 1 || dut.u_core.source_mode !== 0 || led !== 0)
            $fatal(1,"Power-on reset / default mode");
        for(i=0;i<12;i=i+1) begin
            keys=18'h3FFFF ^ (18'h001<<i);settle;
            expected_note=i+1;
            if(dut.u_core.disp_note !== expected_note || led==0)
                $fatal(1,"Music key %0d mapping, note=%0d",i,dut.u_core.disp_note);
            keys=18'h3FFFF;settle;
            if(led !== 0) $fatal(1,"Stuck music key %0d",i);
        end
        // Natural and sharp notes together: four voices and nonzero PCM.
        keys=18'h3FF6C;settle; // bits 0,1,4,7 held
        if(led !== 4'hF) $fatal(1,"Four-voice chord");
        audio_nonzero=0;samples=0;last_sample_cycle=0;
        repeat(10000) begin
            @(negedge clk);
            if(dut.u_core.sample_tick) begin
                if(last_sample_cycle!=0 && cycles-last_sample_cycle!=1024)
                    $fatal(1,"Incorrect sample rate");
                last_sample_cycle=cycles;samples=samples+1;
            end
        end
        if(samples<8 || audio_nonzero==0) $fatal(1,"Audio chain silent");
        keys=18'h3FFFF;settle;
        // Check board timbre and volume/octave connections with accelerated counters.
        timbre=0;repeat(8) @(negedge clk);
        force dut.u_core.key0_cnt=20'd500000;
        repeat(4) @(negedge clk);release dut.u_core.key0_cnt;settle;
        if(dut.u_core.timbre!==1) $fatal(1,"Board KEY1 timbre mapping");
        timbre=1;
        octave=0;repeat(8) @(negedge clk);
        force dut.u_core.key3_cnt=20'd500000;
        repeat(4) @(negedge clk);release dut.u_core.key3_cnt;settle;
        if(dut.u_core.octave!==1) $fatal(1,"Octave GPIO mapping");
        octave=1;
        down=0;repeat(8) @(negedge clk);
        force dut.u_core.key2_cnt=20'd500000;
        repeat(4) @(negedge clk);release dut.u_core.key2_cnt;settle;
        if(dut.u_core.vol!==14) $fatal(1,"Volume down GPIO mapping");
        down=1;
        up=0;repeat(8) @(negedge clk);
        force dut.u_core.key1_cnt=20'd500000;
        repeat(4) @(negedge clk);release dut.u_core.key1_cnt;settle;
        if(dut.u_core.vol!==15) $fatal(1,"Volume up GPIO mapping");
        up=1;
        mode_press;
        if(dut.u_core.source_mode!==1) $fatal(1,"MIDI mode");
        keys=18'h3FDFF;settle; // key bit 9 = F#; octave up => MIDI 78
        wait(byte_count>=3);
        if(midi[0]!==8'h90 || midi[1]!==8'd78 || midi[2]==0)
            $fatal(1,"MIDI Note On %h %h %h",midi[0],midi[1],midi[2]);
        mode_press;
        wait(byte_count>=6);
        if(midi[3]!==8'h80 || midi[4]!==8'd78 || midi[5]!==0)
            $fatal(1,"Mode exit must transmit Note Off");
        keys=18'h3FFFF;
        if(dut.u_core.source_mode!==2) $fatal(1,"Theremin mode");
        // Test the mapping consumer with the 47 cm boundary from the documented scale.
        force dut.u_core.distance_cm=16'd47;
        force dut.u_core.dist_valid=1'b1;
        settle;
        if(dut.u_core.theremin_note!==1 || dut.u_core.theremin_octave!==4)
            $fatal(1,"Theremin C4 mapping");
        release dut.u_core.distance_cm;release dut.u_core.dist_valid;
        mode_press;
        if(dut.u_core.source_mode!==0)
            $fatal(1,"Three-mode cycle must return from theremin to local audio");
        reset_n=0;settle;
        if(dut.core_rst_n!==0 || led!==0) $fatal(1,"External reset");
        reset_n=1;settle;
        if(dut.u_core.source_mode!==0) $fatal(1,"Reset default mode");
        $display("PASS: power-on/reset, 12 keys, four voices, PCM/sample rate, timbre/volume/octave, MIDI wire Note On/Off, theremin and three-mode cycle");
        $finish;
    end
    initial begin #20000000; $fatal(1,"Board test timeout"); end
endmodule
