`timescale 1ns/1ps
module tb_wm8960_board;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,present=1,stuck=0;
 reg [17:0] keys=18'h3ffff;
 tri1 scl,sda,oscl,osda,vscl,vsda;
 assign scl=stuck ? 1'b0:1'bz;
 wire bclk,lrck,dac,mclk,bt,uart;
 top_piano_wm8960_acg525 #(.WM_I2C_DIV(2),.WM_BOOT_CYCLES(20),
  .WM_RESET_CYCLES(10),.WM_BIAS_CYCLES(100),.WM_RETRY_CYCLES(100),.WM_TIMEOUT_CYCLES(100),
  .OLED_BOOT_CYCLES(10),.OLED_TIMEOUT_CYCLES(100),.OLED_RETRY_CYCLES(100),
  .VISUAL_BOOT_CYCLES(10),.VISUAL_TIMEOUT_CYCLES(100),.VISUAL_RETRY_CYCLES(100)) dut(
  .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),
  .key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0),
  .encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),
  .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
  .oled_scl(oscl),.oled_sda(osda),.visual_oled_scl(vscl),.visual_oled_sda(vsda),
  .wm8960_scl(scl),.wm8960_sda(sda),.wm8960_mclk(mclk),
  .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(dac),.bt_txd(bt),.uart_txd(uart));
 wm8960_model model(rst_n,present,1'b0,scl,sda);
 integer cycles=0,mc=0,bc=0,frames=0,nonzero=0,pcm_ticks=0;
 integer last_mc=0,last_bc=0,last_frame=0;
 integer press_cycle=0,first_latency=0;
 reg prev_lr=1,slot=1;
 integer bitn=0;
 reg [15:0] received=0,expected=0;
 always @(posedge clk)begin
  cycles=cycles+1;
  if(rst_n && dut.u_board.pcm_frame_valid)pcm_ticks=pcm_ticks+1;
  #1;
  if(rst_n && !dut.audio_enabled && dac!==0)$fatal(1,"DAC data before ready/frame boundary");
 end
 always @(posedge mclk)if(rst_n && dut.rst_n)begin
  if(mc>0 && cycles-last_mc!=4)$fatal(1,"MCLK not 12.5MHz");
  last_mc=cycles;mc=mc+1;
 end
 always @(posedge bclk)if(rst_n && dut.rst_n)begin
  if(bc>0 && cycles-last_bc!=16)$fatal(1,"BCLK not 3.125MHz");
  last_bc=cycles;bc=bc+1;
  if(lrck!=prev_lr)begin
   if(lrck)begin
    if(frames>0 && cycles-last_frame!=1024)$fatal(1,"Fs changed");
    last_frame=cycles;frames=frames+1;
   end
   prev_lr=lrck;slot=lrck;bitn=0;received=0;
  end else begin
   if(bitn<16)begin
    if(bitn==0)expected=dut.audio_enabled ? dut.u_board.pcm_frame : 16'd0;
    received={received[14:0],dac};bitn=bitn+1;
    if(bitn==16)begin
     if(received!==expected)$fatal(1,"I2S %s sample mismatch got=%h expected=%h",slot?"right":"left",received,expected);
     if(!slot && received!=0)begin
      nonzero=nonzero+1;
      if(press_cycle>0 && first_latency==0)first_latency=cycles-press_cycle;
     end
    end
   end else if(dac!==0)$fatal(1,"I2S padding nonzero");
  end
 end
 initial begin
  repeat(5)@(negedge clk);rst_n=1;
  wait(dut.codec_ready);wait(dut.audio_enabled);
  press_cycle=cycles;keys[0]=0;
  repeat(180000)@(negedge clk); // Real 1ms key filter and synthesizer, no forced PCM.
  if(nonzero<20 || model.regs[49]!=9'h077)$fatal(1,"no left speaker samples");
  if(first_latency<=0 || first_latency>=250000)$fatal(1,"physical key to WM8960 left I2S exceeds 5ms");
  $display("WM8960 initialized: physical C4 to complete left-channel I2S = %0d cycles (%0f ms), excludes analog DAC/speaker",first_latency,first_latency/50000.0);
  keys=18'h3ffff;repeat(150000)@(negedge clk);
  // Configuration failure must mute only the physical codec path, not stop audio,
  // displays, UART, or clock generation. Reset while the WM bus is held low.
  rst_n=0;stuck=1;mc=0;bc=0;frames=0;prev_lr=1;
  repeat(5)@(negedge clk);rst_n=1;
  wait(dut.codec_fault);pcm_ticks=0;keys[1]=0;
  repeat(150000)@(negedge clk);
  if(dut.codec_ready || dac!==0 || pcm_ticks<100 || dut.u_board.pcm_frame===0)
   $fatal(1,"codec fault stopped underlying synthesis or failed to mute output");
  stuck=0;wait(dut.codec_ready);wait(dut.audio_enabled);
  nonzero=0;repeat(30000)@(negedge clk);
  if(nonzero<10)$fatal(1,"no recovery after bus restored");
  $display("PASS: WM8960 board MCLK/BCLK/Fs, I2S payload/zero padding, real key audio, muted failure and recovery");
  $finish;
 end
 initial begin #30000000;$fatal(1,"WM board test timeout");end
endmodule
