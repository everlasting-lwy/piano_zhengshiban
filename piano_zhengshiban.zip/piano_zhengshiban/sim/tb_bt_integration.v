`timescale 1ns/1ps
module tb_bt_integration;
    reg clk=0;always #10 clk=~clk;
    reg bt_rx=1;
    reg [17:0] keys=18'h3FFFF;
    wire bt_tx;
    localparam BIT=16;
    top_piano_acg525 #(.BT_UART_CYCLES(BIT),.BT_MS_CYCLES(50),
        .BT_WATCHDOG_MS(2000)) dut(
        .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(1'b1),.key_in(keys),.key_timbre(1'b1),
        .key_mode(1'b1),.key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),
        .bt_rxd(bt_rx),.bt_txd(bt_tx),.hc_echo(1'b0));
    defparam dut.u_core.u_key.DEBOUNCE_CYCLES=100;
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    task bt_byte;input [7:0] value;integer k;begin
        bt_rx=0;clocks(BIT);
        for(k=0;k<8;k=k+1)begin bt_rx=value[k];clocks(BIT);end
        bt_rx=1;clocks(BIT);clocks(4);
    end endtask
    function [7:0] crc8;input [63:0] bytes;integer k,i;reg [7:0] c;begin
        c=0;for(i=0;i<8;i=i+1)begin c=c^bytes[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
        crc8=c;
    end endfunction
    task request;input [7:0] seq,op;input [47:0] payload;integer i;begin
        bt_byte(8'hA5);bt_byte(8'h5A);bt_byte(seq);bt_byte(op);
        for(i=0;i<6;i=i+1)bt_byte(payload[i*8 +:8]);
        bt_byte(crc8({payload,op,seq}));
        bt_byte(8'h0D);
        clocks(20);
    end endtask
    integer edges=0;
    integer cycles=0,last_sample=0,samples=0;
    always @(negedge bt_tx)edges=edges+1;
    always @(negedge clk) begin
        cycles=cycles+1;
        if(dut.core_rst_n && dut.u_core.sample_tick) begin
            if(last_sample!=0 && cycles-last_sample!=1024)$fatal(1,"APP traffic changed audio sample timing");
            last_sample=cycles;samples=samples+1;
        end
    end
    initial begin
        clocks(100);
        request(1,2,9);
        if(dut.u_core.vol!==9)$fatal(1,"Board did not accept APP framed parameter");
        request(2,1,3);request(3,3,2);
        if(dut.u_core.timbre!==3 || dut.u_core.octave!==2)$fatal(1,"APP timbre/octave");
        request(4,4,48'h801);
        if(dut.u_core.keys[11:0]!==12'h801)$fatal(1,"Remote keys were sent through mechanical debounce");
        if(dut.u_core.v_gate==0)$fatal(1,"Remote mask did not reach synth allocator");
        keys=18'h3FFFD;clocks(400);
        request(5,5,0);
        if(dut.u_core.keys[11:0]!==12'h002)$fatal(1,"Remote release disturbed physical D key");
        request(6,1,2);
        if(dut.u_core.timbre!==2)$fatal(1,"Board did not accept updated APP framed timbre");
        request(7,4,48'h800);clocks(100100);
        if(dut.u_core.keys[11:0]!==12'h002)$fatal(1,"Board watchdog left stuck remote note");
        request(8,6,0);clocks(5000);
        if(edges==0)$fatal(1,"HC-05 return TX pin never toggled");
        if(samples<100)$fatal(1,"Insufficient audio samples under APP traffic");
        $display("PASS: board UART APP controls, remote debounce bypass, physical/remote release, timbre update, watchdog and BT return pin");$finish;
    end
    initial begin #30000000;$fatal(1,"BT board timeout");end
endmodule
