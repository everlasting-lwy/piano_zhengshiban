`timescale 1ns/1ps
module tb_uart_rx;
    reg clk=0;
    always #10 clk=~clk;
    reg rst_n=0, rx=1;
    wire [7:0] data;
    wire valid;
    uart_rx dut(.sys_clk(clk),.sys_rst_n(rst_n),.uart_rxd(rx),.rx_data(data),.rx_valid(valid));
    localparam BIT=5208;
    integer count=0;
    reg [7:0] got[0:31];
    always @(negedge clk) if(valid) begin got[count]=data;count=count+1;end
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task send;input [7:0] value;input stop_ok;integer i;begin
        rx=0;clocks(BIT);
        for(i=0;i<8;i=i+1) begin rx=value[i];clocks(BIT);end
        rx=stop_ok;clocks(BIT);
    end endtask
    initial begin
        clocks(8);rst_n=1;clocks(8);
        send(8'h01,1);clocks(20);
        if(count!=1 || got[0]!==8'h01) $fatal(1,"Valid D0=1 command 01 was lost or corrupted; got %0d bytes",count);
        send(8'h03,1);send(8'h41,1);send(8'h8F,1);send(8'h00,1);send(8'h86,1);clocks(20);
        if(count!=6 || got[1]!==8'h03 || got[2]!==8'h41 || got[3]!==8'h8F || got[4]!==8'h00 || got[5]!==8'h86)
            $fatal(1,"Back-to-back commands / LSB-first receive");
        rx=0;clocks(20);rx=1;clocks(BIT*11);
        if(count!=6) $fatal(1,"Short start glitch accepted");
        send(8'h55,0);rx=0;clocks(BIT*12);rx=1;clocks(BIT*2);
        if(count!=6) $fatal(1,"Bad stop or held-low line produced a command");
        send(8'h42,1);clocks(20);
        if(count!=7 || got[6]!==8'h42) $fatal(1,"Did not recover after framing error");
        $display("PASS: 9600 UART odd/even data, back-to-back frames, false start, bad stop, break recovery");
        $finish;
    end
    initial begin #50000000;$fatal(1,"UART test timeout");end
endmodule
