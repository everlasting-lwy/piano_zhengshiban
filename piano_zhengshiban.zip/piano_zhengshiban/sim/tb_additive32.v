`timescale 1ns/1ps
module tb_additive32;
    reg clk=0;always #10 clk=~clk;
    reg rst=0,clear=0,tick=0;
    reg [127:0] phases=0,increments=0;
    wire [63:0] body,strike;
    wire [3:0] valid;
    additive32_bank dut(.clk(clk),.rst_n(rst),.clear(clear),.sample_tick(tick),
        .phase_all(phases),.increment_all(increments),
        .body_all(body),.strike_all(strike),.result_valid(valid));
    integer input_file,output_file,fields,index=0,elapsed,v,seen,commits;
    reg [63:0] expected_body,expected_strike;
    reg [127:0] captured_phases,captured_increments;
    task clocks;input integer count;begin repeat(count)@(negedge clk);end endtask
    task flush;input integer delay_cycles;begin
        tick=1;clocks(1);tick=0;clocks(delay_cycles);clear=1;clocks(1);clear=0;
        repeat(40)begin
            clocks(1);
            if(valid!=0 || body!=0 || strike!=0)$fatal(1,"Stale result escaped clear");
        end
    end endtask
    initial begin
        clocks(3);rst=1;clocks(3);
        if(body!==0 || strike!==0 || valid!==0)$fatal(1,"Reset silence");
        phases=128'hABCD0123_FEDC8765_23456789_12345678;
        increments={4{32'd23012828}};
        for(elapsed=0;elapsed<15;elapsed=elapsed+1)flush(elapsed);
        input_file=$fopen("tmp/additive32/vectors.txt","r");
        output_file=$fopen("tmp/additive32/samples.csv","w");
        if(input_file==0 || output_file==0)$fatal(1,"Test fixture missing");
        while(!$feof(input_file))begin
            fields=$fscanf(input_file,"%h %h %h %h\n",captured_phases,captured_increments,
                           expected_body,expected_strike);
            if(fields==4)begin
                phases=captured_phases;increments=captured_increments;
                tick=1;clocks(1);tick=0;
                phases=~captured_phases;increments=~captured_increments;
                seen=0;commits=0;
                for(elapsed=1;elapsed<=40;elapsed=elapsed+1)begin
                    clocks(1);
                    if(valid!=0 && (valid & (valid-1))!=0)$fatal(1,"Voice tag not one-hot");
                    for(v=0;v<4;v=v+1)if(valid[v])begin
                        if(elapsed>32)$fatal(1,"Additive sample missed32-cycle deadline");
                        if((seen & (1<<v))!=0 || v!=commits)$fatal(1,"Duplicate/reordered voice tag");
                        seen=seen|(1<<v);commits=commits+1;
                        if(body[v*16+:16]!==expected_body[v*16+:16] ||
                           strike[v*16+:16]!==expected_strike[v*16+:16])
                            $fatal(1,"Math mismatch vector%0d voice%0d body%0d/%0d strike%0d/%0d",
                                index,v,$signed(body[v*16+:16]),$signed(expected_body[v*16+:16]),
                                $signed(strike[v*16+:16]),$signed(expected_strike[v*16+:16]));
                    end
                end
                if(seen!=15 || commits!=4)$fatal(1,"Missing four-voice sample commit");
                if(index<1024)$fdisplay(output_file,"%0d,%0d",$signed(body[15:0]),$signed(strike[15:0]));
                index=index+1;
            end
        end
        $fclose(input_file);$fclose(output_file);
        if(index<1200)$fatal(1,"Insufficient math coverage");
        rst=0;clocks(2);
        if(body!==0 || strike!==0 || valid!==0)$fatal(1,"Async reset did not clear");
        $display("PASS: additive32 %0d vectors,4 distinct voices/snapshots;15 flush phases,32-cycle deadline",index);
        $finish;
    end
    initial begin #20000000;$fatal(1,"Additive unit timeout");end
endmodule
