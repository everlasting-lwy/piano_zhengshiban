`timescale 1ns/1ps
module tb_sd_boot_identity_guard;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_req_valid=0;reg[7:0]bt_req_command=0;reg[47:0]bt_req_payload=0;
wire bt_rsp_valid;wire[7:0]bt_rsp_command;wire[47:0]bt_rsp_payload;
wire g_req_valid;wire[7:0]g_req_command;wire[47:0]g_req_payload;
wire g_rsp_valid;wire[7:0]g_rsp_command;wire[47:0]g_rsp_payload;
wire guide_loaded,guide_loading,guide_active;wire[11:0]guide_total_steps;
reg[17:0]physical_keys=0;reg local_next=0,local_prev=0;
reg remote_active=0,remote_uncertain=0;wire storage_idle;
wire sd_busy,selected_valid;wire[4:0]selected_slot;wire[7:0]sd_error;
reg media_ready=1,media_busy=0;reg[7:0]media_error=0;wire media_reinit;
wire file_request;wire[1:0]file_operation;wire[4:0]file_slot;wire[15:0]file_write_size;
reg file_mounted=0,file_busy=0,file_done=0;reg[7:0]file_error=0;reg[15:0]file_size=0;
reg[31:0]present_slots=0;reg write_locked=0;reg[7:0]file_attributes=0;
reg read_valid=0;reg[15:0]read_index=0;reg[7:0]read_data=0;wire read_ready;
reg source_request=0;reg[15:0]source_index=0;wire source_valid;wire[7:0]source_data;
wire[17:0]target;wire complete,wrong;wire[11:0]step;
sd_song_bridge dut(.*);
song_guide guide(.clk(clk),.rst_n(rst_n),.request_valid(g_req_valid),.request_command(g_req_command),.request_payload(g_req_payload),
 .response_valid(g_rsp_valid),.response_command(g_rsp_command),.response_payload(g_rsp_payload),.local_toggle(1'b0),.local_restart(1'b0),
 .physical_keys(physical_keys),.target(target),.active(guide_active),.loaded(guide_loaded),.loading(guide_loading),.complete(complete),.wrong(wrong),.step(step),.total_steps(guide_total_steps));
reg[7:0]disk[0:4095];reg[15:0]sizes[0:31];reg[31:0]exists=0,readonly=0;
integer mode=0,pos=0,saved_slot=0,saved_size=0,requests=0,save_requests=0,delete_requests=0,scan_requests=0,hold_cycles=0;
reg verify_pass=0;reg backend_unsupported=0,backend_io_error=0;
reg source_gaps=0;initial if($test$plusargs("GAPS"))source_gaps=1;
// The fake file layer only replaces block/FAT I/O. Guide RAM and bridge are real.
always @(posedge clk) begin
 file_done<=0;
 if(!rst_n)begin mode<=0;file_busy<=0;file_mounted<=0;read_valid<=0;source_request<=0;end
 else begin
 if(media_reinit)begin media_ready<=1;media_error<=0;end
 case(mode)
 0:if(file_request)begin
  requests<=requests+1;file_busy<=1;file_error<=0;file_attributes<=readonly[file_slot]?1:0;
  saved_slot<=file_slot;saved_size<=file_write_size;pos<=0;verify_pass<=0;
  if(file_operation==0)begin scan_requests<=scan_requests+1;mode<=1;end
  else if(file_operation==1)begin
   file_size<=sizes[file_slot];
   if(!exists[file_slot])begin file_error<=6;mode<=9;end
   else if(backend_io_error)begin file_error<=9;mode<=9;end
   else mode<=2;
  end else if(file_operation==2)begin save_requests<=save_requests+1;mode<=4;end
  else begin delete_requests<=delete_requests+1;exists[file_slot]<=0;sizes[file_slot]<=0;mode<=9;end
 end
 1:begin
  if(backend_unsupported)begin file_error<=3;file_mounted<=0;end
  else begin file_mounted<=1;present_slots<=exists;end
  mode<=9;
 end
 2:begin read_index<=pos;read_data<=disk[saved_slot*128+pos];read_valid<=1;mode<=3;end
 3:if(read_valid&&read_ready)begin read_valid<=0;pos<=pos+1;if(pos+1>=sizes[saved_slot])mode<=9;else mode<=2;end
 4:begin
  source_index<=verify_pass?pos:saved_size-1-pos;source_request<=1;mode<=5;
 end
 5:if(source_request&&source_valid)begin
  if(verify_pass)begin
   if(source_data!==disk[saved_slot*128+pos])$fatal(1,"random source changed at %0d",pos);
  end else disk[saved_slot*128+saved_size-1-pos]<=source_data;
  source_request<=!source_gaps;pos<=pos+1;
  if(pos+1==saved_size)begin
   if(verify_pass)begin source_request<=0;exists[saved_slot]<=1;sizes[saved_slot]<=saved_size;present_slots[saved_slot]<=1;mode<=9;end
   else begin verify_pass<=1;pos<=0;if(source_gaps)mode<=4;else source_index<=0;end
  end else if(source_gaps)mode<=4;else source_index<=verify_pass?pos+1:saved_size-2-pos;
 end
 9:begin file_busy<=0;file_done<=1;mode<=0;end
 endcase
 end
end
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer i;reg[15:0]c;begin c=old^{v,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
function[15:0]crcmask;input[15:0]old;input[17:0]m;begin crcmask=crcbyte(crcbyte(crcbyte(old,m[7:0]),m[15:8]),{6'd0,m[17:16]});end endfunction
task req;input[7:0]c;input[47:0]p;input[7:0]r;integer n;begin
 bt_req_command=c;bt_req_payload=p;bt_req_valid=1;clocks(1);bt_req_valid=0;n=1;
 while(!bt_rsp_valid&&n<11)begin clocks(1);n=n+1;end
 if(!bt_rsp_valid||bt_rsp_command!==r)$fatal(1,"response/latency cmd=%h rsp=%h cycles=%0d",c,bt_rsp_command,n);
 if(n>10)$fatal(1,"BT response exceeded 10 cycles: %h %0d",c,n);
end endtask
task ack;input[7:0]c;input[47:0]p;input[7:0]e;begin req(c,p,8'h80);if(bt_rsp_payload!=={24'd0,8'd1,e,c})$fatal(1,"ACK %h got%h wanted error%h",c,bt_rsp_payload,e);clocks(2);end endtask
task idle;integer n;begin n=0;while(sd_busy&&n<80000)begin clocks(1);n=n+1;end if(sd_busy)$fatal(1,"SD operation stuck state%0d",dut.state);clocks(3);end endtask
task upload;input[17:0]a,b,c;reg[15:0]crc;begin crc=crcmask(crcmask(crcmask(16'hffff,a),b),c);
 ack(8'h10,{8'd0,8'd1,crc,16'd3},0);ack(8'h11,{8'd0,6'd0,a,16'd0},0);ack(8'h11,{8'd0,6'd0,b,16'd1},0);ack(8'h11,{8'd0,6'd0,c,16'd2},0);ack(8'h12,0,0);
end endtask
task expect_saved;input integer slotn;integer j;reg[15:0]hc,bc;begin
 if(sizes[slotn]!==73)$fatal(1,"save wrong size %0d",sizes[slotn]);
 if({disk[slotn*128+7],disk[slotn*128+6],disk[slotn*128+5],disk[slotn*128+4],disk[slotn*128+3],disk[slotn*128+2],disk[slotn*128+1],disk[slotn*128]}!==64'h4544495547383150)$fatal(1,"P18 magic");
 hc=16'hffff;for(j=0;j<62;j=j+1)hc=crcbyte(hc,disk[slotn*128+j]);
 if({disk[slotn*128+63],disk[slotn*128+62]}!==hc)$fatal(1,"header CRC");
 bc=16'hffff;for(j=64;j<73;j=j+1)bc=crcbyte(bc,disk[slotn*128+j]);
 if({disk[slotn*128+13],disk[slotn*128+12]}!==bc)$fatal(1,"payload CRC");
 if(disk[slotn*128+64]!==1||disk[slotn*128+67]!==8'h81||disk[slotn*128+68]!==8'h30||disk[slotn*128+72]!==2)$fatal(1,"export differs from real RAM");
end endtask

integer i,n;reg[15:0]crc,hcrc;
task seed;input integer slotn;begin
 for(i=0;i<128;i=i+1)disk[slotn*128+i]=0;
 {disk[slotn*128+7],disk[slotn*128+6],disk[slotn*128+5],disk[slotn*128+4],disk[slotn*128+3],disk[slotn*128+2],disk[slotn*128+1],disk[slotn*128]}=64'h4544495547383150;
 disk[slotn*128+8]=1;disk[slotn*128+9]=5;disk[slotn*128+10]=3;
 {disk[slotn*128+20],disk[slotn*128+19],disk[slotn*128+18],disk[slotn*128+17],disk[slotn*128+16]}=40'h656c746954;
 disk[slotn*128+64]=1;disk[slotn*128+67]=8'h81;disk[slotn*128+68]=8'h30;disk[slotn*128+72]=2;
 crc=16'hffff;for(i=64;i<73;i=i+1)crc=crcbyte(crc,disk[slotn*128+i]);
 disk[slotn*128+12]=crc[7:0];disk[slotn*128+13]=crc[15:8];
 hcrc=16'hffff;for(i=0;i<62;i=i+1)hcrc=crcbyte(hcrc,disk[slotn*128+i]);
 disk[slotn*128+62]=hcrc[7:0];disk[slotn*128+63]=hcrc[15:8];sizes[slotn]=73;exists[slotn]=1;
end endtask
task ack2;input[7:0]c;input[47:0]p;input[7:0]e;begin req(c,p,8'h80);if(bt_rsp_payload!=={24'd0,8'd2,e,c})$fatal(1,"v2 ACK %h got%h expected error%0d",c,bt_rsp_payload,e);clocks(2);end endtask
reg boot_loaded_seen=0; always @(negedge clk) begin if(guide_loaded)boot_loaded_seen=1; if(rst_n && !boot_loaded_seen && selected_valid && !guide_loaded) $fatal(1,"SD identity published before first guide COMMIT");end
integer failures=0;
task check;input integer condition;input [8*120-1:0] what;begin
 if(!condition)begin failures=failures+1;$display("FAIL: %0s target=%h selected=%0d valid=%0d",what,target,selected_slot,selected_valid);end
end endtask
task load5;input [31:0]token;begin
 ack2(8'h17,{token,8'd5,8'd2},0);idle();
 if(target!==18'd32||!selected_valid||selected_slot!==5)$fatal(1,"SD slot5 fixture did not load");
end endtask
initial begin
 for(i=0;i<32;i=i+1)sizes[i]=0;for(i=0;i<4096;i=i+1)disk[i]=0;
 seed(0);seed(5);disk[5*128+64]=32;
 crc=16'hffff;for(i=64;i<73;i=i+1)crc=crcbyte(crc,disk[5*128+i]);
 disk[5*128+12]=crc[7:0];disk[5*128+13]=crc[15:8];
 hcrc=16'hffff;for(i=0;i<62;i=i+1)hcrc=crcbyte(hcrc,disk[5*128+i]);
 disk[5*128+62]=hcrc[7:0];disk[5*128+63]=hcrc[15:8];
 clocks(4);rst_n=1;clocks(4);idle();
 check(guide_loaded&&target==1&&selected_valid&&selected_slot==0,"boot first valid SD load has identity");
 load5(1);
 // A catalog-only rescan must not falsely label the retained slot5 RAM as slot0.
 ack2(8'h17,{32'd2,8'hff,8'd0},0);idle();
 check(target==32&&!selected_valid,"manual scan preserves old RAM and clears SD identity");
 req(8'h16,0,8'h8b);check(bt_rsp_payload[39:32]==8'hff,"status returns FF when catalog cursor has no RAM identity");clocks(2);
 // Failed/aborted ordinary staging leaves the known, published SD RAM intact.
 load5(3);ack(8'h10,{16'd1,16'd0,16'd3},0);ack(8'h12,0,3);
 check(target==32&&selected_valid&&selected_slot==5,"failed external COMMIT preserves SD identity");
 ack(8'h13,4,0);check(target==32&&selected_valid,"external ABORT preserves SD identity");
 // A successful ordinary RAM upload changes source, without touching catalog.
 upload(2,4,8);check(target==2&&!selected_valid,"successful BT RAM COMMIT clears SD identity");
 req(8'h19,5,8'h8c);check(bt_rsp_payload[8]&&bt_rsp_payload[31:16]==3,"RAM upload preserves valid SD catalog");clocks(2);
 load5(4);ack(8'h13,3,0);check(!guide_loaded&&!selected_valid,"successful RAM delete clears SD identity");
 // A previously scanned file can later fail validation; old RAM must survive.
 load5(5);disk[65]=8'h80;
 ack2(8'h17,{32'd6,8'd0,8'd2},0);clocks(16);
 check(!selected_valid,"in-progress SD replacement has no premature identity");idle();
 check(target==32&&sd_error!=0&&!selected_valid,"failed SD load keeps old RAM without failed target label");
 disk[65]=0;
 // Local cursor remains usable even when RAM identity is unknown.
 ack(8'h13,1,0);local_next=1;clocks(1);local_next=0;clocks(6);
 check(!selected_valid,"queued local selection has no premature identity");idle();
 check(target==32&&selected_valid&&selected_slot==5,"local successful COMMIT restores chosen SD identity");
 // Unknown/unsupported scan likewise never destroys the published RAM.
 backend_unsupported=1;ack2(8'h17,{32'd7,8'hff,8'd0},0);idle();
 check(target==32&&!selected_valid&&sd_error==3,"unsupported scan preserves RAM without stale SD identity");
 if(failures)$fatal(1,"SD RAM identity contract failed %0d checks",failures);
 $display("PASS: SD slot identity follows successful RAM publication; scan/upload/delete/failure never mislabel retained RAM");$finish;
end
initial begin#100000000;$fatal(1,"slot identity watchdog");end
endmodule
