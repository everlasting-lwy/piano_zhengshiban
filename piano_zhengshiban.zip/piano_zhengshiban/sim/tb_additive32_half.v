`timescale 1ns/1ps
// The unchanged full 1024-sample sources are the oracle, never paired images.
module tb_additive32_half;
    reg clk=0,enable0=0,enable1=0,full_cycle=0;
    reg [8:0] address0=0,address1=0;
    reg [9:0] phase0=0,phase1=0;
    wire [15:0] magnitude0[0:15],magnitude1[0:15];
    integer i;
`ifdef NATIVE_DPB
    GSR GSR(.GSRI(1'b1));
`endif
    genvar p;
    generate for(p=0;p<16;p=p+1)begin:G_PAIR
        localparam [7:0] T0=48+(p*2+1)/10,O0=48+(p*2+1)%10;
        localparam [7:0] T1=48+(p*2+2)/10,O1=48+(p*2+2)%10;
        reg [15:0] original0[0:1023],original1[0:1023];
        reg [15:0] want0=0,want1=0,restored0,restored1;
        additive32_rom_pair #(.PAIR_INDEX(p)) dut(
            .clk(clk),.enable0(enable0),.enable1(enable1),
            .address0(address0),.address1(address1),
            .magnitude0(magnitude0[p]),.magnitude1(magnitude1[p]));
        initial begin
            $readmemh({"rom/additive32/h",T0,O0,".hex"},original0);
            $readmemh({"rom/additive32/h",T1,O1,".hex"},original1);
        end
        always @(posedge clk)begin
            if(enable0)want0=original0[address0];
            if(enable1)want1=original1[address1];
            #1;
            if(magnitude0[p]!==want0 || magnitude1[p]!==want1)
                $fatal(1,"Half ROM mismatch pair=%0d address=%0d/%0d got=%h/%h expected original=%h/%h",
                       p,address0,address1,magnitude0[p],magnitude1[p],want0,want1);
            if(full_cycle)begin
                restored0=phase0[9] ? -$signed(magnitude0[p]) : $signed(magnitude0[p]);
                restored1=phase1[9] ? -$signed(magnitude1[p]) : $signed(magnitude1[p]);
                if(restored0!==original0[phase0] || restored1!==original1[phase1])
                    $fatal(1,"Full cycle reconstruction mismatch pair=%0d phase=%0d/%0d",p,phase0,phase1);
            end
        end
    end endgenerate
    task tick;begin #2;clk=1;#2;clk=0;#2;end endtask
    initial begin
        #5;enable0=1;enable1=1;full_cycle=1;
        for(i=0;i<1024;i=i+1)begin
            phase0=i;phase1=(i*37+5)&1023;
            address0=phase0[8:0];address1=phase1[8:0];tick;
        end
        full_cycle=0;
        for(i=0;i<128;i=i+1)begin
            enable0=i%2;enable1=(i/2)%2;
            address0=(i*7+256)&511;address1=(i*11+256)&511;tick;
        end
        $display("PASS: all16 half-ROM pairs, 36864 original-table magnitude/CE comparisons, 32768 exact full-cycle reconstructions");
        $finish;
    end
endmodule
