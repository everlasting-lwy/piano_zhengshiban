"""Sector-image HDL tests and an independent on-disk FAT32 checker. No physical disks."""
from pathlib import Path
import binascii, ctypes, os, struct, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
HERE=ROOT/"tmp/sd_restore_20261101"
HERE.mkdir(parents=True,exist_ok=True)
PY=sys.executable
u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
u32=lambda b,o:struct.unpack_from('<I',b,o)[0]
def song(n=220):
    data=b''.join((1<<(i%18)).to_bytes(3,'little') for i in range(n))
    h=bytearray(64);h[:8]=b'P18GUIDE';h[8]=1;h[9]=4
    struct.pack_into('<HH',h,10,n,binascii.crc_hqx(data,0xffff));h[16:20]=b'Test'
    struct.pack_into('<H',h,62,binascii.crc_hqx(h[:62],0xffff))
    return h+data

def fixture(path,case):
    base=2048 if case in ('mbr','active','spc8','partition_volume_bounds','partition_extent_bounds') else 0
    spc=8 if case=='spc8' else 1
    num_fats=1 if case=='single' else 2
    clusters=1048700 if case=='bound' else 65530
    fatsz=(clusters+129)//128;reserved=32;total=reserved+num_fats*fatsz+clusters*spc
    data_lba=base+reserved+num_fats*fatsz
    boot=bytearray(512);boot[:3]=b'\xeb\x58\x90';boot[3:11]=b'MSDOS5.0'
    struct.pack_into('<HBHBHHBHHHII',boot,11,512,spc,reserved,num_fats,0,0,0xf8,0,63,255,base,total)
    struct.pack_into('<IHHIHH',boot,36,fatsz,0x81 if case=='active' else 0,0,2,1,6)
    boot[64]=0x80;boot[66]=0x29;boot[82:90]=b'FAT32   ';boot[510:]=b'\x55\xaa'
    if case=='bad_geometry':struct.pack_into('<H',boot,11,1024)
    if case=='fat16':struct.pack_into('<I',boot,32,10000)
    if case=='bad_version':struct.pack_into('<H',boot,42,1)
    if case=='bad_root':struct.pack_into('<I',boot,44,clusters+5)
    if case=='bad_spc':boot[13]=3
    if case=='bad_fats':boot[16]=3
    if case=='bad_root_entries':struct.pack_into('<H',boot,17,1)
    if case=='bad_tot16':struct.pack_into('<H',boot,19,1)
    if case=='bad_fat16':struct.pack_into('<H',boot,22,1)
    if case=='card_bounds':struct.pack_into('<I',boot,32,total+1)
    fs=bytearray(512);struct.pack_into('<I',fs,0,0x41615252);struct.pack_into('<III',fs,484,0x61417272,1234,20);struct.pack_into('<I',fs,508,0xaa550000)
    old=song();new=song(2048 if case=='maximum' else 350)
    if case=='bad_header':old[62]^=1
    if case=='bad_payload':old[65]^=1
    if case=='bad_mask':
        old[64:67]=bytes(3);struct.pack_into('<H',old,12,binascii.crc_hqx(old[64:],0xffff));struct.pack_into('<H',old,62,binascii.crc_hqx(old[:62],0xffff))
    if case=='bad_length':
        struct.pack_into('<H',old,10,219);struct.pack_into('<H',old,62,binascii.crc_hqx(old[:62],0xffff))
    if case=='bad_source':new[0]^=1
    with path.open('w+b') as f:
        f.truncate((base+total)*512)
        def sector(lba,b):f.seek(lba*512);f.write(b)
        if base:
            extent=total-1 if case=='partition_volume_bounds' else total+1 if case=='partition_extent_bounds' else total
            m=bytearray(512);m[446+4]=0x0c;struct.pack_into('<II',m,446+8,base,extent);m[510:]=b'\x55\xaa';sector(0,m)
        sector(base,boot);sector(base+6,boot);sector(base+1,(bytes([fs[0]^1])+fs[1:]) if case=='bad_fsinfo' else fs);sector(base+7,fs)
        fat=bytearray(fatsz*512)
        if case in ('full','bound'):
            fat[:]=b'\xff'*len(fat)
        for c,v in ((0,0x0ffffff8),(1,0x0fffffff),(2,7),(7,0x0fffffff),(4,0x0fffffff),(5,9 if spc==1 else 0x0fffffff),(9,0x0fffffff)):
            struct.pack_into('<I',fat,c*4,v|0xa0000000)
        if case=='cyclic_root':struct.pack_into('<I',fat,7*4,2)
        if case=='last_follow':struct.pack_into('<I',fat,7*4,10);struct.pack_into('<I',fat,10*4,0x0fffffff)
        if case=='end_self':struct.pack_into('<I',fat,2*4,2)
        if case=='end_back':struct.pack_into('<I',fat,7*4,2)
        if case in ('end_tail_loop','end_tail_back'):
            for c,v in ((7,10),(10,11),(11,10 if case=='end_tail_loop' else 2)):struct.pack_into('<I',fat,c*4,v)
        if case=='root_bound':
            for c,v in ((7,10),(10,11),(11,12),(12,0x0fffffff)):struct.pack_into('<I',fat,c*4,v)
        if case=='cyclic_file':struct.pack_into('<I',fat,9*4,5)
        if case=='range_file':struct.pack_into('<I',fat,5*4,clusters+7)
        if case=='dirty':struct.pack_into('<I',fat,4,0xa7ffffff)
        sector(base+reserved,fat)
        if case=='active':
            bad=bytearray(fat);struct.pack_into('<I',bad,2*4,0)
            sector(base+reserved,bad)
        if num_fats==2:sector(base+reserved+fatsz,fat)
        first=bytearray(512)
        for i in range(16):
            first[i*32:i*32+11]=('FILE%04dTXT'%i).encode();first[i*32+11]=0x20
            struct.pack_into('<H',first,i*32+26,4);struct.pack_into('<I',first,i*32+28,9)
        if case=='end_self':first[480:]=bytes(32)
        for i in range(spc):sector(data_lba+i,first)
        second=bytearray(512);second[:11]=b'P0000003P18';second[11]=0x01 if case=='readonly' else 0x10 if case=='directory' else 0x20
        struct.pack_into('<H',second,26,5);struct.pack_into('<I',second,28,len(old))
        if case=='temp':second[32:43]=b'T0000009P18';second[43]=0x20;struct.pack_into('<H',second,58,12)
        if case in ('dir_full','last_entry','last_follow','end_back','end_tail_loop','end_tail_back'):
            for i in range(1,16):second[i*32:i*32+11]=('FULL%04dTXT'%i).encode();second[i*32+11]=0x20
        if case in ('last_entry','last_follow','end_back','end_tail_loop','end_tail_back'):second[480:]=bytes(32)
        if case in ('cyclic_root','root_bound'):second[:]=first
        sector(data_lba+(7-2)*spc,second)
        if case=='last_follow':sector(data_lba+8,b'GARBAGE TXT'+bytes(501))
        if case=='root_bound':
            for c in (10,11,12):sector(data_lba+c-2,first)
        sector(data_lba+(4-2)*spc,b'ordinary!'+bytes(503))
        if spc==1:sector(data_lba+3,old[:512]);sector(data_lba+7,old[512:]+bytes(1024-len(old)))
        else:sector(data_lba+3*spc,old+bytes(512*spc-len(old)))
    (HERE/'source.hex').write_text('\n'.join(f'{x:02x}' for x in new)+'\n')
    (HERE/'old.hex').write_text('\n'.join(f'{x:02x}' for x in old)+'\n')
    return dict(base=base,spc=spc,fatsz=fatsz,num_fats=num_fats,total=base+total,data=data_lba,old=bytes(old),new=bytes(new),invalid_primary=case=='bad_fsinfo')

def check(path,info,deleted=False,active=False,created=False):
    with path.open('rb') as f:
        def sec(lba):f.seek(lba*512);return f.read(512)
        fats=[b''.join(sec(info['base']+32+j*info['fatsz']+i) for i in range(info['fatsz'])) for j in range(info['num_fats'])]
        fat=fats[1 if active else 0]
        def chain(c):
            seen=[]
            while c<0x0ffffff8:
                assert 2<=c<65532 and c not in seen,(c,seen)
                seen.append(c);c=u32(fat,c*4)&0x0fffffff
            return seen
        entries=[]
        for c in chain(2):
            for s in range(info['spc']):
                b=sec(info['data']+(c-2)*info['spc']+s)
                for off in range(0,512,32):
                    e=b[off:off+32]
                    if not e[0]:break
                    if e[0]!=0xe5:entries.append(e)
        target=[e for e in entries if e[:11]==(b'P0000004P18' if created else b'P0000003P18')]
        assert len(target)==(0 if deleted else 1),[e[:11] for e in entries]
        assert not any(e[:1]==b'T' for e in entries)
        assert sec(info['data']+2*info['spc'])[:9]==b'ordinary!'
        assert sum(e[:4]==b'FILE' for e in entries)==16*info['spc']
        assert (u32(fat,4)&0x08000000)!=0
        if not active and len(fats)==2:assert fats[0]==fats[1], 'FAT mirrors diverged'
        if not deleted:
            e=target[0];c=u16(e,26)|(u16(e,20)<<16);content=b''.join(sec(info['data']+(x-2)*info['spc']+s) for x in chain(c) for s in range(info['spc']))[:u32(e,28)]
            assert content==info['new']
            for x in chain(c):assert u32(fat,x*4)>>28==0, 'new free cluster high bits unexpectedly changed'
        if created:
            original=[e for e in entries if e[:11]==b'P0000003P18'];assert len(original)==1
            assert u16(original[0],26)==5 and u32(original[0],28)==724
            assert (sec(info['data']+3)+sec(info['data']+7))[:724]==info['old']
        else:
            for c in ((5,9) if info['spc']==1 else (5,)):
                assert (u32(fat,c*4)&0x0fffffff)==0, 'old chain leaked'
                assert (u32(fat,c*4)>>28)==0xa, 'reserved high nibble lost'
        for x in (info['base']+1,info['base']+7):
            b=sec(x)
            if info['invalid_primary'] and x==info['base']+1:assert b[488:496]==struct.pack('<II',1234,20),'invalid FSInfo was modified'
            else:assert b[488:496]==b'\xff'*8, 'FSInfo hints left stale'

def check_failure(path,info,case):
    with path.open('rb') as f:
        def sec(lba):f.seek(lba*512);return f.read(512)
        b=sec(info['data']+5*info['spc']);e=b[:32]
        assert e[:11]==b'P0000003P18', 'original directory name lost'
        assert sec(info['data']+2*info['spc'])[:9]==b'ordinary!'
        if case in ('data_io','meta_io','verify_io','bad_source'):
            assert u16(e,26)==5 and u32(e,28)==724,'prepublication error changed original entry'
            content=(sec(info['data']+3)+sec(info['data']+7))[:724]
            assert content==info['old'],'prepublication error changed original data'
        elif case=='publish_io':
            assert u16(e,26)==3 and u32(e,28)==1114,'publication error test missed target publication phase'
        assert (u32(sec(info['base']+32),4)&0x08000000)==0,'failed transaction marked clean'

