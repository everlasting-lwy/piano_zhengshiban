"""Run real HDL simulations using Icarus Verilog; no FPGA programming involved."""
import argparse
import ctypes
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--bin", type=Path, default=root / "tmp/iverilog/mingw64/bin")
parser.add_argument("--only", help="Run one testbench by module name")
parser.add_argument("--skip", action="append", default=[], help="Skip a separately verified bench (repeatable; printed in log)")
parser.add_argument("--timeout", type=float, default=3600, help="Wall-clock limit per subprocess, seconds; full-rate dual-OLED/audio benches are CPU intensive")
args = parser.parse_args()
# A clean project may reuse an installed read-only Icarus toolchain.
(root / "tmp").mkdir(exist_ok=True)
for artifact_dir in ("dual_oled_20261027", "song_guide_20261028"):
    (root / "tmp" / artifact_dir).mkdir(exist_ok=True)
env = os.environ.copy()
env["IVERILOG_BIN"] = str(args.bin.resolve())
env["PATH"] = str(args.bin.resolve()) + os.pathsep + r"C:\mingw64\bin" + os.pathsep + env["PATH"]
env["TEMP"] = env["TMP"] = str(root / "tmp")
if os.name == "nt":
    ctypes.windll.kernel32.SetErrorMode(0x8003)
sys.stdout.reconfigure(encoding="utf-8")

def run(command):
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=args.timeout)
    output = result.stdout.decode("utf-8", errors="replace") + result.stderr.decode("utf-8", errors="replace")
    print(output, end="", flush=True)
    if result.returncode:
        raise RuntimeError(f"Failed with exit {result.returncode}: {command[0]}")
    return output

logs = []
if args.skip:
    print("Separately verified benches omitted from this invocation: " + ", ".join(args.skip), flush=True)
if not args.only or args.only == "tb_additive32":
    logs.append(run([sys.executable, "sim/check_additive32.py"]))
if not args.only or args.only == "tb_spectrum32":
    logs.append(run([sys.executable, "sim/check_spectrum.py"]))
for top, files in [
    ("tb_sd_spi_crc7_serial", ["src/sd_spi_block.v", "sim/sd_spi_card_model.v", "sim/tb_sd_spi_crc7_serial.v"]),
    ("tb_wm8960_sd_audio", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/reference_single_oled_core.v", "sim/sd_spi_card_model.v", "sim/wm8960_model.v", "sim/tb_wm8960_sd_audio.v"]),
    ("tb_sd_spi_block_16g", ["src/sd_spi_block.v", "sim/sd_spi_card_model.v", "sim/tb_sd_spi_block_16g.v"]),
    ("tb_sd_boot_identity_guard", ["src/sd_song_bridge.v", "src/song_guide.v", "sim/tb_sd_boot_identity_guard.v"]),
    ("tb_sd_audio_isolation", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/reference_single_oled_core.v", "sim/sd_spi_card_model.v", "sim/tb_sd_audio_isolation.v"]),
    ("tb_sd_sector_rpc", ["src/sd_sector_rpc.v", "src/sd_spi_block.v", "sim/sd_spi_card_model.v", "sim/tb_sd_sector_rpc.v"]),
    ("tb_sd_bridge_slot_identity", ["src/sd_song_bridge.v", "src/song_guide.v", "sim/tb_sd_bridge_slot_identity.v"]),
    ("tb_sd_bridge_v2", ["src/sd_song_bridge.v", "src/song_guide.v", "sim/tb_sd_bridge_v2.v"]),
    ("tb_sd_encoder_select", ["src/visual_rotary_control.v", "sim/tb_sd_encoder_select.v"]),
    ("tb_bt_sd_commands", ["src/bt_link.v", "src/bt_frame_rx.v", "src/core/uart_tx.v", "sim/tb_bt_sd_commands.v"]),
    ("tb_oled_sd_display", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_oled_sd_display.v"]),
    ("tb_wm8960_playback", ["src/i2c_write_stream.v", "src/wm8960_playback.v", "sim/wm8960_model.v", "sim/tb_wm8960_playback.v"]),
    ("tb_wm8960_board", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/wm8960_model.v", "sim/tb_wm8960_board.v"]),
    ("tb_oled_font_sync", ["src/oled_font.v", "src/oled_font_sync.v", "sim/tb_oled_font_sync.v"]),
    ("tb_oled_decimal_serial", ["src/oled_decimal_serial.v", "sim/tb_oled_decimal_serial.v"]),
    # Retired no-SD rejection test: SD commands are intentionally restored.
    ("tb_song_export", ["src/song_guide.v", "sim/tb_song_export.v"]),
    ("tb_oled_guide_keyboard", ["src/oled_guide_keyboard.v", "sim/tb_oled_guide_keyboard.v"]),
    ("tb_visual_guide_control", ["src/visual_rotary_control.v", "sim/tb_visual_guide_control.v"]),
    ("tb_oled_song_display", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_oled_song_display.v"]),
    ("tb_song_guide", ["src/song_guide.v", "sim/tb_song_guide.v"]),
    ("tb_bt_song_guide", ["src/song_guide.v", "src/bt_link.v", "src/bt_frame_rx.v", "src/core/uart_tx.v", "sim/tb_bt_song_guide.v"]),
    ("tb_song_guide_board", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_song_guide_board.v"]),
    ("tb_parameter_control", ["src/panel_parameter_control.v", "sim/tb_parameter_control.v"]),
    ("tb_oled_wave_capture", ["src/oled_wave_capture.v", "sim/tb_oled_wave_capture.v"]),
    ("tb_oled_parameter_panel", ["src/i2c_write_stream.v", "src/oled_font_sync.v", "src/oled_parameter_panel.v", "sim/tb_oled_parameter_panel.v"]),
    ("tb_visual_rotary_control", ["src/visual_rotary_control.v", "sim/tb_visual_rotary_control.v"]),
    ("tb_oled_visual_panel", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_oled_visual_panel.v"]),
    ("tb_dual_spectrum", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_dual_spectrum.v"]),
    ("tb_dual_oled_integration", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/reference_single_oled_core.v", "sim/tb_dual_oled_integration.v"]),
    ("tb_rotary_noise", ["src/rotary_control.v", "sim/tb_rotary_noise.v"]),
    ("tb_encoder_volume", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_encoder_volume.v"]),
    ("tb_encoder_integration", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_encoder_integration.v"]),
    ("tb_rotary_control", ["src/rotary_control.v", "sim/tb_rotary_control.v"]),
    ("tb_oled_live_audio", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_oled_live_audio.v"]),
    ("tb_bt_effects", ["src/bt_link.v", "src/bt_frame_rx.v", "src/core/uart_tx.v", "sim/tb_bt_effects.v"]),
    ("tb_bt_visual_stream", ["src/bt_visual_stream.v", "src/core/visual_capture.v", "sim/tb_bt_visual_stream.v"]),
    ("tb_bt_effects_integration", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_bt_effects_integration.v"]),
    ("tb_allocator_retrigger", ["src/core/voice_allocator.v", "sim/tb_allocator_retrigger.v"]),
    ("tb_audio_effects", ["src/core/audio_effects.v", "sim/tb_audio_effects.v"]),
    ("tb_practice_guide", ["src/core/practice_guide.v", "sim/tb_practice_guide.v"]),
    ("tb_pitch_expression", ["src/core/pitch_expression_bank.v", "sim/tb_pitch_expression.v"]),
    ("tb_visual_capture", ["src/core/visual_capture.v", "sim/tb_visual_capture.v"]),
    ("tb_i2s_frame", ["src/core/i2s_tx.v", "sim/tb_i2s_frame.v"]),
    ("tb_additive_integration", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))]
        + ["sim/tb_additive_integration.v"]),
    ("tb_allocator48", ["src/core/voice_allocator.v", "src/core/message_encoder.v", "sim/tb_allocator48.v"]),
    ("tb_ensemble36_midi", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_ensemble36_midi.v"]),
    ("tb_ensemble36", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))] + ["sim/tb_ensemble36.v"]),
    ("tb_bt_ensemble36", ["src/core/uart_tx.v", "src/bt_frame_rx.v", "src/bt_link.v", "sim/tb_bt_ensemble36.v"]),
    ("tb_midi_integrity", ["src/core/midi_encoder.v", "src/core/uart_tx.v", "sim/tb_midi_integrity.v"]),
    ("tb_audio_latency", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))]
        + ["sim/tb_audio_latency.v"]),
    ("tb_keys_latency", ["src/core/key_direct7.v", "sim/tb_keys_latency.v"]),
    ("tb_keyboard18", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))]
        + ["sim/tb_keyboard18.v"]),
    ("tb_bt_frame_rx", ["src/bt_frame_rx.v", "sim/tb_bt_frame_rx.v"]),
    ("tb_bt_link", ["src/core/uart_tx.v", "src/bt_frame_rx.v", "src/bt_link.v", "sim/tb_bt_link.v"]),
    ("tb_bt_integration", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))]
        + ["sim/tb_bt_integration.v"]),
    ("tb_uart_rx", ["src/core/uart_rx.v", "sim/tb_uart_rx.v"]),
    ("tb_seg595_bridge", ["src/seg595_bridge.v", "sim/tb_seg595_bridge.v"]),
    ("tb_piano_acg525", [str(p.relative_to(root)) for p in sorted((root / "src").rglob("*.v"))]
        + ["sim/tb_piano_acg525.v"]),
]:
    if args.only and args.only != top:
        continue
    if top in args.skip:
        continue
    compiled = "sim/" + top + ".vvp"
    logs.append(run([str(args.bin / "iverilog.exe"), "-g2012", "-I", "src/core", "-s", top,
                     "-o", compiled] + files))
    output = run([str(args.bin / "vvp.exe"), compiled])
    if "PASS:" not in output:
        raise RuntimeError("Simulation exited without its success assertion")
    logs.append(output)
(root / "sim/verification.log").write_text("\n".join(logs), encoding="utf-8")
print("ALL HDL TESTS PASSED")
