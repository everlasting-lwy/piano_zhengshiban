`timescale 1ns/1ps
module tb_ensemble36_midi;
 reg clk=0;always #10 clk=~clk;
 reg [17:0] key_in=18'h3ffff;
 reg down=1,up=1;
 wire midi_tx;
 top_piano_acg525 #(.BT_UART_CYCLES(16),.BT_MS_CYCLES(50000)) dut(
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(1'b1),.key_in(key_in),.key_timbre(1'b1),.key_mode(1'b1),
 .key_vol_up(up),.key_vol_down(down),.key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0),.uart_txd(midi_tx));
 defparam dut.u_core.u_key.DEBOUNCE_CYCLES=8;
 defparam dut.u_core.u_uart_tx.CD_MAX=16;
 reg [7:0] input_data=0;reg input_valid=0;
 initial begin force dut.u_core.rx_data=input_data;force dut.u_core.rx_valid=input_valid;end
 task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
 function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
 c=0;for(i=0;i<8;i=i+1)begin c=c^b[i*8+:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;end endfunction
 task byte_in;input [7:0] value;begin input_data=value;input_valid=1;clocks(1);input_valid=0;clocks(1);end endtask
 task request;input [7:0] op;input [47:0] p;integer k;begin
 byte_in(8'ha5);byte_in(8'h5a);byte_in(8'h01);byte_in(op);for(k=0;k<6;k=k+1)byte_in(p[k*8+:8]);
 byte_in(crc8({p,op,8'h01}));byte_in(8'h0d);clocks(100);end endtask
 reg [7:0] midi[0:511];integer byte_count=0,bit_index,i,start_byte,t;
 reg [7:0] received;
 initial forever begin
 @(negedge midi_tx);clocks(24);
 for(bit_index=0;bit_index<8;bit_index=bit_index+1)begin received[bit_index]=midi_tx;clocks(16);end
 if(midi_tx!==1'b1)$fatal(1,"MIDI stop bit");
 midi[byte_count]=received;byte_count=byte_count+1;clocks(16);
 if(midi_tx!==1'b1)$fatal(1,"MIDI second stop bit");end
 task message;input integer first;input [7:0] status,pitch;begin
 t=0;while(byte_count<first+3 && t<5000)begin clocks(1);t=t+1;end
 if(byte_count!=first+3 || midi[first]!==status || midi[first+1]!==pitch ||
 (status==8'h90 && midi[first+2]!==120) || (status==8'h80 && midi[first+2]!==0))
 $fatal(1,"Extended MIDI expected %h/%0d, got %h/%0d/%0d bytes=%0d",status,pitch,midi[first],midi[first+1],midi[first+2],byte_count-first);
 end endtask
 initial begin
 clocks(100);force dut.u_core.source_mode=2'd1;
 for(i=0;i<36;i=i+1)begin
 start_byte=byte_count;request(9,48'd1<<i);message(start_byte,8'h90,48+i);
 start_byte=byte_count;request(5,0);message(start_byte,8'h80,48+i);clocks(100);
 end
 // Phone absolute pitch survives a physical octave command while held.
 start_byte=byte_count;request(9,48'd1<<12);message(start_byte,8'h90,60);
 start_byte=byte_count;request(3,1);clocks(1000);
 if(byte_count!==start_byte)$fatal(1,"Physical octave changed held phone MIDI pitch");
 start_byte=byte_count;request(5,0);message(start_byte,8'h80,60);
 // Original high six physical notes become C6..F6 and retain correct NoteOff.
 for(i=12;i<18;i=i+1)begin
 start_byte=byte_count;key_in=18'h3ffff^(18'd1<<i);message(start_byte,8'h90,72+i);
 start_byte=byte_count;key_in=18'h3ffff;message(start_byte,8'h80,72+i);clocks(100);
 end
 // Release physical source first, leaving phone's same pitch sounding.
 request(3,0);start_byte=byte_count;request(9,48'd1<<12);message(start_byte,8'h90,60);
 start_byte=byte_count;key_in=18'h3fffe;clocks(200);key_in=18'h3ffff;clocks(1000);
 if(byte_count!==start_byte)$fatal(1,"Same-pitch physical add/release retriggered phone MIDI");
 start_byte=byte_count;request(5,0);message(start_byte,8'h80,60);
 // Leaving MIDI must flush the old pitch even while remote key stays held.
 start_byte=byte_count;request(9,1);message(start_byte,8'h90,48);
 start_byte=byte_count;force dut.u_core.source_mode=2'd2;message(start_byte,8'h80,48);
 $display("PASS: all36 MIDI wire notes/releases, fixed absolute phone octave, physical C6..F6, same-pitch hold and mode exit NoteOff");$finish;
 end
 initial begin #30000000;$fatal(1,"ensemble timeout");end
endmodule
