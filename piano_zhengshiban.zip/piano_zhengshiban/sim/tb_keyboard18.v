`timescale 1ns/1ps
// Catches missing upper input bits, 4-bit note aliasing, wrong frequencies,
// lost high-key NoteOff, octave errors and broken four-voice stealing.
module tb_keyboard18;
    reg clk=0;always #10 clk=~clk;
    reg [17:0] keys=18'h3FFFF;
    reg mode_key=1,octave_key=1;
    wire midi_tx;
    top_piano_acg525 dut(
        .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(1'b1),.key_in(keys),
        .key_timbre(1'b1),.key_mode(mode_key),.key_vol_up(1'b1),
        .key_vol_down(1'b1),.key_octave(octave_key),.bt_rxd(1'b1),
        .hc_echo(1'b0),.uart_txd(midi_tx));
    defparam dut.u_core.u_key.DEBOUNCE_CYCLES=8;
    defparam dut.u_core.u_uart_tx.CD_MAX=16;
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    task settle;begin clocks(100);end endtask
    task next_octave;begin
        octave_key=0;clocks(8);force dut.u_core.key3_cnt=20'd500000;
        clocks(4);release dut.u_core.key3_cnt;settle;
        octave_key=1;clocks(8);force dut.u_core.key3_cnt=20'd500000;
        clocks(4);release dut.u_core.key3_cnt;settle;
    end endtask
    task next_mode;begin
        mode_key=0;clocks(8);force dut.u_core.key4_cnt=20'd500000;
        clocks(4);release dut.u_core.key4_cnt;settle;
        mode_key=1;clocks(8);force dut.u_core.key4_cnt=20'd500000;
        clocks(4);release dut.u_core.key4_cnt;settle;
    end endtask
    integer pitch[0:17];
    reg [31:0] increment[0:17];
    integer i,o,slot,start_byte,t;
    reg found;
    reg [31:0] want_increment;
    reg [7:0] midi[0:511];
    integer byte_count=0,b;
    reg [7:0] rx_byte;
    initial forever begin
        @(negedge midi_tx);clocks(24);
        for(b=0;b<8;b=b+1)begin rx_byte[b]=midi_tx;clocks(16);end
        if(midi_tx!==1'b1)$fatal(1,"MIDI stop bit");
        midi[byte_count]=rx_byte;byte_count=byte_count+1;
        clocks(16);if(midi_tx!==1'b1)$fatal(1,"MIDI second stop bit");
    end
    task await_message;input integer first;input [7:0] status,p;
        begin
            t=0;while(byte_count<first+3 && t<3000)begin clocks(1);t=t+1;end
            if(byte_count!=first+3 || midi[first]!==status || midi[first+1]!==p ||
                (status==8'h90 && midi[first+2]==0) || (status==8'h80 && midi[first+2]!=0))
                $fatal(1,"MIDI key %0d octave %0d: want %h/%0d got %h/%0d bytes=%0d",i,o,status,p,midi[first],midi[first+1],byte_count-first);
        end
    endtask
    initial begin
        // Independent fixtures: MIDI pitches and original phase increments,
        // with the upper six notes exactly one octave above the lower six.
        pitch[0]=60;pitch[1]=62;pitch[2]=64;pitch[3]=65;pitch[4]=67;pitch[5]=69;
        pitch[6]=71;pitch[7]=61;pitch[8]=63;pitch[9]=66;pitch[10]=68;pitch[11]=70;
        pitch[12]=72;pitch[13]=73;pitch[14]=74;pitch[15]=75;pitch[16]=76;pitch[17]=77;
        increment[0]=23012828;increment[1]=25831026;increment[2]=28994347;
        increment[3]=30718440;increment[4]=34480283;increment[5]=38702809;
        increment[6]=43442435;increment[7]=24381242;increment[8]=27367019;
        increment[9]=32545054;increment[10]=36530588;increment[11]=41004198;
        increment[12]=46025656;increment[13]=48762484;increment[14]=51662052;
        increment[15]=54734038;increment[16]=57988694;increment[17]=61436880;
        settle;
        for(o=0;o<3;o=o+1)begin
            for(i=0;i<18;i=i+1)begin
                keys=18'h3FFFF ^ (18'h1<<i);settle;
                found=0;
                for(slot=0;slot<4;slot=slot+1)
                    if(dut.u_core.v_gate[slot] && dut.u_core.v_note[slot]==i+1)found=1;
                if(!found)$fatal(1,"Physical key %0d not allocated as note %0d",i,i+1);
                if(dut.u_core.disp_octave !== (pitch[i]+((o==1)?12:(o==2)?-12:0))/12-1)
                    $fatal(1,"Display lost actual pitch octave, key %0d octave %0d",i,o);
                if(dut.u_core.keys!==(18'h1<<i))$fatal(1,"High key mask truncated or aliased");
                want_increment=(o==1)?increment[i]<<1:(o==2)?increment[i]>>1:increment[i];
                if((dut.u_core.v_gate[0] && dut.u_core.G_VOICE[0].u_voice.carrier_increment!==want_increment) ||
                   (dut.u_core.v_gate[1] && dut.u_core.G_VOICE[1].u_voice.carrier_increment!==want_increment) ||
                   (dut.u_core.v_gate[2] && dut.u_core.G_VOICE[2].u_voice.carrier_increment!==want_increment) ||
                   (dut.u_core.v_gate[3] && dut.u_core.G_VOICE[3].u_voice.carrier_increment!==want_increment))
                    $fatal(1,"Wrong audio pitch key %0d octave %0d",i,o);
                keys=18'h3FFFF;settle;
                if(dut.u_core.v_gate!==0)$fatal(1,"Stuck high key %0d",i);
            end
            next_octave;
        end
        // Two original keys and the two highest keys must remain independent.
        keys=18'h0FFFC;settle;
        if(dut.u_core.v_gate!==4'hF)$fatal(1,"Mixed low/high chord lost voices");
        keys=18'h0FFF8;settle; // fifth held key steals one voice
        if(dut.u_core.v_gate!==4'hF)$fatal(1,"Voice stealing broke polyphony");
        keys=18'h3FFFF;settle;
        if(dut.u_core.v_gate!==0)$fatal(1,"Chord release left stuck voices");
        next_mode;
        for(o=0;o<3;o=o+1)begin
            for(i=0;i<18;i=i+1)begin
                start_byte=byte_count;keys=18'h3FFFF ^ (18'h1<<i);
                await_message(start_byte,8'h90,pitch[i]+((o==1)?12:(o==2)?-12:0));
                start_byte=byte_count;keys=18'h3FFFF;
                await_message(start_byte,8'h80,pitch[i]+((o==1)?12:(o==2)?-12:0));
                clocks(100);
            end
            next_octave;
        end
        // Highest held key must send the OLD pitch off before octave-change on.
        i=17;o=0;start_byte=byte_count;keys=18'h1FFFF;
        await_message(start_byte,8'h90,8'd77);
        start_byte=byte_count;next_octave;
        t=0;while(byte_count<start_byte+6 && t<4000)begin clocks(1);t=t+1;end
        if(byte_count!=start_byte+6 || midi[start_byte]!==8'h80 || midi[start_byte+1]!==8'd77 ||
            midi[start_byte+3]!==8'h90 || midi[start_byte+4]!==8'd89)
            $fatal(1,"Held F5 octave change must send Off77 before On89");
        start_byte=byte_count;next_mode;
        await_message(start_byte,8'h80,8'd89);
        keys=18'h3FFFF;settle;
        $display("PASS: 18 physical keys, 54 audio pitches, high-bit independence, four-voice stealing/release and 108 MIDI wire messages");
        $finish;
    end
    initial begin #30000000;$fatal(1,"18-key test timeout");end
endmodule

