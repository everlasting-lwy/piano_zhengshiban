`timescale 1ns/1ps
module tb_visual_capture;
reg clk=0;always #10 clk=~clk;
reg rst=0,clear=0,valid=0,request=0;reg signed[15:0] pcm=0;
reg[5:0] address=0;wire[15:0] point;wire ready;
integer i,j,expected,expected_lag,frames=0;
visual_capture d(.clk(clk),.rst_n(rst),.clear(clear),.sample_valid(valid),.sample(pcm),
 .snapshot_request(request),.snapshot_ready(ready),.read_index(address),.point_data(point));
always @(posedge clk)if(ready)frames=frames+1;
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task ask;begin request=1;clocks(1);request=0;end endtask
task feed;input integer offset;begin
for(i=0;i<256;i=i+1)begin pcm=(((i+offset)%256)-128)*256;valid=1;clocks(1);valid=0;clocks(3);end
end endtask
task check;input integer offset;input integer first;input integer previous_offset;begin
for(j=0;j<64;j=j+1)begin
address=j;clocks(2);
expected=(j*4+offset)%256;expected_lag=(first && j*4<64)?128:(j*4+(j<16?previous_offset:offset)+192)%256;
if(point[7:0]!==expected[7:0]||point[15:8]!==expected_lag[7:0])
 $fatal(1,"Snapshot x[n]/x[n-64], idx%0d actual%0d/%0d expected%0d/%0d",j,point[7:0],point[15:8],expected,expected_lag);
end end endtask
initial begin
clocks(3);rst=1;clocks(3);ask;feed(0);clocks(2);
if(frames!=1)$fatal(1,"First complete snapshot not acknowledged");
check(0,1,0);
// Producer may overwrite its private bank repeatedly; consumer's frame stays coherent.
feed(32);feed(64);check(0,1,0);
ask;feed(96);clocks(2);
if(frames!=2)$fatal(1,"Second snapshot not acknowledged");check(96,0,64);
ask;clear=1;clocks(2);clear=0;
feed(128);if(frames!=2)$fatal(1,"Clear did not cancel pending snapshot");
ask;feed(160);clocks(2);if(frames!=3)$fatal(1,"Snapshot did not recover after clear");check(160,0,128);
$display("PASS: RAM double-buffer snapshots, producer isolation, exact64-sample lag and clear recovery");$finish;
end endmodule
