`timescale 1ns/1ps
module tb_oled_guide_keyboard;
reg [6:0] x=0;reg [2:0] page=0;reg [17:0] target=0,physical=0;
wire [7:0] pixels;
oled_guide_keyboard dut(.x(x),.page(page),.target(target),.physical(physical),.pixels(pixels));
integer key_number,n,y,xx,fd;
integer center_x[0:17];integer center_y[0:17];
task pixel_at;input integer px,py,expected;begin
 x=px;page=py/8;#1;
 if(pixels[py%8]!==expected[0])$fatal(1,"key%0d pixel(%0d,%0d) got%b expected%0d",key_number,px,py,pixels[py%8],expected);
end endtask
initial begin
 center_x[0]=8;center_x[1]=19;center_x[2]=30;center_x[3]=41;
 center_x[4]=52;center_x[5]=63;center_x[6]=74;
 center_x[7]=14;center_x[8]=25;center_x[9]=47;center_x[10]=58;center_x[11]=69;
 center_x[12]=85;center_x[13]=91;center_x[14]=96;center_x[15]=102;center_x[16]=107;center_x[17]=118;
 for(n=0;n<18;n=n+1)center_y[n]=55;
 center_y[7]=32;center_y[8]=32;center_y[9]=32;center_y[10]=32;center_y[11]=32;center_y[13]=32;center_y[15]=32;
 // Literal physical wiring positions: every one of18 targets lights exactly its own center.
 for(key_number=0;key_number<18;key_number=key_number+1)begin
  target=18'd1<<key_number;
  for(n=0;n<18;n=n+1)pixel_at(center_x[n],center_y[n],n==key_number);
 end
 // Four-key C4/E4/G4/C5 chord, and black keys end above white key bottoms.
 target=18'h01015;
 pixel_at(8,55,1);pixel_at(30,55,1);pixel_at(52,55,1);pixel_at(85,55,1);
 pixel_at(14,32,0);pixel_at(14,47,1);pixel_at(19,55,0);
 target=0;physical=1;
 pixel_at(8,60,1);pixel_at(8,55,0);pixel_at(3,20,1);pixel_at(123,63,1);
 for(y=0;y<20;y=y+1)for(xx=0;xx<128;xx=xx+1)pixel_at(xx,y,0);
 target=18'h01015;physical=0;
 fd=$fopen("tmp/song_guide_20261028/guide_keyboard.hex","w");
 for(n=0;n<1024;n=n+1)begin page=n/128;x=n%128;#1;$fdisplay(fd,"%02x",pixels);end
 $fclose(fd);$display("PASS: all18 physical key targets, four-note chord,11 long/7 short proportional keys, actual-key marker and reserved title rows");$finish;
end
endmodule
