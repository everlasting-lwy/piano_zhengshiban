`timescale 1ns/1ps
module tb_ensemble36;
 reg clk=0;always #10 clk=~clk;
 reg [17:0] key_in=18'h3ffff;
 reg down=1,up=1;
 top_piano_acg525 #(.BT_UART_CYCLES(16),.BT_MS_CYCLES(50000)) dut(
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(1'b1),.key_in(key_in),.key_timbre(1'b1),.key_mode(1'b1),
 .key_vol_up(up),.key_vol_down(down),.key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0));
 defparam dut.u_core.u_key.DEBOUNCE_CYCLES=8;
 reg [7:0] input_data=0;reg input_valid=0;
 initial begin force dut.u_core.rx_data=input_data;force dut.u_core.rx_valid=input_valid;end
 task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
 function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
 c=0;for(i=0;i<8;i=i+1)begin c=c^b[i*8+:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;end endfunction
 task byte_in;input [7:0] value;begin input_data=value;input_valid=1;clocks(1);input_valid=0;clocks(1);end endtask
 task request;input [7:0] op;input [47:0] p;integer k;begin
 byte_in(8'ha5);byte_in(8'h5a);byte_in(8'h01);byte_in(op);for(k=0;k<6;k=k+1)byte_in(p[k*8+:8]);
 byte_in(crc8({p,op,8'h01}));byte_in(8'h0d);clocks(100);end endtask
 integer i,o,s;reg found;reg [31:0] increment[0:11];reg [31:0] expected;
 task expect_pitch;input integer pitch;begin
 found=0;expected=increment[(pitch-48)%12];
 if(pitch<60)expected=expected>>1;else if(pitch>=84)expected=expected<<2;else if(pitch>=72)expected=expected<<1;
 if(dut.u_core.v_gate[0] && dut.u_core.G_VOICE[0].u_voice.carrier_increment==expected)found=1;
 if(dut.u_core.v_gate[1] && dut.u_core.G_VOICE[1].u_voice.carrier_increment==expected)found=1;
 if(dut.u_core.v_gate[2] && dut.u_core.G_VOICE[2].u_voice.carrier_increment==expected)found=1;
 if(dut.u_core.v_gate[3] && dut.u_core.G_VOICE[3].u_voice.carrier_increment==expected)found=1;
 if(!found)$fatal(1,"Absolute phone/physical pitch %0d missing, gate=%h expected=%0d",pitch,dut.u_core.v_gate,expected);
 end endtask
 initial begin
 increment[0]=23012828;increment[1]=24381242;increment[2]=25831026;increment[3]=27367019;
 increment[4]=28994347;increment[5]=30718440;increment[6]=32545054;increment[7]=34480283;
 increment[8]=36530588;increment[9]=38702809;increment[10]=41004198;increment[11]=43442435;
 clocks(100);
 request(9,1);expect_pitch(48);
 for(o=0;o<3;o=o+1)begin
 request(3,o);
 for(i=0;i<36;i=i+1)begin request(9,48'd1<<i);expect_pitch(48+i);request(9,0);
 if(dut.u_core.v_gate!==0)$fatal(1,"Phone key stuck after release %0d",i);
 if(dut.u_core.disp_octave!==((o==1)?4'd5:(o==2)?4'd3:4'd4))$fatal(1,"Idle extended octave must show selected physical octave, got %h",dut.u_core.disp_octave);end
 end
 // Physical C4 and phone C4 share one allocation until BOTH sources release.
 request(3,0);request(9,48'd1<<12);key_in=18'h3fffe;clocks(100);expect_pitch(60);
 if($countones(dut.u_core.v_gate)!==1)$fatal(1,"Same pitch duplicated across sources");
 request(5,0);expect_pitch(60);key_in=18'h3ffff;clocks(100);
 if(dut.u_core.v_gate!==0)$fatal(1,"Dual source final release stuck");
 // F5 physical goes to F6 at octave-up, outside the phone36 displayed mask.
 request(3,1);key_in=18'h1ffff;clocks(100);expect_pitch(89);
 key_in=18'h3ffff;clocks(100);
 request(9,48'h00000000000f);if(dut.u_core.v_gate!==15)$fatal(1,"Four phone voices missing");
 request(9,48'h00000000001f);if(dut.u_core.v_gate!==15)$fatal(1,"Fifth key stealing failed");
 request(4,1);expect_pitch(72);request(5,0);
 if(dut.u_core.v_gate!==0)$fatal(1,"Legacy transition left extended gates");
 // Unused physical volume pins are disabled at the board boundary by default.
 request(2,6);down=0;clocks(8);force dut.u_core.key2_cnt=20'd500000;clocks(4);release dut.u_core.key2_cnt;clocks(100);
 if(dut.u_core.vol!==6)$fatal(1,"Disabled physical volume pins changed selected volume");
 $display("PASS: 36 absolute pitches across all physical octaves, source OR/release, F6, four voices, transition and default-disabled volume pins");$finish;
 end
 initial begin #30000000;$fatal(1,"ensemble timeout");end
endmodule
