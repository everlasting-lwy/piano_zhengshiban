`timescale 1ns/1ps
module tb_bt_ram_only;
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0,rx_valid=0;reg [7:0] rx_data=0;
    reg [17:0] physical=0;wire [11:0] remote;
    wire [35:0] remote36;wire extended_mode,tx;
    wire guide_request,guide_response_valid;
    wire [7:0] guide_request_command,guide_response_command;
    wire [47:0] guide_request_payload,guide_response_payload;
    wire active,loaded,loading,complete,wrong;
    wire [17:0] target;wire [11:0] step,total_steps;
    wire volume_en;wire [3:0] new_volume;
    reg [3:0] volume=8;integer forwarded=0;
    localparam BIT=8;
    bt_link #(.UART_CYCLES(BIT),.MS_CYCLES(50),.WATCHDOG_MS(4000),.RX_TIMEOUT_CYCLES(64)) dut(
        .clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
        .timbre(2'd0),.octave(2'd0),.mode(2'd2),.volume(volume),.voices(4'd1),
        .keys(physical[11:0]|remote),.extended_keys({18'd0,physical}|remote36),
        .remote_keys(remote),.remote_extended_keys(remote36),.extended_mode(extended_mode),
        .set_volume(new_volume),.volume_en(volume_en),.tx(tx),.effects_status(48'd0),
        .visual_ready(1'b0),.visual_command(8'd0),.visual_tx_sequence(8'd0),.visual_payload(48'd0),
        .guide_request(guide_request),.guide_request_command(guide_request_command),
        .guide_request_payload(guide_request_payload),.guide_response_valid(guide_response_valid),
        .guide_response_command(guide_response_command),.guide_response_payload(guide_response_payload));
    song_guide guide(.clk(clk),.rst_n(rst_n),.request_valid(guide_request),
        .request_command(guide_request_command),.request_payload(guide_request_payload),
        .response_valid(guide_response_valid),.response_command(guide_response_command),
        .response_payload(guide_response_payload),.local_toggle(1'b0),.local_restart(1'b0),
        .physical_keys(physical),.target(target),.active(active),.loaded(loaded),.loading(loading),
        .complete(complete),.wrong(wrong),.step(step),.total_steps(total_steps));
    always @(posedge clk)begin
        if(volume_en)volume<=new_volume;
        if(guide_request)forwarded=forwarded+1;
    end
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
        c=0;for(i=0;i<8;i=i+1)begin c=c^b[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;
    end endfunction
    function [15:0] crcbyte;input [15:0] c0;input [7:0] b;integer j;reg[15:0]c;begin
        c=c0^{b,8'd0};for(j=0;j<8;j=j+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;
    end endfunction
    function [15:0] crcmask;input[15:0]c;input[17:0]m;begin crcmask=crcbyte(crcbyte(crcbyte(c,m[7:0]),m[15:8]),{6'd0,m[17:16]});end endfunction
    task byte_in;input [7:0] b;begin rx_data=b;rx_valid=1;clocks(1);rx_valid=0;clocks(1);end endtask
    task request;input[7:0]seq,op;input[47:0]p;input bad;integer k;begin
        byte_in(8'ha5);byte_in(8'h5a);byte_in(seq);byte_in(op);
        for(k=0;k<6;k=k+1)byte_in(p[k*8+:8]);byte_in(crc8({p,op,seq})^{7'd0,bad});byte_in(8'h0d);clocks(8);
    end endtask
    reg [95:0] packets[0:255],partial=0;reg[7:0]wire_byte;
    integer count=0,index=0,j;
    initial forever begin
        @(negedge tx);clocks(BIT+BIT/2);
        for(j=0;j<8;j=j+1)begin wire_byte[j]=tx;clocks(BIT);end
        if(tx!==1)$fatal(1,"Guide UART stop bit");
        partial[index*8+:8]=wire_byte;
        if(index==11)begin
            if(partial[15:0]!==16'h5aa5 || partial[95:88]!==8'h0d || partial[87:80]!==crc8(partial[79:16]))
                $fatal(1,"Guide UART frame CRC/atomicity %h",partial);
            packets[count]=partial;count=count+1;partial=0;index=0;
        end else index=index+1;
    end
    reg[47:0]response;integer response_index;integer reply_start=0;
    task reply;input[7:0]seq,op;integer t,k;reg found;begin
        t=0;found=0;
        while(!found && t<60000)begin
            for(k=reply_start;k<count;k=k+1)if(packets[k][23:16]==seq && packets[k][31:24]==op)begin
                response=packets[k][79:32];response_index=k;found=1;
            end
            if(!found)begin clocks(50);t=t+50;end
        end
        if(!found)$fatal(1,"Missing guide response seq=%h op=%h",seq,op);
    end endtask
    task ack;input[7:0]seq,op;input[47:0]p;input[7:0]code;begin
        reply_start=count;request(seq,op,p,0);reply(seq,8'h80);reply_start=0;
        if(response!=={24'd0,8'd1,code,op})$fatal(1,"Guide ACK layout/sequence seq=%h payload=%h",seq,response);
    end endtask
    task reject_removed;integer op,before_forwarded;begin
    before_forwarded=forwarded;
    for(op='h16;op<='h1b;op=op+1)ack(op[7:0],op[7:0],0,2);
    for(op='h20;op<='h26;op=op+1)ack(op[7:0],op[7:0],48'hffffffffffff,2);
    ack(8'h28,8'h28,0,2);
    if(forwarded!=before_forwarded)$fatal(1,"Removed storage opcode reached RAM guide");
end endtask
reg [15:0] song_crc;integer i,start_count,guide_index,event_index;
    initial begin
        clocks(8);rst_n=1;clocks(8);
        request(8'h61,8'h0f,0,0);reply(8'h61,8'h88);
        if(response!==48'h041208000147 || forwarded!=1)$fatal(1,"Capability not forwarded exactly once");
        reject_removed();
        song_crc=crcmask(crcmask(16'hffff,18'h1),18'h20000);
        ack(8'h62,8'h10,{8'd0,8'd1,song_crc,16'd2},0);
        ack(8'h63,8'h11,{8'd0,24'h1,16'd0},0);
        ack(8'h64,8'h11,{8'd0,24'h1,16'd0},0);
        ack(8'h65,8'h11,{8'd0,24'h20000,16'd1},0);
        ack(8'h66,8'h12,0,0);ack(8'h67,8'h12,0,0);
        ack(8'h68,8'h13,1,0);
        reject_removed();
        if(!loaded || !active || target!==1 || step!==0 || total_steps!==2)$fatal(1,"Removed traffic altered published guide");
        ack(8'h69,8'h04,1,0);clocks(20);
        if(step!==0 || target!==1)$fatal(1,"Phone key falsely advanced physical guide");
        physical=1;clocks(8);if(step!==1 || target!==18'h20000)$fatal(1,"Physical key did not advance");
        request(8'h6a,8'h15,0,0);reply(8'h6a,8'h8a);
        if(response!==48'h000001020000)$fatal(1,"Actual physical target payload %h",response);
        request(8'h6b,8'h14,0,0);reply(8'h6b,8'h89);
        if(response!==48'h010300020001)$fatal(1,"Actual guide state payload %h",response);
        // A second old-control request while a guide reply is transmitting keeps its own sequence.
        request(8'h70,8'h14,0,0);request(8'h71,8'h02,11,0);
        reply(8'h70,8'h89);reply(8'h71,8'h80);
        if(volume!==11 || response[23:0]!==24'h010002)$fatal(1,"Guide serializer harmed old setter");
        // A guide reply queued during an event frame takes precedence over the remaining event FIFO.
        physical=0;clocks(2000);start_count=count;
        for(i=0;i<8;i=i+1)begin physical=physical^18'h2;clocks(2);end
        request(8'h72,8'h14,0,0);reply(8'h72,8'h89);guide_index=response_index;
        clocks(12000);event_index=-1;
        for(i=start_count;i<count;i=i+1)if(packets[i][31:24]==8'h82 && i>guide_index)event_index=i;
        if(guide_index>start_count+1 || event_index<0)$fatal(1,"Guide reply lost priority or destroyed queued events");
        ack(8'h73,8'h13,3,0);ack(8'h74,8'h13,3,0);
        if(loaded || !active)$fatal(1,"Wire DELETE did not preserve NO SONG view");
        ack(8'h75,8'h10,48'h000100000000,1);
        ack(8'h76,8'h11,{8'd0,24'd1,16'd0},3);
        ack(8'h77,8'h14,1,1);
        i=forwarded;request(8'h78,8'h13,1,1);clocks(2000);
        if(forwarded!=i)$fatal(1,"CRC-bad guide request reached engine");
        ack(8'h79,8'h02,7,0);if(volume!==7)$fatal(1,"Old controls failed after guide traffic");
        $display("PASS: all 14 removed storage opcodes reject without guide forwarding; RAM capability/upload/retry/commit/delete, physical stepping, setters and event priority preserved");$finish;
    end
    initial begin #10000000;$fatal(1,"Bluetooth song guide timeout");end
endmodule
