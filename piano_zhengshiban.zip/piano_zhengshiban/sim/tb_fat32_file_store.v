`timescale 1ns/1ps
module tb_fat32_file_store #(parameter ROOT_LIMIT=4096,IO_LIMIT=100000000);
reg clk=0;always #5 clk=~clk;
reg rst_n=0,media_ready=1,request=0;reg[31:0]media_sectors;reg[7:0]media_error=0;reg[1:0]operation=0;reg[4:0]slot=3;reg[15:0]write_size=1114;
wire mounted,busy,done;wire[7:0]error;wire[15:0]file_size;wire[31:0]present_slots;
wire[7:0]file_attributes;wire write_locked;
wire read_valid;wire[15:0]read_index;wire[7:0]read_data;reg read_ready=0;
wire source_request;wire[15:0]source_index;reg source_valid=0;reg[7:0]source_data=0;
wire block_start,block_write;wire[31:0]block_lba;reg block_busy=0,block_done=0;reg[7:0]block_error=0;
reg rd_valid=0;reg[8:0]rd_index=0;reg[7:0]rd_data=0;reg wr_request=0;reg[8:0]wr_index=0;wire wr_valid;wire[7:0]wr_data;
fat32_file_store #(.ROOT_SECTOR_LIMIT(ROOT_LIMIT),.IO_TIMEOUT_CYCLES(IO_LIMIT)) dut(.*);
reg[7:0]sector[0:511],source[0:6207],old_song[0:723];integer fd,mode=0,pos=0,n,seek_result,writes=0,cycles=0,read_count=0,source_delay=0;
reg[4095:0]image_name,source_name,old_name;reg[255:0]case_name;reg[31:0]pending_lba;reg pending_write,fail_once=0;integer old_size=724;
always @(posedge clk) begin
 cycles<=cycles+1;block_done<=0;rd_valid<=0;
 if(cycles>45000000)$fatal(1,"global timeout state=%0d",dut.state);
 if(block_start)begin
  if(block_busy)$fatal(1,"overlapping block request");
  if(block_lba>=media_sectors)$fatal(1,"out of card access lba=%0d",block_lba);
  block_busy<=1;block_error<=0;pending_lba<=block_lba;pending_write<=block_write;pos<=0;mode<=1;
 end else if(mode==1)begin
  if(!pending_write)begin
   seek_result=$fseek(fd,pending_lba*512,0);n=$fread(sector,fd);if(n!=512)$fatal(1,"short image read");mode<=2;
  end else begin writes<=writes+1;wr_index<=0;wr_request<=1;mode<=3;end
 end else if(mode==2)begin
  rd_valid<=1;rd_index<=pos;rd_data<=sector[pos];
  if(pos==511)begin mode<=4;end else pos<=pos+1;
 end else if(mode==3)begin
  if(wr_valid&&wr_request)begin
   sector[pos]<=wr_data;wr_request<=0;mode<=5;
  end
 end else if(mode==5)begin
  if(pos==511)begin
   seek_result=$fseek(fd,pending_lba*512,0);for(n=0;n<512;n=n+1)$fwrite(fd,"%c",sector[n]);$fflush(fd);mode<=4;
  end else begin pos<=pos+1;wr_index<=pos+1;wr_request<=1;mode<=3;end
 end else if(mode==4)begin
  block_busy<=0;block_done<=1;mode<=0;
  if(!fail_once && ((case_name=="read_io"&&!pending_write&&operation==1)||(case_name=="data_io"&&pending_write&&writes==12)||(case_name=="meta_io"&&pending_write&&writes==1)||(case_name=="publish_io"&&pending_write&&writes==15)))begin block_error<=8'h42;fail_once<=1;end
 end
 if(mode==2&&case_name=="verify_io"&&!fail_once&&operation==2&&writes==12&&pos==100)begin rd_data<=sector[pos]^8'h01;fail_once<=1;end
 // Delayed random-access source; a changed index must never reuse previous valid.
 source_valid<=0;
 if(source_request)begin
  if(source_delay==3)begin source_valid<=1;source_data<=source[source_index];source_delay<=0;end
  else source_delay<=source_delay+1;
 end else source_delay<=0;
 read_ready<=(cycles%5)!=0;
 if(read_valid&&read_ready)begin
  if(read_index!=read_count)$fatal(1,"read stream skipped/duplicated index got%0d expected%0d",read_index,read_count);
  if(read_data!==(old_size==724?old_song[read_count]:source[read_count]))$fatal(1,"wrong file byte %0d got%h",read_count,read_data);
  read_count<=read_count+1;
 end
end
task cmd(input[1:0]op);integer budget;begin
 @(negedge clk);operation=op;request=1;@(negedge clk);request=0;budget=0;
 while(!done)begin @(negedge clk);budget=budget+1;if(budget>44000000)$fatal(1,"command timeout op%0d state%0d",op,dut.state);end
 @(negedge clk);
end endtask
task success;begin if(error!=0)$fatal(1,"unexpected error%0d op%0d state%0d",error,operation,dut.state);end endtask
integer before_writes;
initial begin
 if(!$value$plusargs("IMAGE=%s",image_name))$fatal;
 if(!$value$plusargs("CASE=%s",case_name))$fatal;
 if(!$value$plusargs("SECTORS=%d",media_sectors))$fatal;
 if(!$value$plusargs("SIZE=%d",write_size))$fatal;
 if(!$value$plusargs("SOURCE=%s",source_name))$fatal;
 if(!$value$plusargs("OLD=%s",old_name))$fatal;
 $readmemh(source_name,source,0,write_size-1);$readmemh(old_name,old_song);fd=$fopen(image_name,"r+b");if(!fd)$fatal(1,"cannot open image");
 repeat(5)@(negedge clk);rst_n=1;if(case_name=="busy_stuck")block_busy=1;if(case_name=="no_media")media_ready=0;cmd(0);
 if(case_name=="bad_geometry"||case_name=="fat16"||case_name=="bad_version"||case_name=="bad_root"||case_name=="bad_spc"||case_name=="bad_fats"||case_name=="bad_root_entries"||case_name=="bad_tot16"||case_name=="bad_fat16"||case_name=="card_bounds"||case_name=="partition_volume_bounds"||case_name=="partition_extent_bounds"||case_name=="cyclic_root"||case_name=="root_bound"||case_name=="busy_stuck"||case_name=="no_media")begin
  if(!error||mounted||writes)$fatal(1,"bad volume accepted error%0d mounted%0d writes%0d",error,mounted,writes);
  if(case_name=="root_bound"&&error!=11)$fatal(1,"root bound not distinguished");if(case_name=="busy_stuck"&&error!=16)$fatal(1,"busy timeout not distinguished");
 end else if(case_name=="bad_header"||case_name=="bad_payload"||case_name=="bad_mask"||case_name=="bad_length"||case_name=="directory"||case_name=="cyclic_file"||case_name=="range_file")begin
  if(present_slots[3])$fatal(1,"invalid managed file listed");before_writes=writes;cmd(2);if(!error||writes!=before_writes)$fatal(1,"invalid same-name file overwritten");
 end else if(case_name=="end_self"||case_name=="end_back"||case_name=="end_tail_loop"||case_name=="end_tail_back")begin
  success();cmd(2);if(error!=5||writes!=0)$fatal(1,"end-marker root loop was mutated error%0d writes%0d",error,writes);
 end else if(case_name=="readonly"||case_name=="temp"||case_name=="dirty"||case_name=="dir_full")begin
  success();before_writes=writes;cmd(2);if(!error||writes!=before_writes)$fatal(1,"protected volume/file written");
 end else if(case_name=="full"||case_name=="bound")begin
  success();cmd(2);if(error!=(case_name=="full"?8'd10:8'd11))$fatal(1,"full/bound conflated got%0d",error);
 end else if(case_name=="read_io")begin
  success();cmd(1);if(!error)$fatal(1,"read I/O failure hidden");
  media_error=8'h42;cmd(0);success();read_count=0;cmd(1);success();if(read_count!=724)$fatal(1,"stale media error prevented read recovery");
 end else if(case_name=="data_io"||case_name=="meta_io"||case_name=="verify_io"||case_name=="publish_io"||case_name=="bad_source")begin
  success();cmd(2);if(!error||(!fail_once&&case_name!="bad_source"))$fatal(1,"write I/O failure hidden writes%0d",writes);if(case_name=="verify_io"&&error!=13)$fatal(1,"readback mismatch not detected");if(case_name=="bad_source"&&error!=7)$fatal(1,"invalid source published");before_writes=writes;cmd(2);if(!error||writes!=before_writes)$fatal(1,"metadata uncertainty did not lock writes");
  media_error=8'h42;@(negedge clk);rst_n=0;repeat(4)@(negedge clk);rst_n=1;cmd(0);success();cmd(2);if(error!=14||writes!=before_writes)$fatal(1,"reboot/rescan cleared interrupted metadata lock");
 end else begin
  success();if(!mounted||present_slots!=8)$fatal(1,"managed scan wrong present%h",present_slots);
  read_count=0;cmd(1);success();if(file_size!=724||read_count!=724)$fatal(1,"read size/count mismatch");
  if(case_name=="create")slot=4;
  cmd(2);success();
  // Reboot must discover an ordinary published P18 file without internal state.
  @(negedge clk);rst_n=0;repeat(4)@(negedge clk);rst_n=1;cmd(0);success();if(!present_slots[slot])$fatal(1,"save not persistent");
  old_size=write_size;read_count=0;cmd(1);success();if(read_count!=write_size)$fatal(1,"new read length");
  if(case_name!="saveonly")begin cmd(3);success();cmd(0);success();if(present_slots[slot])$fatal(1,"delete not persistent");end
 end
 $fclose(fd);$display("PASS FAT32 %0s writes=%0d cycles=%0d",case_name,writes,cycles);$finish;
end
endmodule
