`timescale 1ns/1ps
// Host emulates a small ordinary FAT32 transaction through the real sectorRPC.
// Full allocation/overwrite/failure semantics are tested by Fat32Store's suite.
module tb_sd_phone_library;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_req_valid=0;reg[7:0]bt_req_command=0;reg[47:0]bt_req_payload=0;
wire bt_rsp_valid;wire[7:0]bt_rsp_command;wire[47:0]bt_rsp_payload;
reg[47:0]reply;
wire g_req_valid,g_rsp_valid;wire[7:0]g_req_command,g_rsp_command;wire[47:0]g_req_payload,g_rsp_payload;
wire guide_loaded,guide_loading,guide_active;wire[11:0]guide_total_steps;
reg[17:0]physical_keys=0;reg local_next=0,local_prev=0,local_toggle=0;
wire sd_busy,selected_valid;wire[4:0]selected_slot;wire[7:0]sd_error;
wire sd_cs_n,sd_clk,sd_mosi,sd_miso;
wire[17:0]target;wire complete,wrong;wire[11:0]step;
sd_song_library #(.INIT_DIV(2),.DATA_DIV(1),.POWERUP_CYCLES(8),.INIT_TIMEOUT_CYCLES(1000000)) dut(.*);
song_guide guide(.clk(clk),.rst_n(rst_n),.request_valid(g_req_valid),.request_command(g_req_command),.request_payload(g_req_payload),
 .response_valid(g_rsp_valid),.response_command(g_rsp_command),.response_payload(g_rsp_payload),
 .local_toggle(local_toggle),.local_restart(1'b0),.physical_keys(physical_keys),.target(target),.active(guide_active),
 .loaded(guide_loaded),.loading(guide_loading),.complete(complete),.wrong(wrong),.step(step),.total_steps(guide_total_steps));
sd_spi_image_model card(.cs_n(sd_cs_n),.sclk(sd_clk),.mosi(sd_mosi),.miso(sd_miso),.kind(2'd0),.csd_variant(3'd0),
 .absent(1'b0),.bad_crc(1'b0),.reject_write(1'b0),.stuck_busy(1'b0),.no_token(1'b0),.bad_r7(1'b0),.bad_ocr(1'b0),.bad_csd(1'b0),.init_stuck(1'b0),.status_error(1'b0));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task req;input[7:0]c;input[47:0]p;input[7:0]r;integer n;begin
 bt_req_command=c;bt_req_payload=p;bt_req_valid=1;clocks(1);bt_req_valid=0;n=0;
 while(!bt_rsp_valid&&n<10)begin clocks(1);n=n+1;end
 if(!bt_rsp_valid||bt_rsp_command!==r)$fatal(1,"cmd%h latency%d rsp%h payload%h",c,n,bt_rsp_command,bt_rsp_payload);
 reply=bt_rsp_payload;clocks(2);
end endtask
task ack;input[7:0]c;input[47:0]p;begin req(c,p,8'h80);if(reply[15:8]!=0||reply[7:0]!=c)$fatal(1,"ACK cmd%h code%h",c,reply);end endtask
task idle;integer n;begin n=0;while(sd_busy&&n<3000000)begin clocks(100);n=n+100;end
 if(sd_busy||sd_error!=0)$fatal(1,"file operation error%d state%d/%d",sd_error,dut.u_bridge.state,dut.u_files.state);clocks(10);
end endtask
task coldboot;integer n;begin
 n=0;while((!guide_loaded||sd_busy)&&n<3000000)begin clocks(100);n=n+100;end
 idle();if(!guide_loaded||guide_total_steps!=220||selected_slot!=3)$fatal(1,"coldboot independent FAT reader");
end endtask
task rpc_done;integer n;begin n=0;while(dut.u_rpc.state!=0&&n<50000)begin clocks(1);n=n+1;end
 if(dut.u_rpc.state!=0||dut.u_rpc.operation_error!=0||dut.rpc_uncertain)$fatal(1,"RPC error%d state%d",dut.u_rpc.operation_error,dut.u_rpc.state);clocks(3);
end endtask
reg[7:0]cache[0:511],song[0:69];reg[1023:0]song_path;reg[15:0]id=0;
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer i;reg[15:0]c;begin c=old^{v,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
task read_sector;input[31:0]lba;integer k;begin
 id=id+1;ack(8'h21,{id,lba});rpc_done();
 for(k=0;k<512;k=k+4)begin req(8'h25,k,8'h91);if(reply[15:0]!=k)$fatal(1,"cached offset");
 cache[k]=reply[23:16];cache[k+1]=reply[31:24];cache[k+2]=reply[39:32];cache[k+3]=reply[47:40];end
end endtask
task write_sector;input[31:0]lba;integer k;reg[15:0]crc;begin
 id=id+1;ack(8'h24,id);crc=16'hffff;
 for(k=0;k<512;k=k+4)begin ack(8'h22,{cache[k+3],cache[k+2],cache[k+1],cache[k],k[15:0]});end
 for(k=0;k<512;k=k+1)crc=crcbyte(crc,cache[k]);ack(8'h23,{crc,lba});rpc_done();
end endtask
localparam FAT0=32,FAT1=544,DATA=1056;
integer j,f,oldwrites;
task dirty;input integer clean;begin
 for(f=0;f<2;f=f+1)begin read_sector(f?FAT1:FAT0);cache[7]=clean?(cache[7]|8'h08):(cache[7]&8'hf7);write_sector(f?FAT1:FAT0);end
end endtask
always @(posedge clk)if(rst_n&&dut.block_start&&dut.block_write&&!dut.rpc_active)$fatal(1,"file reader attempted write");
initial begin
 if(!$value$plusargs("SONG=%s",song_path))$fatal(1,"missing SONG");$readmemh(song_path,song);
 clocks(10);rst_n=1;clocks(100);coldboot();
 req(8'h16,0,8'h8b);if(reply[7:0]!=2)$fatal(1,"capability2");
 req(8'h17,{32'd1,8'd4,8'd1},8'h80);if(reply[15:8]!=2)$fatal(1,"firmware write path exposed");
 ack(8'h20,{8'd0,32'h12345678,8'd0});dirty(0);
 // Invalidate primary and backup FSInfo hints.
 read_sector(1);for(j=488;j<496;j=j+1)cache[j]=8'hff;write_sector(1);
 read_sector(7);for(j=488;j<496;j=j+1)cache[j]=8'hff;write_sector(7);
 // Fresh cluster3; preserve both FAT copies' upper reserved nibbles.
 for(f=0;f<2;f=f+1)begin read_sector(f?FAT1:FAT0);cache[12]=255;cache[13]=255;cache[14]=255;cache[15]=(cache[15]&8'hf0)|8'h0f;write_sector(f?FAT1:FAT0);end
 read_sector(DATA);for(j=32;j<64;j=j+1)cache[j]=0;
 cache[32]="T";for(j=33;j<39;j=j+1)cache[j]="0";cache[39]="4";cache[40]="P";cache[41]="1";cache[42]="8";
 cache[43]=8'h20;cache[58]=3;cache[60]=70;write_sector(DATA);
 for(j=0;j<512;j=j+1)cache[j]=j<70?song[j]:0;write_sector(DATA+1);
 read_sector(DATA);cache[32]="P";write_sector(DATA);dirty(1);
 ack(8'h20,{8'd0,32'h12345678,8'd1});ack(8'h17,{32'h11111111,8'hff,8'd0});idle();
 req(8'h19,4,8'h8c);if(reply[39:8]!==32'h03000201)$fatal(1,"phone file catalog%h",reply);
 if($test$plusargs("SAVEONLY"))begin $display("PASS: phone sector transaction created independently readable FAT32 P18 through real SPI/RPC");$finish;end
 rst_n=0;clocks(10);rst_n=1;clocks(100);coldboot();
 local_toggle=1;clocks(1);local_toggle=0;clocks(5);local_next=1;clocks(1);local_next=0;clocks(20);idle();
 if(selected_slot!=4||guide_total_steps!=2||target!=1)$fatal(1,"offline encoder-selected file");
 physical_keys=1;clocks(6);if(step!=1||target!=18'h20000)$fatal(1,"physical progress after SD load");
 physical_keys=0;clocks(5);physical_keys=18'h20000;clocks(5);if(!complete)$fatal(1,"last physical key");physical_keys=0;clocks(5);
 ack(8'h20,{8'd0,32'h87654321,8'd0});dirty(0);
 read_sector(DATA);cache[32]=8'he5;write_sector(DATA);
 for(f=0;f<2;f=f+1)begin read_sector(f?FAT1:FAT0);cache[12]=0;cache[13]=0;cache[14]=0;cache[15]=cache[15]&8'hf0;write_sector(f?FAT1:FAT0);end
 dirty(1);ack(8'h20,{8'd0,32'h87654321,8'd1});ack(8'h17,{32'h22222222,8'hff,8'd0});idle();
 req(8'h19,4,8'h8c);if(reply[15:8]!=0)$fatal(1,"deleted file still listed");
 req(8'h19,3,8'h8c);if(!reply[8])$fatal(1,"other file lost");
 if(card.errors!=0)$fatal(1,"SPI protocol error%d",card.errors);
 $display("PASS: real SPI/RPC phone-style FAT32 create/readback/rescan, autonomous coldboot, encoder selection, physical guidance and delete (%d reads/%d writes)",card.reads,card.writes);$finish;
end
initial begin#1200000000;$fatal(1,"phone-library timeout bridge%d file%d rpc%d",dut.u_bridge.state,dut.u_files.state,dut.u_rpc.state);end
endmodule
