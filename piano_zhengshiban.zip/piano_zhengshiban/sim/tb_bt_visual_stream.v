`timescale 1ns/1ps
// Contract tests use the production capture RAM and independently generated PCM.
module tb_bt_visual_stream;
reg clk=0; always #10 clk=~clk;
reg rst_n=0,clear=0,sample_valid=0,request_start=0,spectrum_valid=0,tx_take=0;
reg signed [15:0] sample=0;
reg [2:0] request_kind=0;
reg [7:0] request_sequence=0;
reg [31:0] device_millis=0;
reg [255:0] spectrum_bars=0;
reg [17:0] physical_keys=0;
reg [4:0] guide_step=0;
reg [1:0] guide_mode=0;
reg guide_wrong=0;
wire tx_ready;
wire [7:0] tx_command,tx_sequence;
wire [47:0] tx_payload;
integer c,b,p,want,checks=0;
bt_visual_stream #(.MS_CYCLES(5)) d(
 .clk(clk),.rst_n(rst_n),.clear(clear),.sample_valid(sample_valid),.sample(sample),
 .request_start(request_start),.request_kind(request_kind),.request_sequence(request_sequence),
 .device_millis(device_millis),.spectrum_bars(spectrum_bars),.spectrum_valid(spectrum_valid),
 .physical_keys(physical_keys),.guide_step(guide_step),.guide_mode(guide_mode),.guide_wrong(guide_wrong),
 .tx_ready(tx_ready),.tx_command(tx_command),.tx_sequence(tx_sequence),.tx_payload(tx_payload),.tx_take(tx_take));
task clocks; input integer n; begin repeat(n) @(negedge clk); end endtask
task ask; input [2:0] kind; input [7:0] seq; begin
 request_kind=kind;request_sequence=seq;request_start=1;clocks(1);request_start=0;clocks(2);
end endtask
task wait_ready; integer timeout; begin
 timeout=0;
 while(!tx_ready && timeout<3000)begin clocks(1);timeout=timeout+1;end
 if(!tx_ready)$fatal(1,"Timed out waiting for visual packet (kind=%0d seq=%0h)",request_kind,request_sequence);
end endtask
task quiet; input integer n; integer q; begin
 for(q=0;q<n;q=q+1)begin clocks(1);if(tx_ready)$fatal(1,"Unsolicited/stale visual packet");end
end endtask
task packet;input [7:0] cmd;input [7:0] seq;input [47:0] data;
 reg [63:0] held;integer q; begin
 wait_ready;
 if(tx_command!==cmd || tx_sequence!==seq || tx_payload!==data)
  $fatal(1,"Packet mismatch cmd=%h seq=%h payload=%h expected %h/%h/%h",tx_command,tx_sequence,tx_payload,cmd,seq,data);
 held={tx_command,tx_sequence,tx_payload};
 for(q=0;q<7;q=q+1)begin
  clocks(1);if(!tx_ready || {tx_command,tx_sequence,tx_payload}!==held)$fatal(1,"Packet changed under backpressure");
 end
 checks=checks+1;
end endtask
task take;begin tx_take=1;clocks(1);tx_take=0;clocks(1);end endtask
task meta;input [7:0]kind;input[7:0]seq;input[7:0]count;input[31:0]stamp;begin
 packet(8'h86,seq,{stamp,count,kind});take;
end endtask
task feed;input integer offset;input integer count;integer n;begin
 for(n=0;n<count;n=n+1)begin
  sample=(((n+offset)%256)-128)*256;sample_valid=1;clocks(1);sample_valid=0;clocks(3);
 end
end endtask
task check_pcm;input integer kind;input [7:0]seq;input integer offset;
 reg [31:0] data;integer n,j,point,expected;begin
 for(n=0;n<(kind==1?16:32);n=n+1)begin
  data=0;
  for(j=0;j<4;j=j+1)begin
   point=kind==1 ? n*4+j : n*2+j/2;
   if(kind==3 && j%2==1)expected=point<16 ? 128 : (point*4+offset+192)%256;
   else expected=(point*4+offset)%256;
   data[j*8+:8]=expected;
  end
  packet(8'h87,seq,{data,n[7:0],kind[7:0]});take;
 end
 quiet(20);
end endtask
initial begin
 clocks(3);rst_n=1;clocks(3);quiet(12);
 // Guide metadata/chunk are atomic, correctly packed and consumed once.
 device_millis=32'h12345678;physical_keys=18'h2a55a;guide_step=17;guide_mode=2;guide_wrong=1;
 ask(4,8'h31);
 physical_keys=0;guide_step=0;guide_mode=0;guide_wrong=0;device_millis=32'h87654321;
 meta(4,8'h31,1,32'h12345678);
 packet(8'h87,8'h31,48'h111aa55a0004);take;quiet(20);
 // A request waits for the next DFT pulse, then freezes all 32 bar values.
 device_millis=32'h01020304;spectrum_bars={256{1'b1}};spectrum_valid=1;
 request_kind=2;request_sequence=8'h42;request_start=1;clocks(1);
 request_start=0;spectrum_valid=0;clocks(2);quiet(20);
 for(b=0;b<32;b=b+1)spectrum_bars[b*8+:8]=b*7+3;
 device_millis=32'h10203040;spectrum_valid=1;clocks(1);spectrum_valid=0;clocks(2);
 spectrum_bars=0;device_millis=0;
 meta(2,8'h42,8,32'h10203040);
 for(c=0;c<8;c=c+1)begin
  packet(8'h87,8'h42,{8'(c*28+24),8'(c*28+17),8'(c*28+10),8'(c*28+3),c[7:0],8'd2});take;
 end
 quiet(20);
 // First capture starts with neutral lag and spans 64 decimated PCM points.
 device_millis=32'h11223344;ask(1,8'h51);feed(0,256);wait_ready;
 // More live PCM cannot overwrite the bank held for Bluetooth transmission.
 feed(37,256);feed(73,256);
 meta(1,8'h51,16,32'h11223344);check_pcm(1,8'h51,0);
 // XY interleaves current and exact 64-sample lag (the first 16 lag points neutral).
 device_millis=32'h55667788;ask(3,8'h52);feed(19,256);
 meta(3,8'h52,32,32'h55667788);feed(91,256);check_pcm(3,8'h52,19);
 // Clear while acquiring discards the partial frame and rearms after the clear edge.
 device_millis=32'h100;ask(1,8'h61);feed(5,96);
 clear=1;clocks(2);clear=0;device_millis=32'h200;clocks(3);quiet(10);feed(40,256);
 meta(1,8'h61,16,32'h200);check_pcm(1,8'h61,40);
 // Clear while sending must publish replacement metadata before any new chunks.
 device_millis=32'h300;ask(3,8'h62);feed(7,256);meta(3,8'h62,32,32'h300);wait_ready;
 clear=1;tx_take=1;clocks(1);clear=0;tx_take=0;device_millis=32'h400;clocks(3);quiet(10);
 feed(60,256);meta(3,8'h62,32,32'h400);check_pcm(3,8'h62,60);
 // Rapid return to the same PCM view cancels both previous capture requests.
 ask(1,8'h71);feed(10,24);ask(3,8'h72);feed(20,24);device_millis=32'h500;ask(1,8'h73);feed(80,256);
 meta(1,8'h73,16,32'h500);check_pcm(1,8'h73,80);
 // New request wins a coincident take, even when a chunk is already ready.
 device_millis=32'h600;physical_keys=18'h10001;guide_mode=1;guide_step=3;guide_wrong=0;
 ask(4,8'h81);meta(4,8'h81,1,32'h600);wait_ready;
 tx_take=1;ask(2,8'h82);tx_take=0;quiet(20);
 for(b=0;b<32;b=b+1)spectrum_bars[b*8+:8]=255-b;
 device_millis=32'h700;spectrum_valid=1;clocks(1);spectrum_valid=0;clocks(2);
 meta(2,8'h82,8,32'h700);wait_ready;
 // Kind zero cancels ready metadata/chunks and cannot produce an unsolicited repeat.
 tx_take=1;ask(0,8'h83);tx_take=0;quiet(50);feed(0,256);quiet(20);
 // Guide clear also refreshes the one atomic snapshot with the same sequence.
 device_millis=32'h800;physical_keys=18'h30000;guide_mode=2;guide_wrong=1;guide_step=16;
 ask(4,8'h91);wait_ready;
 clear=1;clocks(1);clear=0;device_millis=32'h900;physical_keys=18'h00003;guide_mode=1;guide_wrong=0;guide_step=2;
 clocks(3);meta(4,8'h91,1,32'h900);packet(8'h87,8'h91,48'h020400030004);take;quiet(20);
 $display("PASS: bt_visual_stream %0d packet checks; all kinds, RAM capture isolation, backpressure, clear, latest request and cancel",checks);$finish;
end
initial begin #10000000;$fatal(1,"Overall visual stream timeout");end
endmodule
