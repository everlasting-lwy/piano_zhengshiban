`timescale 1ns/1ps
module tb_bt_frame_rx;
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0,valid=0;
    reg [7:0] data=0;
    wire frame_valid,legacy_valid,error;
    wire [7:0] seq,cmd,legacy;
    wire [47:0] payload;
    bt_frame_rx #(.TIMEOUT_CYCLES(64)) dut(
        .clk(clk),.rst_n(rst_n),.rx_data(data),.rx_valid(valid),
        .frame_valid(frame_valid),.seq(seq),.command(cmd),.payload(payload),
        .legacy_valid(legacy_valid),.legacy_data(legacy),.frame_error(error));
    integer frames=0,legacies=0,errors=0;
    reg [7:0] got_seq,got_cmd;
    reg [47:0] got_payload;
    always @(negedge clk) begin
        if(frame_valid) begin frames=frames+1;got_seq=seq;got_cmd=cmd;got_payload=payload;end
        if(legacy_valid) legacies=legacies+1;
        if(error) errors=errors+1;
    end
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task byte_in;input [7:0] b;begin data=b;valid=1;clocks(1);valid=0;clocks(1);end endtask
    function [7:0] crc8;input [63:0] bytes;integer i,k;reg [7:0] c;begin
        c=0;
        for(i=0;i<8;i=i+1) begin
            c=c^bytes[i*8 +:8];
            for(k=0;k<8;k=k+1)c=c[7] ? (c<<1)^8'h07 : c<<1;
        end
        crc8=c;
    end endfunction
    task frame;input [7:0] n,op;input [47:0] p;input bad_crc,bad_end;integer i;reg [7:0] c;begin
        c=crc8({p,op,n});byte_in(8'hA5);byte_in(8'h5A);byte_in(n);byte_in(op);
        for(i=0;i<6;i=i+1)byte_in(p[i*8 +:8]);
        byte_in(c^{7'd0,bad_crc});byte_in(bad_end ? 8'h00 : 8'h0D);clocks(2);
    end endtask
    initial begin
        clocks(4);rst_n=1;clocks(4);
        byte_in(8'h02);byte_in(8'h41);byte_in(8'h86);
        frame(8'h11,8'h02,48'h000000000006,0,0);
        if(frames!=1 || got_seq!==8'h11 || got_cmd!==2 || got_payload!==6)
            $fatal(1,"Valid checked Bluetooth frame not delivered");
        if(legacies!=3) $fatal(1,"Legacy parameter compatibility");
        // Same independent frozen on-wire fixture as Android CoreTest, CRC=D0.
        byte_in(8'hA5);byte_in(8'h5A);byte_in(8'h07);byte_in(8'h04);
        byte_in(8'h81);byte_in(8'h08);byte_in(0);byte_in(0);byte_in(0);byte_in(0);
        byte_in(8'hD0);byte_in(8'h0D);clocks(2);
        if(frames!=2 || got_seq!==7 || got_payload!==48'h881)$fatal(1,"Android frozen wire fixture mismatch");
        frame(8'h02,8'h01,48'h000000004180,1,0);
        frame(8'h03,8'h01,48'h000000000002,0,1);
        if(frames!=2 || legacies!=3 || errors!=2) $fatal(1,"Bad CRC/end leaked a command");
        byte_in(8'hA5);byte_in(8'h5A);byte_in(8'h01);clocks(70);
        byte_in(8'h00);byte_in(8'h42);byte_in(8'h8F);
        if(frames!=2 || legacies!=3 || errors!=3) $fatal(1,"Timed-out payload leaked legacy commands");
        byte_in(8'hA5);
        frame(8'hA5,8'h04,48'h000000005AA5,0,0);
        if(frames!=3 || got_seq!==8'hA5 || got_payload!==48'h5AA5) $fatal(1,"Prefix/payload resynchronization");
        frame(8'hFF,8'h06,0,0,0);
        if(frames!=4 || got_cmd!==6) $fatal(1,"Recovery frame");
        $display("PASS: Bluetooth frame CRC/tail, timeout, legacy lock, binary payload and resynchronization");$finish;
    end
    initial begin #1000000;$fatal(1,"Bluetooth parser timeout");end
endmodule
