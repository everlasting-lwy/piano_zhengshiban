$ErrorActionPreference = 'Stop'
$tools = Join-Path $PSScriptRoot '../tools'
$sources = @((Join-Path $tools 'FpgaMidiSpeakers.cs'), (Join-Path $tools 'desktop/MidiMonitor.cs'), (Join-Path $tools 'desktop/MidiConnection.cs'))
Add-Type -Path $sources
$monitor = New-Object PianoDesktop.MidiMonitor
$parser = New-Object FpgaMidiSpeakers.MidiParser
function Accept([uint32]$message, [double]$ms) {
    $output = [FpgaMidiSpeakers.MidiDynamics]::ApplyVelocityGain($message, 1.25)
    $monitor.Accept($message, $output, $ms)
}
function Assert($condition, [string]$reason) { if (-not $condition) { throw $reason } }

$first = [byte[]](0x90, 60)
Assert (@($parser.Feed($first, 2)).Count -eq 0) 'Partial packets must not create notes'
$last = [byte[]](64)
foreach ($message in $parser.Feed($last, 1)) { Accept $message 10 }
$s = $monitor.Snapshot()
Assert ($s.ActiveCount -eq 1 -and $s.Active[60]) 'C4 must light after complete Note On'
Assert ($s.LastRawVelocity -eq 64 -and $s.LastOutputVelocity -eq 80) 'Show both velocities'
Accept 0x783C91 15
Accept 0x003C90 30
$s = $monitor.Snapshot()
Assert ($s.Active[60] -and $s.ActiveCount -eq 1) 'Channel 2 C4 must survive channel 1 zero-velocity release'
$events = $monitor.EventsAfter(0)
Assert ($events[2].Action -eq 'OFF' -and $events[2].DurationMs -eq 20) 'Zero velocity release must retain measured duration'
Accept 0x003C81 40
Assert (-not $monitor.Snapshot().Active[60]) 'Final channel release must extinguish the key'
Accept 0x784D90 50
Assert ($monitor.Snapshot().LastOutputVelocity -eq 127) 'Output velocity must saturate'
Accept 0x007BB0 60
Assert ($monitor.Snapshot().ActiveCount -eq 0) 'All notes off must clear the channel'
Accept 0x403E90 70
Accept 0x403F91 71
$monitor.ReleaseNotes()
Assert ($monitor.Snapshot().ActiveCount -eq 0) 'Disconnect/panic must clear all notes'
for ($i=0; $i -lt 1100; $i++) { Accept 0x003C80 (100+$i) }
$events = $monitor.EventsAfter(0)
Assert ($events.Length -eq 1000) 'Event history must stay bounded'
Assert ($monitor.EventsAfter($events[-1].Id).Length -eq 0) 'UI must not duplicate old events'
$csv = $monitor.ExportCsv()
Assert ($csv.Contains('raw_velocity,output_velocity') -and $csv.Contains('C4')) 'CSV must include useful note and velocity data'
Write-Output 'PASS: monitor partial packets, zero velocity, independent channels, duration, panic, saturation, bounded history and CSV'

$sent = New-Object 'System.Collections.Generic.List[uint32]'
$sink = [System.Action[uint32]]{param([uint32]$message) $sent.Add($message)}
$wireMonitor = New-Object PianoDesktop.MidiMonitor
$pipe = New-Object PianoDesktop.MidiPipeline($wireMonitor, $sink)
$pipe.Feed([byte[]](0x90,60),2,1.25,0)
Assert ($sent.Count -eq 0) 'Do not send incomplete MIDI to the audio device'
$pipe.Feed([byte[]](120,0x80,60,0),4,1.25,20)
Assert ($sent.Count -eq 2 -and $sent[0] -eq 0x7F3C90 -and $sent[1] -eq 0x003C80) 'Real receive pipeline must send amplified ON and intact OFF'
Assert ($wireMonitor.Snapshot().ByteCount -eq 6 -and $wireMonitor.Snapshot().ActiveCount -eq 0) 'Wire counts and UI must reflect the same pipeline'

$session = New-Object PianoDesktop.MidiConnection
try {
    $session.StartDemo()
    Start-Sleep -Milliseconds 150
    Assert ($session.Running -and $session.IsDemo -and $session.Monitor.Snapshot().OnCount -gt 0) 'Offline demo must feed real parser and monitor'
    $session.Disconnect()
    Assert (-not $session.Running -and $session.Monitor.Snapshot().ActiveCount -eq 0) 'Disconnect must stop worker and release notes'
    $failed = $false
    try { $session.Connect('NONEXISTENT_PIANO_PORT',0) } catch { $failed = $true }
    Assert $failed 'Invalid port must report a connection error'
    Assert (-not $session.Running) 'Connection failure must not leave a running session'
    $session.StartDemo()
    Start-Sleep -Milliseconds 100
    Assert ($session.Running) 'Application must remain usable after connection failure'
} finally { $session.Dispose() }
Write-Output 'PASS: serial-to-synth pipeline, demo lifecycle, disconnect cleanup and reconnect after invalid port'

# Empty driver buffer must initiate a blocking read for one byte; it must not
# return early and leave the receiver to sleep/poll again.
$script:readCalls=0
$available=[System.Func[int]]{return 0}
$driverRead=[PianoDesktop.ReadBytes]{param($buffer,$offset,$count)
    if($count -ne 1){throw 'Empty driver requires a one-byte blocking read'}
    $script:readCalls++
    $buffer[$offset]=0x90
    return 1
}
$reader=New-Object PianoDesktop.MidiByteReader($available,$driverRead)
$buffer=New-Object byte[] 32
Assert ($reader.Read($buffer) -eq 1 -and $script:readCalls -eq 1 -and $buffer[0] -eq 0x90) 'Reader must wait on the driver, not poll an empty buffer'
Add-Type 'public static class IdleDriverProbe { public static int Read(byte[] b,int offset,int count) { throw new System.TimeoutException(); } }'
$timeoutRead=[System.Delegate]::CreateDelegate([PianoDesktop.ReadBytes],[IdleDriverProbe].GetMethod('Read'))
$reader=New-Object PianoDesktop.MidiByteReader($available,$timeoutRead)
Assert ($reader.Read($buffer) -eq 0) 'An idle read timeout must permit control/stop processing without disconnecting'
Write-Output 'PASS: empty-buffer blocking read and idle timeout'

$diagnostics=New-Object PianoDesktop.MidiMonitor
$diagnostics.Accept(0x003C90,0x003C90,10,2.5)
$diagnostics.AddSerialError()
$diagnostics.Accept(0x783C90,0x7F3C90,20,0.1)
$snapshot=$diagnostics.Snapshot()
Assert ($snapshot.ZeroVelocityOnCount -eq 1 -and $snapshot.SerialErrorCount -eq 1) 'Count zero-velocity ON and driver errors without inventing force readings'
Assert ($snapshot.MaxForwardMs -eq 2.5 -and $snapshot.LastForwardMs -eq 0.1) 'Expose bridge API timings independently of note duration'
$csv=$diagnostics.ExportCsv()
Assert ($csv.Contains('forward_ms,raw_hex') -and $csv.Contains('90 3C 78')) 'CSV must retain original MIDI bytes and API timing'
Write-Output 'PASS: velocity-zero/driver diagnostics, forwarding metrics and original MIDI hex export'
