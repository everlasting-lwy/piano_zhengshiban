`timescale 1ns/1ps
module tb_audio_effects;
reg clk=0;always #10 clk=~clk;
reg rst=0,clear=0,tick=0;reg signed[15:0] pcm=0;
reg[3:0] expression=15,reverb=0,echo=0,chorus=0;reg[1:0] delay_sel=0;
wire signed[15:0] out,lag;wire valid,clip;
reg seen=0;
audio_effects d(clk,rst,clear,tick,pcm,expression,reverb,echo,chorus,delay_sel,out,lag,valid,clip);
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task frame;input integer value;begin
pcm=value;tick=1;clocks(1);tick=0;clocks(45);
if(!seen)$fatal(1,"Effect did not publish within64-clock I2S window");
clocks(18);seen=0;end endtask
always @(negedge clk)if(valid)seen=1;
task reset;begin clear=1;clocks(2);clear=0;end endtask
integer i,energy,tail;
initial begin
clocks(3);rst=1;clocks(3);
frame(12345);if(out!==12345)$fatal(1,"Neutral dry bypass not exact");
frame(-32768);if(out!==-32768)$fatal(1,"Negative dry sample changed");
expression=0;frame(12345);if(out!==0)$fatal(1,"Expression zero not silent");
expression=15;reset;echo=15;
for(i=0;i<4200;i=i+1)begin
frame(i==0?16000:0);
if(i>0 && i<4096 && out!==0)$fatal(1,"Uninitialized/early echo at%0d",i);
if(i==4096 && out!=7500)$fatal(1,"Wrong echo impulse gain/time: %d",out);
end
reset;
for(i=0;i<4100;i=i+1)begin
frame(i==0?-16000:0);
if(i==4096 && out!=-7500)$fatal(1,"Negative echo polarity/gain error: %d",out);
if(out>0)$fatal(1,"Negative impulse produced positive echo");
end
echo=0;reverb=15;reset;energy=0;
for(i=0;i<5000;i=i+1)begin frame(i==0?16000:0);if(i>0&&out!=0)energy=energy+1;end
if(energy<4)$fatal(1,"Reverb taps absent");
reset;
for(i=0;i<5000;i=i+1)begin frame(i==0?-16000:0);if(out>0)$fatal(1,"Negative room tap polarity");end
reverb=0;chorus=15;reset;energy=0;
for(i=0;i<1100;i=i+1)begin frame(i==0?16000:0);if(i>0&&out!=0)energy=energy+1;end
if(energy==0)$fatal(1,"Chorus tap absent");
reset;
for(i=0;i<1100;i=i+1)begin frame(i==0?-16000:0);if(out>0)$fatal(1,"Negative chorus tap polarity");end
reverb=15;echo=15;reset;
for(i=0;i<12000;i=i+1)begin frame(i%2 ? -32768:32767);if(^out===1'bx)$fatal(1,"Unknown or overflow effect");end
reset;frame(0);if(out!==0||lag!==0)$fatal(1,"Clear leaked old history");
echo=0;reverb=0;chorus=0;frame(-12345);if(out!==-12345)$fatal(1,"Effects-off altered dry sound");
$display("PASS: shared effects dry/zero expression/echo exact impulse/reverb/chorus/overload/clear/deadline");$finish;
end
initial begin #100000000;$fatal(1,"effects timeout");end
endmodule
