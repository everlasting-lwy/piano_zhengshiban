`timescale 1ns/1ps
// Real 50MHz/default sampling. Brief electrical/contact excursions are not detents.
module tb_rotary_noise;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=1,b=1,sw=1;
reg [31:0] values={1'b0,2'd0,4'd0,4'd0,4'd0,4'd0,5'd8,4'd15,4'd12};
wire [2:0] selected;wire [7:0] command;wire valid;
integer events=0,n;
rotary_control #(.INITIAL_SELECTION(7)) dut(
 .clk(clk),.rst_n(rst_n),.a(a),.b(b),.sw_n(sw),.values(values),
 .selected(selected),.command(command),.command_valid(valid));
always @(posedge clk)if(valid)begin
 events=events+1;
 if(command>=8'h80 && command<=8'h8f)values[3:0]<=command[3:0];
end
task clocks;input integer count;begin repeat(count)@(negedge clk);end endtask
task phase;input [1:0] ab;input integer count;begin {a,b}=ab;clocks(count);end endtask
initial begin
 clocks(8);rst_n=1;clocks(12000);
 // Twenty-us excursions can look like an entire Gray-code turn to a 10us sampler.
 phase(1,1000);phase(0,1000);phase(2,1000);phase(3,12000);
 if(events!=0 || values[3:0]!=12)$fatal(1,"brief A/B noise changed volume without a real detent: events=%0d vol=%0d",events,values[3:0]);
 // A genuine hand-operated detent remains responsive with 400us per phase.
 phase(1,20000);phase(0,20000);phase(2,20000);phase(3,20000);
 if(events!=1 || values[3:0]!=11)$fatal(1,"filtered encoder lost a genuine negative detent");
 phase(2,20000);phase(0,20000);phase(1,20000);phase(3,20000);
 if(events!=2 || values[3:0]!=12)$fatal(1,"filtered encoder lost a genuine positive detent");
 // Neither a short single-contact spike nor a stable partial reversal is a turn.
 phase(2,600);phase(3,12000);
 phase(2,20000);phase(0,20000);phase(2,20000);phase(3,20000);
 if(events!=2)$fatal(1,"noise or partial reversal emitted an extra command");
 for(n=0;n<4;n=n+1)begin
  rst_n=0;{a,b}=n[1:0];clocks(10);rst_n=1;clocks(15000);
  if(valid || dut.accumulated!=0)$fatal(1,"startup learned a synthetic rotation from initial A/B=%0d",n);
 end
 $display("PASS: production50MHz A/B short-noise rejection, real detents, partial reversal and all four startup states");
 $finish;
end
initial begin #20000000;$fatal(1,"rotary noise timeout");end
endmodule
