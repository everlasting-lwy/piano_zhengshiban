`timescale 1ns/1ps
module tb_visual_guide_control;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=1,b=1,sw=1,active=0;
wire[1:0]view;wire[2:0]gain;wire toggle_guide,restart_guide;
integer toggles=0,restarts=0;
visual_rotary_control #(.SAMPLE_CYCLES(1),.AB_FILTER_SAMPLES(2),.SW_FILTER_SAMPLES(3),.LONG_PRESS_SAMPLES(30)) dut(
 .clk(clk),.rst_n(rst_n),.a(a),.b(b),.sw_n(sw),.guide_active(active),
 .view(view),.gain_shift(gain),.guide_toggle(toggle_guide),.guide_restart(restart_guide));
always @(negedge clk)begin
 if(toggle_guide)begin active=!active;toggles=toggles+1;end
 if(restart_guide)restarts=restarts+1;
end
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task click;input integer n;begin sw=0;clocks(n);sw=1;clocks(12);end endtask
initial begin
 clocks(10);rst_n=1;clocks(20);
 click(10);if(view!=1)$fatal(1,"normal short click should switch graph");
 click(65);if(!active||toggles!=1||view!=1)$fatal(1,"long must enter guide once, retaining graph");
 click(10);if(restarts!=1||view!=1||!active)$fatal(1,"guide short must restart without view advance");
 // Rotation in GUIDE cannot index outside the3 graph gain slots.
 a=1;b=0;clocks(8);a=0;clocks(8);b=1;clocks(8);a=1;clocks(8);
 if(gain!=0)$fatal(1,"guide rotation changed spectrum gain");
 click(65);if(active||toggles!=2||view!=1)$fatal(1,"second long exits without extra short");
 click(10);if(view!=2)$fatal(1,"normal graph cycling must resume");
 $display("PASS: long one-shot guide entry/exit, short restart, rotation isolation and graph resumption");$finish;
end
initial begin #100000;$fatal(1,"guide control timeout");end
endmodule
