`timescale 1ns/1ps
module tb_sd_encoder_select;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,a=0,b=0,sw_n=1,guide_active=0;
wire [1:0]view;wire[2:0]gain_shift;
wire guide_toggle,guide_restart,guide_next,guide_prev;
integer next_count=0,prev_count=0;
visual_rotary_control #(.SAMPLE_CYCLES(2),.AB_FILTER_SAMPLES(3),
 .SW_FILTER_SAMPLES(3),.LONG_PRESS_SAMPLES(40)) dut(.*);
always @(posedge clk)begin
 if(guide_next)next_count<=next_count+1;
 if(guide_prev)prev_count<=prev_count+1;
end
task phase;input[1:0] ab;begin {a,b}=ab;repeat(14)@(negedge clk);end endtask
task cw;begin phase(1);phase(3);phase(2);phase(0);end endtask
task ccw;begin phase(2);phase(3);phase(1);phase(0);end endtask
initial begin
 repeat(8)@(negedge clk);rst_n=1;repeat(30)@(negedge clk);
 cw();if(gain_shift!=3||next_count!=0)$fatal(1,"normal gain behavior");
 guide_active=1;cw();ccw();repeat(3)@(negedge clk);
 if(next_count!=1||prev_count!=1||gain_shift!=3)$fatal(1,"guide selection pulses/gain isolation");
 phase(1);phase(0);repeat(3)@(negedge clk);
 if(next_count!=1||prev_count!=1)$fatal(1,"partial turn selected song");
 guide_active=0;ccw();if(gain_shift!=2)$fatal(1,"normal gain restored");
 $display("PASS: GUIDE full detent next/previous, partial rejection and normal gain isolation");$finish;
end
endmodule
