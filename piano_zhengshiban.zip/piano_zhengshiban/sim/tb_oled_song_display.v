`timescale 1ns/1ps
module tb_oled_song_display;
parameter integer SH=1,COL=2;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,loaded=1,complete=0,wrong=0;
reg[17:0]target=18'h01001,physical=0;
tri1 scl,sda;wire frame_done,online;
oled_visual_panel #(.I2C_DIV(2),.BOOT_CYCLES(2),.REFRESH_CYCLES(100),
 .RETRY_CYCLES(20),.TIMEOUT_CYCLES(50),.SH1106(SH),.COLUMN_OFFSET(COL)) dut(
 .clk(clk),.rst_n(rst_n),.pcm_frame(16'd0),.pcm_frame_valid(1'b0),.view(2'd0),.gain_shift(3'd2),
 .spectrum_bars(256'd0),.spectrum_valid(1'b0),.guide_active(1'b1),.guide_loaded(loaded),
 .guide_complete(complete),.guide_wrong(wrong),.guide_target(target),.guide_physical(physical),
 .guide_step(12'd7),.guide_total(12'd12),.scl(scl),.sda(sda),.online(online),.frame_done(frame_done));
reg low=0,active=0,ack=0,page_command=0;reg[7:0]shift=0,control=0;
integer bits=0,bytes=0,page=0,pages=0,index,i,fd;
reg[7:0]pixels[0:1023];reg saw_power=0,saw_ssd=0;
assign sda=low?1'b0:1'bz;
always @(negedge sda)if(rst_n && scl===1'b1 && !low)begin active=1;bits=0;bytes=0;page_command=0;end
always @(posedge sda)if(rst_n && scl===1'b1)active=0;
always @(posedge scl)if(active)begin
 if(bits<8)begin
  shift={shift[6:0],sda};bits=bits+1;
  if(bits==8)begin
   if(bytes==0)ack=shift==8'h78;
   if(bytes==1)control=shift;
   if(bytes>=2 && ack && control==0)begin
    if(bytes==2 && shift>=8'hb0 && shift<=8'hb7)begin page=shift-8'hb0;page_command=1;end
    if(page_command && bytes==3 && shift!==COL%16)$fatal(1,"wrong column low address");
    if(page_command && bytes==4 && shift!==(8'h10+COL/16))$fatal(1,"wrong column high address");
    if(bytes==23 && shift==8'had)saw_power=1;
    if(bytes==23 && shift==8'h20)saw_ssd=1;
   end
   if(bytes>=2 && ack && control==8'h40)begin
    if(bytes>129)$fatal(1,"display sent outside128 visible pixels");
    pixels[page*128+bytes-2]=shift;
    if(bytes==129)pages=pages+1;
   end
   bytes=bytes+1;
  end
 end else bits=9;
end
always @(negedge scl)if(active)begin
 if(bits==8)low=ack;
 else if(bits==9)begin low=0;bits=0;end
end
function pixel;input integer x,y;begin pixel=pixels[(y/8)*128+x][y%8];end endfunction
task await_frame;begin wait(!frame_done);wait(frame_done);@(negedge clk);end endtask
initial begin
 repeat(8)@(negedge clk);rst_n=1;
 // Change the live target mid-frame; screen must finish its coherent old chord.
 wait(pages==1);@(negedge clk);target=18'h00080;
 await_frame();
 if(!online || pages!=8)$fatal(1,"GUIDE failed to refresh without audio");
 if(!pixel(8,55)||!pixel(85,55)||pixel(14,32))$fatal(1,"first chord torn or key mapping wrong");
 if(pixels[0]!==8'h3e || pixels[1]!==8'h41 || pixels[2]!==8'h49)$fatal(1,"GUIDE header G missing");
 if(SH && !saw_power || !SH && !saw_ssd)$fatal(1,"wrong OLED driver initialization");
 fd=$fopen(SH ? "tmp/song_guide_20261028/guide_sh1106.hex" : "tmp/song_guide_20261028/guide_ssd1306.hex","w");
 for(i=0;i<1024;i=i+1)$fdisplay(fd,"%02x",pixels[i]);$fclose(fd);
 await_frame();
 if(pixel(8,55)||pixel(85,55)||!pixel(14,32))$fatal(1,"next target failed to refresh");
 loaded=0;target=0;await_frame();await_frame();
 if(pixel(14,32))$fatal(1,"deleted song retains target");
 $display("PASS: GUIDE actualI2C header/chord pixels, coherent frame update, no-audio refresh and delete display SH%0d COL%0d",SH,COL);$finish;
end
initial begin #12000000;$fatal(1,"guide display timeout");end
endmodule
