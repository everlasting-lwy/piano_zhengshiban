`timescale 1ns/1ps
module tb_bt_effects_integration;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,bt_rx=1;reg[17:0] pins=18'h3ffff;
wire tx;localparam BIT=16;
top_piano_acg525 #(.BT_UART_CYCLES(BIT)) dut(
.visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst_n),.key_in(pins),.key_timbre(1'b1),.key_mode(1'b1),
.key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(bt_rx),.bt_txd(tx),
.hc_echo(1'b0));
    function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
        c=0;
        for(i=0;i<8;i=i+1) begin c=c^b[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
        crc8=c;
    end endfunction
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task byte_in;input [7:0] value;integer z;begin
bt_rx=0;clocks(BIT);for(z=0;z<8;z=z+1)begin bt_rx=value[z];clocks(BIT);end
bt_rx=1;clocks(BIT+2);end endtask
    task request;input [7:0] seq,op;input [47:0] p;input bad;integer k;begin
        byte_in(8'hA5);byte_in(8'h5A);byte_in(seq);byte_in(op);
        for(k=0;k<6;k=k+1)byte_in(p[k*8 +:8]);
        byte_in(crc8({p,op,seq})^{7'd0,bad});byte_in(8'h0D);clocks(8);
    end endtask
    reg [95:0] packets[0:511];
    reg [95:0] partial=0;
    reg [7:0] wire_byte;
    integer count=0,index=0,j;
    initial forever begin
        @(negedge tx);clocks(BIT+BIT/2);
        for(j=0;j<8;j=j+1)begin wire_byte[j]=tx;clocks(BIT);end
        if(tx!==1) $fatal(1,"BT TX stop bit");
        partial[index*8 +:8]=wire_byte;
        if(index==11)begin
            if(partial[15:0]!==16'h5AA5 || partial[95:88]!==8'h0D || partial[87:80]!==crc8(partial[79:16]))
                $fatal(1,"Bad outgoing BT wire frame %h",partial);
            if(count>=512)$fatal(1,"Response overflow");
            packets[count]=partial;count=count+1;partial=0;index=0;
        end else index=index+1;
    end
    reg [47:0] response;
    task reply;input [7:0] seq,op;integer n,k;reg found;begin
        n=0;found=0;
        while(n<600000 && !found)begin
            for(k=0;k<count;k=k+1)if(packets[k][23:16]==seq && packets[k][31:24]==op)begin
                found=1;response=packets[k][79:32];
            end
            if(!found)begin clocks(50);n=n+50;end
        end
        if(!found)$fatal(1,"Missing reply seq=%h op=%h",seq,op);
    end endtask
integer i,k,bytes_seen,spectrum_energy,guide_at,dump,n;reg[47:0] gp;
task set_fx;input[7:0] seq,id,val;begin
request(seq,13,{32'd0,val,id},0);reply(seq,8'h80);
if(response[15:8]!==0)$fatal(1,"Integration setter rejected");
end endtask
task wait_chunks;input[7:0] seq,kind;input integer chunks;integer timeout,c,n;begin
timeout=0;c=0;
while(c<chunks && timeout<800000)begin
c=0;for(n=0;n<count;n=n+1)if(packets[n][23:16]==seq && packets[n][31:24]==8'h87)c=c+1;
if(c<chunks)begin clocks(100);timeout=timeout+100;end
end
if(c!=chunks)$fatal(1,"Missing snapshot chunks seq%0d got%0d want%0d",seq,c,chunks);
c=0;
for(n=0;n<count;n=n+1)if(packets[n][23:16]==seq && packets[n][31:24]==8'h87)begin
if(packets[n][39:32]!==kind || packets[n][47:40]!==c[7:0])$fatal(1,"Mixed kind or broken chunk order");
c=c+1;
end
end endtask
initial begin
clocks(10);rst_n=1;clocks(80);
set_fx(1,0,15);clocks(100);
if(dut.u_core.effect_reverb!==15)$fatal(1,"Bluetooth setter ACKed but did not reach FPGA effects without screen");
set_fx(2,1,9);set_fx(3,2,7);set_fx(4,3,8);set_fx(5,4,16);set_fx(6,5,4);set_fx(7,6,2);set_fx(8,7,1);
request(9,12,0,0);reply(9,8'h85);
if(response!==48'h31009064879f)$fatal(1,"Shared register85 state/neutral marker mismatch:%h",response);
pins[0]=0;clocks(52000);
if(dut.u_core.audio_scaled===0)$fatal(1,"Held C4 not generating local FPGA PCM");
request(10,14,1,0);reply(10,8'h86);wait_chunks(10,1,16);
if(response[7:0]!==1||response[15:8]!==16)$fatal(1,"Wave metadata invalid");
request(11,14,2,0);reply(11,8'h86);wait_chunks(11,2,8);
spectrum_energy=0;
for(i=0;i<count;i=i+1)if(packets[i][23:16]==11 && packets[i][31:24]==8'h87)
for(k=0;k<4;k=k+1)spectrum_energy=spectrum_energy+packets[i][(k+6)*8+:8];
if(spectrum_energy==0)$fatal(1,"Bluetooth DFT had no data with local OLED independent");
request(12,14,3,0);reply(12,8'h86);wait_chunks(12,3,32);
request(13,14,4,0);reply(13,8'h86);wait_chunks(13,4,1);
if(dut.u_core.guide_target!==1 || dut.u_core.guide_step!==0)$fatal(1,"Bluetooth guide not active");
pins[0]=1;clocks(100200);
if(dut.u_core.guide_step!==1)$fatal(1,"Physical correct press/release did not advance phone guide");
request(14,14,4,0);reply(14,8'h86);wait_chunks(14,4,1);
for(i=0;i<count;i=i+1)if(packets[i][23:16]==14 && packets[i][31:24]==8'h87)gp=packets[i][79:32];
if(gp!==48'h010400000004)$fatal(1,"Guide physical mask/mode/step packing:%h",gp);
// Polling guide retains progress, and phone notes cannot advance physical practice.
request(15,9,48'h1000,0);reply(15,8'h80);clocks(4000);request(16,5,0,0);reply(16,8'h80);
if(dut.u_core.guide_step!==1)$fatal(1,"Remote playback changed physical practice guide");
request(17,14,0,0);reply(17,8'h80);clocks(50);
if(dut.u_core.bt_visual_kind!==0)$fatal(1,"Test view off not propagated");
dump=$fopen("sim/bt_effects_wire.hex","w");
for(i=0;i<count;i=i+1)begin
 for(n=0;n<12;n=n+1)$fwrite(dump,"%02x",packets[i][n*8+:8]);
 $fwrite(dump,"%c",8'd10);
end
$fclose(dump);
$display("PASS: real UART APP effects reach shared FPGA regs, no-screen PCM wave/DFT/XY/physical guide and remote isolation");$finish;
end
initial begin #80000000;$fatal(1,"BT effects integration timeout count%0d",count);end
endmodule
