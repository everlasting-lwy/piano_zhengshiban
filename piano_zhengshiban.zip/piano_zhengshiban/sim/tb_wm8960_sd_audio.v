`timescale 1ns/1ps
// Actual UART->RPC->SPI activity must be bit-identical to the frozen audio core.
module tb_wm8960_sd_audio;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,rx=1,bad_crc=0;reg[17:0]keys=18'h3ffff;
tri1 scl,sda,vscl,vsda,wm_scl,wm_sda;
wire wm_mclk;
wm8960_model codec(rst_n,1'b1,1'b0,wm_scl,wm_sda);
wire bclk,lrck,din,rbclk,rlrck,rdin,sd_cs_n,sd_clk,sd_mosi,sd_miso;
localparam BIT=16;
top_piano_wm8960_acg525 #(.WM_I2C_DIV(2),.WM_BOOT_CYCLES(20),.WM_RESET_CYCLES(10),.WM_BIAS_CYCLES(100),.WM_RETRY_CYCLES(100),.WM_TIMEOUT_CYCLES(100),.VISUAL_SH1106(0),.VISUAL_COLUMN_OFFSET(0),.BT_UART_CYCLES(BIT),.SD_INIT_DIV(2),.SD_DATA_DIV(1),.SD_POWERUP_CYCLES(8),.SD_INIT_TIMEOUT_CYCLES(1000000),
 .OLED_BOOT_CYCLES(1),.OLED_TIMEOUT_CYCLES(20),.VISUAL_BOOT_CYCLES(1),.VISUAL_TIMEOUT_CYCLES(20)) dut(
 .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),.key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),
 .bt_rxd(rx),.hc_echo(1'b0),.encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),.oled_scl(scl),.oled_sda(sda),
 .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),.visual_oled_scl(vscl),.visual_oled_sda(vsda),
 .wm8960_scl(wm_scl),.wm8960_sda(wm_sda),.wm8960_mclk(wm_mclk),
 .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din),.sd_cs_n(sd_cs_n),.sd_clk(sd_clk),.sd_mosi(sd_mosi),.sd_miso(sd_miso));
reference_single_oled_core #(.BT_UART_CYCLES(BIT)) reference_core(
 .sys_clk(clk),.sys_rst_n(dut.u_board.core_rst_n),.key_in(dut.u_board.keys_sync[17:0]),.key0(dut.u_board.keys_sync[21]),.key1(1'b1),.key2(1'b1),
 .key3(dut.u_board.keys_sync[20]),.key4(dut.u_board.keys_sync[22]),.local_command(dut.u_board.local_command),.local_command_valid(dut.u_board.local_command_valid),
 .uart_rxd(rx),.hc_echo(1'b0),.i2s_bclk(rbclk),.i2s_lrck(rlrck),.i2s_din(rdin));
sd_spi_card_model card(.cs_n(sd_cs_n),.sclk(sd_clk),.mosi(sd_mosi),.miso(sd_miso),.kind(2'd0),.csd_variant(3'd0),
 .absent(1'b0),.bad_crc(bad_crc),.reject_write(1'b0),.stuck_busy(1'b0),.no_token(1'b0),.bad_r7(1'b0),.bad_ocr(1'b0),.bad_csd(1'b0),.init_stuck(1'b0),.status_error(1'b0));
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
task octet;input[7:0]v;integer k;begin rx=0;clocks(BIT);for(k=0;k<8;k=k+1)begin rx=v[k];clocks(BIT);end rx=1;clocks(BIT+4);end endtask
function[7:0]crc8;input[63:0]bits;integer k,j;reg[7:0]c;begin c=0;for(k=0;k<8;k=k+1)begin c=c^bits[k*8+:8];for(j=0;j<8;j=j+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;end endfunction
reg[7:0]seq=0;
task send;input[7:0]cmd;input[47:0]p;integer k;begin octet(8'ha5);octet(8'h5a);octet(seq);octet(cmd);for(k=0;k<6;k=k+1)octet(p[k*8+:8]);octet(crc8({p,cmd,seq}));octet(8'h0d);seq=seq+1;clocks(300);end endtask
function[7:0]pattern;input integer n;begin pattern=(n*3)^8'ha5;end endfunction
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer k;reg[15:0]c;begin c=old^{v,8'd0};for(k=0;k<8;k=k+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
integer frames=0,nonzero=0,active_frames=0,serial_bits=0;
reg previous_lrck=1,started=0,left_seen=0;reg[31:0]slot=0,rslot=0,left=0,rleft=0;
always @(negedge clk)if(dut.u_board.core_rst_n&&(bclk!==rbclk||lrck!==rlrck))$fatal(1,"SD changed I2S clocks");
always @(posedge bclk)begin
 if(!dut.u_board.core_rst_n)begin previous_lrck=lrck;started=0;left_seen=0;serial_bits=0;end
 else begin
  if(lrck!=previous_lrck)begin
   started=1;previous_lrck=lrck;slot=0;rslot=0;serial_bits=0;
  end
  if(started)begin
   slot={slot[30:0],din};rslot={rslot[30:0],rdin};serial_bits=serial_bits+1;
   if(serial_bits==32)begin
    if(lrck)begin left=slot;rleft=rslot;left_seen=1;end
    else if(left_seen)begin
     if((^{left,slot}===1'bx)||(^{rleft,rslot}===1'bx)||{left,slot}!=={rleft,rslot})$fatal(1,"SD changed complete stereo word %h/%h",{left,slot},{rleft,rslot});
     frames=frames+1;if(left[30:15]!=0&&slot[30:15]!=0)nonzero=nonzero+1;
     if(dut.u_board.u_core.u_sd_library.rpc_active)active_frames=active_frames+1;
    end
   end
  end
 end
end
integer n,j,job;reg[15:0]crc;
initial begin
 clocks(10);rst_n=1;clocks(50);n=0;
 while(!(dut.u_board.u_core.u_sd_library.media_ready&&!dut.u_board.u_core.u_sd_library.media_busy&&dut.u_board.u_core.u_sd_library.storage_idle)&&n<100000)begin clocks(1);n=n+1;end
 if(n>=100000)$fatal(1,"card/file bootstrap");
 wait(dut.audio_enabled);
 send(8'h20,{8'd0,32'h12345678,8'd0});if(!dut.u_board.u_core.u_sd_library.rpc_active)$fatal(1,"UART session begin");
 keys[0]=0;crc=16'hffff;for(j=0;j<512;j=j+1)crc=crcbyte(crc,pattern(j));
 for(job=1;job<=2;job=job+1)begin
  send(8'h24,job);
  for(j=0;j<512;j=j+4)begin
   send(8'h22,{pattern(j+3),pattern(j+2),pattern(j+1),pattern(j),j[15:0]});
   if(j==128)keys[7]=0;
   if(j==256)begin keys[0]=1;keys[17]=0;end
  end
  if(dut.u_board.u_core.u_sd_library.u_rpc.write_count!=512)$fatal(1,"UART fill");
  bad_crc=(job==2);send(8'h23,{crc,32'd17});
  n=0;while(dut.u_board.u_core.u_sd_library.u_rpc.state!=0&&n<100000)begin clocks(1);n=n+1;end
  if(n>=100000)$fatal(1,"RPC completion");
 end
 if(!dut.u_board.u_core.u_sd_library.rpc_uncertain)$fatal(1,"fault not injected");
 send(8'h20,{8'd0,32'h12345678,8'd1});keys=18'h3ffff;clocks(105000);
 if(frames<300||active_frames<200||nonzero<100)$fatal(1,"insufficient complete sound samples %d/%d/%d",frames,active_frames,nonzero);
 if(card.errors!=0)$fatal(1,"wire peer error");
 $display("PASS: WM8960 left audio with SD; active SD UART/RPC fill/write/readback/fault leaves%0d complete I2S stereo frames bit-identical (%0d during session,%0d nonzero)",frames,active_frames,nonzero);$finish;
end
initial begin#30000000;$fatal(1,"SD audio isolation timeout");end
endmodule
