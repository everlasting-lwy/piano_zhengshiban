`timescale 1ns/1ps
module tb_additive_integration;
    reg clk=0;always #10 clk=~clk;
    reg rst=0;
    reg [17:0] pins=18'h3ffff;
    wire bclk,lrck,din;
    top_piano_acg525 dut(.visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
.sys_clk(clk),.sys_rst_n(rst),.key_in(pins),
        .key_timbre(1'b1),.key_mode(1'b1),.key_vol_up(1'b1),.key_vol_down(1'b1),
        .key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0),
        .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din));
    integer cycles=0,last_tick=0,commit_mask=0,frames=0,active_frames=0,v;
    reg [3:0] audible=0;
    always @(negedge clk)begin
        cycles=cycles+1;
        if(!dut.core_rst_n)begin last_tick=0;commit_mask=0;end
        else begin
            if(dut.u_core.sample_tick)begin
                if(last_tick && cycles-last_tick!=1024)$fatal(1,"Sample cadence not1024");
                if(last_tick && commit_mask!=15)$fatal(1,"Missed voice in previous frame");
                last_tick=cycles;commit_mask=0;frames=frames+1;
            end
            for(v=0;v<4;v=v+1)if(dut.u_core.additive_valid[v])begin
                if(cycles-last_tick>32)$fatal(1,"Bank deadline exceeded");
                if(commit_mask & (1<<v))$fatal(1,"Duplicate additive voice result");
                commit_mask=commit_mask|(1<<v);
            end
            if(last_tick && dut.u_core.u_i2s.bit_tick && dut.u_core.u_i2s.lrck_cnt==0)begin
                if(cycles-last_tick!=64 || commit_mask!=15)$fatal(1,"All voices not ready before I2S load");
                if(dut.u_core.v_gate==15)begin
                    active_frames=active_frames+1;
                    for(v=0;v<4;v=v+1)
                        if(dut.u_core.v_wave[v]!=0)audible[v]=1;
                end
            end
        end
    end
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    initial begin
        clocks(32);rst=1;clocks(100);
        pins=18'h3ffff^18'h55; // C4/E4/G4/B4
        clocks(180000);
        if(dut.u_core.v_gate!==15 || active_frames<80 || audible!==15)
            $fatal(1,"Four additive voices silent/missing");
        pins=18'h3ffff;clocks(110000);
        if(dut.u_core.v_gate!==0)$fatal(1,"Release lost");
        $display("PASS:four independent additive notes,tagged frame commits before I2S load,release;frames=%0d",frames);
        $finish;
    end
    initial begin #10000000;$fatal(1,"Additive integration timeout");end
endmodule
