"""Small isolated HDL test runner; reports real simulation failure codes."""
from pathlib import Path
import os, subprocess, sys, ctypes
r=Path(__file__).resolve().parents[1]
env=os.environ.copy()
b=Path(os.environ.get("IVERILOG_BIN", str(r/"tmp/iverilog/mingw64/bin")))
env["PATH"]=str(b)+os.pathsep+r"C:\mingw64\bin"+os.pathsep+env["PATH"]
env["TMP"]=env["TEMP"]=str(r/"tmp")
if os.name=="nt": ctypes.windll.kernel32.SetErrorMode(0x8003)
sys.stdout.reconfigure(encoding="utf-8")
top=sys.argv[1]
sources=sys.argv[2:] or [str(p.relative_to(r)) for p in (r/"src").rglob("*.v")]
sources += [f"sim/{top}.v"]
for cmd in ([str(b/"iverilog.exe"),"-g2012","-I","src/core","-s",top,"-o",f"tmp/{top}.vvp"]+sources,
            [str(b/"vvp.exe"),f"tmp/{top}.vvp"]):
    p=subprocess.run(cmd,cwd=r,env=env,capture_output=True,timeout=240)
    print(p.stdout.decode("utf-8",errors="replace")+p.stderr.decode("utf-8",errors="replace"),end="",flush=True)
    if p.returncode:sys.exit(p.returncode)
