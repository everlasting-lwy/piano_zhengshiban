`timescale 1ns/1ps
// Checks real open-drain I2C bytes: no framebuffer or font signals are observed.
module tb_oled_visual_panel;
parameter integer DIV=2,PCM_PERIOD=1,SMOKE=0;
parameter [7:0] SLAVE_ADDRESS=8'h7a;
reg clk=0;always #10 clk=~clk;
reg rst_n=0;
reg signed [15:0] pcm_frame=0;
reg pcm_frame_valid=1;
reg automatic_samples=1,alternating_samples=0,full_scale=0;
reg signed [15:0] steady_sample=0;
integer pcm_cadence=0;
reg sample_phase=0;
reg [1:0] view=0;reg [2:0] gain_shift=0;
reg [255:0] spectrum_bars=0;reg spectrum_valid=0;
integer triangle_index=0;reg triangle_samples=0,square_samples=0;
always @(negedge clk)if(automatic_samples)begin
 pcm_frame_valid=0;
 if(pcm_cadence==PCM_PERIOD-1)begin
 pcm_cadence=0;pcm_frame_valid=1;
 sample_phase=!sample_phase;
 triangle_index=(triangle_index+1)%256;
 pcm_frame=square_samples ? (triangle_index<128 ? 16'sd20000 : -16'sd20000) : triangle_samples ? ((triangle_index<128) ? (-16384+triangle_index*256) : (49152-triangle_index*256)) : alternating_samples ?
  (full_scale ? (sample_phase ? 16'sh7fff : -16'sh8000) :
                (sample_phase ? 16'sd8192 : -16'sd8192)) : steady_sample;
end else pcm_cadence=pcm_cadence+1;
end
tri1 scl,sda;
reg slave_low=0,stuck=0,data_stuck=0,stretch=0,present=1;
assign sda=(slave_low || data_stuck) ? 1'b0:1'bz;
assign scl=(stuck || stretch) ? 1'b0:1'bz;
wire online,frame_done;
oled_visual_panel #(.I2C_DIV(DIV),.BOOT_CYCLES(10),.REFRESH_CYCLES(2000),
 .RETRY_CYCLES(30),.TIMEOUT_CYCLES(200)) dut(
 .clk(clk),.rst_n(rst_n),.pcm_frame(pcm_frame),.pcm_frame_valid(pcm_frame_valid),
 .view(view),.gain_shift(gain_shift),.spectrum_bars(spectrum_bars),.spectrum_valid(spectrum_valid),
 .scl(scl),.sda(sda),.online(online),.frame_done(frame_done));
integer bits=0,bytes=0,transactions=0,data_pages=0,cmd_pages=0,data_bytes=0;
integer i,p,x,fd,init_count=0,current_page=0,af_count=0;
reg [7:0] init_bytes[0:24];
reg [7:0] pixels[0:1023];
reg active=0,ack=0,saw_3c=0,saw_3d=0,in_frame=0;
reg [7:0] shift=0,first=0,control=0,expected;
always @(negedge sda)if(scl===1'b1 && rst_n && !slave_low)begin
 active=1;bits=0;bytes=0;transactions=transactions+1;
end
always @(posedge sda)if(scl===1'b1 && rst_n)active=0;
always @(posedge scl)if(active)begin
 if(bits<8)begin
  shift={shift[6:0],sda};bits=bits+1;
  if(bits==8)begin
   if(bytes==0)begin
    first=shift;ack=(present && shift==SLAVE_ADDRESS);
    if(shift==8'h78)saw_3c=1;
    if(shift==8'h7a)saw_3d=1;
   end
   if(bytes==1)control=shift;
   if(bytes>=2 && ack && control==8'h40)begin
    if(bytes>129)$fatal(1,"more than 128 data bytes in a page");
    pixels[current_page*128+bytes-2]=shift;data_bytes=data_bytes+1;in_frame=1;
    if(bytes==129)data_pages=data_pages+1;
   end
   if(bytes>=2 && ack && control==0)begin
    if(init_count<25)begin init_bytes[init_count]=shift;init_count=init_count+1;end
    if(bytes==2 && shift>=8'hb0 && shift<=8'hb7)begin
     current_page=shift-8'hb0;
     if(current_page!=cmd_pages%8)$fatal(1,"page commands not in order");
     cmd_pages=cmd_pages+1;
    end
    if(shift==8'haf)begin
     if(data_pages!=8 || data_bytes!=1024)$fatal(1,"AF before complete first frame");
     af_count=af_count+1;
    end
   end
   bytes=bytes+1;
  end
 end else bits=9;
end
always @(negedge scl)if(active)begin
 if(bits==8)slave_low=ack;
 else if(bits==9)begin slave_low=0;bits=0;end
end
always @(posedge clk)if(rst_n)begin
 if((dut.capture_request || dut.xy_request) && in_frame)$fatal(1,"snapshot request during transmitted frame");
 if(frame_done || (dut.bus.done && dut.bus.error))in_frame=0;
end


// Independent literal glyph oracle for visible labels and gain.
function [39:0] glyph;input[7:0] c;begin case(c)
"W":glyph=40'h3f4038403f;"A":glyph=40'h7e1111117e;
"V":glyph=40'h1f2040201f;"E":glyph=40'h7f49494941;
"S":glyph=40'h4649494931;"P":glyph=40'h7f09090906;
"C":glyph=40'h3e41414122;"T":glyph=40'h01017f0101;
"R":glyph=40'h7f09192946;"U":glyph=40'h3f4040403f;
"M":glyph=40'h7f020c027f;"X":glyph=40'h6314081463;
"Y":glyph=40'h0708700807;"D":glyph=40'h7f4141221c;
"L":glyph=40'h7f40404040;"1":glyph=40'h00427f4000;
"2":glyph=40'h4261514946;"4":glyph=40'h1814127f10;
"8":glyph=40'h3649494936;"6":glyph=40'h3c4a494930;
default:glyph=0;endcase end endfunction
function pixel;input integer xx,yy;begin pixel=pixels[(yy/8)*128+xx][yy%8];end endfunction
reg [8*9-1:0] label_text;
reg [8*3-1:0] gain_text;
reg [39:0] glyph_bits;
integer row,bar_height,quadrants,lit;
task check_frame;
 input integer shape,header_view,header_gain;
 input [8*180-1:0] output_path;
 begin
  wait(!frame_done);wait(frame_done);@(negedge clk);
  if(!online || data_pages!=8 || cmd_pages!=8 || data_bytes!=1024)
   $fatal(1,"incomplete frame online=%b pages=%0d cmds=%0d bytes=%0d",online,data_pages,cmd_pages,data_bytes);
  case(header_view)0:label_text="WAVE     ";1:label_text="SPECTRUM ";2:label_text="XY DELAY ";endcase
  case(header_gain)0:gain_text="X1 ";1:gain_text="X2 ";2:gain_text="X4 ";3:gain_text="X8 ";4:gain_text="X16";endcase
  fd=$fopen(output_path,"w");if(!fd)$fatal(1,"cannot open pixel artifact");
  quadrants=0;lit=0;
  for(i=0;i<1024;i=i+1)begin
   p=i/128;x=i%128;expected=0;
   if(p==0)begin
    if(x<54)begin glyph_bits=glyph(label_text[8*(8-x/6)+:8]);if(x%6<5)expected=glyph_bits[8*(4-x%6)+:8];end
    if(x>=102 && x<120)begin glyph_bits=glyph(gain_text[8*(2-(x-102)/6)+:8]);if((x-102)%6<5)expected=glyph_bits[8*(4-(x-102)%6)+:8];end
   end else if(shape<6)begin
    for(row=p*8;row<p*8+8;row=row+1)begin
     if(row==36 || (shape==1 && row==29) || (shape==2 && row==43) ||
      (shape==3 && row==8) || (shape==4 && row==63) || shape==5)expected[row%8]=1;
    end
   end else if(shape==9)begin
    for(row=p*8;row<p*8+8;row=row+1)
     if(row==36 || (x<64 && row==29) || (x>64 && row==43) || (x==64 && row>=29 && row<=43))expected[row%8]=1;
   end else if(shape==10)begin
    for(row=p*8;row<p*8+8;row=row+1)
     if(row==36 || x==64 || ((x==0 || x==127) && (row==8 || row==63)))expected[row%8]=1;
   end else if(shape==6 || shape==7)begin
    case(x/4)0:bar_height=shape==6 ? 14:56;1:bar_height=shape==6 ? 28:56;2:bar_height=56;default:bar_height=0;endcase
    for(row=p*8;row<p*8+8;row=row+1)if(row>=64-bar_height)expected[row%8]=1;
   end
   if(shape!=8 || p==0)begin
    if(pixels[i]!==expected)$fatal(1,"shape %0d page %0d column %0d got %02x expected %02x",shape,p,x,pixels[i],expected);
   end
   $fdisplay(fd,"%02x",pixels[i]);
  end
  if(shape==8)begin
   // Delayed triangle must visit all quadrants, with a diamond around (64,36).
   // A copy of x into y collapses to one diagonal and fails this assertion.
   for(x=0;x<128;x=x+1)for(row=8;row<64;row=row+1)
    if(pixel(x,row) && x!=64 && row!=36)begin
     lit=lit+1;
     if(x<64 && row<36)quadrants=quadrants|1;
     if(x>64 && row<36)quadrants=quadrants|2;
     if(x<64 && row>36)quadrants=quadrants|4;
     if(x>64 && row>36)quadrants=quadrants|8;
     if(x<31 || x>97 || row<21 || row>51)$fatal(1,"XY1X triangle exceeds bounds x%0d y%0d",x,row);
    end
   if(quadrants!=15 || lit<40)$fatal(1,"XY must show64 lag quadrature diamond, quadrants=%0d trace=%0d",quadrants,lit);
  end
  $fclose(fd);data_pages=0;cmd_pages=0;data_bytes=0;
 end
endtask
initial begin
 repeat(8)@(negedge clk);rst_n=1;
 check_frame(0,0,0,"tmp/dual_oled_20261027/visual_silence.hex");
 if(!saw_3c || (SLAVE_ADDRESS==8'h7a && !saw_3d) || af_count!=1)$fatal(1,"address fallback/AF");
 if(SMOKE)begin
  steady_sample=8192;gain_shift=2;
  check_frame(3,0,2,"tmp/dual_oled_20261027/visual_div40_pcm1024_4x.hex");
  $display("PASS: visual OLED production DIV40/PCM1024 actual I2C pixels, silence, autonomous refresh, clipped4X and headers");$finish;
 end
 steady_sample=8192;
 fork
  begin wait(data_pages==1);@(negedge clk);steady_sample=-8192;view=1;gain_shift=4;spectrum_bars={32{8'hff}};spectrum_valid=1;end
  check_frame(1,0,0,"tmp/dual_oled_20261027/visual_positive_frozen.hex");
 join
 // An invalid view/gain independently normalizes safely.
 view=3;gain_shift=7;
 check_frame(2,0,0,"tmp/dual_oled_20261027/visual_invalid_safe.hex");
 view=0;gain_shift=1;steady_sample=4096;
 check_frame(1,0,1,"tmp/dual_oled_20261027/visual_header2x.hex");
 gain_shift=3;steady_sample=1024;
 check_frame(1,0,3,"tmp/dual_oled_20261027/visual_header8x.hex");
 view=0;gain_shift=2;steady_sample=8192;
 check_frame(3,0,2,"tmp/dual_oled_20261027/visual_positive4x_clipped.hex");
 steady_sample=-8192;
 check_frame(4,0,2,"tmp/dual_oled_20261027/visual_negative4x_clipped.hex");
 alternating_samples=1;full_scale=1;gain_shift=4;
 check_frame(5,0,4,"tmp/dual_oled_20261027/visual_bipolar16x_clipped.hex");
 alternating_samples=0;full_scale=0;
 automatic_samples=0;pcm_frame_valid=0;view=0;gain_shift=0;
 wait(dut.capture_request);wait(!dut.capture_request);
 @(negedge clk);pcm_frame=-8192;pcm_frame_valid=1;
 repeat(256)begin @(negedge clk);pcm_frame=8192;end
 repeat(256)begin @(negedge clk);pcm_frame=-8192;end
 @(negedge clk);pcm_frame_valid=0;
 check_frame(9,0,0,"tmp/dual_oled_20261027/visual_step_columns.hex");
 automatic_samples=1;view=1;gain_shift=0;
 spectrum_bars=0;spectrum_bars[7:0]=64;spectrum_bars[15:8]=128;spectrum_bars[23:16]=255;spectrum_valid=1;
 fork
  begin wait(data_pages==1);@(negedge clk);spectrum_bars=0;gain_shift=2;view=2;end
  check_frame(6,1,0,"tmp/dual_oled_20261027/visual_spectrum_frozen.hex");
 join
 view=1;gain_shift=2;spectrum_bars=0;spectrum_bars[7:0]=64;spectrum_bars[15:8]=128;spectrum_bars[23:16]=255;
 check_frame(7,1,2,"tmp/dual_oled_20261027/visual_spectrum4x.hex");
 spectrum_valid=0;spectrum_bars=0;
 check_frame(7,1,2,"tmp/dual_oled_20261027/visual_spectrum_valid_latch.hex");
 view=2;gain_shift=0;triangle_samples=1;
 check_frame(8,2,0,"tmp/dual_oled_20261027/visual_xy_lag64.hex");
 triangle_samples=0;square_samples=1;gain_shift=2;
 fork
  begin wait(data_pages==1);@(negedge clk);square_samples=0;steady_sample=0;view=0;gain_shift=0;end
  check_frame(10,2,2,"tmp/dual_oled_20261027/visual_xy4x_clipped_frozen.hex");
 join
 triangle_samples=0;steady_sample=0;view=0;gain_shift=0;
 present=0;repeat(10000)@(negedge clk);if(online)$fatal(1,"absent OLED online");
 present=1;slave_low=0;active=0;data_pages=0;cmd_pages=0;data_bytes=0;in_frame=0;
 check_frame(0,0,0,"tmp/dual_oled_20261027/visual_absent_recovered.hex");
 stuck=1;repeat(10000)@(negedge clk);if(online)$fatal(1,"stuck SCL online");
 stuck=0;slave_low=0;active=0;data_pages=0;cmd_pages=0;data_bytes=0;in_frame=0;
 check_frame(0,0,0,"tmp/dual_oled_20261027/visual_stuck_recovered.hex");
 data_stuck=1;repeat(10000)@(negedge clk);if(online)$fatal(1,"stuck SDA online");
 data_stuck=0;slave_low=0;active=0;data_pages=0;cmd_pages=0;data_bytes=0;in_frame=0;
 check_frame(0,0,0,"tmp/dual_oled_20261027/visual_stuck_sda_recovered.hex");
 $display("PASS: visual OLED realI2C headers, signed1X/4X/16X clipping, frozen mode/gain/PCM/bars, spectrum4pixel bins/valid publication, mono64sample XY diamond/4Xclipped frozen corners, exact wave step columns, autonomous refresh, NACK/absent/stuck buses (DIV=%0d address=%02x)",DIV,SLAVE_ADDRESS);$finish;
end
initial begin wait(rst_n);wait(transactions>=2);@(negedge scl);stretch=1;repeat(20)@(negedge clk);stretch=0;end
initial begin #(SMOKE ? 300000000 : 90000000);$fatal(1,"visual OLED test timeout");end
endmodule
