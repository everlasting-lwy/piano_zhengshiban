"""Read-only RTL image contract; no physical disks or SD devices."""
import ctypes, hashlib, os, subprocess, sys
from pathlib import Path
import fat32_fixture as images
ROOT=images.ROOT
HERE=images.HERE/'reader_v2'
HERE.mkdir(exist_ok=True)
images.HERE=HERE
B=Path(os.environ.get('IVERILOG_BIN',str(ROOT.parent/'piano/tmp/iverilog/mingw64/bin')))
env=os.environ.copy();env['PATH']=str(B)+os.pathsep+r'C:\mingw64\bin'+os.pathsep+env['PATH'];env['TMP']=env['TEMP']=str(ROOT/'tmp')
if os.name=='nt':ctypes.windll.kernel32.SetErrorMode(0x8003)
sys.stdout.reconfigure(encoding='utf-8')
def run(command):
 p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=240)
 print(p.stdout+p.stderr,end='',flush=True);p.check_returncode()
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.digest()
cases=sys.argv[1:] or ['super','mbr','active','single','spc8','last_entry','last_follow','end_self','end_back','end_tail_loop','end_tail_back','bad_geometry','fat16','bad_version','bad_root','bad_spc','bad_fats','bad_root_entries','bad_tot16','bad_fat16','card_bounds','partition_volume_bounds','partition_extent_bounds','cyclic_root','root_bound','cyclic_file','range_file','bad_header','bad_payload','bad_mask','bad_length','readonly','directory','temp','dirty','no_media','busy_stuck','read_io']
for case in cases:
 out=HERE/'reader.vvp';parameters=[]
 if case=='root_bound':parameters=['-Ptb_reader_v2.ROOT_LIMIT=4']
 if case=='busy_stuck':parameters=['-Ptb_reader_v2.IO_LIMIT=1000']
 run([str(B/'iverilog.exe'),'-g2012','-s','tb_reader_v2',*parameters,'-o',str(out),'src/fat32_file_store.v','sim/tb_reader_v2.v'])
 image=HERE/(case+'.img');info=images.fixture(image,case);before=sha(image)
 run([str(B/'vvp.exe'),str(out),f'+IMAGE={image.as_posix()}',f'+CASE={case}',f'+SECTORS={info["total"]}',f'+OLD={HERE.as_posix()}/old.hex'])
 assert sha(image)==before,'RTL changed a read-only image'
 image.unlink()
