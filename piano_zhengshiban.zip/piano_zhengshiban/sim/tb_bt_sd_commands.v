`timescale 1ns/1ps
module tb_bt_sd_commands;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,rx_valid=0;reg[7:0]rx_data=0;wire tx,req;
wire[7:0]cmd;wire[47:0]payload;reg rsp=0;reg[7:0]rsp_cmd=0;reg[47:0]rsp_payload=0;
integer forwarded=0;localparam BIT=8;
bt_link #(.UART_CYCLES(BIT),.MS_CYCLES(50),.RX_TIMEOUT_CYCLES(64)) dut(
.clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),.timbre(2'd0),.octave(2'd0),.mode(2'd0),.volume(4'd15),.voices(4'd0),
.keys(12'd0),.extended_keys(36'd0),.effects_status(48'd0),.visual_ready(1'b0),.visual_command(8'd0),.visual_tx_sequence(8'd0),.visual_payload(48'd0),.tx(tx),
.guide_request(req),.guide_request_command(cmd),.guide_request_payload(payload),.guide_response_valid(rsp),.guide_response_command(rsp_cmd),.guide_response_payload(rsp_payload));
always@(posedge clk)begin
rsp<=0;if(req)begin forwarded<=forwarded+1;rsp<=1;
rsp_cmd<=(cmd==8'h16)?8'h8b:(cmd==8'h19)?8'h8c:(cmd==8'h1a)?8'h8d:(cmd==8'h1b)?8'h8e:8'h80;
rsp_payload<=(cmd==8'h16)?48'h090064000101:(cmd==8'h19)?48'h010600020101:(cmd==8'h1a)?48'h6f6e61695000:(cmd==8'h1b)?48'h0201cafebabe:{24'd0,8'd1,8'd0,cmd};
end end
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
function[7:0]crc8;input[63:0]bits;reg[7:0]c;integer i,j;begin c=0;for(i=0;i<8;i=i+1)begin c=c^bits[i*8+:8];for(j=0;j<8;j=j+1)c=c[7]?(c<<1)^8'h07:c<<1;end crc8=c;end endfunction
task put;input[7:0]v;begin rx_data=v;rx_valid=1;clocks(1);rx_valid=0;clocks(1);end endtask
task send;input[7:0]seq,op;input[47:0]p;integer i;begin put(8'ha5);put(8'h5a);put(seq);put(op);for(i=0;i<6;i=i+1)put(p[i*8+:8]);put(crc8({p,op,seq}));put(8'h0d);end endtask
reg[95:0]packets[0:31],partial=0;reg[7:0]octet;integer count=0,index=0,j;
initial forever begin @(negedge tx);clocks(BIT+BIT/2);for(j=0;j<8;j=j+1)begin octet[j]=tx;clocks(BIT);end
if(tx!==1)$fatal(1,"bad UART stop");partial[index*8+:8]=octet;
if(index==11)begin if(partial[15:0]!==16'h5aa5||partial[95:88]!==8'h0d||partial[87:80]!==crc8(partial[79:16]))$fatal(1,"SD response CRC");packets[count]=partial;count=count+1;partial=0;index=0;end else index=index+1;end
task expect_reply;input integer n;input[7:0]s,c;integer ticks;begin ticks=0;while(count<=n&&ticks<2000)begin clocks(1);ticks=ticks+1;end
if(count<=n||packets[n][23:16]!==s||packets[n][31:24]!==c)$fatal(1,"SD command forwarding failed seq%h cmd%h actual%h",s,c,packets[n]);end endtask
integer k;reg[7:0]expected;
initial begin clocks(5);rst_n=1;clocks(5);
for(k=0;k<6;k=k+1)begin send(8'ha0+k,8'h16+k,k);expected=(k==0)?8'h8b:(k==3)?8'h8c:(k==4)?8'h8d:(k==5)?8'h8e:8'h80;expect_reply(k,8'ha0+k,expected);end
if(forwarded!=6)$fatal(1,"not every SD command forwarded");
for(k=0;k<8;k=k+1)begin
 send(8'hb0+k,(k==7)?8'h28:8'h20+k,k);expect_reply(6+k,8'hb0+k,8'h80);
end
if(forwarded!=14)$fatal(1,"sector RPC commands were not forwarded");
send(8'hc0,8'h1c,0);expect_reply(14,8'hc0,8'h80);
send(8'hc1,8'h1d,0);expect_reply(15,8'hc1,8'h80);
send(8'hc2,8'h27,0);expect_reply(16,8'hc2,8'h80);
if(forwarded!=14||packets[14][47:40]!==2||packets[15][47:40]!==2||packets[16][47:40]!==2)$fatal(1,"private/unassigned command exposed on Bluetooth");
$display("PASS: fourteen SD/RPC commands framed UART sequence/CRC and private/unassigned command isolation");$finish;end
initial begin#1000000;$fatal(1,"BT SD timeout");end
endmodule
