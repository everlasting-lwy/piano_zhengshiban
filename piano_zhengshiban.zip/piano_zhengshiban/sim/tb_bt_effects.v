`timescale 1ns/1ps
module tb_bt_effects;
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0,rx_valid=0;
    reg [7:0] rx_data=0;
    reg [1:0] timbre=0,octave=0;
    reg [3:0] volume=15;
    reg [11:0] physical=0;
    wire [11:0] remote;
    wire [35:0] remote36;
    reg [35:0] physical36=0;
    wire [35:0] extended_keys=physical36|remote36|({24'd0,remote}<<12);
    wire extended_mode;
    wire [11:0] keys=physical|remote;
    wire [1:0] new_timbre,new_octave;
    wire [3:0] new_volume;
    wire te,oe,ve,tx,legacy_ready,overflow;
    localparam BIT=16;
    reg [47:0] effects_status=48'h3188A1F4C2B3;
    wire[7:0] effect_command,visual_sequence;wire effect_en,visual_start;
    wire[2:0] visual_kind;wire[31:0] device_millis;
    reg visual_ready=0;wire visual_take;
    integer effects_count=0,starts=0,takes=0;
    reg[7:0] last_effect;
    always @(posedge clk)begin
      if(effect_en)begin effects_count=effects_count+1;last_effect=effect_command;end
      if(visual_start)starts=starts+1;
      if(visual_take)begin takes=takes+1;visual_ready<=0;end
    end
    bt_link #(.UART_CYCLES(BIT),.MS_CYCLES(50),.RX_TIMEOUT_CYCLES(64)) dut(
        .clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
        .timbre(timbre),.octave(octave),.mode(2'd2),.volume(volume),.voices(4'h3),.keys(keys),
        .extended_keys(extended_keys),.remote_extended_keys(remote36),.extended_mode(extended_mode),
        .set_timbre(new_timbre),.set_octave(new_octave),.set_volume(new_volume),
        .timbre_en(te),.octave_en(oe),.volume_en(ve),.remote_keys(remote),
        .effects_status(effects_status),.effect_command(effect_command),.effect_en(effect_en),
        .visual_kind(visual_kind),.visual_start(visual_start),.visual_sequence(visual_sequence),.device_millis(device_millis),
        .visual_ready(visual_ready),.visual_take(visual_take),.visual_command(8'h86),
        .visual_tx_sequence(8'ha6),.visual_payload(48'h123456780104),
        .tx(tx),.legacy_ready(legacy_ready),.event_overflow(overflow));
    always @(posedge clk) begin
        if(te)timbre<=new_timbre;if(oe)octave<=new_octave;if(ve)volume<=new_volume;
    end
    function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
        c=0;
        for(i=0;i<8;i=i+1) begin c=c^b[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
        crc8=c;
    end endfunction
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task byte_in;input [7:0] value;begin rx_data=value;rx_valid=1;clocks(1);rx_valid=0;clocks(1);end endtask
    task request;input [7:0] seq,op;input [47:0] p;input bad;integer k;begin
        byte_in(8'hA5);byte_in(8'h5A);byte_in(seq);byte_in(op);
        for(k=0;k<6;k=k+1)byte_in(p[k*8 +:8]);
        byte_in(crc8({p,op,seq})^{7'd0,bad});byte_in(8'h0D);clocks(8);
    end endtask
    reg [95:0] packets[0:511];
    reg [95:0] partial=0;
    reg [7:0] wire_byte;
    integer count=0,index=0,j;
    initial forever begin
        @(negedge tx);clocks(BIT+BIT/2);
        for(j=0;j<8;j=j+1)begin wire_byte[j]=tx;clocks(BIT);end
        if(tx!==1) $fatal(1,"BT TX stop bit");
        partial[index*8 +:8]=wire_byte;
        if(index==11)begin
            if(partial[15:0]!==16'h5AA5 || partial[95:88]!==8'h0D || partial[87:80]!==crc8(partial[79:16]))
                $fatal(1,"Bad outgoing BT wire frame %h",partial);
            if(count>=512)$fatal(1,"Response overflow");
            packets[count]=partial;count=count+1;partial=0;index=0;
        end else index=index+1;
    end
    reg [47:0] response;
    task reply;input [7:0] seq,op;integer n,k;reg found;begin
        n=0;found=0;
        while(n<50000 && !found)begin
            for(k=0;k<count;k=k+1)if(packets[k][23:16]==seq && packets[k][31:24]==op)begin
                found=1;response=packets[k][79:32];
            end
            if(!found)begin clocks(50);n=n+50;end
        end
        if(!found)$fatal(1,"Missing reply seq=%h op=%h",seq,op);
    end endtask
    integer n,i,start_count,ack_index,event_index,bulk_index;
    reg[7:0] expected;
    initial begin
        clocks(8);rst_n=1;clocks(8);
        request(1,12,0,0);reply(1,8'h85);
        if(response!==effects_status)$fatal(1,"Effects85 bit layout/sequence mismatch");
        for(i=0;i<8;i=i+1)begin
            n=(i==4)?16:(i>=6)?2:15;
            case(i)
             0:expected=8'h1f;1:expected=8'h2f;2:expected=8'h3f;3:expected=8'haf;
             4:expected=8'hc0;5:expected=8'hdf;6:expected=8'h52;7:expected=8'h72;
            endcase
            request(10+i,13,(n<<8)|i,0);reply(10+i,8'h80);
            if(response[15:8]!==0 || last_effect!==expected || effects_count!=i+1)
                $fatal(1,"Effect id%0d did not produce exactly one correct register command",i);
            request(30+i,13,((n+1)<<8)|i,0);reply(30+i,8'h80);
            if(response[15:8]!==1 || effects_count!=i+1)$fatal(1,"Out-of-range effect changed state");
        end
        request(50,13,48'h010008,0);reply(50,8'h80);
        if(response[15:8]!==1 || effects_count!=8)$fatal(1,"Invalid ID/reserved byte accepted");
        request(51,13,48'h010100,0);reply(51,8'h80);
        if(response[15:8]!==1 || effects_count!=8)$fatal(1,"Reserved setting payload accepted");
        request(52,13,48'h000300,1);clocks(4000);
        if(effects_count!=8)$fatal(1,"Bad CRC changed effect");
        request(53,12,1,0);reply(53,8'h80);
        if(response[15:8]!==1)$fatal(1,"Dirty effects query accepted");
        request(54,14,4,0);reply(54,8'h80);
        if(visual_kind!==4 || visual_sequence!==54 || starts!=1 || response[15:8]!==0)
            $fatal(1,"Visual request did not latch kind/sequence once");
        request(55,14,5,0);reply(55,8'h80);
        if(starts!=1 || response[15:8]!==1)$fatal(1,"Invalid visual kind changed acquisition");
        request(56,14,48'h0101,0);reply(56,8'h80);
        if(starts!=1 || response[15:8]!==1)$fatal(1,"Reserved visual payload accepted");
        // The visual source must lose priority to both control replies and physical events.
        clocks(4000);start_count=count;
        request(8'ha7,2,9,0);physical=1;visual_ready=1;
        reply(8'ha7,8'h80);reply(8'ha6,8'h86);clocks(2000);
        ack_index=-1;event_index=-1;bulk_index=-1;
        for(i=start_count;i<count;i=i+1)begin
            if(packets[i][31:24]==8'h80 && packets[i][23:16]==8'ha7)ack_index=i;
            if(packets[i][31:24]==8'h82 && event_index<0)event_index=i;
            if(packets[i][31:24]==8'h86)bulk_index=i;
        end
        if(ack_index<0||event_index<0||bulk_index<=ack_index||bulk_index<=event_index||takes!=1)
            $fatal(1,"Bulk telemetry preempted ACK/key event or consumed twice");
        if(response!==48'h123456780104)$fatal(1,"Bulk packet payload mixed into ordinary serializer");
        request(57,14,0,0);reply(57,8'h80);
        if(visual_kind!==0 || starts!=2)$fatal(1,"Off did not cancel snapshot");
        request(58,11,0,0);reply(58,8'h83);
        if(response[46:40]!==7'h22)$fatal(1,"Old36 capability broken");
        request(59,15,0,0);reply(59,8'h80);
        if(response[15:8]!==2)$fatal(1,"Unknown extension command not rejected");
        $display("PASS: BT effects85/setters/all bounds/CRC, visual request/cancel, atomic wire CRC and ACK/events above bulk");$finish;
    end
    initial begin #60000000;$fatal(1,"BT effects timeout");end
endmodule
