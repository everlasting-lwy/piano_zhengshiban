`timescale 1ns/1ps
module tb_seg595_bridge;
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0;
    reg [5:0] sel = 6'b111110;
    reg [7:0] seg = 8'hF9;
    wire ds, sh_cp, st_cp;
    seg595_bridge #(.HALF_PERIOD(2)) dut(
        .clk(clk), .rst_n(rst_n), .seg_sel(sel), .seg_led(seg),
        .ds(ds), .sh_cp(sh_cp), .st_cp(st_cp)
    );
    reg [15:0] received = 0;
    integer bits = 0, frames = 0;
    always @(posedge sh_cp) begin
        if (rst_n) begin
            received = {received[14:0], ds};
            bits = bits + 1;
        end
    end
    always @(posedge st_cp) begin
        if (rst_n) begin
            if (bits != 16) $fatal(1, "Expected 16 shift clocks per latch, got %0d", bits);
            if (frames == 0 && received !== 16'hF901)
                $fatal(1, "First digit/polarity/bit order incorrect: %h", received);
            if (frames == 1 && received !== 16'h8000)
                $fatal(1, "Unused digits must be off; invalid input must blank: %h", received);
            if (frames == 2 && received !== 16'h0020)
                $fatal(1, "Leftmost used digit / decimal point incorrect: %h", received);
            frames = frames + 1;
            bits = 0;
        end
    end
    initial begin
        repeat (5) @(negedge clk);
        rst_n = 1;
        // Change inputs halfway through a word: the first word must remain atomic.
        repeat (15) @(negedge clk);
        sel = 6'b111111;
        seg = 8'h80;
        wait (frames == 1);
        // All six selects inactive means all eight digits off (0x00).
        wait (frames == 2);
        @(negedge clk);
        sel = 6'b011111;
        seg = 8'h00;
        wait (frames == 3);
        @(negedge clk);
        rst_n = 0;
        repeat (2) @(negedge clk);
        if ({ds,sh_cp,st_cp} !== 3'b000) $fatal(1, "Reset must idle serial pins");
        $display("PASS: 595 serial ordering, atomic frame, active-high select, decimal point, reset");
        $finish;
    end
    initial begin #100000; $fatal(1, "595 test timed out"); end
endmodule
