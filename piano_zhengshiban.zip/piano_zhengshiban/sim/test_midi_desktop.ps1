$ErrorActionPreference='Stop'
$tools=Join-Path $PSScriptRoot '../tools'
$sources=@((Join-Path $tools 'FpgaMidiSpeakers.cs'))+@(Get-ChildItem (Join-Path $tools 'desktop') -Filter '*.cs' | Select-Object -ExpandProperty FullName)
Add-Type -Path $sources -ReferencedAssemblies System.dll,System.Core.dll,System.Drawing.dll,System.Windows.Forms.dll
function Assert($condition,[string]$reason){if(-not $condition){throw $reason}}
$form=New-Object PianoDesktop.PianoForm
$flags=[System.Reflection.BindingFlags]'NonPublic,Instance'
function Field([string]$name){$form.GetType().GetField($name,$flags).GetValue($form)}
try {
    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()
    $refresh=Field 'refresh'
    $refresh.Stop()
    $session=Field 'connection'
    $session.Monitor.Accept(0x784D90,0x7F4D90,100)
    $form.GetType().GetMethod('RefreshMonitor',$flags).Invoke($form,@()) | Out-Null
    Assert ((Field 'noteText').Text -eq 'F5') 'UI must show the received note name'
    Assert ((Field 'rawText').Text -eq '120 / 127' -and (Field 'outputText').Text -eq '127 / 127') 'UI must show raw and applied velocities'
    Assert ((Field 'log').Rows.Count -eq 1) 'UI must append exactly one event'
    $form.GetType().GetMethod('RefreshMonitor',$flags).Invoke($form,@()) | Out-Null
    Assert ((Field 'log').Rows.Count -eq 1) 'Refresh must not duplicate log events'
    $session.Monitor.Accept(0x785990,0x7F5990,200)
    $form.GetType().GetMethod('RefreshMonitor',$flags).Invoke($form,@()) | Out-Null
    Assert ((Field 'keyboard').BaseNote -eq 72) 'Display must follow high-octave notes'
    $form.Size=New-Object System.Drawing.Size(1020,650)
    $form.PerformLayout()
    [System.Windows.Forms.Application]::DoEvents()
    $viewport=$form.Controls[0]
    Assert ($viewport.AutoScroll -and $viewport.Controls[0].Height -ge 760) 'Short screens must retain a scrollable full layout'
    $session.StartDemo()
    Start-Sleep -Milliseconds 100
    $form.Close()
    Assert (-not $session.Running) 'Closing the window must stop the worker'
    Write-Output 'PASS: real WinForms display, event refresh, octave following, short-screen scrolling and close cleanup'
} finally { $form.Dispose() }
