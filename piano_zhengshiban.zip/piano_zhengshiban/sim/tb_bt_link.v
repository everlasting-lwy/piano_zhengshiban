`timescale 1ns/1ps
module tb_bt_link;
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0,rx_valid=0;
    reg [7:0] rx_data=0;
    reg [1:0] timbre=0,octave=0;
    reg [3:0] volume=15;
    reg [11:0] physical=0;
    wire [11:0] remote;
    wire [11:0] keys=physical|remote;
    wire [1:0] new_timbre,new_octave;
    wire [3:0] new_volume;
    wire te,oe,ve,tx,legacy_ready,overflow;
    localparam BIT=16;
    bt_link #(.UART_CYCLES(BIT),.MS_CYCLES(50),.RX_TIMEOUT_CYCLES(64)) dut(
        .clk(clk),.rst_n(rst_n),.rx_data(rx_data),.rx_valid(rx_valid),
        .timbre(timbre),.octave(octave),.mode(2'd2),.volume(volume),.voices(4'h3),.keys(keys),
        .set_timbre(new_timbre),.set_octave(new_octave),.set_volume(new_volume),
        .timbre_en(te),.octave_en(oe),.volume_en(ve),.remote_keys(remote),
        .tx(tx),.legacy_ready(legacy_ready),.event_overflow(overflow));
    always @(posedge clk) begin
        if(te)timbre<=new_timbre;if(oe)octave<=new_octave;if(ve)volume<=new_volume;
    end
    function [7:0] crc8;input [63:0] b;integer k,i;reg [7:0] c;begin
        c=0;
        for(i=0;i<8;i=i+1) begin c=c^b[i*8 +:8];for(k=0;k<8;k=k+1)c=c[7]?(c<<1)^8'h07:c<<1;end
        crc8=c;
    end endfunction
    task clocks;input integer n;begin repeat(n) @(negedge clk);end endtask
    task byte_in;input [7:0] value;begin rx_data=value;rx_valid=1;clocks(1);rx_valid=0;clocks(1);end endtask
    task request;input [7:0] seq,op;input [47:0] p;input bad;integer k;begin
        byte_in(8'hA5);byte_in(8'h5A);byte_in(seq);byte_in(op);
        for(k=0;k<6;k=k+1)byte_in(p[k*8 +:8]);
        byte_in(crc8({p,op,seq})^{7'd0,bad});byte_in(8'h0D);clocks(8);
    end endtask
    reg [95:0] packets[0:511];
    reg [95:0] partial=0;
    reg [7:0] wire_byte;
    integer count=0,index=0,j;
    initial forever begin
        @(negedge tx);clocks(BIT+BIT/2);
        for(j=0;j<8;j=j+1)begin wire_byte[j]=tx;clocks(BIT);end
        if(tx!==1) $fatal(1,"BT TX stop bit");
        partial[index*8 +:8]=wire_byte;
        if(index==11)begin
            if(partial[15:0]!==16'h5AA5 || partial[95:88]!==8'h0D || partial[87:80]!==crc8(partial[79:16]))
                $fatal(1,"Bad outgoing BT wire frame %h",partial);
            if(count>=512)$fatal(1,"Response overflow");
            packets[count]=partial;count=count+1;partial=0;index=0;
        end else index=index+1;
    end
    reg [47:0] response;
    task reply;input [7:0] seq,op;integer n,k;reg found;begin
        n=0;found=0;
        while(n<50000 && !found)begin
            for(k=0;k<count;k=k+1)if(packets[k][23:16]==seq && packets[k][31:24]==op)begin
                found=1;response=packets[k][79:32];
            end
            if(!found)begin clocks(50);n=n+50;end
        end
        if(!found)$fatal(1,"Missing reply seq=%h op=%h",seq,op);
    end endtask
    integer n,i;
    reg [31:0] last_time;
    initial begin
        clocks(8);rst_n=1;clocks(8);
        request(1,2,6,0);
        if(volume!==6)$fatal(1,"Framed Bluetooth parameter not applied");
        reply(1,8'h80);
        if(response[23:0]!==24'h010002)$fatal(1,"ACK payload/version");
        request(2,1,4,0);reply(2,8'h80);
        if(response[15:8]!==1 || timbre!==0)$fatal(1,"Bad parameter mutated state");
        request(3,4,48'h1000,0);reply(3,8'h80);
        if(response[15:8]!==1 || remote!==0)$fatal(1,"Reserved key bits accepted");
        request(4,8'h7F,0,0);reply(4,8'h80);
        if(response[15:8]!==2)$fatal(1,"Unknown command not rejected");
        request(5,2,12,1);clocks(5000);
        if(volume!==6)$fatal(1,"Bad CRC changed volume");
        request(6,4,48'h801,0);reply(6,8'h80);
        if(remote!==12'h801 || legacy_ready!==0)$fatal(1,"12-key mask / framing lock");
        physical=12'h002;
        request(7,5,0,0);reply(7,8'h80);
        if(remote!==0 || keys!==12'h002)$fatal(1,"Phone release affected physical key");
        request(8,6,0,0);reply(8,8'h81);
        if(response!==48'h300202000600)$fatal(1,"Status snapshot payload %h",response);
        // Remote hold is maintained by heartbeat, then expires without it.
        request(9,4,1,0);reply(9,8'h80);clocks(60000);
        request(10,7,1,0);reply(10,8'h80);clocks(60000);
        if(remote!==1)$fatal(1,"Heartbeat failed to maintain held key");
        clocks(42000);
        if(remote!==0 || keys!==2)$fatal(1,"Watchdog did not release only remote keys");
        // Stress the recording FIFO explicitly; loss must be visible to APP.
        for(i=0;i<60;i=i+1)begin physical=physical^12'h004;clocks(2);end
        clocks(8);
        if(overflow!==1)$fatal(1,"Event FIFO overflow was silent");
        request(11,6,0,0);reply(11,8'h81);
        if(response[31]!==1)$fatal(1,"Status omitted overflow flag");
        request(12,8,0,0);reply(12,8'h80);
        if(overflow!==0)$fatal(1,"Clear overflow command");
        n=0;last_time=0;
        for(i=0;i<count;i=i+1)if(packets[i][31:24]==8'h82)begin
            if(packets[i][63:32]<last_time)$fatal(1,"Recorded timestamps not monotonic");
            last_time=packets[i][63:32];n=n+1;
        end
        if(n<3)$fatal(1,"No timestamped key events");
        $display("PASS: BT ACK/status/CRC, reserved parameters, 12-key on/off, physical isolation, heartbeat timeout, event timestamps/overflow");$finish;
    end
    initial begin #20000000;$fatal(1,"BT link timeout");end
endmodule
