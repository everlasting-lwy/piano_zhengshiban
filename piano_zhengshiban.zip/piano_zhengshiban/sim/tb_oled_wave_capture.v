`timescale 1ns/1ps
module tb_oled_wave_capture;
    reg clk = 0;
    always #10 clk = ~clk;
    reg rst_n = 0;
    reg sample_valid = 0;
    reg signed [15:0] sample = 0;
    reg snapshot_request = 0;
    reg [6:0] read_index = 0;
    wire snapshot_ready;
    wire [5:0] y_top, y_bottom;
    integer ready_count = 0;
    reg previous_ready = 0;
    integer i;
    integer before_count;

    oled_wave_capture dut (
        .clk(clk), .rst_n(rst_n), .sample_valid(sample_valid), .sample(sample),
        .snapshot_request(snapshot_request), .snapshot_ready(snapshot_ready),
        .read_index(read_index), .y_top(y_top), .y_bottom(y_bottom)
    );

    // The one-sample settings exercise the counter terminal values rather than
    // allowing the default four-sample path to hide an off-by-one.
    reg small_rst_n = 0, small_valid = 0, small_request = 0;
    reg signed [15:0] small_sample = 0;
    reg [6:0] small_index = 0;
    wire small_ready;
    wire [5:0] small_top, small_bottom;
    oled_wave_capture #(.DECIMATE(1), .TRIGGER_TIMEOUT(1)) single_sample (
        .clk(clk), .rst_n(small_rst_n), .sample_valid(small_valid), .sample(small_sample),
        .snapshot_request(small_request), .snapshot_ready(small_ready),
        .read_index(small_index), .y_top(small_top), .y_bottom(small_bottom)
    );

    always @(posedge clk) begin
        #1;
        if (!rst_n) begin
            previous_ready = 0;
        end else begin
            if (snapshot_ready && previous_ready)
                $fatal(1, "snapshot_ready lasted more than one clock");
            if (snapshot_ready)
                ready_count = ready_count + 1;
            previous_ready = snapshot_ready;
        end
    end

    task step;
        input valid_value;
        input integer pcm_value;
        input request_value;
        begin
            @(negedge clk);
            sample_valid = valid_value;
            sample = pcm_value;
            snapshot_request = request_value;
            @(posedge clk);
            #2;
        end
    endtask

    task no_ready;
        input integer expected_count;
        begin
            if (snapshot_ready || ready_count != expected_count)
                $fatal(1, "premature/extra snapshot at %0t, count %0d expected %0d",
                       $time, ready_count, expected_count);
        end
    endtask

    task ready_now;
        input integer expected_count;
        begin
            if (!snapshot_ready || ready_count != expected_count)
                $fatal(1, "missing snapshot on exact last sample at %0t, count %0d expected %0d",
                       $time, ready_count, expected_count);
        end
    endtask

    task read_expect;
        input integer index_value;
        input integer top_value;
        input integer bottom_value;
        reg [5:0] held_top, held_bottom;
        begin
            held_top = y_top;
            held_bottom = y_bottom;
            read_index = index_value;
            #1;
            if (y_top !== held_top || y_bottom !== held_bottom)
                $fatal(1, "RAM read changed before a clock at index %0d", index_value);
            step(0, 0, 0);
            if (y_top !== top_value[5:0] || y_bottom !== bottom_value[5:0])
                $fatal(1, "column %0d got %0d..%0d expected %0d..%0d",
                       index_value, y_top, y_bottom, top_value, bottom_value);
        end
    endtask

    task constant_frame;
        input integer top_value;
        input integer bottom_value;
        begin
            for (i = 0; i < 128; i = i + 1)
                read_expect(i, top_value, bottom_value);
        end
    endtask

    initial begin
        // A broken mapper, missing last sample, early bank exchange, restarted
        // busy request, asynchronous read, or timeout clock counter must fail
        // a public-port assertion below. Expectations are hand-checked pixels.
        repeat (3) step(0, 0, 0);
        rst_n = 1;
        read_expect(0, 32, 32);
        read_expect(127, 32, 32);

        // Trigger sample is included even when it coincides with the request.
        step(1, -1, 0);
        step(1, 1024, 1);
        no_ready(0);
        for (i = 1; i < 512; i = i + 1) begin
            case (i)
                1: step(1, 32767, 0);
                2: step(1, -32768, 0);
                3: step(1, -1, 0);
                4: step(1, -1024, 0);
                5: step(1, -1025, 0);
                6: step(1, 1023, 0);
                7: step(1, 1024, 0);
                8, 9, 10, 11: step(1, 2048, (i == 10));
                511: step(1, 32767, 1);
                default: step(1, 0, (i == 129));
            endcase
            if (i < 511) no_ready(0);
            if (i == 100) begin
                step(0, -32768, 1); // Invalid samples cannot fill a bucket.
                no_ready(0);
            end
        end
        ready_now(1);
        read_expect(0, 1, 63);
        read_expect(1, 1, 63);
        read_expect(2, 30, 34);
        read_expect(3, 30, 32);
        read_expect(4, 32, 32);
        read_expect(126, 32, 32);
        read_expect(127, 1, 32);

        // No request: arbitrary PCM cannot modify the visible bank or queue a
        // request that arrived while the previous capture was busy.
        for (i = 0; i < 1100; i = i + 1) begin
            step(1, (i[0] ? -32768 : 32767), 0);
            no_ready(1);
        end
        read_expect(127, 1, 32);

        // Silence cannot cross zero. Exactly 512 VALID waiting samples starts
        // capture, including that timeout sample as the first of 512 samples.
        // Interspersed invalid negative values must not create a crossing.
        step(1, 0, 0);
        step(0, 0, 1);
        for (i = 1; i <= 511; i = i + 1) begin
            step(1, 0, (i == 200));
            no_ready(1);
            if (i == 100) begin
                repeat (600) step(0, -32768, 0);
                read_expect(0, 1, 63);
                no_ready(1);
            end
        end
        read_expect(127, 1, 32);
        step(1, 0, 1); // Waiting sample 512; busy request is ignored.
        no_ready(1);
        for (i = 1; i < 511; i = i + 1) begin
            step(1, 0, (i == 100));
            no_ready(1);
        end
        read_expect(127, 1, 32); // Last visible column remains frozen.
        step(1, 0, 1);
        ready_now(2);
        constant_frame(32, 32);

        // Negative DC also refreshes; arithmetic shift must round -1025 down
        // to -2, giving y34, instead of logical shift or division toward zero.
        step(1, -1025, 1); // First waiting sample coincides with request.
        for (i = 1; i < 512; i = i + 1) begin
            step(1, -1025, 0);
            no_ready(2);
        end
        for (i = 1; i < 511; i = i + 1) begin
            step(1, -1025, 0);
            no_ready(2);
        end
        step(1, -1025, 0);
        ready_now(3);
        constant_frame(34, 34);

        // Individual signed boundaries and the very last sample affect pixels.
        step(1, -1, 0);
        step(1, 0, 1);
        for (i = 1; i < 512; i = i + 1) begin
            case (i)
                1: step(1, -1, 0);
                2: step(1, -1024, 0);
                3: step(1, -1025, 0);
                4, 5, 6, 7: step(1, 32767, 0);
                8, 9, 10, 11: step(1, -32768, 0);
                12: step(1, 31744, 0);
                13: step(1, 31743, 0);
                14: step(1, -31744, 0);
                15: step(1, -31745, 0);
                511: step(1, -32768, 0);
                default: step(1, 0, 0);
            endcase
            if (i < 511) no_ready(3);
        end
        ready_now(4);
        read_expect(0, 32, 34);
        read_expect(1, 1, 34);
        read_expect(2, 1, 63);
        read_expect(3, 1, 63);
        read_expect(4, 1, 63);
        read_expect(5, 32, 32);
        read_expect(126, 32, 32);
        read_expect(127, 32, 63);

        // Reset aborts capture and invalidates both banks without depending on
        // RAM contents. A fresh capture must overwrite all 128 visible columns.
        step(1, -1, 0);
        step(1, 1024, 1);
        repeat (100) step(1, 1024, 0);
        @(negedge clk);
        rst_n = 0;
        snapshot_request = 0;
        sample_valid = 0;
        #2;
        if (snapshot_ready || y_top !== 32 || y_bottom !== 32)
            $fatal(1, "reset did not immediately invalidate the visible frame");
        step(0, 0, 0);
        rst_n = 1;
        read_expect(0, 32, 32);
        read_expect(127, 32, 32);
        before_count = ready_count;
        repeat (1100) step(1, 0, 0);
        no_ready(before_count);
        step(1, -1, 0);
        step(1, 1024, 1);
        repeat (510) begin
            step(1, 1024, 0);
            no_ready(before_count);
        end
        step(1, 1024, 0);
        ready_now(before_count + 1);
        constant_frame(31, 31);

        // A request can arm before the crossing, and invalid samples between
        // the negative and nonnegative values do not change trigger history.
        step(0, 0, 1);
        step(1, -32768, 0);
        repeat (10) step(0, 32767, 0);
        no_ready(before_count + 1);
        step(1, 0, 0);
        repeat (510) begin
            step(1, -1, 0);
            no_ready(before_count + 1);
        end
        step(1, -1, 0);
        ready_now(before_count + 2);
        read_expect(0, 32, 33);
        read_expect(1, 32, 33);
        read_expect(2, 33, 33);
        read_expect(126, 33, 33);
        read_expect(127, 33, 33);

        // Minimal legal parameter values: first/last sample and frame width.
        @(negedge clk);
        small_rst_n = 1;
        small_valid = 1;
        small_request = 1;
        small_sample = 32767;
        @(posedge clk); #2;
        if (small_ready) $fatal(1, "DECIMATE=1 frame completed before 128 samples");
        for (i = 1; i < 128; i = i + 1) begin
            @(negedge clk);
            small_request = (i == 50);
            small_sample = i[0] ? -32768 : 32767;
            @(posedge clk); #2;
            if (small_ready !== (i == 127))
                $fatal(1, "DECIMATE=1 completion at sample %0d", i);
        end
        @(negedge clk); small_valid = 0; small_request = 0; small_index = 0;
        @(posedge clk); #2;
        if (small_top !== 1 || small_bottom !== 1 || small_ready)
            $fatal(1, "DECIMATE=1 first column or ready pulse wrong");
        small_index = 127;
        #1;
        if (small_top !== 1 || small_bottom !== 1)
            $fatal(1, "DECIMATE=1 read was asynchronous");
        @(posedge clk); #2;
        if (small_top !== 1 || small_bottom !== 63)
            $fatal(1, "DECIMATE=1 final/connected column wrong");

        $display("PASS: OLED capture signed min/max, connected 128 columns, exact trigger/timeout, frozen banks, synchronous read, busy requests, reset, parameter boundaries");
        $finish;
    end

    initial begin
        #10000000;
        $fatal(1, "capture test timeout");
    end
endmodule
