`timescale 1ns/1ps
module tb_wm8960_playback;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,present=1,nack_data=0,stuck=0;
 tri1 scl,sda;
 assign scl=stuck ? 1'b0 : 1'bz;
 wire ready,fault;
 wire [6:0] failed_reg;
 wm8960_playback #(.I2C_DIV(2),.BOOT_CYCLES(20),.RESET_CYCLES(10),
  .BIAS_CYCLES(200),.RETRY_CYCLES(30),.TIMEOUT_CYCLES(100)) dut(
  .clk(clk),.rst_n(rst_n),.scl(scl),.sda(sda),.ready(ready),
  .fault(fault),.failed_reg(failed_reg));
 wm8960_model model(rst_n,present,nack_data,scl,sda);
 integer n,baseline,settle_start=-1,cycle=0;
 always @(posedge clk)begin
  cycle=cycle+1;
  if(rst_n && model.regs[25]==9'h1c0 && settle_start<0)settle_start=cycle;
  if(rst_n && model.regs[25]==9'h0c0 && settle_start>=0 && cycle-settle_start<200)
   $fatal(1,"VMID settling skipped");
  if(rst_n && model.regs[49][7:6]!=0 &&
     (model.regs[25]!=9'h0c0 || model.regs[26]!=9'h110 ||
      model.regs[47]!=9'h008 || model.regs[8]!=9'h1c0))
   $fatal(1,"class D enabled before stable power, routing and switching-clock setup");
  if(rst_n && model.regs[49][7:6]!=0 && model.regs[5]!=9'h008 && !ready)
   // The last transaction may have arrived one controller clock before ready.
   if(dut.reg_index!=18)$fatal(1,"speaker unmuted before final write");
 end
 task reset;
 begin rst_n=0;repeat(5)@(negedge clk);settle_start=-1;rst_n=1;end endtask
 task expect_ready;
 begin
  wait(ready);@(negedge clk);
  if(fault)$fatal(1,"fault retained after successful init");
  if(model.regs[7]!==9'h002 || model.regs[4]!==0 || model.regs[8]!==9'h1c0)
   $fatal(1,"I2S slave/16-bit/direct-MCLK configuration");
  if(model.regs[25]!==9'h0c0 || model.regs[26]!==9'h110 || model.regs[47]!==9'h008)
   $fatal(1,"left-only power/routing");
  if(model.regs[34]!==9'h100 || model.regs[40]!==9'h173 || model.regs[41]!==9'h100)
   $fatal(1,"speaker mixer or conservative PGA gain");
  if(model.regs[49]!==9'h077 || model.regs[51]!==9'h080 || model.regs[5]!==0)
   $fatal(1,"class D enable/reserved bits/final unmute");
  for(n=0;n<model.writes;n=n+1)begin
   if(model.log_reg[n]==49 && model.log_data[n][5:0]!==6'h37)$fatal(1,"R49 reserved bits");
   if(model.log_reg[n]==51 && model.log_data[n][8:6]!==3'b010)$fatal(1,"R51 reserved bits");
  end
  baseline=model.writes;repeat(300)@(negedge clk);
  if(model.writes!=baseline)$fatal(1,"unexpected reinitialization after ready");
 end endtask
 initial begin
  reset;expect_ready;
  if(model.writes!=19 || model.resets!=1 || model.log_reg[0]!=15 || model.log_reg[18]!=5)
   $fatal(1,"startup transaction order/count");
  present=0;reset;wait(fault);repeat(500)@(negedge clk);
  if(ready || model.writes!=0)$fatal(1,"missing device accepted");
  present=1;expect_ready;
  nack_data=1;reset;wait(fault);
  if(ready || failed_reg!=15)$fatal(1,"data NACK accepted");
  nack_data=0;expect_ready;
  stuck=1;reset;wait(fault);
  if(ready || dut.writer.scl_low || dut.writer.sda_low)$fatal(1,"stuck bus not released");
  stuck=0;expect_ready;
  reset;wait(model.writes==4);reset;expect_ready;
  $display("PASS: WM8960 register sequence, reserved bits, mute/settling, NACK, timeout, reset and recovery");
  $finish;
 end
 initial begin #20000000;$fatal(1,"codec init test timeout");end
endmodule
