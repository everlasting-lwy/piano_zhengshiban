`timescale 1ns/1ps
module tb_song_export;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,request_valid=0,local_toggle=0,local_restart=0;
reg[7:0]request_command=0;reg[47:0]request_payload=0;reg[17:0]physical_keys=0;
wire response_valid,active,loaded,loading,complete,wrong;
wire[7:0]response_command;wire[47:0]response_payload;wire[17:0]target;wire[11:0]step,total_steps;
song_guide dut(.*);
task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
function[15:0]crcbyte;input[15:0]old;input[7:0]v;integer i;reg[15:0]c;begin c=old^{v,8'd0};for(i=0;i<8;i=i+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end endfunction
function[15:0]crcmask;input[15:0]old;input[17:0]m;begin crcmask=crcbyte(crcbyte(crcbyte(old,m[7:0]),m[15:8]),{6'd0,m[17:16]});end endfunction
task req;input[7:0]c;input[47:0]p;input[7:0]r;integer n;begin
request_command=c;request_payload=p;request_valid=1;clocks(1);request_valid=0;n=0;
while(!response_valid&&n<8)begin clocks(1);n=n+1;end
if(!response_valid||response_command!==r)$fatal(1,"command %h missing response %h actual%h",c,r,response_command);
end endtask
task ack;input[7:0]c;input[47:0]p;begin req(c,p,8'h80);if(response_payload!=={24'd0,8'd1,8'd0,c})$fatal(1,"ACK failed %h",response_payload);clocks(2);end endtask
task unsupported;input[7:0]c;input[47:0]p;begin
req(c,p,8'h80);if(response_payload!=={24'd0,8'd1,8'd2,c})$fatal(1,"removed private command was accepted %h",response_payload);clocks(2);
end endtask
reg[15:0]crc;integer j;
initial begin
clocks(3);rst_n=1;clocks(3);
unsupported(8'h1c,0);unsupported(8'h1d,0);
if(loaded||loading||active||target!==0)$fatal(1,"private rejection changed reset state");
crc=crcmask(crcmask(crcmask(16'hffff,18'h1),18'h3081),18'h20000);
ack(8'h10,{8'd0,8'd1,crc,16'd3});
ack(8'h11,{8'd0,24'h1,16'd0});ack(8'h11,{8'd0,24'h3081,16'd1});ack(8'h11,{8'd0,24'h20000,16'd2});ack(8'h12,0);
if(!loaded||loading||target!==1||step!==0||total_steps!==3)$fatal(1,"ordinary upload publication");
unsupported(8'h1c,0);unsupported(8'h1c,48'hffffffffffff);
for(j=0;j<3;j=j+1)unsupported(8'h1d,j);
ack(8'h13,1);clocks(4);
// Rejected private traffic must not disturb the synchronous next-step read.
physical_keys=1;request_command=8'h1d;request_payload=2;request_valid=1;clocks(1);request_valid=0;
if(!response_valid||response_command!==8'h80||response_payload!==48'h00000001021d)$fatal(1,"concurrent private rejection");
for(j=0;j<8;j=j+1)begin
if(step==1&&target!==18'h3081)$fatal(1,"private rejection corrupted published step/target");
clocks(1);end
if(step!==1||target!==18'h3081)$fatal(1,"key progress blocked by unsupported command");
unsupported(8'h1c,0);unsupported(8'h1d,48'hffffffffffff);
if(step!==1||target!==18'h3081)$fatal(1,"held key advanced without release");
physical_keys=0;clocks(3);
physical_keys=18'h3081;clocks(6);
if(step!==2||target!==18'h20000)$fatal(1,"ordinary chord advancement failed");
ack(8'h10,{8'd0,8'd1,16'd0,16'd1});ack(8'h13,4);
unsupported(8'h1c,0);unsupported(8'h1d,1);
if(loading||!loaded||step!==2||target!==18'h20000||total_steps!==3)$fatal(1,"abort/rejection altered published RAM");
physical_keys=0;clocks(3);physical_keys=18'h20000;clocks(6);
if(!complete||step!==3||target!==0)$fatal(1,"ordinary song completion failed");
ack(8'h13,2);if(complete||step!==0||target!==1)$fatal(1,"ordinary restart failed");
ack(8'h13,3);unsupported(8'h1c,0);unsupported(8'h1d,0);
if(loaded||loading||target!==0||total_steps!==0)$fatal(1,"ordinary delete failed");
$display("PASS: removed private 1C/1D reject while ordinary upload, synchronous playback, chord progression, abort/restart/delete remain correct");$finish;
end
initial begin#1000000;$fatal(1,"private-command rejection timeout");end
endmodule
