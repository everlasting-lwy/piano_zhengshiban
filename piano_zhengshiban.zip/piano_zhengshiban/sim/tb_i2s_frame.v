`timescale 1ns/1ps
module tb_i2s_frame;
    reg clk=0;always #10 clk=~clk;
    reg rst=0;
    reg signed [15:0] sample=16'h1234;
    wire bclk,lrck,din,tick;
    wire signed [15:0] pcm_frame;wire pcm_frame_valid;
    i2s_tx dut(.sys_clk(clk),.sys_rst_n(rst),.sample(sample),.sample_tick(tick),
               .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(din),.pcm_frame(pcm_frame),.pcm_frame_valid(pcm_frame_valid));
    reg previous_lrck=1,left_seen=0;
    reg [15:0] word_rx=0,left_word;
    integer bits=0,pairs=0,cycles=0,last_tick=0;
    reg [15:0] tap_word=0;integer taps=0,last_tap=0;reg was_tap=0;
    always @(negedge clk)if(rst)begin
        cycles=cycles+1;
        if(was_tap && pcm_frame_valid)$fatal(1,"PCM tap valid longer than one clock");
        was_tap=pcm_frame_valid;
        if(pcm_frame_valid)begin
            if(last_tap && cycles-last_tap!=1024)$fatal(1,"PCM tap cadence");
            last_tap=cycles;taps=taps+1;tap_word=pcm_frame;
        end
        if(dut.bit_tick && dut.lrck_cnt==20)sample=sample^16'h8D63;
        if(tick)begin
            if(dut.lrck_cnt!=60)$fatal(1,"Need64 clocks between compute tick and slot0 load");
            if(last_tick!=0 && cycles-last_tick!=1024)$fatal(1,"Sample cadence changed");
            last_tick=cycles;
        end
    end
    always @(posedge bclk)if(rst)begin
        if(lrck!=previous_lrck)begin previous_lrck=lrck;bits=0;word_rx=0;end
        else begin
            bits=bits+1;
            if(bits<=16)word_rx={word_rx[14:0],din};
            if(bits==16)begin
                if(lrck)begin
                    if(taps==0 || word_rx!==tap_word)$fatal(1,"PCM tap differs from real serialized word");
                    left_word=word_rx;left_seen=1;
                end
                else if(left_seen)begin
                    if(word_rx!==left_word)$fatal(1,"Left/right split when sample changes between slots");
                    pairs=pairs+1;
                    if(pairs==12)begin
                        $display("PASS:12 atomic I2S stereo frames under mid-frame changes;1024-cycle cadence/64-cycle compute window");
                        $finish;
                    end
                end
            end
        end
    end
    initial begin repeat(4)@(negedge clk);rst=1;end
    initial begin #500000;$fatal(1,"I2S frame test timeout");end
endmodule
