`timescale 1ns/1ps
// Independent pin-level, write-only WM8960 control-port model.
// It never drives a logic high; testbench supplies pullups.
module wm8960_model(input wire rst_n, input wire present,
 input wire nack_data, inout wire scl,sda);
 reg low=0,active=0,ack=0,accepted=0;
 integer bits=0,bytes=0,writes=0,resets=0,i;
 reg [7:0] shift=0,hi=0,lo=0;
 reg [8:0] regs[0:127];
 reg [6:0] log_reg[0:511];
 reg [8:0] log_data[0:511];
 assign sda=low ? 1'b0 : 1'bz;
 task defaults;
 begin
  for(i=0;i<128;i=i+1)regs[i]=0;
  regs[5]=9'h008;regs[49]=9'h037;regs[51]=9'h080;
 end endtask
 initial defaults;
 always @(negedge rst_n)begin
  low=0;active=0;bits=0;bytes=0;writes=0;resets=0;defaults;
 end
 always @(negedge sda)if(scl===1'b1 && rst_n && !low)begin
  active=1;bits=0;bytes=0;accepted=1;
 end
 always @(posedge sda)if(scl===1'b1 && rst_n && active)begin
  active=0;
  if(bytes==3 && accepted)begin
   if(writes>=512)$fatal(1,"codec model transaction overflow");
   log_reg[writes]=hi[7:1];log_data[writes]={hi[0],lo};
   if(hi[7:1]==15)begin defaults;resets=resets+1;end
   else regs[hi[7:1]]={hi[0],lo};
   writes=writes+1;
  end
 end
 always @(posedge scl)if(active && rst_n)begin
  if(bits<8)begin
   shift={shift[6:0],sda};bits=bits+1;
   if(bits==8)begin
    ack=present && (bytes!=0 || shift==8'h34) && !(nack_data && bytes==2);
    accepted=accepted && ack;
    if(bytes==1)hi=shift;
    if(bytes==2)lo=shift;
    bytes=bytes+1;
   end
  end else bits=9;
 end
 always @(negedge scl)if(active && rst_n)begin
  if(bits==8)low=ack;
  else if(bits==9)begin low=0;bits=0;end
 end
endmodule
