`timescale 1ns/1ps
module tb_wm8960_fifth_key;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,present=1,stuck=0;
 reg [17:0] keys=18'h3ffff;
 tri1 scl,sda,oscl,osda,vscl,vsda;
 assign scl=stuck ? 1'b0:1'bz;
 wire bclk,lrck,dac,mclk,bt,uart;
 top_piano_wm8960_acg525 #(.WM_I2C_DIV(2),.WM_BOOT_CYCLES(20),
  .WM_RESET_CYCLES(10),.WM_BIAS_CYCLES(100),.WM_RETRY_CYCLES(100),.WM_TIMEOUT_CYCLES(100),
  .OLED_BOOT_CYCLES(10),.OLED_TIMEOUT_CYCLES(100),.OLED_RETRY_CYCLES(100),
  .VISUAL_BOOT_CYCLES(10),.VISUAL_TIMEOUT_CYCLES(100),.VISUAL_RETRY_CYCLES(100)) dut(
  .sys_clk(clk),.sys_rst_n(rst_n),.key_in(keys),.key_timbre(1'b1),.key_mode(1'b1),
  .key_vol_up(1'b1),.key_vol_down(1'b1),.key_octave(1'b1),.bt_rxd(1'b1),.hc_echo(1'b0),
  .encoder_a(1'b1),.encoder_b(1'b1),.encoder_sw_n(1'b1),
  .visual_encoder_a(1'b1),.visual_encoder_b(1'b1),.visual_encoder_sw_n(1'b1),
  .oled_scl(oscl),.oled_sda(osda),.visual_oled_scl(vscl),.visual_oled_sda(vsda),
  .wm8960_scl(scl),.wm8960_sda(sda),.wm8960_mclk(mclk),
  .i2s_bclk(bclk),.i2s_lrck(lrck),.i2s_din(dac),.bt_txd(bt),.uart_txd(uart));
 wm8960_model model(rst_n,present,1'b0,scl,sda);
 integer cycles=0,mc=0,bc=0,frames=0,nonzero=0,pcm_ticks=0;
 integer last_mc=0,last_bc=0,last_frame=0;
 integer press_cycle=0,first_latency=0;
 reg prev_lr=1,slot=1;
 integer bitn=0;
 reg [15:0] received=0,expected=0;
 always @(posedge clk)begin
  cycles=cycles+1;
  if(rst_n && dut.u_board.pcm_frame_valid)pcm_ticks=pcm_ticks+1;
  #1;
  if(rst_n && !dut.audio_enabled && dac!==0)$fatal(1,"DAC data before ready/frame boundary");
 end
 always @(posedge mclk)if(rst_n && dut.rst_n)begin
  if(mc>0 && cycles-last_mc!=4)$fatal(1,"MCLK not 12.5MHz");
  last_mc=cycles;mc=mc+1;
 end
 always @(posedge bclk)if(rst_n && dut.rst_n)begin
  if(bc>0 && cycles-last_bc!=16)$fatal(1,"BCLK not 3.125MHz");
  last_bc=cycles;bc=bc+1;
  if(lrck!=prev_lr)begin
   if(lrck)begin
    if(frames>0 && cycles-last_frame!=1024)$fatal(1,"Fs changed");
    last_frame=cycles;frames=frames+1;
   end
   prev_lr=lrck;slot=lrck;bitn=0;received=0;
  end else begin
   if(bitn<16)begin
    if(bitn==0)expected=dut.audio_enabled ? dut.u_board.pcm_frame : 16'd0;
    received={received[14:0],dac};bitn=bitn+1;
    if(bitn==16)begin
     if(received!==expected)$fatal(1,"I2S %s sample mismatch got=%h expected=%h",slot?"right":"left",received,expected);
     if(!slot && received!=0)begin
      nonzero=nonzero+1;
      if(press_cycle>0 && first_latency==0)first_latency=cycles-press_cycle;
     end
    end
   end else if(dac!==0)$fatal(1,"I2S padding nonzero");
  end
 end
 integer before_nonzero;
 integer starts0=0,starts1=0,starts2=0,starts3=0,mode_changes=0;
 always @(posedge clk) if(dut.u_board.core_rst_n)begin
  if(dut.u_board.u_core.G_VOICE[0].u_voice.start_note)starts0=starts0+1;
  if(dut.u_board.u_core.G_VOICE[1].u_voice.start_note)starts1=starts1+1;
  if(dut.u_board.u_core.G_VOICE[2].u_voice.start_note)starts2=starts2+1;
  if(dut.u_board.u_core.G_VOICE[3].u_voice.start_note)starts3=starts3+1;
  if(dut.u_board.u_core.mode_transition)mode_changes=mode_changes+1;
 end
 task check_active;
 begin
  if(dut.u_board.u_core.v_gate!==4'b1111 || !dut.audio_enabled || !dut.codec_ready || mode_changes!=0)
   $fatal(1,"voices/codec/mode changed gates=%b ready=%b enabled=%b transitions=%0d",dut.u_board.u_core.v_gate,dut.codec_ready,dut.audio_enabled,mode_changes);
  if(nonzero-before_nonzero<40)$fatal(1,"left-channel audio stopped count=%0d",nonzero-before_nonzero);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;
  wait(dut.codec_ready);wait(dut.audio_enabled);
  keys[0]=0;repeat(60000)@(negedge clk);
  keys[1]=0;repeat(60000)@(negedge clk);
  keys[2]=0;repeat(60000)@(negedge clk);
  keys[3]=0;before_nonzero=nonzero;repeat(300000)@(negedge clk);
  check_active;
  if(starts0!=1 || starts1!=1 || starts2!=1 || starts3!=1)$fatal(1,"unexpected held4 retriggers");
  $display("held4: starts=%0d/%0d/%0d/%0d, left PCM words=%0d, volume=%0d",starts0,starts1,starts2,starts3,nonzero-before_nonzero,dut.u_board.u_core.vol);
  keys[4]=0;before_nonzero=nonzero;repeat(300000)@(negedge clk);
  check_active;
  if(starts0!=2 || starts1!=1 || starts2!=1 || starts3!=1)$fatal(1,"fifth did not replace exactly one voice");
  if(dut.u_board.u_core.legacy_note[0]!=5)$fatal(1,"fifth note not assigned");
  $display("held5: starts=%0d/%0d/%0d/%0d, left PCM words=%0d, volume=%0d",starts0,starts1,starts2,starts3,nonzero-before_nonzero,dut.u_board.u_core.vol);
  before_nonzero=nonzero;repeat(300000)@(negedge clk);check_active;
  if(starts0!=2 || starts1!=1 || starts2!=1 || starts3!=1)$fatal(1,"held5 unexpectedly retriggered");
  $display("PASS: complete WM8960 top, real1ms physical debounce, four held plus fifth, stable mode/gates, one voice stolen, decoded left I2S continuous; no forced internal audio");
  $finish;
 end
 initial begin #60000000;$fatal(1,"WM board test timeout");end
endmodule
