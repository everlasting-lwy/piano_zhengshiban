`timescale 1ns/1ps
module tb_sd_spi_block_16g;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,reinit=0,start=0,write=0;reg [31:0] lba=0;
wire initialized,busy,done,rd_valid,wr_request,cs_n,sclk,mosi;
wire[31:0]card_sectors;wire[7:0]error,rd_data;wire[8:0]rd_index,wr_index;
reg wr_valid=0;reg[7:0]wr_data=0;
reg[1:0]kind=0;reg absent=0,bad_crc=0,reject_write=0,stuck_busy=0,no_token=0,bad_r7=0,bad_ocr=0,bad_csd=0,init_stuck=0,status_error=0;
reg[2:0]csd_variant=0;
wire miso;reg unknown_miso=0;wire dut_miso=unknown_miso?1'bx:miso;
sd_spi_block #(.INIT_DIV(2),.DATA_DIV(1),.POWERUP_CYCLES(8),.INIT_TIMEOUT_CYCLES(100000),
 .R1_TIMEOUT_BYTES(12),.TOKEN_TIMEOUT_BYTES(32),.BUSY_TIMEOUT_BYTES(32),.SOURCE_TIMEOUT_CYCLES(300))dut(.*,.miso(dut_miso));
sd_spi_card_model card(.cs_n(cs_n),.sclk(sclk),.mosi(mosi),.kind(kind),.csd_variant(csd_variant),.absent(absent),
 .bad_crc(bad_crc),.reject_write(reject_write),.stuck_busy(stuck_busy),.no_token(no_token),
 .bad_r7(bad_r7),.bad_ocr(bad_ocr),.bad_csd(bad_csd),.init_stuck(init_stuck),.status_error(status_error),.miso(miso));
time rose;
always @(posedge sclk)rose=$time;
always @(negedge sclk)if(rst_n && $time>100 && $time-rose<20)$fatal(1,"truncated SCLK high pulse");
integer received=0,stall=0,latency=0;reg source_enable=1,expect_written=0;
always @(posedge clk)begin
 wr_valid<=0;
 if(wr_request && source_enable)begin
  if(stall==(wr_index%7))begin wr_valid<=1;wr_data<=wr_index^8'ha6;end
  else stall<=stall+1;
  if(wr_valid)begin wr_valid<=0;stall<=0;end
 end else stall<=0;
 if(rd_valid)begin
  if(rd_index!==received[8:0])$fatal(1,"read index %0d expected %0d",rd_index,received);
  if(rd_data!==(received[7:0]^(expect_written?8'ha6:8'h5a)))$fatal(1,"read content %0d %h",received,rd_data);
  received=received+1;
 end
end
task reset_card;input[1:0]k;begin
 @(negedge clk);rst_n=0;kind=k;absent=0;unknown_miso=0;bad_crc=0;reject_write=0;stuck_busy=0;no_token=0;bad_r7=0;bad_ocr=0;bad_csd=0;init_stuck=0;source_enable=1;
 csd_variant=0;
 repeat(3)@(negedge clk);rst_n=1;
end endtask
task wait_done;input integer max_cycles;integer t;begin
 t=0;while(!done && t<max_cycles)begin @(negedge clk);t=t+1;end
 if(!done)$fatal(1,"done timeout state=%0d",dut.state);
end endtask
task init_ok;input[1:0]k;begin
 reset_card(k);wait_done(150000);
 if(!initialized || error!=0 || card_sectors!==(k==0?32'd1048576:32'd2097152))$fatal(1,"init kind=%0d err=%h sectors=%d",k,error,card_sectors);
 if(busy)$fatal(1,"busy after init");
end endtask
task operation;input w;input[31:0]a;begin
 @(negedge clk);received=0;lba=a;write=w;start=1;
 @(negedge clk);start=0;wait_done(100000);
end endtask
task expect_error;begin if(error==0)$fatal(1,"unexpected success");if(busy||!cs_n||sclk)$fatal(1,"unclean failure pins");end endtask
integer k;
initial begin
 for(k=0;k<3;k=k+1)begin
  init_ok(k);expect_written=0;
  // Restore known independent sector pattern before each card variant.
  for(latency=0;latency<512;latency=latency+1)card.memory[latency]=latency^8'h5a;
  operation(0,7);if(error||received!=512)$fatal(1,"read failed");
  if(card.last_address!==(k==0?32'd7:32'd3584))$fatal(1,"read addressing");
  operation(1,9);if(error)$fatal(1,"write failed %h",error);
  if(card.last_address!==(k==0?32'd9:32'd4608))$fatal(1,"write addressing");
  for(latency=0;latency<512;latency=latency+1)if(card.memory[latency]!==(latency[7:0]^8'ha6))$fatal(1,"write data %0d",latency);
  expect_written=1;operation(0,9);if(error||received!=512)$fatal(1,"read-back failed");
 end
 init_ok(0);bad_crc=1;operation(0,0);expect_error;bad_crc=0;
 reject_write=1;operation(1,0);expect_error;reject_write=0;
 status_error=1;operation(1,0);expect_error;status_error=0;
 stuck_busy=1;operation(1,0);expect_error;stuck_busy=0;
 no_token=1;operation(0,0);expect_error;no_token=0;
 source_enable=0;operation(1,0);expect_error;source_enable=1;
 // A timed-out source must not poison the next write's source timer.
 operation(1,1);if(error)$fatal(1,"write after source timeout %h",error);
 absent=1;operation(0,0);expect_error;absent=0;
 operation(0,card_sectors);expect_error;
 @(negedge clk);reinit=1;@(negedge clk);reinit=0;wait_done(150000);if(!initialized||error)$fatal(1,"reinit");
 reset_card(0);unknown_miso=1;wait_done(150000);expect_error;if(initialized)$fatal(1,"unknown MISO initialized");
 reset_card(0);absent=1;wait_done(150000);expect_error;if(initialized)$fatal(1,"absent initialized");
 reset_card(0);bad_r7=1;wait_done(150000);expect_error;if(error!=4)$fatal(1,"R7 mismatch error namespace");
 reset_card(0);bad_ocr=1;wait_done(150000);expect_error;
 reset_card(0);bad_csd=1;wait_done(150000);expect_error;
 reset_card(0);csd_variant=1;wait_done(150000);expect_error;if(error!=6)$fatal(1,"2 TiB overflow accepted");
 reset_card(0);csd_variant=2;wait_done(150000);if(error || card_sectors!==32'hfffffc00)$fatal(1,"large HC capacity");
 operation(0,32'hfffffbff);if(error || card.last_address!==32'hfffffbff)$fatal(1,"high HC address");
 reset_card(0);csd_variant=6;wait_done(150000);
 if(error || card_sectors!==32'd33554432)$fatal(1,"16 GiB SDHC capacity");
 operation(0,32'd33554431);if(error || card.last_address!==32'd33554431)$fatal(1,"16 GiB block addressing");
 $display("PASS: 16 GiB SDHC CSDv2 initialization/capacity/last-LBA addressing; R7 mismatch is error4");
 reset_card(1);csd_variant=3;wait_done(150000);if(error || card_sectors!==32'd4194304)$fatal(1,"SDSC read length 1024");
 reset_card(2);csd_variant=4;wait_done(150000);if(error || card_sectors!==32'd8388608)$fatal(1,"SDSC read length 2048");
 operation(0,32'd8388607);if(error || card.last_address!==32'hfffffe00)$fatal(1,"high SDSC address");
 reset_card(2);csd_variant=5;wait_done(150000);expect_error;
 reset_card(0);init_stuck=1;wait_done(150000);expect_error;if(error!=1)$fatal(1,"init deadline err=%h",error);
 init_ok(0);expect_written=1;
 @(negedge clk);start=1;write=0;lba=0;@(negedge clk);start=0;
 wait(!cs_n && sclk);#1;reinit=1;@(negedge clk);reinit=0;
 wait_done(150000);if(error || !initialized)$fatal(1,"mid-byte reinit");
 if(card.errors)$fatal(1,"card protocol errors %0d",card.errors);
 $display("PASS sd_spi_block: HC/v2SC/v1SC initialization, CRC/addressed read-write with source stalls, error and reinit paths");$finish;
end
initial begin #30000000;$fatal(1,"global timeout");end
endmodule
