"""Independent floating-reference vectors for32 actual256-point DFT bins."""
from pathlib import Path
import math, subprocess, sys, json
r=Path(__file__).resolve().parents[1];p=r/"tmp/spectrum";p.mkdir(exist_ok=True)
frames=[]
for kind in ("silence","dc","negative","bin3","bin17","chord","offbin"):
    f=[]
    for n in range(256):
        v={"silence":0,"dc":4000,"negative":-32768,
           "bin3":round(12000*math.cos(2*math.pi*3*n/256)),
           "bin17":round(9000*math.sin(2*math.pi*17*n/256)),
           "chord":round(7000*math.sin(2*math.pi*4*n/256)+4000*math.sin(2*math.pi*11*n/256)),
           "offbin":round(8000*math.sin(2*math.pi*3.4*n/256))}[kind]
        f.append(v)
    frames.append((kind,f))
with (p/"vectors.txt").open("w") as out:
    for kind,f in frames:
        for v in f:out.write(f"{v}\n")
        for k in range(32):
            re=sum(v*math.cos(2*math.pi*k*n/256) for n,v in enumerate(f))/256
            im=-sum(v*math.sin(2*math.pi*k*n/256) for n,v in enumerate(f))/256
            out.write(f"{min(65535,round(abs(re)+abs(im)))}\n")
(p/"reference.json").write_text(json.dumps({"frames":[k for k,f in frames],"window":"rectangular","N":256,"binHz":48828.125/256},indent=2))
subprocess.run([sys.executable,"sim/run_one.py","tb_spectrum32","src/core/spectrum32.v"],cwd=r,check=True)
