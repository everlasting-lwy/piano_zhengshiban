`timescale 1ns/1ps
// A same-note release tail must be reused even when another voice is empty.
// Checks every voice position and low/high note IDs in both allocator sizes.
module allocator_retrigger_case #(
    parameter KEY_COUNT=18,
    parameter NOTE_WIDTH=5
)(output reg done=0);
    reg clk=0;always #10 clk=~clk;
    reg rst_n=0;
    reg [KEY_COUNT-1:0] keys=0;
    reg [3:0] busy=0;
    wire [NOTE_WIDTH-1:0] notes[0:3];
    wire [3:0] gate;
    voice_allocator #(.KEY_COUNT(KEY_COUNT),.NOTE_WIDTH(NOTE_WIDTH)) dut(
        .sys_clk(clk),.sys_rst_n(rst_n),.keys(keys),.busy(busy),
        .n0(notes[0]),.n1(notes[1]),.n2(notes[2]),.n3(notes[3]),.gate(gate));
    task clocks;input integer n;begin repeat(n)@(negedge clk);end endtask
    function integer key_index;input integer slot;begin
        case(slot)
            0:key_index=0;
            1:key_index=KEY_COUNT/2;
            2:key_index=KEY_COUNT-2;
            default:key_index=KEY_COUNT-1;
        endcase
    end endfunction
    integer target,voice;
    reg [KEY_COUNT-1:0] chord,target_key;
    initial begin
        chord=0;
        for(voice=0;voice<4;voice=voice+1)chord[key_index(voice)]=1;
        for(target=0;target<4;target=target+1)begin
            rst_n=0;keys=0;busy=0;clocks(4);rst_n=1;clocks(4);
            keys=chord;busy=4'hf;clocks(16);
            if(gate!==4'hf)$fatal(1,"%0d-key chord setup failed",KEY_COUNT);
            for(voice=0;voice<4;voice=voice+1)
                if(notes[voice]!==key_index(voice)+1)$fatal(1,"Chord note mapping failed");
            target_key=0;target_key[key_index(target)]=1;
            keys=target_key;busy=4'b0001<<target;clocks(16);
            keys=0;clocks(16);
            if(gate!==0 || notes[target]!==key_index(target)+1)
                $fatal(1,"Release tail setup failed");
            keys=target_key;clocks(16);
            if(gate!==(4'b0001<<target))
                $fatal(1,"%0d-key same-note tail in slot%0d lost priority to empty voice: gates=%b",KEY_COUNT,target,gate);
            for(voice=0;voice<4;voice=voice+1)begin
                if(voice==target)begin
                    if(notes[voice]!==key_index(target)+1)$fatal(1,"Retrigger changed pitch");
                end else if(notes[voice]!==0)$fatal(1,"Retrigger left duplicate voice");
            end
            keys=0;busy=0;clocks(16);
            if(gate!==0 || notes[0]!==0 || notes[1]!==0 || notes[2]!==0 || notes[3]!==0)
                $fatal(1,"Released voices were not reclaimed");
        end
        done=1;
    end
endmodule

module tb_allocator_retrigger;
    wire done18,done48;
    allocator_retrigger_case #(.KEY_COUNT(18),.NOTE_WIDTH(5)) legacy(done18);
    allocator_retrigger_case #(.KEY_COUNT(48),.NOTE_WIDTH(6)) extended_keys(done48);
    initial begin
        wait(done18 && done48);
        $display("PASS: same-note tail retrigger in all4 slots,18/48-key low/high IDs, no duplicate voices and final reclaim");
        $finish;
    end
    initial begin #1000000;$fatal(1,"Allocator retrigger timeout");end
endmodule
