onerror {quit -code 1 -f}
onbreak {quit -code 1 -f}
if {![file exists sim/work]} {vlib sim/work}
vmap work sim/work
vlog -sv src/seg595_bridge.v sim/tb_seg595_bridge.v
vsim -c -novopt work.tb_seg595_bridge
run -all
quit -code 0 -f
