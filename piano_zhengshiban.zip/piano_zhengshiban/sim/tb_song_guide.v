`timescale 1ns/1ps
module tb_song_guide;
    reg clk=0; always #10 clk=~clk;
    reg rst_n=0,request_valid=0,local_toggle=0,local_restart=0;
    reg [7:0] request_command=0;
    reg [47:0] request_payload=0;
    reg [17:0] physical_keys=0;
    wire response_valid,active,loaded,loading,complete,wrong;
    wire [7:0] response_command;
    wire [47:0] response_payload;
    wire [17:0] target;
    wire [11:0] step,total_steps;
    song_guide dut(.*);
    task clocks; input integer n; begin repeat(n) @(negedge clk); end endtask
    function [15:0] crcbyte;
        input [15:0] prior;input [7:0] b;integer j;reg [15:0] c;
        begin c=prior^{b,8'h00};for(j=0;j<8;j=j+1)c=c[15]?(c<<1)^16'h1021:c<<1;crcbyte=c;end
    endfunction
    function [15:0] crcmask;
        input [15:0] prior; input [17:0] m;
        begin crcmask=crcbyte(crcbyte(crcbyte(prior,m[7:0]),m[15:8]),{6'd0,m[17:16]}); end
    endfunction
    task req;
        input [7:0] op;input [47:0] p;input [7:0] response_op;input [7:0] code;
        integer timeout;
        begin
            request_command=op;request_payload=p;request_valid=1;clocks(1);request_valid=0;
            timeout=0;while(!response_valid && timeout<8)begin clocks(1);timeout=timeout+1;end
            if(!response_valid)$fatal(1,"Guide response exceeded eight cycles op=%h",op);
            if(response_command!==response_op)$fatal(1,"Guide response op=%h expected=%h actual=%h",op,response_op,response_command);
            if(response_op==8'h80 && response_payload!=={24'd0,8'd1,code,op})
                $fatal(1,"Guide ACK op=%h expected code=%h payload=%h",op,code,response_payload);
            clocks(4);
            if(response_valid)$fatal(1,"Guide response was not a pulse");
        end
    endtask
    task begin_song; input [15:0] count,crc;begin req(8'h10,{8'd0,8'd1,crc,count},8'h80,0);end endtask
    task put;input [15:0] index;input [17:0] mask;begin req(8'h11,{8'd0,6'd0,mask,index},8'h80,0);end endtask
    task action; input [7:0] a;begin req(8'h13,{40'd0,a},8'h80,0);end endtask
    task keys;input [17:0] m;begin physical_keys=m;clocks(6);end endtask
    reg [15:0] crc;
    reg [17:0] masks[0:17];
    reg [17:0] expected_target;
    // An OLED frame latch can sample any clock, including a RAM read pipeline
    // cycle. Every published step must describe the target in that same cycle.
    always @(posedge clk)begin
        #1;
        if(rst_n && loaded)begin
            expected_target=0;
            if(!complete)begin
                case(total_steps)
                    3:case(step)
                        0:expected_target=18'h1;
                        1:expected_target=18'h3081;
                        2:expected_target=18'h20000;
                        default:$fatal(1,"Coherent guide step exceeded three-step song");
                    endcase
                    18:expected_target=18'd1<<step;
                    2048:expected_target=(step==2047)?18'h20000:18'h1;
                    default:$fatal(1,"Unexpected song in coherence monitor total=%0d",total_steps);
                endcase
                if(step>=total_steps)$fatal(1,"Incomplete guide published end step");
            end else if(step!==total_steps)$fatal(1,"DONE step and total differ");
            if(target!==expected_target)
                $fatal(1,"Guide frame coherence: step=%0d total=%0d target=%h expected=%h complete=%b",step,total_steps,target,expected_target,complete);
        end
    end
    integer i;
    initial begin
        clocks(4);rst_n=1;clocks(4);
        if(loaded || active || loading || target!==0)$fatal(1,"Reset state");
        crc=16'hffff;for(i=0;i<9;i=i+1)crc=crcbyte(crc,8'h31+i);
        if(crc!==16'h29b1)$fatal(1,"Test CRC literal is not CCITT-FALSE");
        req(8'h0f,0,8'h88,0);
        if(response_payload!==48'h041208000147)$fatal(1,"Guide capability layout %h",response_payload);
        local_toggle=1;clocks(1);local_toggle=0;clocks(3);
        if(!active || loaded)$fatal(1,"Empty local GUIDE entry");
        local_toggle=1;clocks(1);local_toggle=0;clocks(3);
        if(active)$fatal(1,"Empty local GUIDE exit");
        action(1);if(!active || loaded)$fatal(1,"Empty Bluetooth GUIDE entry");action(0);
        // Invalid uploads must leave all loaded state untouched.
        req(8'h10,{8'd0,8'd1,16'd0,16'd0},8'h80,1);
        req(8'h10,{8'd0,8'd1,16'd0,16'd2049},8'h80,1);
        req(8'h10,{8'd0,8'd2,16'd0,16'd1},8'h80,1);
        req(8'h11,{8'd0,24'd1,16'd0},8'h80,3);
        req(8'h12,0,8'h80,3);
        crc=crcmask(crcmask(crcmask(16'hffff,18'h00001),18'h03081),18'h20000);
        begin_song(3,crc);put(0,1);
        // Lost ACK retries cannot clear accepted steps or update CRC twice.
        begin_song(3,crc);put(0,1);
        req(8'h11,{8'd0,24'd2,16'd0},8'h80,3);
        req(8'h11,{8'd0,24'd2,16'd2},8'h80,3);
        req(8'h11,{8'd0,24'd0,16'd1},8'h80,1);
        req(8'h11,{8'd0,24'h040000,16'd1},8'h80,1);
        req(8'h11,{8'd0,24'h00001f,16'd1},8'h80,1);
        req(8'h11,{8'd1,24'd2,16'd1},8'h80,1);
        req(8'h12,0,8'h80,3);
        put(1,18'h03081);put(2,18'h20000);req(8'h12,0,8'h80,0);req(8'h12,0,8'h80,0);
        if(!loaded || loading || total_steps!==3 || target!==1)$fatal(1,"Initial song commit");
        // Partial and CRC-failed alternate-bank writes preserve the old song.
        begin_song(2,16'h1234);put(0,18'h2);action(4);
        if(!loaded || loading || target!==1 || total_steps!==3)$fatal(1,"ABORT damaged active bank");
        begin_song(1,16'h0000);put(0,18'h2);req(8'h12,0,8'h80,1);
        if(!loaded || loading || target!==1 || total_steps!==3)$fatal(1,"Bad CRC damaged active bank");
        // A preheld target cannot hit. Chords may be built one finger at a time.
        keys(1);action(1);if(step!==0)$fatal(1,"Preheld entry advanced");
        clocks(30);if(step!==0)$fatal(1,"Preheld target repeated");
        keys(0);keys(1);if(step!==1 || target!==18'h03081)$fatal(1,"Next target not displayed while old key held");
        keys(18'h03081);if(step!==1)$fatal(1,"No full release between targets");
        keys(0);keys(18'h80);if(step!==1 || wrong)$fatal(1,"Partial chord rejected");
        keys(18'h81);keys(18'h1081);keys(18'h3081);
        if(step!==2 || target!==18'h20000)$fatal(1,"Four-note staggered chord did not advance");
        keys(0);keys(18'h1);if(!wrong || step!==2)$fatal(1,"Wrong key not latched");
        keys(18'h20000);if(!wrong || step!==2)$fatal(1,"Wrong-key lockout bypassed");
        keys(0);if(wrong)$fatal(1,"Wrong flag did not clear on release");
        keys(18'h20000);if(!complete || step!==3 || target!==0 || !active)$fatal(1,"Completion state");
        req(8'h14,0,8'h89,0);if(response_payload!==48'h010700030003)$fatal(1,"Complete status payload %h",response_payload);
        req(8'h15,0,8'h8a,0);if(response_payload!==48'h020000000000)$fatal(1,"Physical/target layout %h",response_payload);
        local_restart=1;clocks(1);local_restart=0;clocks(5);
        if(complete || step!==0 || target!==1)$fatal(1,"Local restart");
        // Re-entry must publish the first target together with reset step zero.
        keys(0);keys(1);if(step!==1)$fatal(1,"Re-entry setup did not advance");
        local_toggle=1;clocks(1);local_toggle=0;clocks(2);
        local_toggle=1;clocks(1);local_toggle=0;clocks(3);
        if(!active || step!==0 || target!==1)$fatal(1,"Local re-entry coherent restart");
        action(0);action(2);if(active || step!==0)$fatal(1,"Restart unexpectedly entered view");
        // Exercise all eighteen physical port bits without pitch-order remapping.
        crc=16'hffff;for(i=0;i<18;i=i+1)begin masks[i]=18'd1<<i;crc=crcmask(crc,masks[i]);end
        begin_song(18,crc);for(i=0;i<18;i=i+1)put(i,masks[i]);req(8'h12,0,8'h80,0);
        keys(0);action(1);
        for(i=0;i<18;i=i+1)begin
            if(target!==masks[i] || step!==i)$fatal(1,"Physical bit order %0d target=%h",i,target);
            keys(masks[i]);keys(0);
        end
        if(!complete || step!==18)$fatal(1,"All physical keys did not complete");
        // Full capacity uses the twelfth count bit; the last valid address is 2047.
        crc=16'hffff;for(i=0;i<2048;i=i+1)crc=crcmask(crc,(i==2047)?18'h20000:18'h1);
        begin_song(2048,crc);
        for(i=0;i<2048;i=i+1)put(i,(i==2047)?18'h20000:18'h1);
        req(8'h12,0,8'h80,0);
        if(total_steps!==2048 || target!==1 || step!==0 || !active)$fatal(1,"Capacity commit");
        for(i=0;i<2048;i=i+1)begin keys(0);keys((i==2047)?18'h20000:18'h1);end
        if(!complete || step!==2048)$fatal(1,"Capacity last step");
        begin_song(1,16'hffff);action(3);action(3);
        if(loaded || loading || !active || complete || target!==0 || total_steps!==0)$fatal(1,"DELETE state/idempotence");
        req(8'h14,0,8'h89,0);if(response_payload!==48'h010200000000)$fatal(1,"Deleted status layout");
        req(8'h0f,1,8'h80,1);req(8'h12,1,8'h80,1);req(8'h13,48'h100,8'h80,1);
        req(8'h13,5,8'h80,1);req(8'h14,1,8'h80,1);req(8'h15,1,8'h80,1);req(8'hff,0,8'h80,2);
        rst_n=0;clocks(2);rst_n=1;clocks(4);
        if(loaded || active || loading || target!==0)$fatal(1,"Reset did not invalidate song");
        $display("PASS: song guide doublebank CRC/retries/abort/delete, bounds/full 2048, all 18 bits, four-note chords, release/wrong lockout, DONE/restart/status");$finish;
    end
    initial begin #10000000;$fatal(1,"Song guide timeout");end
endmodule
