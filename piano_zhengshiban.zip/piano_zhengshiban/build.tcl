# Default: visual OLED is identical to the working P9 SSD1306 OLED.
# Run from any directory: gw_sh <absolute-path-to-this-file>
cd [file dirname [file normalize [info script]]]
open_project piano.gprj
set_option -top_module top_piano_wm8960_acg525_ssd1306
set_option -output_base_name piano1101_sd_ssd1306
set_option -include_path {src/core}
set_option -verilog_std v2001
set_option -global_freq 50
set_option -gen_text_timing_rpt 1
set_option -timing_driven 1
set_option -place_option 1
set_option -route_option 0
set_option -cst_warn_to_error 1
# Match the factory OLED project's device.cfg: R3/T3 share CPU/SSPI pins.
set_option -use_cpu_as_gpio 1
set_option -use_sspi_as_gpio 1
set_option -use_i2c_as_gpio 1
run all
