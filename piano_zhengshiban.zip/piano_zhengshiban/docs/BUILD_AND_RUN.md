# 构建与运行

## FPGA

目标为GW5A-LV25UG324C2/I1、A版本、50MHz。使用Gowin V1.9.11.03 Education或兼容版本，在当前目录执行：

```powershell
& '../../IDE/bin/gw_sh.exe' './build.tcl'
```

以上是当前电脑安装布局的相对路径；复制到其他电脑时把gw_sh.exe换为当地Gowin安装路径。脚本会进入自身目录，配置正确顶层、include目录和CPU/SSPI/I2C复用GPIO，再执行综合布局布线。首次在GUI编译前也须核对这些选项，不能依赖旧工程的GUI缓存。本目录不带旧.gprj.user窗口/流程状态或绝对路径综合中间工程。

下载现成固件无需编译：选择impl/pnr/piano1101_sd_ssd1306.fs。先SRAM测试，稳定后按实际配置Flash执行写入和校验，再断电验证自启。此整理过程没有重新综合，也没有下载开发板。

## Android

直接安装mobile/android/dist/PianoLink-piano1101-SD-v2.3.apk。源代码、test/stubs、模型资源、许可证、示例及构建脚本均保留，debug.keystore不上传。新生成的签名密钥与已发布APK不同，无法直接覆盖原签名版本；需使用本机保留的原密钥构建，或先备份应用数据再处理安装。需要JDK17、Android API35平台和构建工具，以及LiteRT1.4.2音频依赖；SDK和第三方运行库缓存不属于此次整理包。

可在mobile/android执行bootstrap-sdk.ps1和bootstrap-audio.ps1准备本地依赖，再执行build.ps1。首次依赖准备需要网络和足够磁盘；也可给build.ps1传入-Sdk、-AudioCache、-Jdk三个实际目录。不要依赖旧piano目录的回退缓存；单独带走此目录时，应显式准备或指定这些依赖。

APK仍是现有2.3，不是删除SD写入入口后重新发布的版本。演示只用联弹、音效、曲库、转谱、下落练习、RAM引导及SD查询/载入。

## Windows MIDI和蓝牙测试

tools/start_piano_monitor.cmd启动当前可视化程序；tools/start_fpga_speakers.cmd启动串口到电脑音源桥接。使用模式2，串口115200、8N2。tools/desktop包含对应C#源码和build.ps1；tools/bluetooth_test包含电脑SPP模拟接收器源码及构建/测试脚本，不携带上次生成的测试EXE。

## HDL测试

需要Python3和Icarus Verilog，执行：

```powershell
python sim/run_tests.py --bin 'C:/实际Icarus目录/bin' --timeout 7200
```

源码测试和模型保留；.vvp、.pyc、波形与旧日志不作为源码复制。程序会在新目录创建所需临时文件。长时间总线/音频测试可能耗时较长。此包的evidence为既有构建证据，不表示本次重跑了全部测试。

## SD只读曲谱

卡为FAT32、512字节逻辑扇区。把tools/sd_test_songs/P0000000.P18和P0000001.P18用读卡器复制到根目录，安全弹出后断电装卡。长按图形编码器进入GUIDE，松开实体键后旋转选曲，短按重来、长按退出。自定义CSV用tools/p18_tool.py的from-csv转换、validate校验后再拷卡，文件名范围P0000000.P18至P0000031.P18。详见测试报告第六节。
